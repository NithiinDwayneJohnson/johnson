/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.io.*;
import java.util.*;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The global vision resources.
 */
/*======================================================================*/
public class Resources extends ListResourceBundle
{
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
         { "messagenotfound"  , "The requested message is not found. Check the resource file. Message code is:"  },
	 { "yes"              , "Yes"},
	 { "no"               , "No"},
	 { "new"              , "New"}
    };
}
