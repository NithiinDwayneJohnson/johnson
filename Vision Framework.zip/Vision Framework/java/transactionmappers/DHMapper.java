/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*    ==============================================================    */
/*                                                                      */
/* MODULE:          DHMapper.java                                       */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import COM.novusnet.vision.java.commonbos.DapError;
import COM.novusnet.vision.java.commonbos.Mapper;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
/**
 * <p><b>DESCRIPTION:</b>
 *       The abstract base class for concrete mapper classes that
 *       reference RDH-based (i.e. Backward Services) DAS transactions.
 * <p><b>PURPOSE:</b>
 *       To provide the mapError method.
 * <p><b>REMARKS:</B>
 *       <ol>
 *           <li>
 *               The definition of this base class leaves the concrete
 *               subclasses as simply a set of static data that is
 *               specific to any given DAS transaction (as defined in the
 *               TDT), thus making them easily generatable.
 *           </li>
 *       </ol>
 */
public  abstract  class  DHMapper  extends  Mapper {

    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Attributes  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/
        /*==============================================================*/
        /* Class attributes                                             */
        /*==============================================================*/

        /*==============================================================*/
        /* Protected Attributes                                         */
        /*==============================================================*/

        /*==============================================================*/
        /* Private attributes                                           */
        /*==============================================================*/


    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Operations  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Class  Operations                                                */
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  mapError                                        */
        /**
         * This method maps a mainframe (RDH-style) error code to its
         * appropriate exception.
         *
         * @param       aMajorCode:int
         *                 the major error code to be mapped.
         * @param       aMinorCode:int
         *                 the minor error code to be returned in exception.
         * @param       aErrorText:String
         *                 the error text to be returned in exception.
         * @return      :Exception
         *                 the exception that corresponds to the error
         *                 code.
         */
        /*==============================================================*/
   public  Exception  mapError (
                                int    aMajorCode,
                                int    aMinorCode,
                                String aErrorText
                               )
   {
      DapError error = new DapError(aMajorCode, aMinorCode, aErrorText);
      setDapError(error);

      switch (aMajorCode) {
         case 5:
// 	    System.out.println ("received an error (major code = 5), returning null.  DHMapper.mapError()");
            return (null);

         case 8999:
// 	    System.out.println ("received an error (major code = 8999), returning null.  DHMapper.mapError()");
            return (null);

         default:
            return super.mapError(aMajorCode, aMinorCode, aErrorText);
      }
   }

    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/


    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Unit Test   ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  main                                            */
        /**
         * This method represents the unit test entry point for this
         * class.
         *
         * @param       aArgs:String[]
         *                 the command line arguments. [Unused].
         * @return      :void
         */
        /*==============================================================*/
   public  static  void  main (
                               String args[]
                              )
   {
   }
}
