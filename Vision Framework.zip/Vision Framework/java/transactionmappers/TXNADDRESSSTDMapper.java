/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
// CLASS:       TXNADDRESSSTD0Mapper
/*======================================================================*/

/*======================================================================*/
/*                         Package Statement                            */
/*======================================================================*/
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import COM.novusnet.vision.java.commonbos.Mapper;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
public   class   TXNADDRESSSTDMapper  extends  DHMapper {

        /*==============================================================*/
        /* Object Constructor                                           */
        /*==============================================================*/
   public    TXNADDRESSSTDMapper ()
   {
      setTransactionId        ("TXNADDRESSSTD0");

      setKeyBufferLength      (177);
      setNumberOfKeyFields    (18);
      setKeyNameArray         (s_KeyNameArray);
      setKeyLengthArray       (s_KeyLengthArray);
      setKeyTypeArray         (s_KeyTypeArray);
      setKeyOffsetArray       (s_KeyOffsetArray);

      setRecordBufferLength   (177);
      setNumberOfRecordFields (18);
      setRecordNameArray      (s_RecordNameArray);
      setRecordLengthArray    (s_RecordLengthArray);
      setRecordTypeArray      (s_RecordTypeArray);
      setRecordOffsetArray    (s_RecordOffsetArray);
   }

        /*==============================================================*/
        /* Object Constructor                                           */
        /* Attributes (key / record buffer field arrays)                */
        /*==============================================================*/
   static  final   String []  s_KeyNameArray        =
                           {
                              "ADDR1",
                              "ADDR2",
                              "BARCK",
                              "BARWS",
                              "CITY",
                              "CNTRY",
                              "DHFLG",
                              "FERR1",
                              "FERR2",
                              "FERR3",
                              "FERR4",
                              "FINFO",
                              "FRC1",
                              "FRSN",
                              "STMSC",
                              "STUS",
                              "ZIP4",
                              "ZIP5"
                           };
   static  final   int    []  s_KeyLengthArray      =
                           {
                              41,
                              41,
                              1,
                              3,
                              29,
                              6,
                              1,
                              5,
                              5,
                              5,
                              5,
                              9,
                              1,
                              8,
                              3,
                              3,
                              5,
                              6
                           };
   static  final   int    []  s_KeyTypeArray        =
                           {
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string
                           };
   static  final   int    []  s_KeyOffsetArray      =
                           {
                              0,
                              41,
                              82,
                              83,
                              86,
                              115,
                              121,
                              122,
                              127,
                              132,
                              137,
                              142,
                              151,
                              152,
                              160,
                              163,
                              166,
                              171
                           };
   static  final   String []  s_RecordNameArray     =
                           {
                              "ADDR1",
                              "ADDR2",
                              "BARCK",
                              "BARWS",
                              "CITY",
                              "CNTRY",
                              "DHFLG",
                              "FERR1",
                              "FERR2",
                              "FERR3",
                              "FERR4",
                              "FINFO",
                              "FRC1",
                              "FRSN",
                              "STMSC",
                              "STUS",
                              "ZIP4",
                              "ZIP5"
                           };
   static  final   int    []  s_RecordLengthArray   =
                           {
                              41,
                              41,
                              1,
                              3,
                              29,
                              6,
                              1,
                              5,
                              5,
                              5,
                              5,
                              9,
                              1,
                              8,
                              3,
                              3,
                              5,
                              6
                           };
   static  final   int    []  s_RecordTypeArray     =
                           {
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_char,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string
                           };
   static  final   int    []  s_RecordOffsetArray   =
                           {
                              0,
                              41,
                              82,
                              83,
                              86,
                              115,
                              121,
                              122,
                              127,
                              132,
                              137,
                              142,
                              151,
                              152,
                              160,
                              163,
                              166,
                              171
                           };
}
