/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      NCSPRIMERATEBROWSEMapper.java                           */
/*                                                                      */
/* Generator:   MapperGenerator    Version 0.1                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 November 10 at 14:37:14 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.commonbos.Mapper;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       NCSPRIMERATEBROWSEMapper                                */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  NCSPRIMERATEBROWSEMapper  extends  OracleMapper
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin NCSPRIMERATEBROWSEMapper:Attributes preserve=yes

//##End   NCSPRIMERATEBROWSEMapper:Attributes

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   static final String[] keyNameArray      = { "Search_Start_Date",
                                               "Search_End_Date"
                                             };
   static final int[]    keyLengthArray    = { 9,
                                               9
                                             };
   static final int[]    keyTypeArray      = { Mapper.type_string,
                                               Mapper.type_string
                                             };
   static final int[]    keyOffsetArray    = { 0,
                                               9
                                             };
   static final int[]    keyScaleArray     = { 0,
                                               0
                                             };
   static final String[] recordNameArray   = { "APR",
                                               "Eff_Date",
                                               "Search_Start_Date",
                                               "Search_End_Date"
                                             };
   static final int[]    recordLengthArray = { 4,
                                               9,
                                               9,
                                               9
                                             };
   static final int[]    recordTypeArray   = { Mapper.type_float,
                                               Mapper.type_string,
                                               Mapper.type_string,
                                               Mapper.type_string
                                             };
   static final int[]    recordOffsetArray = { 0,
                                               4,
                                               13,
                                               22
                                             };
   static final int[]    recordScaleArray  = { 2,
                                               0,
                                               0,
                                               0
                                             };

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  NCSPRIMERATEBROWSEMapper                         */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public    NCSPRIMERATEBROWSEMapper (
                                      )
   {
//##Begin NCSPRIMERATEBROWSEMapper:NCSPRIMERATEBROWSEMapper() preserve=no
      setTransactionId("NCSPRIMERATEBROWSE");
      setVersionNumber(0);
      setTimeoutValue(8000);
      setKeyBufferLength(18);
      setNumberOfKeyFields(2);
      setKeyNameArray(keyNameArray);
      setKeyLengthArray(keyLengthArray);
      setKeyTypeArray(keyTypeArray);
      setKeyOffsetArray(keyOffsetArray);
      setKeyScaleArray(keyScaleArray);
      setRecordBufferLength(31);
      setNumberOfRecordFields(4);
      setRecordNameArray(recordNameArray);
      setRecordLengthArray(recordLengthArray);
      setRecordTypeArray(recordTypeArray);
      setRecordOffsetArray(recordOffsetArray);
      setRecordScaleArray(recordScaleArray);
//##End   NCSPRIMERATEBROWSEMapper:NCSPRIMERATEBROWSEMapper()
   }


}
