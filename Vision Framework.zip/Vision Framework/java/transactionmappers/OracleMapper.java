/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*    ==============================================================    */
/*                                                                      */
/* CLASS:       OracleMapper                                            */

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import COM.novusnet.vision.java.commonbos.DapError;
import COM.novusnet.vision.java.commonbos.Mapper;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
/**
 * <P><B>DESCRIPTION:</B>
 *       The abstract base class for concrete mapper classes that
 *       reference Oracle-based DAS transactions.
 * <P><B>PURPOSE:</B>
 *       To provide the mapError method.
 * <P><B>REMARKS:</B>
 *       <ol>
 *           <li>
 *               The definition of this base class leaves the concrete
 *               subclasses as simply a set of static data that is
 *               specific to any given DAS transaction (as defined in the
 *               TDT), thus making them easily generatable.
 *           </li>
 *       </ol>
 * <P><B>REVISIONS:</B>
 */
public  abstract  class  OracleMapper  extends  Mapper {



    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Attributes  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/


    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Operations  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Class  Operations                                                */
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  mapError                                        */
        /**
         * This method maps an Oracle-style error code to its
         * appropriate exception.
         *
         * @param       aMajorCode:int
         *                 the major error code to be mapped.
         * @param       aMinorCode:int
         *                 the minor error code to be returned in exception.
         * @param       aErrorText:String
         *                 the error text to be returned in exception.
         * @return      :Exception
         *                 the exception that corresponds to the error
         *                 code.
         */
   public  Exception  mapError (
                                int    aMajorCode,
                                int    aMinorCode,
                                String aErrorText
                               )
   {
      DapError error = new DapError(aMajorCode, aMinorCode, aErrorText);
      setDapError(error);

      switch (aMajorCode) {
         case 1403:
            return (null);

         default:
            return super.mapError(aMajorCode, aMinorCode, aErrorText);
      }
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Unit Test   ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  main                                            */
        /**
         * This method represents the unit test entry point for this
         * class.
         *
         * @param       aArgs:String[]
         *                 the command line arguments. [Unused].
         * @return      :void
         */
   public  static  void  main (
                               String aArgs[]
                              )
   {
   }

}
