/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
// CLASS:       NCSCOUNTRY2Mapper
/*======================================================================*/

/*======================================================================*/
/*                         Package Statement                            */
/*======================================================================*/
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import COM.novusnet.vision.java.commonbos.Mapper;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
public   class   NCSCOUNTRYMapper  extends  OracleMapper {

        /*==============================================================*/
        /* Object Constructor                                           */
        /*==============================================================*/
   public    NCSCOUNTRYMapper ()
   {
      setTransactionId        ("NCSCOUNTRY2");

      setKeyBufferLength      (6);
      setNumberOfKeyFields    (1);
      setKeyNameArray         (s_KeyNameArray);
      setKeyLengthArray       (s_KeyLengthArray);
      setKeyTypeArray         (s_KeyTypeArray);
      setKeyOffsetArray       (s_KeyOffsetArray);

      setRecordBufferLength   (104);
      setNumberOfRecordFields (4);
      setRecordNameArray      (s_RecordNameArray);
      setRecordLengthArray    (s_RecordLengthArray);
      setRecordTypeArray      (s_RecordTypeArray);
      setRecordOffsetArray    (s_RecordOffsetArray);
   }

        /*==============================================================*/
        /* Object Constructor                                           */
        /* Attributes (key / record buffer field arrays)                */
        /*==============================================================*/
   static  final   String []  s_KeyNameArray        =
                           {
                              "Country_Code"
                           };
   static  final   int    []  s_KeyLengthArray      =
                           {
                              6
                           };
   static  final   int    []  s_KeyTypeArray        =
                           {
                              Mapper.type_string
                           };
   static  final   int    []  s_KeyOffsetArray      =
                           {
                              0
                           };
   static  final   String []  s_RecordNameArray     =
                           {
                              "Country_Code",
                              "Country_Name",
                              "Postal_Code_Template",
                              "Phone_Nbr_Template"
                           };
   static  final   int    []  s_RecordLengthArray   =
                           {
                              6,
                              46,
                              21,
                              31
                           };
   static  final   int    []  s_RecordTypeArray     =
                           {
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string
                           };
   static  final   int    []  s_RecordOffsetArray   =
                           {
                              0,
                              6,
                              52,
                              73
                           };
}
