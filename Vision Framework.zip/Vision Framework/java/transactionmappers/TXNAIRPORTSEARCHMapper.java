/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
// CLASS:       TXNAIRPORTSEARCH0Mapper
/*======================================================================*/

/*======================================================================*/
/*                         Package Statement                            */
/*======================================================================*/
        
package COM.novusnet.vision.java.transactionmappers;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import COM.novusnet.vision.java.commonbos.Mapper;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
public   class   TXNAIRPORTSEARCHMapper  extends  DHMapper {

        /*==============================================================*/
        /* Object Constructor                                           */
        /*==============================================================*/
   public    TXNAIRPORTSEARCHMapper ()
   {
      setTransactionId        ("TXNAIRPORTSEARCH0");

      setKeyBufferLength      (82);
      setNumberOfKeyFields    (5);
      setKeyNameArray         (s_KeyNameArray);
      setKeyLengthArray       (s_KeyLengthArray);
      setKeyTypeArray         (s_KeyTypeArray);
      setKeyOffsetArray       (s_KeyOffsetArray);

      setRecordBufferLength   (82);
      setNumberOfRecordFields (5);
      setRecordNameArray      (s_RecordNameArray);
      setRecordLengthArray    (s_RecordLengthArray);
      setRecordTypeArray      (s_RecordTypeArray);
      setRecordOffsetArray    (s_RecordOffsetArray);
   }

        /*==============================================================*/
        /* Object Constructor                                           */
        /* Attributes (key / record buffer field arrays)                */
        /*==============================================================*/
   static  final   String []  s_KeyNameArray        =
                           {
                              "AIRCI",
                              "AIRCO",
                              "AIRNA",
                              "AIRSE",
                              "AIRST"
                           };
   static  final   int    []  s_KeyLengthArray      =
                           {
                              21,
                              4,
                              31,
                              23,
                              3
                           };
   static  final   int    []  s_KeyTypeArray        =
                           {
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string
                           };
   static  final   int    []  s_KeyOffsetArray      =
                           {
                              0,
                              21,
                              25,
                              56,
                              79
                           };
   static  final   String []  s_RecordNameArray     =
                           {
                              "AIRCI",
                              "AIRCO",
                              "AIRNA",
                              "AIRSE",
                              "AIRST"
                           };
   static  final   int    []  s_RecordLengthArray   =
                           {
                              21,
                              4,
                              31,
                              23,
                              3
                           };
   static  final   int    []  s_RecordTypeArray     =
                           {
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string,
                              Mapper.type_string
                           };
   static  final   int    []  s_RecordOffsetArray   =
                           {
                              0,
                              21,
                              25,
                              56,
                              79
                           };
}
