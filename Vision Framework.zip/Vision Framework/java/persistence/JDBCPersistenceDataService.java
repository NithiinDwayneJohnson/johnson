/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.util.Hashtable;

/**
 * This class handles persistent operations against the JDBC data store.
 * Its main duties are the following:
 * <p>
 * - Establish a JDBC connection based on the connection string (URL)
 * supplied in the PID.
 * <p>
 * - Forward the request to the schema mapper.
 * <p>
 * - Handles PDS transaction involvement.
 * <p>
 * The JDBC PDS uses the Connection Manager to obtain a Connection object
 * based on the connection string stored in the PID. One connection object
 * per transaction context is created for a given JDBC connection string.
 * This connection object is shared by all schemas in the transaction
 * context that use the same connection string.
 * @version 1.0, 5/1/97
 */
public class JDBCPersistenceDataService extends GenericPDS {

	/*==================================================================*/
	/* Private Attributes                                               */
	/*==================================================================*/
	private Hashtable connection = new Hashtable();

	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Operations ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/

	/**
	 * This method returns the value of the "connection" attribute.
	 *  
	 * @return      :java.util.Hashtable -
	 *                 The value of the "connection" attribute.
	 */
	public Hashtable getConnection() {
		return (connection);
	}

	/**
	 * This method sets the value of the "connection" attribute.
	 *  
	 * @param       aValue:java.util.Hashtable
	 *                 The value of the "connection" attribute.
	 */
	public void setConnection(Hashtable aValue) {
		connection = aValue;
	}

	/*==================================================================*/
	/* Base Class Override Operations                                   */
	/*==================================================================*/
	/**
	 * This method is used to print out the current state of this
	 * object instance.
	 *  
	 */
	public void printOut() {
		try {
			System.out.println("JDBCPersistenceDataService:");
			System.out.println("   connection: " + getConnection());
		} catch (Throwable myThrowable) {
			myThrowable.printStackTrace();
			throw new RuntimeException(myThrowable.toString());
		}
	}

	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/
	/**
	 * This returns whether the PDS connection corresponding to the
	 * given PID is transactional.
	 *  
	 * @param       aPID:COM.novusnet.vision.java.persistence.PID
	 *                 the PID containing the URL corresponding to the
	 *                 JDBC connection to be tested.
	 * @return      :boolean -
	 *                 indication of whether the PDS connection is
	 *                 transactional
	 */
	/*==============================================================*/
	public boolean isTransactional(PID aPID) {
		try {
			return (
				getConnection((JDBCPersistenceIdentifier) aPID)
					.getTransactionIsolation()
					!= Connection.TRANSACTION_NONE);
		} catch (Exception e) {
			return false;
		}
	}

	/*==================================================================*/
	/* Protected Operations                                             */
	/*==================================================================*/
	/**
	 * This saves the object's persistent state. The following is
	 * performed:
	 * <p>
	 * - Establish a JDBC connection using the URL specified in the PID
	 * <p>
	 * - Forward the request to the schema passing it the stream, the
	 * PID and the connection.
	 *  
	 * @param      
	 * aSchema:SchemaMapper
	 * @param       stream:ObjectInputStream
	 * @param      
	 * aPID:GenericPID
	 * @exception  
	 * PersistenceException -
	 *                 If a persistence operation error occurs.
	 */
	protected void schemaStore(
		SchemaMapper aSchema,
		ObjectInputStream stream,
		GenericPID aPID)
		throws PersistenceException {
		((JDBCSchemaMapper) aSchema).store(
			getConnection((JDBCPersistenceIdentifier) aPID),
			stream,
			(JDBCPersistenceIdentifier) aPID);
	}

	/**
	 * This disconnects the object from its persistent state and
	 * deletes the object's persistent data from the data store
	 * location indicated by the PID.
	 * <p>
	 * - Establish a JDBC connection using the URL specified in the PID
	 * <p>
	 * - Forward the request to the schema passing it the stream, the
	 * PID and the connection.
	 *  
	 * @param      
	 * aSchema:SchemaMapper
	 * @param       stream:ObjectInputStream
	 * @param      
	 * aPID:GenericPID
	 * @exception  
	 * PersistenceException -
	 *                 If a persistence operation error occurs.
	 */
	protected void schemaDelete(
		SchemaMapper aSchema,
		ObjectInputStream stream,
		GenericPID aPID)
		throws PersistenceException {
		((JDBCSchemaMapper) aSchema).Delete(
			getConnection((JDBCPersistenceIdentifier) aPID),
			stream,
			(JDBCPersistenceIdentifier) aPID);
	}

	/**
	 * This loads the object's persistent state. The persistent state
	 * will not be modified unless a store or other mutating operation
	 * is performed on the persistent state.
	 * <p>
	 * - Establish a JDBC connection using the URL specified in the PID
	 * <p>
	 * - Forward the request to the schema passing it the stream, the
	 * PID and the connection.
	 *  
	 * @param      
	 * aSchema:SchemaMapper
	 * @param       stream:ObjectOutputStream
	 * @param      
	 * aPID:GenericPID
	 * @exception  
	 * PersistenceException -
	 *                 If a persistence operation error occurs.
	 */
	protected void schemaRestore(
		SchemaMapper aSchema,
		ObjectOutputStream stream,
		GenericPID aPID)
		throws PersistenceException {

		((JDBCSchemaMapper) aSchema).restore(
			getConnection((JDBCPersistenceIdentifier) aPID),
			stream,
			(JDBCPersistenceIdentifier) aPID);

	}

	/**
	 * Returns the JDBC connection for the given PID and current
	 * transaction context.
	 *  
	 * @param      
	 * aPID:JDBCPersistenceIdentifer
	 *                 the PID containing the URL for the JDBC
	 *                 connection to be created.
	 * @return      :java.sql.Connection -
	 *                 a JDBC connection corresponding to the given URL
	 */
	/*==============================================================*/
	protected Connection getConnection(JDBCPersistenceIdentifier aPID) {
		return ConnectionManager.instance().getConnection(
			aPID.getConnectionString(),
			null);
	}
}
