package COM.novusnet.vision.java.persistence;

import java.util.EventListener;

/**
The listener interface for PO factory.
*/
public interface POFactoryListener extends EventListener {
    /**
    This method is called when a new object is created.
    */
    public void newObjectCreated(POFactoryEvent event);


}

