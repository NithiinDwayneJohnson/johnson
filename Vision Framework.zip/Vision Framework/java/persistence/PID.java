package COM.novusnet.vision.java.persistence;

import COM.novusnet.vision.java.utility.streamhelpers.MemoryIODataStream;
/**
 *The PID (Persistent Identifier) identifies one or more locations
 *within a Datastore that represent the persistent data of an object
 *and generates a string identifier for that data. An object must have
 *a PID in order to store its data persistently. The client can create
 *a PID, initialize its attributes, and connect it to the object. A
 *persistent object�s implementation uses the POM interface by passing
 *the object and the PID as parameters.
*/
public abstract class PID extends MemoryIODataStream {
   /**
    *    This identifies the interface of a Datastore. Example datastore_types
    *    might be ,DB2, PosixFS, and ObjectStore. The PDS hides the Datastore�s
    *    interface from the client, the persistent object and the POM, but
    *    PDS implementations are dependent on the Datastore�s interface.
    */
   private String m_datastore_type;
   /**
    *    The parent PO. This is set the PDS before calling restore on the
    *    object.
    */
   private PO m_parentPO = null;

   /**
    *    This method must be overridden to return the data store type that
    *    can handle the PID/PO combination. The data store type is used by
    *    the POM.
    *    
    *    @return The data store type.
    */
   public String getdatastore_type() {
      return(m_datastore_type);
   }

   /**
    *    Sets the datastore_type attribute. This represents a class name that
    *    is loaded dynamically by the POM.
    *    
    *    @param datastore_type The data store type that should be used
    *    with this PID.
    */
   protected void setdatastore_type(String datastoreType) {
      m_datastore_type = datastoreType;
   }

   /**
    *    Returns the parent PO.
    *    
    *    @return Parent PO
    */
   public PO getParentPO() {
      return m_parentPO;
   }

   /**
    *    Sets the parent PO.
    *    
    *    @param parentPO. The parent PO.
    */
   public void setParentPO(PO parentPO) {
      m_parentPO = parentPO;
   }

}

