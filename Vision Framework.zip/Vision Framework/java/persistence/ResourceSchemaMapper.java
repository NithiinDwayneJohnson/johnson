package COM.novusnet.vision.java.persistence;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;
import java.util.Enumeration;
import java.util.ListResourceBundle;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;

import COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList;
import COM.novusnet.vision.java.businessobjects.BusinessObject;


/**
 * This is the resource file schema mapper interface. Every resource
 * file schema mapper must extend this class. This class provides the
 * functionality required to populate lookup list business objects from
 * resource files based on the current locale.
 * 
 * All the required behaviour is defined in the base class, so subclasses
 * need only override the createAndPopulateItem method.
*/
public abstract class ResourceSchemaMapper implements GenericSchema {


   /**
    *     This method is called by the PDS to store the state of a PO. It is
    *     not implemented for resource files.
    */
   public void store(ObjectInputStream stream, GenericPID aPID)throws PersistenceException {
   }

   /**
    *     This method is called by the PDS to delete the state of a PO. It
    *     is not implemented for resource files.
    */
   public void Delete(ObjectInputStream stream, GenericPID aPID)throws PersistenceException  {
   }

   /**
    *     This method is called by the PDS to restore the state of a PO. It
    *     loads a resource file using the current locale and uses it to populate
    *     a lookup list of business objects.
    *    
    *     It invokes the createAndPopulateItem hook method to create and
    *     populate each individual lookup list business object.
    *    
    *     @exception PersistenceException If a persistence error occurrs.
    */
   public void restore(ObjectOutputStream stream, GenericPID aPID)throws PersistenceException {
      try {
	 ResourceResolver         resourceResolver = null;
         BusinessObjectLookupList lookupList       = null;
         BusinessObject           lookupListItem   = null;
	 Class                    aClass           = null;

	 resourceResolver = new ResourceResolver();
	 resourceResolver.setPolicy(ResourceResolver.POLICY_EXACT_CLASS);

	 /*======================================================*/
	 /* Create the appropriate business object lookup list   */
	 /* subclass instance.                                   */
	 /*======================================================*/
	 aClass = Class.forName (aPID.getClassName ());
         lookupList = (BusinessObjectLookupList) aClass.newInstance ();

	 /*======================================================*/
	 /* Get the resource candidate list. We will only use    */
	 /* entry 0, since we specified an exact match.          */
	 /*======================================================*/
	 Vector listName = resourceResolver.getResourceCandidateList(aClass);

	 /*======================================================*/
	 /* Instantiate the first class in the list.             */
	 /*======================================================*/
	 aClass = Class.forName ((String)listName.elementAt(0));         
	 ListResourceBundle resources = (ListResourceBundle)aClass.newInstance ();

	 /*======================================================*/
	 /* Loop, enumerating through all the elements in the    */
	 /* resource file retrieving the keys and descriptions.  */
	 /*======================================================*/
         if (resources != null) {
            for (Enumeration enum = resources.getKeys (); enum.hasMoreElements ();){
               String key         = (String) enum.nextElement ();

	       /*==============================================*/
	       /* Create and populate the lookup list item     */
	       /*==============================================*/
               lookupListItem     =  createAndPopulateItem (key,
                                                            resources.getString (key));

	       /*==============================================*/
	       /* Add the lookup list item to the lookup list  */
	       /*==============================================*/
               lookupList.put       (key , lookupListItem);
            }
         }

	 /*==============================================*/
	 /* Write the statement designs to the stream    */
	 /*==============================================*/
         stream.writeObject(new ReferenceHolder(lookupList));
      }

      /*======================================================*/
      /* Map any exceptions to a persistence exception        */
      /*======================================================*/
      catch (Exception myException) {
         throw new PersistenceException (
                                         "ResourceSchemaMapper: "  +
                                         myException.toString   () +
                                         ":"                       +
                                         myException.getMessage ()
					 );
      }
   }

   /**
    *     This "hook" method is invoked by the restore operation and is used
    *     to create and populate an individual lookup list business object.
    *    
    *     This is the only method that subclasses need override.
    */
   protected abstract BusinessObject createAndPopulateItem(String code, String description);
}

