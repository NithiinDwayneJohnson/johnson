package COM.novusnet.vision.java.persistence;

import java.util.Vector;

/**
The PO factory provides a basic mechanism to create a PO. Creating
a PO from a factory has several advantages. The most important of
which, the caller does not have to know the concrete type of the
PO before performing a restore().  A PO type can be dependent on
the persistent state information stored in some database.

This is best explained in an example:

<p>class Account
<p>{
<p>}

<p>class
DiscoverAccount  extends Account
<p>{
<p>}

<p>class Bravo extends Account
<p>{
<p>}

<p>Suppose
the type of the account is stored in the database. Thus the caller
has no knowledge of what account object he should instantiate. By
using a PO_Factory, the PDS retrieves the data of the object , determines
the proper type and then instantiates the concrete type of account.

The
caller then assigns the retrieved account to the base account reference
he/she declared. As you probobly know by now, the caller can treat
all account object polymorphically without ever needing to know all
possible account types that exist.
*/
public class POFactory {

   public Vector m_Listeners = new Vector();

   /**
      Creates a PO given a PID. The type of the PO is unknown to the factory
      but should be casted properly in the client.
    
      @param aPID The pid to use to perform the restore operation.
      @param
      aPOMID no used and should be set to null.
      @return The PO object created by the PDS.
      @exception PersistenceException
      If a persistence error occurs.
   */
   public PO create_PO(PID aPID, String aPOMID)throws PersistenceException {
      POHolder aHolder = new POHolder();
      aHolder.restore(aPID);
      fireNewObjectEvent (new POFactoryEvent(this , aHolder.getPO()));
      return(aHolder.getPO());
   }

   /**
      Adds a listener to the POFactory.
   */
   public void addPOFactoryListener(POFactoryListener l) {
      m_Listeners.addElement(l);
   }

   /**
      Removed a POFactory listener.
   */
   public void removePOFactoryListener(POFactoryListener l) {
      m_Listeners.removeElement(l);    
   }

   /**
      Fires a new object created event.
   */
   protected void fireNewObjectEvent(POFactoryEvent event) {
      Vector listeners = (Vector) m_Listeners.clone();
      for (int i = 0; i < listeners.size() ; i++) {
	 POFactoryListener aListener = (POFactoryListener)listeners.elementAt(i);
	 aListener.newObjectCreated(event);
      }
   }
}

