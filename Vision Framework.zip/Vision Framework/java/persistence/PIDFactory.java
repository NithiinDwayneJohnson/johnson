package COM.novusnet.vision.java.persistence;

/**
A PIDFactory is used to created specific implementation PID. Some
applications need to be able to restore an object given a PID but
without knowing which type or implementation to use. 

A well designed application should use a PID factory to obtain
a PID for a given implementation. A client should never create a
PID directly since that will introduce data store dependent code
into client code.
*/
public interface PIDFactory {

    /**
    This creates an instance of a PID given a Class object that identifies
    a particular PID implementation.
    
    @param aKey A class object that can be used to create a concrete
    type PID.
    @return A PID of a concrete type.
    @exception PersistenceException
    If a persistence error occurs.
    */
    public PID create_PID_from_class(Class aClass)throws PersistenceException;


}

