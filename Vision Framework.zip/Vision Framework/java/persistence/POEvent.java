package COM.novusnet.vision.java.persistence;

import java.util.EventObject;


public class POEvent extends EventObject {
    /**
    Constructor that takes the event source.
    */
    public POEvent(Object source) {
       super(source);
    }

}

