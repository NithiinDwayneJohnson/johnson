package COM.novusnet.vision.java.persistence;

import java.util.EventListener;

public class POMListener implements EventListener {
   /**
    *    This method is called when an object is about to be restored.
    */
   public void restoreStarted(POMEvent event) {
   }

   /**
     *    This method is called when an object is done being restored.
    */
   public void restoreEnded(POMEvent event) {
   }

   /**
     *    This method is called when an object is about to be stored.
    */
   public void storeStarted(POMEvent event) {
   }

   /**
     *    This method is called when an object is stored.
    */
   public void storeEnded(POMEvent event) {
   }

   /**
     *    This method is called when an object is about to be deleted.
    */
   public void deleteStarted(POMEvent event) {
   }

   /**
     *    This method is called when an object is  deleted.
    */
   public void deleteEnded(POMEvent event) {
   }

}

