package COM.novusnet.vision.java.persistence;

import java.util.Vector;
import java.io.Serializable;

/**
 * The PO (Persistent Object) interface provides a mechanism for
 * allowing a client to externally control the PO's relationship with
 * its persistent data:
 * 
 * <p>- Store/restore: These operations allow the client to move
 * data between the PO and its Datastore in each direction separately,
 * with each movement in each direction explicitly initiated by the
 * client.</p>
 * 
 * The PO interface operations allow client control of a single PO's
 * persistent data. When one of these operations is performed on a PO,
 * what data is included in these operations is up to that PO's implementation.
 * For example, only part of the PO's private data may be included.
 * Other POs may be included based on any criteria. If other POs are
 * included, the target PO's implementation becomes their client and
 * is responsible for controlling their persistence.
 * 
 * A PO client is responsible for the following:
 * 
 * <p>- Creating
 * a PID for the PO and initializing the PID. For storage, whatever
 * location information is not specified will be determined by the Datastore.
 * For a retrieval or delete operation, the location information must
 * be complete.</p>
 * 
 * <p>- Controlling the relationship between the data in the PO and
 * the Datastore. This is done by asking the PO to store(), restore() 
 * or delete() itself.</p>
 * 
 * To adhere to the plug and play philosophy, objects pass these
 * requests through to the POM, so that the interface for PO parallels
 * that of the POM. This delegation to the POM allows objects to change
 * PDSs (combination of Datastore and Protocol) without changing their
 * implementation.
 * 
 * This implementation of a Persistence Object uses the Serialization
 * protocol for data transfer between a PO and a PDS.
 * 
*/
public abstract class PO implements Serializable, Cloneable {

   /**
    * A flag to indicate whether a restore operation is currently in progress
    *    for this PO instance.
    */
   protected boolean m_restoreInProgress = false;
   /**
    *    A flag to indicate whether a store operation is currently in progress
    *    for this PO instance.
    */
   protected boolean m_storeInProgress = false;
   /**
    *    A flag to indicate whether a Delete operation is currently in progress
    *    for this PO instance.
    */
   protected boolean m_deleteInProgress = false;
   /**
    *    This flag indicates whether the previous restore operation for this
    *    persistent object failed. An explicit call to setPID will clear this
    *    flag.
    */
   protected boolean m_failedRestore = false;
   /**
    *    Constant that represents a restore operation.
    */
   public static final int RESTORE_EVENT = 0;
   /**
    *    Constant that represents a store operation.
    */
   public static final int STORE_EVENT = 1;
   /**
    *    Constant that represents a delete operation.
    */
   public static final int DELETE_EVENT = 2;
   /**
    *    The parent PO class.
    */
   private PO m_parent = null;
   /**
    *    A flag to indicate to the PO not to this store this po but still
    *    call its pre and post store methods. This is useful for PO's that
    *    do not themselves have a separate state.
    */
   private boolean m_noStore = false;
   private transient PID m_PID = null;
   public static POM POM;
   private transient Vector m_listeners = null;
     
   private static final String READONLY = "readonly";

   static {
      POM = POM.instance();
   }

   /**
    *    @return The currently set PID or null if none is set.
    */
   public PID getPID() {
      return m_PID;
   }

   /**
    *    This method sets the current PID. This PID will be used if the caller
    *    did not supply a PID during a persistent operation. The PID stores
    *    the same reference as that supplied by a caller. An changes to made
    *    by the client to the PID will be reflected. If the client wishes
    *    otherwise, a copy of the PID must be made before passing it the the
    *    PO.
    *    
    *    @param aPID The PID to set.
    */
   public void setPID(PID aPID) {
      m_PID           = aPID;
      m_failedRestore = false;
   }

   /**
    *    This copies the object�s persistent data from the Datastore location
    *    indicated by the PID and inserts it into the object in memory.
    *    
    *    @param aPID. The pid can be null in which case the pid set on
    *    the PO will be used.
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void restore(PID aPID)throws PersistenceException {
      if (m_restoreInProgress == true) {
	 return;
      } 
      m_restoreInProgress = true;

      try {	 
	 POM.restore (this, (aPID != null) ? aPID : getPID ());
	 firePOEvent(RESTORE_EVENT);
      }
      catch (PersistenceException e) {
	 m_failedRestore = true;
	 throw e;
      }
      finally {
	 m_restoreInProgress = false;
      }
   }

   /**
    *    This deletes the object�s persistent data from the Datastore location
    *    indicated by the PID.
    *    
    *    @param aPID. The pid can be null in which case the pid set on
    *    the PO will be used.
    *    @exception PersistenceException If a persistence error occurs
    */
   public void Delete(PID aPID)throws PersistenceException {
      // Readonly
//       String readonly = ApplicationConfigHelper.instance().getProperty(READONLY);
      String readonly = System.getProperty(READONLY);
      if ((readonly != null) && (readonly.equalsIgnoreCase("true"))) {
	 if ( aPID != null && aPID instanceof GenericPID ) {
	    if ( ! ((GenericPID)aPID).isModifiable() ) {
	       System.err.println("@@@@@@@@ SchemaName = " + ((GenericPID)aPID).getSchemaName());
	       throw new ReadonlyException("You're in read-only mode.  No modification will be allowed.");
	    }
	 }
      }

      if (m_deleteInProgress == true) {
	 return;
      } 
      m_deleteInProgress = true;

      try {
	 POM.Delete (this, (aPID != null) ? aPID : getPID ());           
	 firePOEvent(DELETE_EVENT);
      }
       
      finally {
	 m_deleteInProgress = false;
      }
   }

   /**
    *    This copies the persistent data out of the object in memory and puts
    *    it in the Datastore location indicated by the PID. 
    *    
    *    @param aPID. The pid can be null in which case the pid set on
    *    the PO will be used.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void store(PID aPID)throws PersistenceException {
    
      // Readonly
//       String readonly = ApplicationConfigHelper.instance().getProperty(READONLY);
      String readonly = System.getProperty(READONLY);
      if ((readonly != null) && (readonly.equalsIgnoreCase("true"))) {
	 if ( aPID != null && aPID instanceof GenericPID ) {
	    if ( ! ((GenericPID)aPID).isModifiable() ) {
	       System.err.println("@@@@@@@@ SchemaName = " + ((GenericPID)aPID).getSchemaName());
	       throw new ReadonlyException("You're in read-only mode.  No modification will be allowed.");
	    }
	 }
      }

      if (m_storeInProgress == true) {
	 return;
      } 
      m_storeInProgress = true;

      try {
	 POM.store (this, (aPID != null) ? aPID : getPID ());           
	 firePOEvent(STORE_EVENT);
      }
       
      finally {
	 m_storeInProgress = false;
      }
   }

   /**
    *    This method is called by a PDS when a restore operation takes place
    *    against an existing object. The processRestoreResult method of the
    *    parent must be called during the processing of this method.
    *    
    *    @param anObject. This object should be casted to the proper type
    *    by this method.
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void processRestoreResult(Object anObject)throws PersistenceException {

   }

   /**
    *    Called by POM when the object is about to be stored.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected void pre_store()throws PersistenceException {

   }

   /**
    *    Called by the POM when the object has been restored.
    *@exception PersistenceException
    *    If a persistence error occurs.
    */
   protected void post_restore()throws PersistenceException {

   }

   /**
    *    Called by the POM when the object has been stored.
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected void post_store()throws PersistenceException {

   }

   /**
    *    Called by POM when the object is about to be restored.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected void pre_restore()throws PersistenceException {

   }

   /**
    *    Called by POM when the object is about to be deleted.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected void pre_delete()throws PersistenceException {

   }

   /**
    *    Called by the POM when the object has been deleted.
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected void post_delete()throws PersistenceException {

   }

   /**
    *    Adds a listener to the PO. The listener will get notified when the
    *    PO is restored, stored or deleted.
    */
   public void addPOListener(POListener l) {
      System.out.println("addPOListener: "+ l);
      if (m_listeners == null) {
	 m_listeners = new Vector();
      }

      for (int i = 0; i < m_listeners.size() ; i++) {
	 POListener aListener = (POListener)m_listeners.elementAt(i);
	 if (aListener == l) {
	    return;
	 }
      }

      m_listeners.addElement(l);
   }

   /**
    *    Removed a PO listener.
    */
   public void removePOListener(POListener l) {
      System.out.println("removePOListener");
      m_listeners.removeElement(l);
   }

   /**
    *    Fires an event based on the event ID. This method calls the proper
    *    handler on the listener interface.
    */
   protected void firePOEvent(int eventID) {
      if (m_listeners == null) {
	 return;
      }

      Vector listeners = (Vector) m_listeners.clone();

      for (int i = 0; i < listeners.size() ; i++) {

	 POListener aListener = (POListener)listeners.elementAt(i);

	 switch (eventID) {
	    case RESTORE_EVENT:
	       aListener.restored( new POEvent(this) );
	       break;

	    case STORE_EVENT:
	       aListener.stored( new POEvent(this) );
	       break;

	    case DELETE_EVENT:
	       System.out.println("Firing Deleted to:" + aListener);
	       aListener.deleted( new POEvent(this) );
	       break;
	 }
      }
   }

   /**
    *    This returns an indication of whether the previous restore operation
    *    for this persistent object failed.
    */
   protected boolean isFailedRestore() {
      return (m_failedRestore);
   }

   /**
    *    returns whether a restore operation is currently taking place against
    *    the object.
    */
   protected boolean isRestoreInProgress() {
      return (m_restoreInProgress);
   }

   /**
    *    Returns the parent PO.
    *    
    *    @return Parent PO
    */
   public PO getParent() {
      return m_parent;
   }

   /**
    *    Sets the parent PO.
    *    
    *    @param parentPO. The parent PO.
    */
   public void setParent(PO parentPO) {
      m_parent = parentPO;
   }

   public Object clone()throws CloneNotSupportedException {

      PO myPO = (PO)super.clone();

      myPO.m_restoreInProgress = false;
      myPO.m_storeInProgress   = false;
      myPO.m_deleteInProgress  = false;
      myPO.m_failedRestore     = false;
      myPO.m_listeners         = null;
      return myPO;
   }

   /**
    *    Sets the noStore attribute. If a PO stores otherobjects but does
    *    not have any persistence state, then this flag will only cause the
    *    pre_ and post store methods to be called.
    */
   public void setNoStore(boolean noStore) {
      this.m_noStore = noStore;
   }

   /**
    *    Returns a boolean to indicate whether the noStore attribute has been set or not. 
    *    If a PO stores other objects but does
    *    not have any persistence state, then this flag will only cause the
    *    pre_ and post store methods to be called.
    */
   public boolean isNoStore() {
      return m_noStore;
   }
}

