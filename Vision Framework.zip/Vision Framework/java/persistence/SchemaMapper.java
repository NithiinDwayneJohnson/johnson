package COM.novusnet.vision.java.persistence;


/**
This is the abstract base class of all schema mappers.
*/
public interface SchemaMapper {
}

