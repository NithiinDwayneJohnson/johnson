package COM.novusnet.vision.java.persistence;

public class ReadonlyException extends PersistenceException {

   public ReadonlyException(String text) {
      super(text);
   }
}

