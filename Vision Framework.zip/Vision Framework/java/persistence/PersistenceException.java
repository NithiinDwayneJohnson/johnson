package COM.novusnet.vision.java.persistence;

import java.lang.RuntimeException;

/**
 *The PersistenceException class represents the base exception that
 *can be thrown from the persistence service. 
 *
 *Modified by Parag: March 15 2004 to carry a rootCause
 *to allow nested exceptions
*/
public class PersistenceException extends RuntimeException {
   private Throwable rootCause;

   public PersistenceException(String anExceptionString) {
      super (anExceptionString);
   }

   public PersistenceException(Throwable rootCause, String anExceptionString) {
      super (anExceptionString);
      this.rootCause = rootCause;
   }

   public PersistenceException(Throwable rootCause) {
      super (rootCause.getMessage());
      this.rootCause = rootCause;
   }

   /**
    * Gets the rootCause
    * @return Returns a Throwable
    */
   public Throwable getRootCause() {
      return rootCause;
   }

}


