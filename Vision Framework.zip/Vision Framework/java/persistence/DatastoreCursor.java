package COM.novusnet.vision.java.persistence;

import java.io.Serializable;

/**
 * A placeholder interface that represents a serializable database cursor.
 * @version 1.0, 5/1/97
 */
public interface DatastoreCursor extends Serializable {

}

