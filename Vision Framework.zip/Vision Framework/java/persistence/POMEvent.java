package COM.novusnet.vision.java.persistence;

import java.util.EventObject;
public class POMEvent extends EventObject {


   /**
    *    Constructor that takes the event source.
    */
   public POMEvent(Object source) {
      super(source);
   }

}

