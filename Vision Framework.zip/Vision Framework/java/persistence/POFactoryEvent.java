package COM.novusnet.vision.java.persistence;

import java.util.EventObject;


/**
The POFactoryEvent is the type used by the factory when an event
occurs.
*/
public class POFactoryEvent extends EventObject {

    /**
    The persistence object affected.
    */
    private PO m_po;

    /**
    Returns the PO in the event.
    */
    public PO getPO() {
       return(m_po);
    }

    /**
    Constructor.
    */
    public POFactoryEvent(Object source, PO aPO) {
       super(source);
       m_po = aPO;
    }

}

