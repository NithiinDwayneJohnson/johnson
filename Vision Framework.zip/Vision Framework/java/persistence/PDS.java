package COM.novusnet.vision.java.persistence;

/**
 * The PDS (Persistence Data Service) implementation is responsible
 * for the following:
 *
 * <p>-Interacting with the object to get data in and out of the
 * object using a protocol. Protocols are introduced in this section.</p>
 * 
 * <p>-
 * Interacting with the Datastore to get data in and out of the object.
 * Datastores are introduced in this section.</p>
 * 
 *A PDS performs the work for moving data into and out of an object
 *and moving data into and out of a Datastore. There can be a wide
 * variety of implementations of PDSs which provide different performance,
 *robustness, storage efficiency, storage format, or other characteristics,
 *and which are tuned to the size, structure, granularity, or other
 *properties of the object�s state.
 *
 *The PDS has the responsibility of translating from the object
 *world above it to the storage world below it. It plays critical roles
 *in identifying the storage as well as providing convenient and efficient
 *access to it.
 *
 *We define multiple kinds of PDSs, each tuned to a particular protocol
 *and data storage mechanism, since the range of requirements for performance,
 *cost, and qualitative features is so large. Multiple PDSs must work
 *together to create the impression of a uniform persistence mechanism.
 *The Persistent Object Manager provides the framework for PDSs to
 *cooperate this way.
 *
 *Because the range of storage requirements is so large, there may
 *be different ways in which the object can best access its persistent
 *data, and there may be different ways in which the PDS can store
 *that data. The way in which the object interacts with the PDS is
 *called the Protocol. A Protocol may consist of calls from the object
 *to the PDS, calls from the PDS to the object, implicit operations
 *implemented with hidden interfaces, or some combination. The interaction
 *might be explicit, for example, asking the object to stream out its
 *data, or implicit, for example, the object might be mapped into persistent
 *virtual memory. The Protocol is initiated when an object�s persistent
 *state is stored, restored, or connected; this may be initiated by
 *a POM or by the object itself. What happens after that depends on
 *the particular Protocol. An object that uses a particular Protocol
 *can work with any PDS that supports that Protocol. The protocol for
 *vision-2000 is the java object serialization.
 *
 *A PDS may use either a standard or a proprietary interface to
 *its Datastore. A Datastore might be a file, virtual memory, some
 *kind of database, or anything that can store information. This specification
 *defines one Datastore interface that can be implemented by a variety
 *of databases.
 *The PDS component interface is specified here as one module containing
 *only the base PDS interface, plus one additional module per protocol.
 *Each protocol-specific module inherits from the base module, augmenting
 *the base functionality as needed.
 * @version 1.0, 5/1/97
 */
public interface PDS {

    /**
     *    This saves the object�s persistent state.
     *    
     *    @exception PersistenceException If a persistence error occurs.
    */
    public void store(PO aPO, PID aPID)throws PersistenceException;

    /**
     *    This disconnects the object from its persistent state and deletes
     *    the object�s persistent data from the Datastore location indicated
     *    by the PID.
     *    
     *   @exception PersistenceException If a persistence error occurs.
    */
    public void Delete(PO aPO, PID aPID)throws PersistenceException;

    /**
     *   This loads the object�s persistent state. The persistent state will
     *   not be modified unless a store or other mutating operation is performed
     *   on the persistent state.
     *   
     *   @exception PersistenceException If a persistence error occurs.
    */
    public void restore(PO aPO, PID aPID)throws PersistenceException;

    /**
     *   This disconnects the object from the persistent state. It is undefined
     *   whether or not the object is usable if not connected to persistent
     *   state.
     *   
     *   @exception PersistenceException If a persistence error occurs.
    */
    public abstract void disconnect(PO aPO, PID aPID)throws PersistenceException;

    /**
     *   This connects the object to its persistent state, after disconnecting
     *   any previous persistent state. The persistent state may be updated
     *   as operations are performed on the object.
     *   
     *   @exception PersistenceException If a persistence error occurs.
    */
    public PDS connect(PO aPO, PID aPID)throws PersistenceException;

    /**
     *   This returns whether the PDS connection corresponding to the given
     *    PID is transactional.
     */
    public boolean isTransactional(PID aPID);
}

