/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import COM.novusnet.vision.java.utility.helpers.ClassHelper;

/**
 * The default PID factory is capable of creating PIDs for JDBC and
 * resource objects. The JDBC URL defaults to transaction mappers in the
 * transaction mapper package of the class of PID to be created. For
 * example, creating a PID for class COM.novusnet.myapp.java.Foo, will
 * result in the transaction mapper definition to be set to:
 * COM.novusnet.myapp.java.transactionmappers. All access to this class
 * should be done though createPID method.
 * @version 1.0, 5/1/97
 */
public  class  DefaultPIDFactory  implements  PIDFactory {

   /**
    * This creates an instance of a PID given a key that identifies a
    * particular PID implementation.
    * <p>
    * @param aKey A string key that can be used to create a concrete
    * type PID.
    * <p>
    * @return A PID of a concrete type.
    * <p>
    * @exception PersistenceException If a persistence error occurs.
    *  
    * @param       aKey:String
    * @return      :PID -
    * @exception   PersistenceException -
    */
   public  PID  create_PID_from_key (String  aKey)throws PersistenceException {
      return null;
   }

   /**
    * This creates an instance of a PID given a Class object that
    * identifies a particular PID implementation.
    * <p>
    * @param aKey A class object that can be used to create a concrete
    * type PID.
    * <p>
    * @return A PID of a concrete type.
    * <p>
    * @exception PersistenceException If a persistence error occurs.
    *  
    * @param       aClass:Class
    * @return      :PID -
    * @exception   PersistenceException -
    */
   public  PID  create_PID_from_class (Class  aClass) throws PersistenceException {
      GenericPID myPID           = null;
      String     mySchemaClass   = null;

      /*======================================================*/
      /* Create the appropriate PID and schema subclassed for */
      /* the given business object class.                     */
      /*======================================================*/
      try {
	 Class  lookupListClass = COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList.class;
	 String exceptions[] = getLookupListExceptions();
	 String className    = aClass.getName();
	 boolean exception   = false;
	 if (exceptions != null) {
	    for(int i = 0; i < exceptions.length; i++) {
	       if (className.endsWith(exceptions[i])) {
		  //myPID         = new JDBCPersistenceIdentifier ();
		  myPID         = new GenericPID ();
		  if( (  System.getProperty("localdemo") == null)  ||	 
		      (! System.getProperty("localdemo").equalsIgnoreCase("TRUE" ))) {
		     mySchemaClass = (aClass.getName () + "Schema");
		  }
		  else {
		     mySchemaClass = (aClass.getName () + "LocalSchema");
			((JDBCPersistenceIdentifier) myPID).setConnectionString (getURLFromClass(aClass));
		  }
		  
		  exception = true;
		  break;
	       }
	    }
	 }

	 if (!exception) {
	    /*==============================================*/
	    /* Any lookup list business object that are     */
	    /* not retrieved via JDBC, but rather use a     */
	    /* resource file are a special case.            */
	    /*==============================================*/
	    if (lookupListClass.isAssignableFrom (aClass)) {         
	       myPID         = new GenericPID  ();
	       mySchemaClass = (className + "ResourceSchema");
	    }
            /*==============================================*/
	    /* If this is a local serialized business object*/
	    /* use the special local schema                 */
	    /*==============================================*/
	    else if ( ( System.getProperty("localdemo") != null)  &&	 
		      ( System.getProperty("localdemo").equalsIgnoreCase("TRUE" ))) {
	       myPID         = new JDBCPersistenceIdentifier ();
	       mySchemaClass = (aClass.getName () + "LocalSchema");
	       ((JDBCPersistenceIdentifier) myPID).setConnectionString (getURLFromClass(aClass));
	    }
	 
	    /*==============================================*/
	    /* All other business objects default to JDBC   */
	    /*==============================================*/
	    else {
	       //myPID         = new JDBCPersistenceIdentifier ();
		   myPID         = new GenericPID ();
	       mySchemaClass = (className + "Schema");
	       //Set below to go to JDBC
	       //((JDBCPersistenceIdentifier) myPID).setConnectionString (getURLFromClass(aClass));
	    }
	 }

         myPID.setClassName  (className);
         myPID.setSchemaName (mySchemaClass);
         return              ((PID) myPID);
      } catch (Throwable myThrowable) {
	 myThrowable.printStackTrace();
         throw (new PersistenceException ("DefaultPIDFactory: PID creation failure"));
      }
   }

   /**
    * Creates a PID based on the class object.
    *  
    * @param       aClass:Class
    * @return      :PID -
    * @exception   PersistenceException -
    */
   public  PID  createPID (Class  aClass) throws PersistenceException  {
      return create_PID_from_class(aClass);
   }


   /*==================================================================*/
   /* Protected Operations                                             */
   /*==================================================================*/
   /**
    * This method returns a list for classes that are lookup lists but
    * are populated using JDBC. This method is intended for
    * subclassers. The default returns null.
    *  
    * @return      :String[] -
    */
   protected  String[]  getLookupListExceptions () {
      return null;
   }


   /*==================================================================*/
   /* Class Operations                                                 */
   /*==================================================================*/
   /**
    * Returns the URL needed by a JDBC driver given a class object.
    *  
    * @param       aClass:Class
    * @return      :String -
    */
   public static  String  getURLFromClass (Class  aClass)  {
      String    applicationName = getApplicationNameFromClass(aClass);
      return    "jdbc:dasjdbc;Package=" + applicationName + ".java.transactionmappers";
   }


   /*==================================================================*/
   /* Private Operations                                               */
   /*==================================================================*/

   /**
    * Gets the application name from a class. 
    * <br>This method assumes that the classname follows the naming convention
    * 'com.novusnet.cms.java.products' where 'com.novusnet.cms' represents the 
    * the application name and 'java.products' represents the function name or 
    * description.
    * <br>
    * @param       aClass:Class
    * @return      :String -
    */
   private static  String  getApplicationNameFromClass (Class  aClass) {
      String appName = aClass.getName ();
      int    index   = 0;
      
      for (int i = 0; i < 3; i++) {
	 index = appName.indexOf ('.', index);
	 if (index >= 0) {
	    index++;
	 }
	 else {
	    return null;
	 }
      }
      
      return appName.substring (0, index - 1);
   }

}




