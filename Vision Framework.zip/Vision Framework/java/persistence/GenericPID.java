package COM.novusnet.vision.java.persistence;

/**
 * This is the generic, schema-based PID. It allows for a schema nameand
 * a PO class name. Most relational implementation will inherit from
 * this class.
 */
public class GenericPID extends PID {

   /**
    * The schema name to use for persistent operations. The schema is loaded
    * dynamically by the JDBC PDS.
    */
   private String m_schemaName = null;

   /**
    * The name of the PO class associated with the PID.
    */
   private String m_className = null;
 
   /**
    * Holds the maximum number of rows that should be retrieved during
    * a run.
    */
   private int m_maxRows = 0;

   /**
    * Holds an indicator on whether the store operation is an update or
    * an insert.
    */
   private boolean m_update = false;
   /**
    * This attribute indicates to the Generic PDS whether a store should
    * be optimized.
    */
   private boolean m_optimizedStore = true;
   private DatastoreCursor m_DatastoreCursor;

   // Readonly
   // This attribute indicates whether the modification operation is allowed
   private boolean modifiable = false;

   /**
    * The default constructor.
    */
   public GenericPID() {
      setdatastore_type ("COM.novusnet.vision.java.persistence.GenericPDS");
   }

   /**
    *  Sets the schema name in the schemaName attribute. This name will
    *  be used by the JDBC PDS to load the schema dynamically.
    */
   public void setSchemaName(String schemaName) {
      m_schemaName = schemaName;
   }

   /**
    * Returns the schema mapper ID currenlty set in the PID.
    */
   public String getSchemaName() {
      return m_schemaName;
   }

   /**
    *  Sets the name of the PO class associated with the PID.
    */
   public void setClassName(String className) {
      m_className = className;
   }

   /**
    * Returns the name of the PO class associated with the PID.
    */
   public String getClassName() {
      return m_className;
   }

   /**
    * Sets the maximum number of rows that should be retrieved during a
    * run.
    */
   public void setMaxRows(int rows) {
      m_maxRows = rows;
   }

   /**
    * Returns the maximum number of rows that will be retrieved during
    * a run.
    */
   public int getMaxRows() {
      return m_maxRows;
   }

   /**
    * Enables/Disables the semantics of a store() operation. If true, the
    * store() is an update to an existing object. Otherwise a new object
    * is to be created.
    */
   public void enableUpdate(boolean updateIndicator) {
      m_update = updateIndicator;
   }

   /**
    * Returns the update/insert indicator.
    */
   public boolean isUpdate() {
      return m_update;
   }

   /**
    * Sets the optimized store flag. If this flag is set, the PDS does
    * not stream the stored object but instead creates a reference holder
    * of the object and writes it to the stream.
    *
    * @param flag Optimization flag.
    */
   public void setOptimizedStore(boolean flag) {
      m_optimizedStore = flag;
   }

   /**
    * Returns the optimization state of the store.
    */
   public boolean isOptimizedStore() {
      return m_optimizedStore;
   }

   /**
    * @return The DataStoreCursor used to reposition the cursor for the
    * next restore operation.
    */
   public DatastoreCursor getDatastoreCursor() {
      return m_DatastoreCursor;
   }

   /**
    * This sets the DataStoreCursor used to reposition the cursor for the
    * next restore operation.
    *
    * @param  aDataStoreCursor  The datastore cursor.
    */
   public void setDatastoreCursor(DatastoreCursor aDatastoreCursor) {
      m_DatastoreCursor = aDatastoreCursor;
   }

   // Readonly
   public void setModifiable( boolean aVal ) {
      modifiable = aVal;
   }

   // Readonly
   public boolean isModifiable() {
      return( modifiable );
   }
}


