package COM.novusnet.vision.java.persistence;

/**
 * This represents a DAS error, which includes major and minor return codes and 
 * an error text message.
 * @version 1.0, 5/1/97
 */
public class DapErrorPersistenceException extends PersistenceException {
    private int m_majorCode = 0;
    private int m_minorCode = 0;
    private String m_errorText = "";

   /**
    * Constructs a DapErrorPersistenceException with the specified detail message.
    */
    public DapErrorPersistenceException(String anExceptionString) {
       super (anExceptionString);
    }

   /**
    * Constructs a DapErrorPersistenceException with the specified detail message,
    * major return code, minor return code and error text.
    */
    public DapErrorPersistenceException(String anExceptionString, int aMajorCode, int aMinorCode, String aErrorText) {
      super (anExceptionString);
      
      m_majorCode = aMajorCode;
      m_minorCode = aMinorCode;
      m_errorText = aErrorText;    
    }

   /**
    * Return the major return code.
    */
    public int getMajorCode() {
      return m_majorCode;    
    }

   /**
    * Return the minor return code.
    */
    public int getMinorCode() {
      return m_minorCode;    
    }

   /**
    * Return the error text.
    */
    public String getErrorText() {
      return m_errorText;    
    }

}





