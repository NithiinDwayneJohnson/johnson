/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import java.util.EventListener;

/**
 * No documentation is currently available for this class.
 */
public interface  POListener  extends  EventListener {

        /**
         * This method is called when an object is restored.
         * @param       event:POEvent
         */
   public  void  restored (POEvent  event);

        /**
         * This method is called when an object is stored.
         * @param       event:POEvent
         */
   public  void  stored (POEvent  event);

        /**
         * This method is called when an object is deleted.
         * @param       event:POEvent
         */
   public  void  deleted (POEvent  event);


}
