/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

package COM.novusnet.vision.java.persistence;

import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import COM.novusnet.vision.java.utility.cache.ObjectCache;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;

/**
 * This class handles persistent operations against a generic, schema-based
 * data store. Its main duties are the following:
 * <p>- Create a schema mapper dynamically based on the schema name set in
 * the PID.</p>
 * <p>- Stream the object (if need be).</p>
 * <p>- Forward the request to the schema mapper.</p>
 * <p>- Call the appropriate post processing methods on the PO (for
 * example: processRestoreResult)</p>
 * <p>- Maintain a cache of all persistent objects defined to support
 * object caching.</p>
 * <p><b> Notes </p></b>
 * <p>
 * Any subclasses wishing to specialize the PDS behaviour, typically need
 * only override the schemaStore, schemaDelete and schemaRestore methods.
 */
public  class  GenericPDS  implements  PDS {

   /*==================================================================*/
   /* Class Attributes                                                 */
   /*==================================================================*/
   private static ObjectCache objectCache = new ObjectCache ();

   /*==================================================================*/
   /* Public Operations                                                */
   /*==================================================================*/
   /**
    * Return the value of the "objectCache" attribute.
    *  
    * @return      :ObjectCache -
    *                 The value of the "objectCache" attribute.
    */
   public static  ObjectCache  getObjectCache () {
      return (objectCache);
   }


   /**
    * Sets the value of the "objectCache" attribute.
    *  
    * @param       aValue:ObjectCache
    *                 The value of the "objectCache" attribute.
    */
   public static  void  setObjectCache (ObjectCache  aValue)  {
      objectCache = aValue;
   }


   /**
    * This saves the objects persistent state. The following is
    * performed:
    * <p>- From the PID, obtain the schema class name that can save
    * the passed PO.</p>
    * <p>- Create a schema dynamically</p>
    * <p>-If store optimization if off, serialize the PO into an input
    * stream otherwise wirte a reference holder object to the stream.
    * The reference holder object will contain a reference to the
    * actual PO.</p>
    * <p>- Create an output from the input stream.</p>
    * <p>- Forward the request to the schema passing it the stream and
    * the PID.</p>
    * <p>- If the persistent object supports caching, the object cache
    * is updated following a successful store operation.</p>
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aPO:PO
    * @param       aPID:PID
    */
   public  void  store (PO   aPO, PID  aPID)throws PersistenceException  {
      ByteArrayOutputStream  OutputByteArray;
      ObjectOutputStream     ObjectOutputStream;
      ByteArrayInputStream   InputByteArray;
      ObjectInputStream      ObjectInputStream;
      SchemaMapper           aSchema;       
      String                 aSchemaName = ((GenericPID) aPID).getSchemaName ();
      int                    aHashCode   = aPID.hashCode ();
      ReferenceHolder        aReferenceHolder = null;

      //***************************************
      // Load the schema specified in the PID
      //***************************************
      aSchema = loadSchemaMapper (aSchemaName);

      try {
	 //***************************************
	 // Create an memory output stream
	 //***************************************
	 OutputByteArray     = new ByteArrayOutputStream ();
	 ObjectOutputStream  = new ObjectOutputStream    (OutputByteArray);

	 //*****************************************************************
	 // Ask PO to stream itself only if the optimization is turned off
	 //*****************************************************************
	 if (((GenericPID) aPID).isOptimizedStore ()) {
	    aReferenceHolder = new ReferenceHolder (aPO);
	    ObjectOutputStream.writeObject (aReferenceHolder);
	    ObjectOutputStream.flush       ();
	 } else {
	    ObjectOutputStream.writeObject (aPO);
	    ObjectOutputStream.flush       ();
	 }

	 //***************************************
	 // Create an memory input stream
	 //***************************************
	 InputByteArray     = new ByteArrayInputStream (OutputByteArray.toByteArray());
	 ObjectInputStream  = new ObjectInputStream    (InputByteArray);
      }catch (Throwable anException) {
	 throw new PersistenceException (
					 "GenericPDS:"         +
					 anException.toString ()
					 );
      }

      try {
	 //***************************************
	 // Ask schema to store PO
	 //***************************************
	 schemaStore (aSchema, ObjectInputStream, (GenericPID) aPID);

	 //***************************************
	 // Add the stored PO to the object cache
	 //***************************************
	 updateCache (aSchemaName, aHashCode, aPO);
      }
      finally {
	 if (aReferenceHolder != null) {
	    aReferenceHolder.releaseReference();
	 }
      }
   }

   /**
    * This disconnects the object from its persistent state and
    * deletes the objects persistent data from the Datastore location
    * indicated by the PID.
    * <p>- From the PID, obtain the schema class name that can save
    * the passed PO.</p>
    * <p>-Create a schema dynamically.</p>
    * <p>-Forward the request to the schema passing it the PID.</p>
    * <p>- If the persistent object supports caching, the object cache
    * is updated to remove any corresponding entry following a
    * successful delete operation.</p>
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aPO:PO
    * @param       aPID:PID
    */
   public  void  Delete (PO   aPO, PID  aPID)throws PersistenceException {
      ByteArrayOutputStream  OutputByteArray;
      ObjectOutputStream     ObjectOutputStream;
      ByteArrayInputStream   InputByteArray;
      ObjectInputStream      ObjectInputStream;
      SchemaMapper           aSchema;
      String                 aSchemaName = ((GenericPID) aPID).getSchemaName ();
      int                    aHashCode   = aPID.hashCode ();
      ReferenceHolder        aReferenceHolder = null;

      //***************************************
      // Load the schema specified in the PID
      //***************************************
      aSchema = loadSchemaMapper (((GenericPID) aPID).getSchemaName ());

      try {
	 //***************************************
	 // Create an memory output stream
	 //***************************************
	 OutputByteArray     = new ByteArrayOutputStream ();
	 ObjectOutputStream  = new ObjectOutputStream    (OutputByteArray);

	 //*****************************************************************
	 // Ask PO to stream itself only if the optimization is turned off
	 //*****************************************************************
	 if (((GenericPID) aPID).isOptimizedStore ()) {
	    aReferenceHolder = new ReferenceHolder (aPO);
	    ObjectOutputStream.writeObject (aReferenceHolder);
	    ObjectOutputStream.flush       ();
	 } else {
	    ObjectOutputStream.writeObject (aPO);
	    ObjectOutputStream.flush       ();
	 }

	 //***************************************
	 // Create an memory input stream
	 //***************************************
	 InputByteArray     = new ByteArrayInputStream (OutputByteArray.toByteArray ());
	 ObjectInputStream  = new ObjectInputStream    (InputByteArray);
      } catch (Throwable anException)  {
	 throw new PersistenceException (
					 "GenericPDS:"         +
					 anException.toString ()
					 );
      }

      try {
	 //***************************************
	 // Ask schema to store PO
	 //***************************************
	 schemaDelete    (aSchema, ObjectInputStream, (GenericPID) aPID);

	 //********************************************
	 // Remove the deleted PO from the object cache
	 //********************************************
	 removeFromCache (aSchemaName, aHashCode);
      }
      finally {
	 if (aReferenceHolder != null) {
	    aReferenceHolder.releaseReference();
	 }
      }
   }

   /**
    * This loads the objects persistent state. The persistent state
    * will not be modified unless a store or other mutating operation
    * is performed on the persistent state.
    * <p>- From the PID, obtain the schema class name that can save
    * the passed PO.</p>
    * <p>-Create a schema dynamically.</p>
    * <p>-Create an output stream.</p>
    * <p>-Forward the request to the schema passing it the result
    * stream and the PID.</p>
    * <p>- If the persistent object supports caching, an attempt is
    * made to read the object from the cache before retrieving the
    * data from the persistent store. The object cache is updated
    * following a successful restore operation.</p>
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aPO:PO
    * @param       aPID:PID
    */
   public  void  restore (PO   aPO, PID  aPID)throws PersistenceException {
      ByteArrayOutputStream  OutputByteArray;
      ObjectOutputStream     ObjectOutputStream;
      ByteArrayInputStream   InputByteArray;
      ObjectInputStream      ObjectInputStream;
      SchemaMapper           aSchema;
      String                 aSchemaName       = ((GenericPID) aPID).getSchemaName ();
      int                    aHashCode         = aPID.hashCode ();
      Object                 resultObject      = null;

      try {
	 //****************************************************************
	 // Attempt to retrieve the PO from the object cache, using the
	 // schema name and a hash code based on the PID contents as a key.
	 //****************************************************************
	 if ((resultObject = retrieveFromCache (aSchemaName,
						aHashCode)) != null) {
	    aPO.processRestoreResult(resultObject);
	    aPID.clear();
	    return;
	 }

         //***************************************
         // Load the schema specified in the PID
         //***************************************
	 aSchema = loadSchemaMapper (aSchemaName);

         //***************************************
         // Create an memory output stream
         //***************************************
	 OutputByteArray     = new ByteArrayOutputStream ();
	 ObjectOutputStream  = new ObjectOutputStream    (OutputByteArray);
      }catch (Throwable anException) {
	 anException.printStackTrace();
	 throw new PersistenceException (anException.toString());
      }

      //***************************************
      // Ask schema to restore PO
      //***************************************
      if (aPID.getParentPO() == null) {
	 aPID.setParentPO(aPO.getParent());
      }

      schemaRestore (aSchema, ObjectOutputStream, (GenericPID) aPID);

      //*********************************************
      // Create an input stream from an ouput stream
      // then ask PO to read from it.
      //*********************************************
      try {
	 ObjectOutputStream.flush ();
	 InputByteArray     = new ByteArrayInputStream (OutputByteArray.toByteArray ());
	 ObjectInputStream  = new ObjectInputStream    (InputByteArray);

	 resultObject       = ObjectInputStream.readObject ();

	 //******************************************************
	 // Check if the object represents a ReferenceHolder.
	 // Extract the real reference from the object.
	 //******************************************************
	 if (resultObject instanceof ReferenceHolder) {
            ReferenceHolder aHolder = (ReferenceHolder) resultObject;
            resultObject            = aHolder.getObjectReference ();
            aHolder.releaseReference ();
	 }

	 //*************************************************
	 // Ask PO to read its state of a PO
	 //*************************************************
	 aPO.processRestoreResult (resultObject);
	 aPO.setParent(aPID.getParentPO());
	 aPID.clear ();

	 //****************************************
	 // Add the restored PO to the object cache
	 //****************************************
	 updateCache (aSchemaName, aHashCode, resultObject);
      } catch (Throwable anException) {
	 throw new PersistenceException (
					 "GenericPDS:"         +
					 anException.toString ()
					 );
      }
   }

   /*==============================================================*/
   /* OPERATION:  disconnect                                       */
   /*                                                              */
   /**
    * This disconnects the object from the persistent state. It is
    * undefined whether or not the object is usable if not connected
    * to persistent state.
    * <p>
    * @exception PersistenceException If a persistence error occurs.
    *  
    * @param       aPO:PO
    * @param       aPID:PID
    */
   public  void  disconnect (PO   aPO, PID  aPID) throws PersistenceException {
   }

   /**
    * This connects the object to its persistent state, after
    * disconnecting any previous persistent state. The persistent
    * state may be updated as operations are performed on the object.
    * <p>
    * @exception PersistenceException If a persistence error occurs.
    *  
    * @param       aPO:PO
    * @param       aPID:PID
    * @return      :PDS -
    */
   public  PDS  connect (PO   aPO, PID  aPID) throws PersistenceException {
      return this;
   }

   /**
    * This returns whether the PDS connection corresponding to the
    * given PID is transactional.
    *  
    * @param       aPID:PID
    * @return      :boolean -
    */
   public  boolean  isTransactional (PID  aPID) {
      return false;
   }

   /**
    * This method adds the given schema name to the collection of
    * schemas whose associated persistent objects will be cached. The
    * number of objects to be cached is also specified.
    *  
    * @param       aSchemaName:String
    * @param       aNumberOfItems:int
    */
   public  void  addCachedSchemaName (String aSchemaName,int aNumberOfItems){
      objectCache.addEntry (aSchemaName, aNumberOfItems);
   }

   /**
    * This method removes the given schema name from the collection of
    * schemas whose associated persistent objects will be cached.
    *  
    * @param       aSchemaName:String
    */
   public  void  removeCachedSchemaName (String  aSchemaName) {
      objectCache.removeEntry (aSchemaName);
   }


   /*==================================================================*/
   /* Protected Operations                                             */
   /*==================================================================*/
   /**
    * This saves the objects persistent state. It's prime function is
    * to forward the store operation on to a generic schema, passing
    * it the stream and the PID. 
    * <p>
    * This method is essentially a "hook" from within the main store
    * operation. Any subclasses wishing to specialize the PDS
    * behaviour should override this method.
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aSchema:SchemaMapper
    * @param       stream:ObjectInputStream
    * @param       aPID:GenericPID
    */
   protected  void  schemaStore (SchemaMapper aSchema,
				 ObjectInputStream stream,
                                 GenericPID aPID)throws PersistenceException {
      ((GenericSchema) aSchema).store (stream, (GenericPID) aPID);
   }

   /**
    * This disconnects the object from its persistent state and
    * deletes the objects persistent data from the Datastore location
    * indicated by the PID. It's prime function is to forward the
    * delete operation on to a generic schema, passing it the stream
    * and the PID. 
    * <p>
    * This method is essentially a "hook" from within the main delete
    * operation. Any subclasses wishing to specialize the PDS
    * behaviour should override this method.
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aSchema:SchemaMapper
    * @param       stream:ObjectInputStream
    * @param       aPID:GenericPID
    */
   protected  void  schemaDelete (SchemaMapper       aSchema,
                                  ObjectInputStream  stream,
                                  GenericPID aPID) throws PersistenceException {
      ((GenericSchema) aSchema).Delete (stream, (GenericPID) aPID);
   }

   /**
    * This loads the objectss persistent state. The persistent state
    * will not be modified unless a store or other mutating operation
    * is performed on the persistent state. It's prime function is to
    * forward the restore operation on to a generic schema, passing it
    * the stream and the PID. 
    * <p>
    * This method is essentially a "hook" from within the main restore
    * operation. Any subclasses wishing to specialize the PDS
    * behaviour should override this method.
    * <p>
    * @exception PersistenceException If an error occurs.
    *  
    * @param       aSchema:SchemaMapper
    * @param       stream:ObjectOutputStream
    * @param       aPID:GenericPID
    */
   protected  void  schemaRestore (SchemaMapper        aSchema,
                                   ObjectOutputStream  stream,
                                   GenericPID          aPID)throws PersistenceException {
      ((GenericSchema) aSchema).restore (stream, (GenericPID) aPID);
   }


   /*==================================================================*/
   /* Private Operations                                               */
   /*==================================================================*/
   /**
    * This method is used internally to dynamically load a schema
    * mapper.
    *  
    * @param       schemaName:String
    * @return      :SchemaMapper -
    * @exception   PersistenceException -
    */
   private  SchemaMapper  loadSchemaMapper (String  schemaName)throws PersistenceException {
      SchemaMapper aSchema;
      
      try {
	 aSchema = (SchemaMapper) Class.forName (schemaName).newInstance ();
      } catch (Throwable anException) {
	 // 	 VisionRuntime.instance().getDispatcher().output
	 // 	 (
	 // 	  VisionRuntime.PERSISTENCE_SERVICE,
	 // 	  EventDispatcher.NPS_ERROR,
	 // 	  EventDispatcher.NPS_ERRORCLASS_CONFIGURATION,
	 // 	  0,
	 // 	  EventDispatcher.NPS_SUBSYSTEM_VISION,
	 // 	  "GenericPDS.java",
	 // 	  0,
	 // 	  "loadSchemaMapper",
	 // 	  "Loading schema mapper \"" + schemaName +
	 // 	  "\" failed: " + anException.toString()
	 // 	 );
	 // 	 replace with Log4J
         throw new PersistenceException (anException.toString ());
      }
      return aSchema;
   }

   /**
    * This method updates or adds the persistent object associated
    * with the specified schema name to the object cache. The cached
    * object is identified by the given hash code key.
    *  
    * @param       aSchemaName:String
    * @param       aHashCode:int
    * @param       anObject:Object
    */
   private  void  updateCache (String  aSchemaName,
                               int     aHashCode,
                               Object  anObject) {
      //****************************************************
      // If the specified name is found in the collection of
      // cached schemas, add the PO, along with the given
      // hash code to the cache.
      //****************************************************
      if (objectCache.containsEntry (aSchemaName) == true) 
      {
	 objectCache.addItem (aSchemaName,
			      new Integer (aHashCode),
			      anObject);
      }
   }

   /**
    * This method retrieves the persistent object associated with the
    * specified schema name and corresponding to the given hash code
    * key, from the object cache.
    *  
    * @param       aSchemaName:String
    * @param       aHashCode:int
    * @return      :Object -
    */
   private  Object  retrieveFromCache (String  aSchemaName,
                                       int     aHashCode) {
      Object  resultObject = null;

      //****************************************************
      // If the specified name is found in the collection of
      // cached schemas, attempt to retrieve the PO matching
      // the given hash code from the cache.
      //****************************************************
      if (objectCache.containsEntry (aSchemaName) == true) {
	 resultObject = objectCache.retrieveItem (aSchemaName,
						  new Integer (aHashCode));
      }   
      return resultObject;
   }

   /**
    * This method removes the persistent object associated with the
    * specified schema name and corresponding to the given hash code
    * key, from the object cache.
    *  
    * @param       aSchemaName:String
    * @param       aHashCode:int
    */
   private  void  removeFromCache (String  aSchemaName,
                                   int     aHashCode){
      //****************************************************
      // If the specified name is found in the collection of
      // cached schemas, remove the PO matching the given
      // hash code from the cache.
      //****************************************************
      if (objectCache.containsEntry (aSchemaName) == true) {
	 objectCache.removeItem (aSchemaName,
				 new Integer (aHashCode));
      }
   }


   /*==================================================================*/
   /* Class Operations                                                 */
   /*==================================================================*/
   /**
    * This method returns the object that is in the stream. If the
    * object in the stream is a reference holder, the reference to
    * which the holder refers to is returned. Otherwise the object is
    * deserialized and returned to caller.
    * <p>
    * @param       stream:ObjectInputStream
    * @return      :Object -
    * @exception   IOException -
    */
   public static  Object  getObjectFromStream (ObjectInputStream  stream)throws IOException {
      Object anObject     = null;
      Object resultObject = null;

      try {
	 anObject = stream.readObject ();
      }catch (Exception anException) {
	 // 	 VisionRuntime.instance().getDispatcher().output
	 // 	 (
	 // 	  VisionRuntime.PERSISTENCE_SERVICE,
	 // 	  EventDispatcher.NPS_ERROR,
	 // 	  EventDispatcher.NPS_ERRORCLASS_COMMUNICATION,
	 // 	  0,
	 // 	  EventDispatcher.NPS_SUBSYSTEM_VISION,
	 // 	  "GenericPDS.java",
	 // 	  0,
	 // 	  "getObjectFromStream",
	 // 	  "stream is invalid : " + anException.toString()
	 // 	 );
	 // 	 replace with Log4J

	 throw new IOException (
				"GenericPDS:"         +
				anException.toString ()
				);
      }

      if (anObject instanceof ReferenceHolder) {
	 ReferenceHolder aHolder = (ReferenceHolder) anObject;
	 resultObject = aHolder.getObjectReference ();
	 aHolder.releaseReference ();
      }else {
	 resultObject = anObject;
      }
      return resultObject;
   }
}
   
  







