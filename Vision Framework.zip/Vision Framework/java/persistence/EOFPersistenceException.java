/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

/**
 * The EOFPersistenceException class to handle reaching an End of File
 * condition (i.e., as in a mainframe vsam file)
 * Created for ticket fix PM63492
 * @author VGRUNST
 * @version 1.0, 5/19/03
 */
public class EOFPersistenceException extends PersistenceException {
        /**
         * One argument constructor for this custom persistence exception
         *  
         * @param       initialize:String
         */
    public EOFPersistenceException(String anExceptionString) {
       super (anExceptionString);
    }
}






