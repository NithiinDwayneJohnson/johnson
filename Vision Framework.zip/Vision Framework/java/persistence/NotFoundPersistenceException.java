package COM.novusnet.vision.java.persistence;

public class NotFoundPersistenceException extends PersistenceException {
    public NotFoundPersistenceException(String anExceptionString) {
       super (anExceptionString);
    }
}

