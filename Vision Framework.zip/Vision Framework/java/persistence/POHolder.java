package COM.novusnet.vision.java.persistence;


/**
This class is used to hold a reference of a PO returned from the
restore() operation. The POS needs a PO and this class acts as a
surrogate for the PO that is about to be restored. A POHolder has
a PO as its single attribute. This PO represent the PO that will
be restored by the PDS.
*/
public class POHolder extends PO {
    private PO m_PO;

    /**
    Returns a reference to the embedded PO.
    */
    public PO getPO() {
       return(m_PO);
    }

    /**
    Called by the POM when the object has been restored(). We forward
    the call to the held object in turn.
    @exception PersistenceException If a persistence error occurs.
    */
    public void post_restore()throws PersistenceException {
       m_PO.post_restore();
    }

    /**
    This method is called by a PDS when a restore operation takes place
    against an existing object. The processRestoreResult method of the
    parent must be called during the processing of this method.
    
    @exception PersistenceException If a persistence error occurs.
    */
    public void processRestoreResult(Object anObject)throws PersistenceException {
        m_PO = (PO) anObject;
    }

    /**
    Called by the POM when the object has been stored(). We forward the
    call to the held object in turn.
    
    @exception PersistenceException If a persistence error occurs.
    */
    public void post_store()throws PersistenceException {
       m_PO.post_store();    
    }

    /**
    Sets the parent PO on child PO.
    
    @param parentPO. The parent PO.
    */
    public void setParent(PO parentPO) {
       m_PO.setParent(parentPO);    
    }

}

