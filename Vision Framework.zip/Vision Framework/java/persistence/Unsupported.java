package COM.novusnet.vision.java.persistence;

/**
 * The persistence unsupported exception.
*/
public class Unsupported extends PersistenceException {

   /**
    *    The constructor to this exception.
    */
   public Unsupported(String exceptionString) {
      super (exceptionString);
   }

}

