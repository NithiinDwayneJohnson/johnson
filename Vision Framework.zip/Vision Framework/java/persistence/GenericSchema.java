/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * This is the generic schema mapper interface. Every generic schema mapper
 * subclass must extend this class. A mapper is needed for the following
 * reasons:
 * <p>- Handle the different data formats of the object and the data
 * store.</p>
 * <p>- Execute as many data store specific transactions so a PO can be
 * properly stored or restored.</p>
 * <p>
 *  A schema mapper knows about the internal structure of a PO and can be
 * treated as trusted code.
 */
public abstract interface  GenericSchema  extends  SchemaMapper {
   /**
    * This method is called by the PDS to store the state of a PO. The
    * method receives an input stream that contains the PO's state and
    * a PID that has any specific keys if needed. The client of the PO
    * must supply any key information in the PID. The implmentation of
    * store should call getObjectFromStream() on the PDS to obtain the
    * reference to the object in the stream.
    * <p>
    * @exception PersistenceException If a persistence error occurs.
    *  
    * @param       stream:ObjectInputStream
    * @param       aPID:GenericPID
    */
   public abstract  void  store (ObjectInputStream stream, GenericPID aPID)
     throws PersistenceException;

   /**
    * This method is called by the PDS to delete the state of a PO.
    * The method receives a PID that has any specific keys if needed.
    * The client of the PO must supply any key information in the PID.
    * <p>
    * @exception PersistenceException If a persistence error occurrs.
    *  
    * @param       stream:ObjectInputStream
    * @param       aPID:GenericPID
    */
   public abstract  void  Delete (ObjectInputStream stream, GenericPID aPID)
     throws PersistenceException;

   /**
    * This method is called by the PDS to restore the state of a PO.
    * The method receives an output stream that the schem should use
    * to the write the state of the restored PO into. The PID contains
    * any specific keys needed for the restore operation. The client
    * of the PO must supply any key information in the PID
    * <p>
    * @exception PersistenceException If a persistence error occurrs.
    *  
    * @param       stream:ObjectOutputStream
    * @param       aPID:GenericPID
    */
   public abstract  void  restore (ObjectOutputStream stream, GenericPID aPID)
     throws PersistenceException;

}

