/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import java.io.Serializable;
/**
 * The Key Descriptor is an interface which allows the key values required
 * to restore a Persistent Object to be encapulated. Persistent Object
 * (typically Business Object) subclasses should implement this interface
 * in order to define the key value attributes to be passed to the schema
 * via a pid.
 * @version 1.0, 5/1/97
 */
public interface  KeyDescriptor  extends  Serializable {
}
