package COM.novusnet.vision.java.persistence;

import java.util.Hashtable;
import java.util.Vector;


/**
 * The major function of the POM (Persistent Object Manager) is to route
 * requests to a PDS that can support the combination of Protocol and
 * Datastore needed by the persistent object. To do this, the POM must
 * know which PDSs are available and which Protocol and Datastore combinations
 * they support. There are several possible ways that this information
 * can be made available to a POM:
 * <P>
 * 1) How a Protocol is associated with an object. One possibility
 * is for the client to set the Protocol for that object. Another possibility
 * is for the Protocol to be associated with the object�s type or implementation.
 * <P>
 * 2)
 * How a POM finds out the set of available PDSs and which Protocol
 * (or object type) and Datastores they support. One possibility is
 * for the POM to find the information in a configuration file or a
 * registry. Another possibility is to provide an interface to the POM
 * for registering the information. The best or most natural technique
 * may depend on the environment.
 * 
 * Because there are multiple ways to accomplish the above and more
 * experience is needed to better understand whether there is a best
 * way and what that might be, a POM interface for registering this
 * information in the POM is not specified at this time.
 * 
 * When the POM is asked to store an object, the following steps logically
 * occur:
 * 
 * <P>1. From the PID, the POM gets the datastore_type attribute.
 * <P>2.
 * The POM uses the datastore_type to determine the PDS. The PDS is
 * loaded dynamically. Only one copy of a given PDS type is loaded in
 * this implementation.
 * <P>3. The POM passes the store request through to the PDS.
 * <P>4.
 * The PDS gets data from the object using a Protocol and stores the
 * data in the Datastore.
 * 
 * <P>
 * The routing function of the POM serves to shield the client
 * from having to know the details of how actual data storage/retrieval
 * takes place. A client can change the repository of an object by changing
 * the PID. The change will result in routing the next store/restore
 * request to whatever the appropriate PDS is for the new Datastore.
 * Clients of a PO will see the operations of the POM interface indirectly
 * through the PO interface. The implementation of a persistent object
 * with either externally or internally controlled persistence can use
 * the POM interface. The POM provides a uniform interface across all
 * PDSs, so different PDSs (combination of Datastore and Protocol) can
 * be used without changing the object�s implementation.
 * 
 * There is only one copy of a POM in a given system. A reference
 * to this copy can be obtained by calling the instance() method.
*/
public class POM {

   /**
    *    Constant that represents a restore operation.
    */
   private static final int s_RESTORE_STARTED_EVENT = 0;
   /**
    *    Constant that represents a restore operation.
    */
   private static final int s_RESTORE_ENDED_EVENT = 1;
   /**
    *    Constant that represents a store operation.
    */
   private static final int s_STORE_STARTED_EVENT = 2;
   /**
    *    Constant that represents a store operation.
    */
   private static final int s_STORE_ENDED_EVENT = 3;
   /**
    *    Constant that represents a delete operation.
    */
   private static final int s_DELETE_STARTED_EVENT = 4;
   /**
    *    Constant that represents a delete operation.
    */
   private static final int s_DELETE_ENDED_EVENT = 5;
   public Hashtable m_PDSList;
   private static POM s_POM;
   private Vector m_listeners = new Vector();

   static {
      s_POM = new POM();
   }

   /**
    *    This gets the persistent data out of the object in memory and puts
    *    it in the Datastore location indicated by the PID. After a store()
    *    method, the POM calls the post_restore() method on a PO.
    *    
    *    The POM uses the data store type in the PID to load the proper
    *    PDS.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void store(PO aPO, PID aPID)throws PersistenceException {
      try {
	 firePOMEvent(s_STORE_STARTED_EVENT);
	 aPO.pre_store();
	 if (!aPO.isNoStore()) {
	    getAppropriatePDS(aPID).store(aPO, aPID);
	 }
	 aPO.post_store();       
      }
      finally {
	 firePOMEvent(s_STORE_ENDED_EVENT);
      }
   }

   /**
    *    This deletes the object�s persistent data from the Datastore location
    *    indicated by the PID. The PID can be nil.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void Delete(PO aPO, PID aPID)throws PersistenceException {
      try {
	 firePOMEvent(s_DELETE_STARTED_EVENT);
	 aPO.pre_delete();
	 getAppropriatePDS(aPID).Delete(aPO, aPID);    
	 aPO.post_delete();       
      }
      finally {
	 firePOMEvent(s_DELETE_ENDED_EVENT);
      }
   }

   /**
    *    This gets the object�s persistent data from the Datastore location
    *    indicated by the PID and inserts it into the object in memory. The
    *    PID can be nil. Before a restore() operation, the POM calls the pre_restore()
    *    method on a BO.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void restore(PO aPO, PID aPID)throws PersistenceException {
      try {	 
	 firePOMEvent(s_RESTORE_STARTED_EVENT);
	 ActiveRestoreManager.activateRestore();
	 aPO.pre_restore();
	 getAppropriatePDS(aPID).restore(aPO, aPID);
	 aPO.post_restore();        	
      }
      finally {
	 firePOMEvent(s_RESTORE_ENDED_EVENT);
	 ActiveRestoreManager.deActivateRestore();
      }
   }

   /**
    *    This ends a connection between the data in the object and the Datastore
    *    location indicated by the PID. It is undefined whether or not the
    *    object is usable if not connected to persistent state. The PID can
    *    be nil.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public void disconnect(PO aPO, PID aPID)throws PersistenceException {
      getAppropriatePDS(aPID).disconnect(aPO, aPID);    
   }

   /**
    *    This begins a connection between data in the object and the Datastore
    *    location indicated by the PID. The persistent state may be updated
    *    as operations are performed on the object. This operation returns
    *    the PDS that is assigned the object�s PID for use by those Protocols
    *    that require the PO to call the PDS.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   public PDS connect(PO aPO, PID aPID)throws PersistenceException {
      return(getAppropriatePDS(aPID).connect(aPO, aPID));    
   }

   /**
    *    This method returns a PDS suitable for use by the PO. The PID supplied
    *    by the persistent operations determines the suitability.
    *    
    *    @exception PersistenceException If a persistence error occurs.
    */
   protected synchronized PDS getAppropriatePDS(PID aPID)throws PersistenceException {
    
      PDS aPDS = null;
      
      //**************************************************************//
      // Obtain the PDS class type from the PID.                      //
      //**************************************************************//
      String  aPDSType = aPID.getdatastore_type();
          
      //**************************************************************//
      // If the PDS is in our Hashtable then reuse that PDS, otherwise//
      // create a new PDS, intialize it and then insert it in the     //
      // hashtable.                                                   //
      //**************************************************************//
           
      try {
         if ( (aPDS = (PDS) m_PDSList.get(aPDSType)) == null) {
            aPDS = (PDS) Class.forName(aPDSType).newInstance();
            m_PDSList.put(aPDSType, aPDS);
         }  
      } 
      catch(Exception anException) {
	 //          VisionRuntime.instance().getDispatcher().output 
	 //                                (
	 //                                 VisionRuntime.PERSISTENCE_SERVICE,
	 //                                 EventDispatcher.NPS_ERROR,
	 //                                 EventDispatcher.NPS_ERRORCLASS_CONFIGURATION,
	 //                                 0,
	 //                                 EventDispatcher.NPS_SUBSYSTEM_VISION,
	 //                                 "POM.java", 
	 //                                 0, 
	 //                                 "getAppropriatePDS", 
	 //                                 "Could not load PDS class: " + aPDSType
	 //                                );
      
         throw new PersistenceException("Could not load PDS class " + aPDSType);
      }
      
      return(aPDS);
   }

   /**
    *    Returns the singleton instance of the POM.
    */
   public static POM instance() {
      return(s_POM);
   }

   /**
    *    The private constructor for the POM class. It is private so that
    *    instance creation is forced to go through the static instance() method.
    */
   private POM() {
      m_PDSList = new Hashtable();
   }

   /**
    *  Adds a listener to the POM. The listener will get notified when the
    *  PO is restored, stored or deleted.
    */
   public void addPOMListener(POMListener l) {
      if (m_listeners == null) {
	 m_listeners = new Vector();
      }

      m_listeners.addElement(l);
   }

   /**
    * Removed a PO listener.
    */
   public void removePOMListener(POMListener l) {
      m_listeners.removeElement(l);
   }

   /**
    * Fires an event based on the event ID. This method calls the proper
    *    handler on the listener interface.
    */
   protected void firePOMEvent(int eventID) {
      if (m_listeners == null) {
	 return;
      }

      Vector listeners = (Vector) m_listeners.clone();

      for (int i = 0; i < listeners.size() ; i++) {

	 POMListener aListener = (POMListener)listeners.elementAt(i);

	 switch (eventID) {
	    case s_RESTORE_STARTED_EVENT:
	       aListener.restoreStarted( new POMEvent(this) );
	       break;

	    case s_RESTORE_ENDED_EVENT:
	       aListener.restoreEnded( new POMEvent(this) );
	       break;

	    case s_STORE_STARTED_EVENT:
	       aListener.storeStarted( new POMEvent(this) );
	       break;

	    case s_STORE_ENDED_EVENT:
	       aListener.storeEnded( new POMEvent(this) );
	       break;

	    case s_DELETE_STARTED_EVENT:
	       aListener.deleteStarted( new POMEvent(this) );
	       break;

	    case s_DELETE_ENDED_EVENT:
	       aListener.deleteEnded( new POMEvent(this) );
	       break;
	 }
      }
   }

}

