package COM.novusnet.vision.java.persistence;

/**
 * This is the JDBC subclass of a schema PID. It sets the data store
 * type to "JDBCPDS" in its constructor.
 * @version 1.0, 5/1/97
 */
public class JDBCPersistenceIdentifier extends GenericPID {
   /**
    *    The JDBC connection string.
    */
   private String m_connectionString = null;

   /**
    *    This is the JDBC implementation of a PID. It simply sets the PDS
    *    type to " JDBCPDS".
    *
    */
   public JDBCPersistenceIdentifier() {
      setdatastore_type("COM.novusnet.vision.java.persistence.JDBCPersistenceDataService");
   }

   /**
    *    Sets the JDBC connection string.
    */
   public void setConnectionString(String aConnectionString) {
      m_connectionString = aConnectionString;
   }

   /**
    *    Returns the JDBC connection string.
    */
   public String getConnectionString() {
      return(m_connectionString);
   }
}


