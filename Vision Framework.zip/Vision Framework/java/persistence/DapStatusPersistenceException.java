package COM.novusnet.vision.java.persistence;

public class DapStatusPersistenceException
	extends PersistenceException {
		
	private String dapStatusCode = " ";
	
	public DapStatusPersistenceException(String s) {super(s);}
		
	public DapStatusPersistenceException(String s1, String s2) {
		super(s1);
		dapStatusCode = s2;
	}
	
	public String getDapStatusCode() {
    
      return dapStatusCode;    
    }
}