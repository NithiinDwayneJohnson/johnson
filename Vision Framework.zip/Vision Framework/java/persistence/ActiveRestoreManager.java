package COM.novusnet.vision.java.persistence;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Used by POM to indicate that a restore operation is currently active
 * and it is used by BusinessObject to check whether a restore operation is 
 * currently active.
 * The setDirty methods within BusinessObject will return without performing 
 * any operations while we are within the context of a Restore operation. 
 * Typically when an attribute of a BusinessObect changes we want to mark it 
 * as dirty and perhaps get involved in a transaction. However when we are 
 * in the middle of a restore operation and we are creating the BusinessObject
 * and calling the set attribute methods to move the data from the ResultSet 
 * into the new BusinessObject then we do not need to mark each attribute as
 * dirty.
 * @version 1.0, 5/1/97
 */
public class ActiveRestoreManager {

	//private static Set s_suspendedThreads = Collections.synchronizedSet(new HashSet());
	
	private static List s_suspendedThreads = Collections.synchronizedList(new LinkedList());

	/** 
	 * Returns a boolean to indicate if a restore operation is currently
	 * active or not.
	 */
	public static boolean isRestoreActive() {
		return s_suspendedThreads.contains(Thread.currentThread());
	}

	/**
	 * Indicate that we are currently performing an active restore operation
	 * on this thread.
	 */
	public static void activateRestore() {
		s_suspendedThreads.add(Thread.currentThread());
	}

	/**
	 * Indicate that we have finished performing the restore operation
	 * on this thread.
	 */
	public static void deActivateRestore() {
		s_suspendedThreads.remove(Thread.currentThread());
	}

}
