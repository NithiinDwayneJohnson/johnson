/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.persistence;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import COM.novusnet.vision.java.utility.runtime.VisionRuntime;

/**
 * The connection manager is responsible for establishing, caching and
 * closing JDBC connections. Connections are created on a per-transaction
 * context basis (typically per-thread). Both a short-term and a long-term
 * cache are used for holding established connections.
 * <p>
 * The short-term cache is used to hold all connections for which there is
 * an active transaction. Connections will be added to the cache at the
 * time of the transaction begin and removed at the time of the transaction
 * commit/rollback.
 * <p>
 * The long-term cache holds long-lived connections and is used to avoid
 * repeatedly reestablishing JDBC connections for a given URL.
 */
public class ConnectionManager {

	static boolean DEBUG = false;

	private Map longTermCache = Collections.synchronizedMap(new HashMap());
	private Map shortTermCache = Collections.synchronizedMap(new HashMap());

	/**
	 * This is the singleton instance of the ConnectionCache
	 * class. It is created by static initialization when the
	 * class is first loaded.
	 */
	private static COM.novusnet.vision.java.persistence.ConnectionManager singleton =
		new ConnectionManager();

	/**
	 * This method returns a JDBC connection instance given a URL and a
	 * transaction Control instance.
	 *  
	 * @param       aURL:java.lang.String
	 *                 the URL connection string used to establish the
	 *                 JDBC connection
	 * @param      
	 * aControl:COM.novusnet.vision.java.transactions.Control
	 *                 the transaction Control instance representing
	 *                 the current transaction context
	 * @return      :java.sql.Connection -
	 *                 the JDBC connection corresponding to the given
	 *                 URL and transaction context
	 */
	//    public  java.sql.Connection  getConnection (java.lang.String aURL,
	//                                                COM.novusnet.vision.java.transactions.Control  aControl) {
	public java.sql.Connection getConnection(
		java.lang.String aURL,
		Object aControl) {
		Connection connection = null;

		//==============================================================
		// Obtain a JDBC connection for the given URL. First search
		// the short and long term caches for a matching connection.
		// If none is found, establish a new connection and add it
		// to the cache(s).
		//==============================================================
		try {
			if ((connection = findCachedConnection(aURL, aControl)) == null) {
				//======================================================
				// No cached connection was found - establish a new
				// connection
				//======================================================
				Enumeration enum = DriverManager.getDrivers();
				while (enum.hasMoreElements()) {
					Driver d = (Driver) enum.nextElement();
				}
				System.out.println(
					"URL = "
						+ aURL
						+ " UserName: "
						+ VisionRuntime.instance().getUserName()
						+ " Password : "
						+ VisionRuntime.instance().getUserName());

				connection =
					DriverManager.getConnection(
						aURL,
						VisionRuntime.instance().getUserName(),
						VisionRuntime.instance().getPassword());

				//======================================================
				// Disable auto-commit and add the newly established 
				// connection to the cache(s).
				//======================================================
				connection.setAutoCommit(false);
				addCachedConnection(aURL, aControl, connection);
			} else {
				System.out.println(
					"Using cached connection.           !!!!!!!!!!!");
			}
		} catch (Throwable anException) {
			// 	 VisionRuntime.instance().getDispatcher().output
			//                                (
			//                                 VisionRuntime.PERSISTENCE_SERVICE,
			//                                 EventDispatcher.NPS_ERROR,
			//                                 EventDispatcher.NPS_ERRORCLASS_COMMUNICATION,
			//                                 0,
			//                                 EventDispatcher.NPS_SUBSYSTEM_VISION,
			//                                 "ConnectionManager.java",
			//                                 0,
			//                                 "getConnection",
			//                                 "Error getting JDBC connection for \"" + aURL +
			//                                 "\" failed: " + anException.toString()
			//                                );
			//	 replace with Log4J
			throw new PersistenceException(
				"ConnectionManager:" + anException.toString());
		}
		return connection;
	}

	/**
	 * This method returns the JDBC connection instance for the current
	 * transaction context.
	 *  
	 * @param      
	 * aControl:COM.novusnet.vision.java.transactions.Control
	 *                 the transaction Control instance representing
	 *                 the current transaction context
	 * @return      :java.sql.Connection -
	 *                 the JDBC connection associated with the given
	 *                 transaction context
	 */
	//    public  java.sql.Connection  getConnection (COM.novusnet.vision.java.transactions.Control  aControl) {
	public java.sql.Connection getConnection(Object aControl) {
		return (Connection) shortTermCache.get(aControl);
	}

	/**
	 * Releases the given connection. The connection is removed from
	 * the short-term cache, marked as unused in the long-term cache
	 * and then closed.
	 *  
	 * @param       aConnection:java.sql.Connection
	 *                 the JDBC connection to be released
	 */
	void releaseConnection(java.sql.Connection aConnection) {
		//==============================================================
		// Search the short-term cache for the given connection. If it
		// is found, remove it from the cache.
		//==============================================================
		Iterator itr = shortTermCache.values().iterator();
		while (itr.hasNext()) {
			Connection connection = (Connection) itr.next();

			//======================================================
			// Connection was found - remove it
			//======================================================
			if (connection == aConnection) {
				itr.remove();
				break;
			}
		}

		//==============================================================
		// Search the long-term cache for the given connection. If it
		// is found, mark the cache entry as unused.
		//==============================================================
		itr = longTermCache.values().iterator();
		while (itr.hasNext()) {
			ConnectionCacheItem cachedItem = (ConnectionCacheItem) itr.next();

			//======================================================
			// Connection was found - mark the cached item as unused
			//======================================================
			if (cachedItem.getConnection() == aConnection) {
				cachedItem.setControl(null);
				return;
			}
		}

		//==============================================================
		// Close the specified connection
		//==============================================================
		try {
			if (!aConnection.isClosed())
				aConnection.close();
		} catch (SQLException e) {
			// Rethrow as appropriate exception type
		}
	}

	/**
	 * Searches first the short-term cache and then the long-term cache
	 * for a connection corresponding to the given URL and transaction
	 * context.
	 *  
	 * @param       aURL:java.lang.String
	 * @param      
	 * aControl:COM.novusnet.vision.java.transactions.Control
	 * @return      :java.sql.Connection -
	 */
	//    private  java.sql.Connection  findCachedConnection (java.lang.String  aURL,
	//                                                        COM.novusnet.vision.java.transactions.Control  aControl) {
	private java.sql.Connection findCachedConnection(
		java.lang.String aURL,
		Object aControl) {
		Connection connection = null;
		ConnectionCacheItem cacheItem = null;

		//==============================================================
		// Search the short-term cache for the connection associated
		// with the current transaction context.
		//==============================================================
		if (aControl != null
			&& (connection = (Connection) shortTermCache.get(aControl)) != null) {
			return connection;
		}

		//==============================================================
		// If there is no connection associated with the current 
		// transaction context, search the long-term cache for a
		// connection for the given URL. The cached connection should
		// either be associated with the current context or unused.
		//==============================================================
		if ((cacheItem = (ConnectionCacheItem) longTermCache.get(aURL))
			!= null) {
			if (cacheItem.getControl() == aControl
				|| cacheItem.getControl() == null) {
				try {
					if (cacheItem.getConnection().isClosed()) {
						longTermCache.remove(cacheItem);
						return null;
					}
				} catch (SQLException e) {
					longTermCache.remove(cacheItem);
					return null;
				}

				cacheItem.setControl(aControl);
				return cacheItem.getConnection();
			}
		}
		return null;
	}

	/**
	 * Adds the given connection to the short-term cache, associated
	 * with the specified transaction context. If there is an avaialble
	 * unused slot, it will also be added to the long-term cache,
	 * associated with the specified URL and transaction context.
	 *  
	 * @param       aURL:java.lang.String
	 * @param      
	 * aControl:COM.novusnet.vision.java.transactions.Control
	 * @param       aConnection:java.sql.Connection
	 */
	//    private  void  addCachedConnection (java.lang.String aURL,
	//                                        COM.novusnet.vision.java.transactions.Control  aControl,
	//                                        java.sql.Connection                            aConnection){
	private void addCachedConnection(
		java.lang.String aURL,
		Object aControl,
		java.sql.Connection aConnection) {
		ConnectionCacheItem cacheItem = null;

		//==============================================================
		// Add the connection associated with the current transaction 
		// context to the short-term cache.
		//==============================================================
		if (aControl != null) {
			shortTermCache.put(aControl, aConnection);
		}

		//==============================================================
		// If there is no connection in the long-term cache that was
		// established for the given URL, add the connection along
		// with the current transaction context.
		//==============================================================
		if ((cacheItem = (ConnectionCacheItem) longTermCache.get(aURL))
			== null) {
			longTermCache.put(
				aURL,
				new ConnectionCacheItem(aControl, aConnection));
		}
	}

	/**
	 * This method returns the singleton ConnectionManager instance. 
	 *  
	 * @return     
	 * :COM.novusnet.vision.java.persistence.ConnectionManager -
	 *                 The singleton ConnectionManager instance.
	 */
	public static final COM.novusnet.vision.java.persistence.ConnectionManager instance() {
		return singleton;
	}

	/*==================================================================*/
	/*=========================               ==========================*/
	/*========================= Inner Classes ==========================*/
	/*=========================               ==========================*/
	/*==================================================================*/

	/**
	 * This class is used to hold a cached JDBC connection along with its
	 * associated transaction context.
	 */
	public class ConnectionCacheItem {
		private java.sql.Connection connection = null;
		//       private COM.novusnet.vision.java.transactions.Control control    = null;
		private Object control = null;

		/**
		 * The connection cache item constructor.
		 *  
		 * @param      
		 * aControl:COM.novusnet.vision.java.transactions.Control
		 * @param       aConnection:java.sql.Connection
		 */
		//       public    ConnectionCacheItem (COM.novusnet.vision.java.transactions.Control  aControl,
		// 				     java.sql.Connection aConnection){
		public ConnectionCacheItem(
			Object aControl,
			java.sql.Connection aConnection) {
			connection = aConnection;
			control = aControl;
		}

		/**
		 * This method returns the value of the cached JDBC connection.
		 *  
		 * @return      :java.sql.Connection -
		 *                 The value of the cached JDBC connection.
		 */
		public java.sql.Connection getConnection() {
			return (connection);
		}

		/**
		 * This method returns the value of the transaction context
		 * associated with the cached JDBC connection.
		 *  
		 * @return      :COM.novusnet.vision.java.transactions.Control
		 * -
		 *                 The value of the transaction context
		 *                 associated with the cached JDBC connection.
		 */
		//       public  COM.novusnet.vision.java.transactions.Control  getControl () {
		public Object getControl() {
			return (control);
		}
		/**
		 * This method sets the value of the cached JDBC connection.
		 *  
		 * @param       aValue:java.sql.Connection
		 *                 The value of the cached JDBC connection.
		 */
		public void setConnection(java.sql.Connection aValue) {
			connection = aValue;
		}

		/**
		 * This method sets the value of the transaction context
		 * associated with the cached JDBC connection.
		 *  
		 * @param      
		 * aValue:COM.novusnet.vision.java.transactions.Control
		 *                 The value of the transaction context
		 *                 associated with the cached JDBC connection.
		 */
		//       public  void  setControl (COM.novusnet.vision.java.transactions.Control  aValue) {
		public void setControl(Object aValue) {
			control = aValue;
		}

		/*==============================================================*/
		/* Base Class Override Operations                               */
		/*==============================================================*/
		/**
		 * This method determines whether or not this object is
		 * functionally equal to another specified object.
		 *  
		 * @param       aObject:Object
		 *                 The object instance to be compared to this
		 *                 one.
		 * @return      :boolean -
		 *                 true, if the two objects are of the same
		 *                 type and equal; false, otherwise.
		 */
		public boolean equals(Object aObject) {
			/*======================================================*/
			/* References are to the same object - they are equal   */
			/*======================================================*/
			if (this == aObject) {
				return (true);
			}

			/*======================================================*/
			/* Comparison object null (but "this" object cannot be) */
			/*======================================================*/
			if (aObject == null) {
				return (false);
			}

			/*======================================================*/
			/* Classes are different - objects can't be equal       */
			/*======================================================*/
			if (ConnectionCacheItem.class != aObject.getClass()) {
				return (false);
			}

			/*======================================================*/
			/* Check the equality of superclasses                   */
			/*======================================================*/
			if (!super.equals(aObject)) {
				return (false);
			}

			/*======================================================*/
			/* Compare the individual attributes                    */
			/*======================================================*/
			ConnectionCacheItem myOther = (ConnectionCacheItem) aObject;

			try {
				Connection myConnection = getConnection();
				if (myConnection != null) {
					if (!(myConnection.equals(myOther.getConnection()))) {
						return (false);
					}
				}
			} catch (Throwable myThrowable) {
				throw new RuntimeException(
					"ConnectionCacheItem::equals: " + myThrowable.toString());
			}
			return (true);
		}

		/**
		 * This method determines a hash code value for this object
		 * instance.
		 *  
		 * @return      :int -
		 *                 The calculated hash code value.
		 */
		public int hashCode() {
			int myHashCode = 0;

			try {
				myHashCode = super.hashCode();
				Connection myConnection = getConnection();
				if (myConnection != null) {
					myHashCode += (37 * myHashCode) + (myConnection.hashCode());
				}
			} catch (Throwable myThrowable) {
				throw new RuntimeException(
					"ConnectionCacheItem::hashCode: " + myThrowable.toString());
			}
			return (myHashCode);
		}

		/**
		 * This method is used to print out the current state of this
		 * object instance.
		 *  
		 */
		public void printOut() {
			try {
				System.out.println("ConnectionCacheItem:");
				System.out.println("   connection: " + getConnection());
				System.out.println("   control: " + getControl());
			} catch (Throwable myThrowable) {
				myThrowable.printStackTrace();
				throw new RuntimeException(myThrowable.toString());
			}
		}
	}

}
