/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.helpers;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.util.Enumeration;

/**
 * This class provides methods to manipulate class and package names.
 *
 * @version 1.0, 5/1/98
 * 
 * This class was provided primarily to assist with code 
 * generation. Since the COM.novusnet.cogent packages are being eliminated
 * Q3, 2004. All other use of this class should be eliminated also.
 */
public  class  ClassHelper {
   /**
    * Return the classname with out the package qualifier.
    * <br>For example: 
    * <br>Integer myInt = new Integer(10);
    * <br>String className = getClassOnlyName(myInt);
    * <br>'className' will contain the string "Integer" not "java.lang.Integer"
    * <br>
    * @param       Object
    * @return      String 
    */
   public static final  String  getClassOnlyName (Object  aObject){
      String myClassName = aObject.getClass().getName();
      return getClassNameFromTypeString(myClassName);
   }

   /**
    * Return an instantiated object of the type specified by the supplied
    * fully-qualified class name 
    * <br>For Example:
    * <br>Object  myObject = ClassHelper.createObjectByName ("java.lang.Object");
    * <br>
    * @param       aClassName:String
    *                 The class name of the object to be instantiated.
    * @return      :Object -
    *                 The instantiated object of the specified class
    *                 name.
    * @exception   InstantiationException 
    *                 The class, as specified, could not be
    *                 instantiated.
    * @exception   IllegalAccessException 
    *                 The class attempting to instantiate this class
    *                 does not have access to the class, because it
    *                 either does not have a public constructor, or it
    *                 is in a different package.
    * @exception   ClassNotFoundException 
    *                 A class of the specified name could not be
    *                 found.
    */
   public static final  Object  createObjectByName (String  aClassName )
     throws InstantiationException,
	    IllegalAccessException,
	    ClassNotFoundException  {
      Class  myClass = Class.forName (aClassName);
      return (myClass.newInstance ());
   }

   /**
    * Return an instantiated object of the type specified by the supplied
    * class name, using the first class with this name found in the supplied
    * package list.
    * <br>For Example:
    * <br>myObject = ClassHelper.createObjectByName ("Object", "java.math;java.lang");
    * <br>
    * @param       aClassName:String
    *                 The class name of the object to be instantiated.
    * @param       aPackageList:String
    *                 A lsit of the package names to be searched .
    * @return      :Object -
    *                 The instantiated object of the specified class
    *                 name.
    * @exception   InstantiationException 
    *                 The class, as specified, could not be
    *                 instantiated.
    * @exception   IllegalAccessException 
    *                 The class attempting to instantiate this class
    *                 does not have access to the class, because it
    *                 either does not have a public constructor, or it
    *                 is in a different package.
    * @exception   ClassNotFoundException 
    *                 A class of the specified name could not be
    *                 found.
    */
   public static final  Object  createObjectByName (String  aClassName,
                                                    String  aPackageList)
     throws ClassNotFoundException, 
	    InstantiationException,
	    IllegalAccessException {
      String          myPackageList   = aPackageList;
      Class           myClass = null;
      int             myIndex         = 0;

      /*======================================================*/
      /* First try to instantiate the class, as is            */
      /*======================================================*/
      try {
	 return createObjectByName(aClassName);
      }catch (ClassNotFoundException e) {
	 // we can swallow this exception because it is ok that we did not 
	 // find this class yet.
      }catch (InstantiationException e) {
	 // we should throw this exception because we have found the class
	 // that was requested however we do not have enough information to 
	 // create a new instance of it.
	 throw e;
      }catch (IllegalAccessException e) {
	 // we should throw this exception because we have found the class
	 // that was requested however we tried to load in the class, but 
	 // did not have access to the definition of the specified class, 
	 // because the class is not public and in another package or because
	 // we tried to create an instance of a class using the newInstance 
	 // method and we not have access to the appropriate zero-argument
	 // constructor. 
	 throw e;
      }

      /*======================================================*/
      /* Now try each of the package prefixes, in turn        */
      /*======================================================*/
      while (myPackageList.length () > 0) {

	 String          myPackage;
	 String          myClassName;

	 /*==============================================*/
	 /* Strip off the next package in the list       */
	 /*==============================================*/
         myIndex = myPackageList.indexOf (';');
         if (myIndex == -1) {
            myIndex = myPackageList.length ();
         }
         myPackage   = myPackageList.substring (0, myIndex);
         myClassName = myPackage + "." + aClassName;

	 /*==============================================*/
	 /* Instantiate the package/class if possible    */
	 /*==============================================*/
	 try {
	    return createObjectByName(myClassName);
	 }catch (ClassNotFoundException e) {
	    // we can swallow this exception because it is ok that we did not 
	    // find this class yet.
	 }catch (InstantiationException e) {
	    // we should throw this exception because we have found the class
	    // that was requested however we do not have enough information to 
	    // create a new instance of it.
	    throw e;
	 }catch (IllegalAccessException e) {
	    // we should throw this exception because we have found the class
	    // that was requested however we tried to load in the class, but 
	    // did not have access to the definition of the specified class, 
	    // because the class is not public and in another package or because
	    // we tried to create an instance of a class using the newInstance 
	    // method and we not have access to the appropriate zero-argument
	    // constructor. 
	    throw e;
	 }
 
	 /*==============================================*/
	 /* Move on to the next package in the list      */
	 /*==============================================*/
         if (myIndex < myPackageList.length ()) {
            myPackageList = myPackageList.substring (myIndex + 1);
         }
         else {
            myPackageList = "";
         }
      }

      /*======================================================*/
      /* Class could not be instantiated - throw exception    */
      /*======================================================*/
      throw new ClassNotFoundException (
                                        "Class \""                  +
                                        aClassName                  +
                                        "\" not found in packages " +
                                        aPackageList
					);
   }

   /**
    * Return the classname from the supplied fully qualified classname.
    * <br>For example: 
    * <br>String className = getClassNameFromTypeString("java.lang.Integer");
    * <br>'className' will contain the string "Integer"
    * <br>
    * @param       aType:String
    * @return      :String 
    */
   public static final  String  getClassNameFromTypeString (String  aType) {
      return (aType.substring ((aType.lastIndexOf ('.') + 1)));
   }

   /**
    * Gets the application name from a class. 
    * <br>This method assumes that the classname follows the naming convention
    * 'com.novusnet.cms.java.products' where 'com.novusnet.cms' represents the 
    * the application name and 'java.products' represents the function name or 
    * description.
    * <br>
    * @param       aClass:Class
    * @return      :String -
    */
   public static  String  getApplicationNameFromClass (Class  aClass) {
      String appName = aClass.getName ();
      int    index   = 0;
      
      for (int i = 0; i < 3; i++) {
	 index = appName.indexOf ('.', index);
	 if (index >= 0) {
	    index++;
	 }
	 else {
	    return null;
	 }
      }
      
      return appName.substring (0, index - 1);
   }


   /**
    * Get the method that best matchs the method name supplied in the class
    * supplied or its ancestors. It also adjusts for parameterTypes ancestors.
    * <br>For example:
    * <br> Class[] myArray = {String.class, Integer.class};
    * <br> Method myMethod = ClassHelper.getClosestMatchingMethod("getInteger", Integer.class, myArray);
    * <br>
    * @param       methodName:String
    * @param       anObjectClass:Class
    * @param       parametersType:Class[]
    * @return      :Method -
    */
   public static  Method  getClosestMatchingMethod (
                                                    String   methodName,
                                                    Class    anObjectClass,
                                                    Class[]  parametersType
						    ) {
      Method          aMethod    = null;
      boolean         bFound     = false;

      try {
         aMethod = anObjectClass.getMethod(methodName , 
					   parametersType);
      } catch(NoSuchMethodException n) {

	 Object clone = null;

	 //===========================================================================
	 // Replace all Wrapper classes (if any) with their equivelant class objects.
	 //===========================================================================
	 if ((parametersType != null) && (parametersType.length > 0)) {

	    clone = parametersType.clone();

	    for (int i = 0; i < parametersType.length ;i++) {

	       if (parametersType[i] == Integer.class) {
		  parametersType[i] = Integer.TYPE;
	       }
	       else if (parametersType[i] == Boolean.class) {
		  parametersType[i] = Boolean.TYPE;
	       }
	       else if (parametersType[i] == Byte.class) {
		  parametersType[i] = Byte.TYPE;
	       }	       
	       else if (parametersType[i] == Float.class) {
		  parametersType[i] = Float.TYPE;
	       }	       
	       else if (parametersType[i] == Double.class) {
		  parametersType[i] = Double.TYPE;
	       } 
	       else if (parametersType[i] == Long.class) {
		  parametersType[i] = Long.TYPE;
	       }	       
	       else if (parametersType[i] == Short.class) {
		  parametersType[i] = Short.TYPE;
	       }	       
	    }

	    try {
	       aMethod = anObjectClass.getMethod(methodName , 
						 parametersType);
	       return aMethod;
	    } catch(NoSuchMethodException ignore) {
	       
	    }

	    parametersType = (Class[])clone;
	 
	    for ( int i = 0; i < parametersType.length; i++) {
	       for ( Class[] c = (Class[])parametersType.clone(); (c[i] = c[i].getSuperclass())!=null; ) {
		  aMethod = getClosestMatchingMethod( methodName, anObjectClass, c );
		  if ( aMethod != null ) {
		     bFound = true;
		     break;
		  }
	       }
	       if ( bFound == true ) {
		  break;
	       }
	    }
	 }
      } catch(Throwable e) {
         e.printStackTrace();
      }
      return aMethod ;
   }

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>Eg. Executing the following command from a command prompt 
    * <br>java COM.novusnet.vision.java.utility.helpers.ClassHelper
    * <br> Will dump the following output to the console.
    * <br>ClassHelper.getClassOnlyName(10)=Integer
    * <br>ClassHelper.createObjectByName(java.lang.Object)=java.lang.Object@5d87b2
    * <br>ClassHelper.createObjectByName(Object, java.math;java.lang)=java.lang.Object@30f13d
    * <br>ClassHelper.getClassNameFromTypeString("java.lang.Integer")=Integer
    * <br>ClassHelper.getApplicationNameFromClass(ClassHelper.class)=COM.novusnet.util
    * <br>ClassHelper.getClosestMatchingMethod("getInteger", Integer.class, 
    * {String.class, Integer.class})=public static java.lang.Integer 
    * java.lang.Integer.getInteger(java.lang.String,java.lang.Integer)
    * <br>
    * @param       aArgs:String[]
    */
   public static  void  main (String[]  aArgs) {
      // Test each of the Methods provided by this class.
      try {
	 Integer myInt = new Integer(10);
	 String className = ClassHelper.getClassOnlyName(myInt);
	 System.out.println("\n\n\nClassHelper.getClassOnlyName(10)=" + className);
	 Object  myObject = ClassHelper.createObjectByName ("java.lang.Object");
	 if (myObject != null) {
	    System.out.println("\nClassHelper.createObjectByName(java.lang.Object)=" + myObject.toString());
	 }
	 myObject = ClassHelper.createObjectByName ("Object", "java.math;java.lang");
	 if (myObject != null) {
	    System.out.println("\nClassHelper.createObjectByName(Object, java.math;java.lang)=" + myObject.toString());
	 }
	 System.out.println("\nClassHelper.getClassNameFromTypeString(\"java.lang.Integer\")=" + ClassHelper.getClassNameFromTypeString("java.lang.Integer"));
	 System.out.println("\nClassHelper.getApplicationNameFromClass(ClassHelper.class)=" +  ClassHelper.getApplicationNameFromClass (ClassHelper.class));
	 Class[] myArray = {String.class, Integer.class};
	 Method myMethod = ClassHelper.getClosestMatchingMethod("getInteger", Integer.class, myArray);
	 if (myMethod != null) {
	    System.out.println("\nClassHelper.getClosestMatchingMethod(\"getInteger\", Integer.class, {String.class, Integer.class})=" + myMethod.toString());
	 }
      }catch (InstantiationException e) {
	 e.printStackTrace();
      }catch (IllegalAccessException e) {
	 e.printStackTrace();
      }catch (ClassNotFoundException e) {
	 e.printStackTrace();
      }	 

   }


}




