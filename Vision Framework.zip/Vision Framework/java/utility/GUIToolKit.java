/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      GUIToolKit.java                                         */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 November 06 at 13:32:43 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.utility;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.AbstractButton;

import javax.swing.text.JTextComponent;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;

import COM.novusnet.vision.java.gui.FormComponent;
/**
 * This toolkit contains various useful GUI utility methods.
 */
public  class  GUIToolKit {
        /**
	 * Constructor
         */
   public GUIToolKit ()  {
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getDimensionFromCharacters                       */
        /*                                                              */
        /**
         * This method returns the dimension that should be set on a
         * <p>
         * components in order to display a minumum number of characters.
         *  
         * @param       aComponent:Component
         * @param       numberOfChars:int
         * @return      :Dimension -
         */
        /*==============================================================*/
   public static  Dimension  getDimensionFromCharacters (
                                                         Component  aComponent,
                                                         int        numberOfChars
                                                        )
   {
//##Begin GUIToolKit:getDimensionFromCharacters(Component,int) preserve=yes
        Font f = aComponent.getFont();

        if (f != null) {
            FontMetrics fm = aComponent.getFontMetrics(f);
	    int w = fm.stringWidth("W") * numberOfChars;
	    int h = aComponent.getPreferredSize().height;
	    return new Dimension(w, h);
	}
	else {
	    return (aComponent.getPreferredSize());
	}        

//##End   GUIToolKit:getDimensionFromCharacters(Component,int)
   }

        /*==============================================================*/
        /* OPERATION:  createImage                                      */
        /*                                                              */
        /**
         * This method creates images from jar files or from any other
         * location. It user getResourceAsStream instead of the unsupported
         * (Netscape)  getResource() method.
         * <p>
         * The class is used to determine the class loader internally. For
         * more information on this method, please refer to the
         * Class.getResource() method.
         *  
         * @param       aClass:Class
         * @param       imageName:String
         * @return      :ImageIcon -
         */
        /*==============================================================*/
   public static  ImageIcon  createImage (
                                          Class   aClass,
                                          String  imageName
                                         )
   {
//##Begin GUIToolKit:createImage(Class,String) preserve=yes
      InputStream is         = aClass.getResourceAsStream(imageName);
      ImageIcon   imageIcon  = null;

      if (is != null) {      

	 ByteArrayOutputStream baos = new ByteArrayOutputStream();

	 try {

	    int c;

	    while((c = is.read()) >= 0) {
	       baos.write(c);
	    }

	    imageIcon = new ImageIcon(Toolkit.getDefaultToolkit().createImage(baos.toByteArray()));
	 }
	 catch(IOException ignore) {
	 }
      }

      return (imageIcon); 
//##End   GUIToolKit:createImage(Class,String)
   }

        /*==============================================================*/
        /* OPERATION:  createPlainImage                                 */
        /*                                                              */
        /**
         * This method creates images from jar files or from any other
         * location. It user getResourceAsStream instead of the unsupported
         * (Netscape)  getResource() method.
         * <p>
         * The class is used to determine the class loader internally. For
         * more information on this method, please refer to the
         * Class.getResource() method.
         *  
         * @param       aClass:Class
         * @param       imageName:String
         * @return      :Image -
         */
        /*==============================================================*/
   public static  Image  createPlainImage (
				      Class   aClass,
				      String  imageName
				      )
   {
//##Begin GUIToolKit:createPlainImage(Class,String) preserve=yes
      InputStream is         = aClass.getResourceAsStream(imageName);
      Image   image  = null;

      if (is != null) {      

	 ByteArrayOutputStream baos = new ByteArrayOutputStream();

	 try {

	    int c;

	    while((c = is.read()) >= 0) {
	       baos.write(c);
	    }

	    image = Toolkit.getDefaultToolkit().createImage(baos.toByteArray());
	 }
	 catch(IOException ignore) {
	 }
      }

      return (image); 
//##End   GUIToolKit:createPlainImage(Class,String)
   }

        /*==============================================================*/
        /* OPERATION:  setEditable                                      */
        /*                                                              */
        /**
         * Toggles the editable state of a component and changes the colors
         * properly. If the component is an instance of FormComponent, then
         * recurse.
         *  
         * @param       component:Component
         * @param       editable:boolean
         */
        /*==============================================================*/
   public static  void  setEditable (
                                     Component  component,
                                     boolean    editable
                                    )
   {
//##Begin GUIToolKit:setEditable(Component,boolean) preserve=yes

      //==============================================================
      // If JPanel then recursively call setEditable on the
      // individual components
      // If JTextComponent call setEditable(boolean )
      // if JComboBox also call setEnablee( boolean )
      //==============================================================      
      if ( component instanceof JScrollPane ) {
	 JScrollPane sp = (JScrollPane) component;
	 component  = sp.getViewport().getView();
	 if (component == null) return;
      }

      if ( component instanceof FormComponent ) {
	 ((FormComponent)component).setEditable( editable );
      }       
      else if ( component instanceof JTextComponent ) {
	 ((JTextComponent)component).setEditable( editable );
      }       
      else if ( component instanceof JComboBox ) {
	 ((JComboBox)component).setEnabled( editable);
      }
      else if ( component instanceof AbstractButton ) {
	 ((AbstractButton)component).setEnabled( editable);
      }
      if ( component instanceof JPanel) {
	 Component components[] = ((JPanel)component).getComponents();
	 for (int i = 0; i < components.length; i++) {
	    setEditable(components[i], editable);
	 }
      }       
//##End   GUIToolKit:setEditable(Component,boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setMnemonics                                     */
        /*                                                              */
        /**
         * Sets the Mnemonics on the supplied Container and all its
         * subpanels ensuring that no duplicates exist. The user can pass
         * an optional list of characters that have been reserved and
         * should not be used by this method. The main benefit of this
         * method is that ensures that different panels that are authored
         * by different developers do not collide when it comes to
         * accelarators. This method uses a depth first algorithm. That is
         * children are handled first. This way, commonly used panels will
         * "usually" get the same accelarators.
         *  
         * @param       component:JComponent
         * @param       reservedChars:char[]
         */
        /*==============================================================*/
   public static  void  setMnemonics (
                                      JComponent  component,
                                      char[]      reservedChars
                                     )
   {
//##Begin GUIToolKit:setMnemonics(JComponent,char[]) preserve=yes
      char usedChars[] = new char[1024];
      int  length      = 0;

      if (reservedChars != null) {
	  System.arraycopy(reservedChars,
			   0,
			   usedChars,
			   0,
			   reservedChars.length);
	  length = reservedChars.length;
      }

      if (component instanceof FormComponent) {
	 reservedChars = ((FormComponent)component).getReservedAccelarators();
	 if (reservedChars != null) {
	    System.arraycopy(reservedChars,
			     0,
			     usedChars,
			     length,
			     reservedChars.length);	    
	 }
      }

      setMnemonicsWorker(component, usedChars);
//##End   GUIToolKit:setMnemonics(JComponent,char[])
   }

        /*==============================================================*/
        /* OPERATION:  setMnemonicsWorker                               */
        /*                                                              */
        /**
         * @param       component:JComponent
         * @param       usedChars:char[]
         */
        /*==============================================================*/
   private static  void  setMnemonicsWorker (
                                             JComponent  component,
                                             char[]      usedChars
                                            )
   {
//##Begin GUIToolKit:setMnemonicsWorker(JComponent,char[]) preserve=yes
      if ( component instanceof JPanel) {
	 Component components[] = ((JPanel)component).getComponents();
	 
	 for (int i = 0; i < components.length; i++) {
	    if (components[i] instanceof JComponent) {	    
	       setMnemonicsWorker((JComponent)components[i], usedChars);
	    }
	 }
      }       
      else if ( component instanceof AbstractButton ) {
	 AbstractButton myButton = (AbstractButton)component;
	 String         myText   = myButton.getText();
	 if (myButton.getMnemonic() == '\0') {
	    myButton.setMnemonic(getNextChar(myText, usedChars));
	 }
      }
      else if (component instanceof JLabel ) {
	 JLabel   myLabel  = (JLabel)component;
	 if (myLabel.getLabelFor() != null) {
	    String   myText   = myLabel.getText();
	    myLabel.setDisplayedMnemonic(getNextChar(myText, usedChars));
	 }
      }
//##End   GUIToolKit:setMnemonicsWorker(JComponent,char[])
   }

        /*==============================================================*/
        /* OPERATION:  getNextChar                                      */
        /*                                                              */
        /**
         * @param       text:String
         * @param       usedChars:char[]
         * @return      :char -
         */
        /*==============================================================*/
   private static  char  getNextChar (
                                      String  text,
                                      char[]  usedChars
                                     )
   {
//##Begin GUIToolKit:getNextChar(String,char[]) preserve=yes
      int     length  = text.length();
      char    newChar = '\0';
      boolean found   = false;

      for (int i = 0; !found && (i < length); i++) {

	 newChar = Character.toLowerCase(text.charAt(i));

	 if (!Character.isLetter(newChar)) continue;

	 for (int j = 0; j < usedChars.length ; j++) {

	    if (newChar == Character.toLowerCase(usedChars[j])) {
	       break;
	    }

	    if (usedChars[j] == '\0') {
	       usedChars[j] = newChar;
	       found = true;
	       break;
	    }
	 }
      }

      if (!found) {
	 newChar = '\0';
      }

      return newChar;
//##End   GUIToolKit:getNextChar(String,char[])
   }
}
