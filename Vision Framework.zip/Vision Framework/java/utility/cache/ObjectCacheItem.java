/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.cache;

import java.util.Date;
/**
 * Holds a cached Java object.
 * <p>
 * The ObjectCacheItem consists of a Java Object, a key (typically a hash
 * code) and a "last accessed" timestamp.
 * <p>
 * The timestamp will be updated whenever the cached object is read or
 * written.
 * @version 1.0, 5/1/98
 */
class  ObjectCacheItem {
   private Object key;
   private Object object;
   /**
    * The timestamp associated with the cache item.
    */
   private Date   timeStamp = new Date();

   /**
    * This method returns the value of the key object (typically a
    * hash code) used to uniquely identify the cached object.
    *  
    * @return      :Object -
    *                 The value of the key object (typically a hash
    *                 code) used to uniquely identify the cached
    *                 object.
    */
   public  Object  getKey ()   {
      return (key);
   }

   /**
    * This method returns the value of the cached object.
    * @return      :Object -
    *                 The value of the cached object.
    */
   public  Object  getObject () {
      return (object);
   }

   /**
    * This method is used to print out the current state of this
    * object instance.
    */
   public  void  printOut () {
      try {
         System.out.println ("ObjectCacheItem:");
         System.out.println ("   key: " + getKey ());
         System.out.println ("   object: " + getObject ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }
   }


   /**
    * The ObjectCacheItem constructor. The cache item's timestamp is
    * set to the current time when the item is created.
    * @param anItemKey:Object  The key value which will be used to identify (and
    * locate) the object being cached.
    * @param anObject:Object  The object to be cached.
    */
   ObjectCacheItem (Object  anItemKey,  Object  anObject)  {
      key    = anItemKey;
      object = anObject;
   }

   /**
    * Returns the cache item's timestamp.
    * @return int: The cache item's timestamp.
    */
   public  int  getTimestamp () {
      return (int) timeStamp.getTime ();
   }

   /**
    * Sets the cache item's timestamp to the current time.
    */
   public  void  setTimestamp () {
      timeStamp = new Date ();
   }


}




