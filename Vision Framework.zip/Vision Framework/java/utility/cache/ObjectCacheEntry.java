/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.cache;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
/**
 * Holds the collection of cached Java objects associated with an Object
 * Cache entry.
 * <p>
 * A ObjectCacheEntry consists of a name and a collection of cache items.
 * The number of cached items is specified when the cache entry is
 * constructed.
 * <p>
 * The cache entry maintains a collection containing a fixed number of
 * cached objects. Once this limit is reached, when new objects are added
 * to the cache, older objects are discarded using a Least Recently Used
 * (LRU) algorithm. The age of each item is indicated by means of a
 * timestamp, which is updated whenever the item is added or retrieved.
 * @version 1.0, 5/1/98
 */
class ObjectCacheEntry {

	/**
	 * The name of the cache entry.
	 */
	private java.lang.String entryName;

	/**
	 * The maximum number cache items that can be associated
	 * with this entry.
	 */
	private int numberOfItems;
	private Map cacheItems = Collections.synchronizedMap(new HashMap());

	/**
	 * The ObjectCacheEntry constructor.
	 * @param anEntryName:String  The name of the cache entry.
	 * @param aNumberOfItems:int  The number of cache items associated with the
	 * cache entry.
	 */
	ObjectCacheEntry(java.lang.String anEntryName, int aNumberOfItems) {
		entryName = anEntryName;
		numberOfItems = aNumberOfItems;
	}

	/**
	 * This method adds the given object to the collection of cache
	 * items associated with this entry. The cached object is
	 * identified by means of the specified key object (typically a
	 * hash code).
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object being cached.
	 * @param anObject:Object  The object to be cached.
	 */
	public void addItem(
		java.lang.Object anItemKey,
		java.lang.Object anObject) {
		ObjectCacheItem anObjectCacheItem =
			new ObjectCacheItem(anItemKey, anObject);

		if (cacheItems.containsKey(anItemKey)
			&& cacheItems.size() >= numberOfItems) {
			ObjectCacheItem objectToBeDeleted = findOldestItem();
			cacheItems.remove(objectToBeDeleted.getKey());
		}

		cacheItems.put(anItemKey, anObjectCacheItem);
	}

	/**
	 * This method removes the cached object identified by the given
	 * key from the collection of cache items associated with this
	 * entry.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object being removed.
	 */
	public void removeItem(java.lang.Object anItemKey) {
		cacheItems.remove(anItemKey);
	}

	/**
	 * This method removes the collection of cache items associated
	 * with this entry.
	 */
	public void removeItems() {
		cacheItems.clear();
	}

	/**
	 * This determines whether the object corresponding to the
	 * specified key (hash code) exists in the collection of cache
	 * items associated with this entry.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object in the cache.
	 * @return boolean: A boolean indication of whether or not the item corresponding to
	 * the key object is found in the cache.
	 */
	public boolean containsItem(java.lang.Object anItemKey) {
		return (cacheItems.containsKey(anItemKey));
	}

	/**
	 * This searches for the object corresponding to the specified key
	 * (hash code) in the collection of cache items associated with
	 * this entry, and returns the corresponding cache item (if found).
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object in the cache.
	 * @return Object: The object retrieved from the cache (or null if not found).
	 *  
	 */
	public java.lang.Object retrieveItem(java.lang.Object anItemKey) {
		if (cacheItems.containsKey(anItemKey)) {
			ObjectCacheItem retrievedCacheItem =
				(ObjectCacheItem) cacheItems.get(anItemKey);
			if (retrievedCacheItem != null) {
				retrievedCacheItem.setTimestamp();
				return retrievedCacheItem.getObject();
			}
		}
		return null;
	}

	/**
	 * This method uses a Least Recently Used algorithm to locate the
	 * oldest object in the collection of cache items associated with
	 * this entry. The age of a cache item is determined by means of
	 * its timestamp.
	 *  
	 * @return     ObjectCacheItem -
	 */
	private ObjectCacheItem findOldestItem() {
		ObjectCacheItem oldestCacheItem = null;

		synchronized (cacheItems) {
			Iterator cacheItemIterator = cacheItems.values().iterator();

			while (cacheItemIterator.hasNext()) {
				ObjectCacheItem currentCacheItem =
					(ObjectCacheItem) cacheItemIterator.next();
				if ((currentCacheItem.getTimestamp()
					< (oldestCacheItem.getTimestamp())
					|| oldestCacheItem == null)) {
					oldestCacheItem = currentCacheItem;
				}
			}
		}

		return oldestCacheItem;
	}

}
