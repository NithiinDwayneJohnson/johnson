/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.cache;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Allows Java objects to be added, retrieved and removed from a cache.
 * The ObjectCache consists of a collection of cache entries, each of which
 * can have a specified number of cached items associated with it. Each of
 * these cache items is a Java Object and is identified by means of a key.
 * <p>
 * A ObjectCacheEntry consists of a name and a collection of cache items.
 * The number of cached items is specified when the cache entry is
 * constructed.
 * <p>
 * The cache entry maintains a collection containing a fixed number of
 * cached objects. Once this limit is reached, when new objects are added
 * to the cache, older objects are discarded using a Least Recently Used
 * (LRU) algorithm. The age of each item is indicated by means of a
 * timestamp, which is updated whenever the item is added or retrieved.
 * @version 1.0, 5/1/98
 */

public class ObjectCache {
	private Map cacheEntries = Collections.synchronizedMap(new HashMap());
	/**
	 * This method adds the specified name to the collection of cache
	 * entries, each of which will have the specified number of cache
	 * items associated with it.
	 * <br>
	 * @param  anEntryName:String  The name of the entry with which the cache items
	 * (objects) are to be associated.
	 * @param  aNumberOfItems:Int  The number of cache items associated with the
	 * entry being added.
	 *  
	 */
	public synchronized void addEntry(String anEntryName, int aNumberOfItems) {
		if (!cacheEntries.containsKey(anEntryName)) {
			ObjectCacheEntry aCacheEntry =
				new ObjectCacheEntry(anEntryName, aNumberOfItems);
			cacheEntries.put(anEntryName, aCacheEntry);
		}
	}

	/**
	 * This method removes the specified name from the collection of
	 * cache entries.
	 * @param anEntryName:String  The name of the entry to be removed.
	 */
	public synchronized void removeEntry(String anEntryName) {
		if (cacheEntries.containsKey(anEntryName)) {
			cacheEntries.remove(anEntryName);
		}
	}

	/**
	 * This method determines whether the specified entry name exists
	 * in the collection of cache entries.
	 * @param anEntryName:String  The name of the entry to be located.
	 * @return A boolean indication of whether or not the entry is found in the
	 * collection of cache entries.
	 */
	public synchronized boolean containsEntry(String anEntryName) {
		return (cacheEntries.containsKey(anEntryName));
	}

	/**
	 * This method adds the given object to the collection of cache
	 * items associated with the specified entry name. The cached
	 * object is identified by means of the specified key object
	 * (typically a hash code).
	 * @param anEntryName:String  The name of the entry with which the cache item is
	 * to be associated.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object being cached.
	 * @param anObject:Object  The object to be cached.
	 *  
	 */
	public synchronized void addItem(
		java.lang.String anEntryName,
		java.lang.Object anItemKey,
		java.lang.Object anObject) {
		ObjectCacheEntry aCacheEntry =
			(ObjectCacheEntry) retrieveEntry(anEntryName);
		aCacheEntry.addItem(anItemKey, anObject);
	}

	/**
	 * This method removes the cached object identified by the given
	 * key from the collection of cache items associated with the
	 * specified entry name.
	 * @param anEntryName:String  The name of the entry with which the cache item is
	 * associated.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object being removed.
	 *  
	 */
	public synchronized void removeItem(
		java.lang.String anEntryName,
		java.lang.Object anItemKey) {
		ObjectCacheEntry aCacheEntry =
			(ObjectCacheEntry) retrieveEntry(anEntryName);
		aCacheEntry.removeItem(anItemKey);
	}

	/**
	 * This method removes the collection of cached items associated
	 * with the specified entry name.
	 * @param anEntryName:String  The name of the entry whose cache items 
	 * are to be cleared.
	 *  
	 */
	public synchronized void removeItems(java.lang.String anEntryName) {
		ObjectCacheEntry aCacheEntry =
			(ObjectCacheEntry) retrieveEntry(anEntryName);
		if (aCacheEntry != null) {
			aCacheEntry.removeItems();
		}
	}

	/**
	 * This methods determines whether the object corresponding to the
	 * specified key (hash code) exists in the collection of cache
	 * items associated with the specified entry name.
	 * @param anEntryName:String  The name of the entry with which the cache item is
	 * associated.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object in the cache.
	 * @return A boolean indication of whether or not the item corresponding to
	 * the given key is found in the cache.
	 *  
	 */
	public synchronized boolean containsItem(
		java.lang.String anEntryName,
		java.lang.Object anItemKey) {
		ObjectCacheEntry aCacheEntry =
			(ObjectCacheEntry) retrieveEntry(anEntryName);
		return aCacheEntry.containsItem(anItemKey);
	}

	/**
	 * This searches for the object corresponding to the specified key
	 * (hash code) in the collection of cache items associated with the
	 * specified entry name, and returns the corresponding cache item
	 * (if found).
	 * @param anEntryName:String  The name of the entry with which the cache item is
	 * associated.
	 * @param anItemKey:Object  The key value which will be used to identify (and
	 * locate) the object in the cache.
	 * @return The object retrieved from the cache (or null, if not found).
	 */
	public synchronized java.lang.Object retrieveItem(
		java.lang.String anEntryName,
		java.lang.Object anItemKey) {
		ObjectCacheEntry aCacheEntry =
			(ObjectCacheEntry) retrieveEntry(anEntryName);
		return aCacheEntry.retrieveItem(anItemKey);
	}

	/**
	 * This method clears all the contents of the cache (removes all
	 * entries and their corresponding items).
	 *  
	 */
	public synchronized void clearCache() {
		cacheEntries.clear();
	}

	/**
	 * This method clears all the cache items corresponding to the
	 * named cache entry.
	 * @param anEntryName:String  The cache entry to be cleared.
	 *  
	 */
	public synchronized void clearCache(java.lang.String anEntryName) {
		removeEntry(anEntryName);
	}

	/**
	 * This method searches the collection of cache entries for the
	 * specified name and returns the corresponding cache entry (if
	 * found).
	 * @param anEntryName:String  The name of the entry to be located.
	 * @return The cache entry corresponding to the specified name (or null, if
	 * not found).
	 *  
	 */
	private synchronized java.lang.Object retrieveEntry(String anEntryName) {
		return cacheEntries.get(anEntryName);
	}

	/**
	 * Main method, used for command line unit testing and to demonstrate
	 * usage of this class.
	 * <br>eg. executing the following command from a command prompt 
	 * <br>>java COM.novusnet.vision.java.utility.cache.ObjectCache
	 * <br>will result in the following output to the console
	 * <p>
	 * <br>anObjectCache.addEntry("CARDMEMBER", 3)
	 * <br>anObjectCache.addEntry("MEMOS", 1)
	 * <br>anObjectCache.addEntry("TEST", 1)
	 * <br>anObjectCache.containsEntry ("MEMOS")=true
	 * <br>anObjectCache.retrieveEntry ("MEMOS")=COM.novusnet.vision.java.utility.cache.ObjectCacheEntry@239137
	 * <br>anObjectCache.removeEntry("MEMOS")
	 * <br>anObjectCache.containsEntry ("MEMOS")=false
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (1), new String ("Object 1"))
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (2), new String ("Object 2"))
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (3), new String ("Object 3"))
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (4), new String ("Object 4"))
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (3))=Object 3
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (5), new String ("Object 5"))
	 * <br>anObjectCache.addItem ("CARDMEMBER", new Integer (6), new String ("Object 6"))
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (1))=false
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (1))=null
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (2))=false
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (2))=null
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (3))=true
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (3))=Object 3
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (4))=false
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (4))=null
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (5))=true
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (5))=Object 5
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (6))=true
	 * <br>anObjectCache.retrieveItem ("CARDMEMBER", new Integer (6))=Object 6
	 * <br><t>Because the cache entry maintains a collection containing a fixed number of cached objects, once this limit is reached and new objects are added to the cache, 
	 * <br>then older objects are discarded using the Least Recently Used algorithm.
	 * <br>So you will see that objects 3, 5 and 6 are currently left in the cache. Remember that the size of our cache is 3 (from the addEntry method above) and every 
	 * <br>time an item is added or retrieved its timestamp is updated.
	 * <br>anObjectCache.removeItem ("CARDMEMBER", new Integer (5))
	 * <br>anObjectCache.containsItem  ("CARDMEMBER", new Integer (5))=false
	 */
	public static void main(java.lang.String args[]) {
		ObjectCache anObjectCache = new ObjectCache();
		ObjectCacheEntry anObjectCacheEntry = null;
		boolean flag = false;

		anObjectCache.addEntry("CARDMEMBER", 3);
		System.out.println("anObjectCache.addEntry(\"CARDMEMBER\", 3)");
		anObjectCache.addEntry("MEMOS", 1);
		System.out.println("anObjectCache.addEntry(\"MEMOS\", 1)");
		anObjectCache.addEntry("TEST", 1);
		System.out.println("anObjectCache.addEntry(\"TEST\", 1)");
		System.out.println(
			"anObjectCache.containsEntry (\"MEMOS\")="
				+ anObjectCache.containsEntry("MEMOS"));
		System.out.println(
			"anObjectCache.retrieveEntry (\"MEMOS\")="
				+ anObjectCache.retrieveEntry("MEMOS"));
		anObjectCache.removeEntry("MEMOS");
		System.out.println("anObjectCache.removeEntry(\"MEMOS\")");
		System.out.println(
			"anObjectCache.containsEntry (\"MEMOS\")="
				+ anObjectCache.containsEntry("MEMOS"));
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(1),
			new String("Object 1"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (1), new String (\"Object 1\"))");
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(2),
			new String("Object 2"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (2), new String (\"Object 2\"))");
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(3),
			new String("Object 3"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (3), new String (\"Object 3\"))");
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(4),
			new String("Object 4"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (4), new String (\"Object 4\"))");
		System.out.println(
			"anObjectCache.retrieveItem (\"CARDMEMBER\", new Integer (3))="
				+ anObjectCache.retrieveItem("CARDMEMBER", new Integer(3)));
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(5),
			new String("Object 5"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (5), new String (\"Object 5\"))");
		anObjectCache.addItem(
			"CARDMEMBER",
			new Integer(6),
			new String("Object 6"));
		System.out.println(
			"anObjectCache.addItem (\"CARDMEMBER\", new Integer (6), new String (\"Object 6\"))");

		for (int i = 1; i <= 6; i++) {
			System.out.println(
				"anObjectCache.containsItem  (\"CARDMEMBER\", new Integer ("
					+ i
					+ "))="
					+ anObjectCache.containsItem("CARDMEMBER", new Integer(i)));
			System.out.println(
				"anObjectCache.retrieveItem (\"CARDMEMBER\", new Integer ("
					+ i
					+ "))="
					+ anObjectCache.retrieveItem("CARDMEMBER", new Integer(i)));
		}
		System.out.println(
			"Because the cache entry maintains a collection "
				+ "containing a fixed number of cached objects, once "
				+ "this limit is reached and new objects are added to "
				+ "the cache, then older objects are discarded using "
				+ "the Least Recently Used algorithm.\n"
				+ "So you will see that objects 3, 5 and 6 are currently "
				+ "left in the cache. Remember that the size of our cache is 3 "
				+ "(from the addEntry method above) and every time an "
				+ "item is added or retrieved its timestamp is updated. ");
		anObjectCache.removeItem("CARDMEMBER", new Integer(5));
		System.out.println(
			"anObjectCache.removeItem (\"CARDMEMBER\", new Integer (5))");
		System.out.println(
			"anObjectCache.containsItem  (\"CARDMEMBER\", new Integer (5))="
				+ anObjectCache.containsItem("CARDMEMBER", new Integer(5)));
	}
}
