/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Hashtable;
import java.util.Enumeration;


/**
 * Extends PropertyHelper in order to allow the loading of multiple properties
 * files. 
 * @version 1.0, 4-19-2004
 */
public  class  ApplicationConfigHelper extends PropertyHelper {

   //These probably belong in some global contants class within Orion 
   //and not here in a Vision class. But I will not remove them at this 
   //time. Eoin F. 6-29-04
   public static final java.lang.String APPLICATION_CODE_ORION  = "CS";
   public static final java.lang.String APPLICATION_CODE_SIRIUS = "MS";
   public static final java.lang.String APPLICATION_CODE_COSMOS = "RS";
   // This the instance variable is a singleton
   private static ApplicationConfigHelper instance = null;
   // The collection of names of loded properties files
   private Hashtable  configFileSummary = null;

   /**
    * ApplicationConfigHelper constructor. It will instantiate super class 
    * PropertyHelper. It will allow you to load multiple properties files and
    * will keep their names in the summary of all prperties files loaded. It 
    * will not reload the same file over and over.
    */
   private   ApplicationConfigHelper () {
      super("");
      configFileSummary = new Hashtable();
   }

   /**
    * Returns the singleton ApplicationConfigHelper instance.
    * @return ApplicationConfigHelper
    */
   public  static  ApplicationConfigHelper instance (){
      if(instance == null) {
	 instance = new ApplicationConfigHelper();
      }      
      return instance;
   }

   /**
    * Load a property file. It will check the <b>configFileSummary</b> collection
    * to make sure that the given file name is not already there. If it is
    * the method will return. Otherwise it will load new given properties file
    * into <b>properties</b> object.
    * @param fileName:String  The properties file name
    */
   public  void  load (String fileName) {
      try {
	 String fileAbsName = System.getProperty ("user.dir") + fileName;
	 if(!configFileSummary.containsKey(fileAbsName)){
	    BufferedInputStream inputStream = new BufferedInputStream (new FileInputStream (fileAbsName));
	    System.getProperties().load(inputStream);
	    configFileSummary.put(fileAbsName, fileAbsName);
	    System.out.println("Property file << " + System.getProperty ("user.dir") +
			       fileName + " >> is loaded!  ");
            }
      }catch (IOException e) {
	 //  The properties file's existence is not mandatory 
	 System.out.println("Property file << " + System.getProperty ("user.dir") +
			    fileName + " >>can not be loaded!  ");
      }
   }


   /**
    * Takes a Properties object and will load the properties contained within it 
    * into the current System properties.
    * @param newProperties:Propertieserties
    */
   public  void  load (Properties newProperties) {
      Properties systemProperties = new Properties(System.getProperties());
      Enumeration enum = newProperties.keys();
      while ( enum.hasMoreElements() ) {
	 String newkey = (String)enum.nextElement();
	 String newvalue = newProperties.getProperty(newkey);
	 systemProperties.setProperty(newkey, newvalue);
      }
      System.setProperties(systemProperties);      
   }
}
