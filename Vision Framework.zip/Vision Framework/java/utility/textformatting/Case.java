//======================================================================*/
//   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
//======================================================================*/
package COM.novusnet.vision.java.utility.textformatting;

import java.util.Locale;

/**
 * A utility that provides the ability to the capitalize/uncapilalize the
 * initial character of a word or words in a string.
 * @version 1.0, 5/1/98
*/
public class Case {

   /**
    * Changes a string so that the first letter of each word is capitalized.
    *
    * <br>The method gets the index of a string where it finds spaces and changes
    * the char at index + 1 (next char) to upper.
    * <br>This method assumes only one space between words.
    * <br>Eg.
    * <br>Case.makeMixedCase ("MY TEST STRING")
    * <br>will return "My Test String"
    *  @param String - Item which needs capitalization per first word
    *  @return String - Item with proper capitaliztion (see above)
    */
   public static String  makeMixedCase (String aValue) {
      StringBuffer    tempStringBuffer;
      int      indexFirst = 0;
      int      indexLast = 0;

      /*======================================================*/
      /* Remove all starting and ending spaces                */
      /*======================================================*/
      aValue = aValue.trim();

      /*======================================================*/
      /* Change the string to all lower case                  */
      /*======================================================*/
      aValue = aValue.toLowerCase(Locale.US);

      /*======================================================*/
      /* Create a string buffer with contents of the string   */
      /* passed (already lower cased)                         */
      /*======================================================*/
      tempStringBuffer = new StringBuffer(aValue);
      tempStringBuffer.setCharAt(0, Character.toUpperCase(aValue.charAt(0)));

      /*======================================================*/
      /* Mark end of search                                   */
      /*======================================================*/
      indexLast =  aValue.lastIndexOf(' ');

      while (indexFirst != indexLast) 
      {
	 /*=================================================*/
	 /* Change character next to space to upper case    */
	 /*=================================================*/
	 indexFirst =  aValue.indexOf(' ', indexFirst + 1);
	 tempStringBuffer.setCharAt(indexFirst + 1, 
				    Character.toUpperCase(aValue.charAt(indexFirst + 1)));
      }
      /*======================================================*/
      /* Return the copied buffer as a string                 */
      /*======================================================*/
      return tempStringBuffer.toString();
   }

   /**
    * Capitalize the first letter of the supplied string.
    * <br> Eg.
    * <br> Case.capitalize ("string")
    * <br> will return "String"
    * @param String - The string whose first letter is to be capitalized. 
    * @return String - The supplied string with the first letter capitalized.
    */
   public static final  String  capitalize (String  aString){
      if (aString != null) {
	 if (aString.length () > 0) {
	    char myCharArray [] = aString.toCharArray ();
	    myCharArray [0] = Character.toUpperCase (myCharArray [0]);
	    return (new String (myCharArray));
	 }
      }
      return ("");
   }

   /**
    * Change the first letter of the supplied string to lower case.
    * <br> Eg.
    * <br> Case.uncapitalize ("STRING")
    * <br> will return "sTRING"
    * @param String - The string whose first letter is to be changed to 
    * lower case.
    * @return String - The supplied string with the first letter in lower case.
    */
   public static final  String  uncapitalize (String  aString) {
      if (aString != null) {
	 if (aString.length () > 0) {
	    char myCharArray [] = aString.toCharArray ();
	    myCharArray [0] = Character.toLowerCase (myCharArray [0]);
	    return (new String (myCharArray));
	 }
      }
      return ("");
   }

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility.textformatting.Case "my test phrase"
    * <br>will result in the following output to the console
    * <p>
    * <br>> No arguments provided. Defaults will be used.
    * <br>>makeMixedCase("MY TEST STRING")=My Test String
    * <br>>capitalize("string")=String
    *<br>>uncapitalize("STRING")=sTRING
    */
   public  static  void  main (
                               String  args []
			       )
      {
	 if (args.length <= 0) {
	    System.out.println("\n No arguments provided. Defaults will be used.");
	    System.out.println ("\nmakeMixedCase(\"MY TEST STRING\")=" + Case.makeMixedCase ("MY TEST STRING"));
	    System.out.println ("\ncapitalize(\"string\")=" + Case.capitalize ("string"));
	    System.out.println ("\nuncapitalize(\"STRING\")=" + Case.uncapitalize ("STRING"));
	 }else {
	    System.out.println ("\nmakeMixedCase(\""+ args[0] + "\")=" + Case.makeMixedCase (args[0]));
	    System.out.println ("\ncapitalize(\""+ args[0] + "\")=" + Case.capitalize (args[0]));
	    System.out.println ("\nuncapitalize(\""+ args[0] + "\")=" + Case.uncapitalize (args[0]));
	 }
      }
}


