/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.textformatting;

/**
 * This class provides methods to format a value within a
 * given text area, with specified justification.
 * <p>
 * <b>Notes:</b><p>
 * There are four different justification modes allowed:
 * <p>
 * 1. LeftJustify - the input string begins at the first character of the
 * formatted output string. (Any excess input characters at the end are
 * ignored).
 * <p>
 * 2. RightJustify - the input string ends at the last character of the
 * formatted output string. (Any excess input characters at the beginning
 * are ignored).
 * <p>
 * 3. Center - the input string is centered in the formatted output string.
 * (Any excess input characters at either end are ignored).
 * <p>
 * 4. LeftJustifyEllipsis - the input string begins at the first character
 * of the formatted output string. However, if there are excess input
 * characters at the end, the final character of the formatted string is
 * replaced with a period.
 * <p>
 * The formatted string is padded with spaces whenever necessary.
 * @version 1.0, 5/1/98
 */
public  class  Formatter {

   /**
    * An indication that the output string is to be formatted
    * such that the input string begins at the first character
    * of the output.
    * <p>
    * However, if there are excess input characters at the
    * end,  the final character of output is to be replaced
    * with a period.
    */
   public static final int LeftJustifyEllipsis = 0;

   /**
    * An indication that the output string is to be formatted
    * such that the input string begins at the first character
    * of the output.
    * <p>
    * (Any excess input characters at the end are ignored).
    */
   public static final int LeftJustify         = 1;

   /**
    * An indication that the output string is to be formatted 
    * such that the input string ends with the last character
    * of the output.
    * <p>
    * (Any excess input characters at the beginning are
    * ignored).
    */
   public static final int RightJustify        = 2;

   /**
    * An indication that the output string is to be formatted
    * such that the input string is centered within the field.
    * <p>
    * (Any excess input characters at either end are ignored).
    */
   public static final int Center              = 3;

   /**
    * This method formats a Java primitive "String" value into a new
    * String of specified length and specified justification.
    *  
    * @param       aString:String
    *                 The string to be formatted.
    * @param       aSize:int
    *                 The length of the formatted string.
    * @param       aJustification:int
    *                 The justification style to be used (i.e. left-,
    *                 right- or center-justified).
    * @return      :String -
    *                 The formatted and justified string.
    * @exception   NegativeArraySizeException -
    *                 A negative value was passed as the size of the
    *                 string to be formatted.
    */
   public static  String  formatString (String  aString,
					int     aSize,
                                        int     aJustification) 
     throws NegativeArraySizeException {
      // Validate the size (it must be positive or zero)      
      if (aSize < 0) {
	 throw new NegativeArraySizeException
	 (
	  "Invalid output string size (" +
	  aSize                          +
	  ") specified"
	  );
      }

      /*======================================================*/
      /* Zero size requested - return an empty string         */
      /*======================================================*/
      if (aSize == 0) {
	 return ("");
      }

      /*======================================================*/
      /* Copy the original string into a blank target buffer  */
      /*======================================================*/
      char [] myBuffer = (blankString (aSize)).toCharArray ();
      return (embeddedString (myBuffer, aString, aJustification));

   }

   /**
    * This method formats a Java primitive "String" value into a new
    * String of specified length, with a default of left
    * justification.
    *  
    * @param       aString:String
    *                 The string to be formatted.
    * @param       aSize:int
    *                 The length of the formatted string.
    * @return      :String -
    *                 The formatted and left-justified string.
    * @exception   NegativeArraySizeException -
    *                 A negative value was passed as the size of the
    *                 string to be formatted.
    */
   public static  String  formatString (String  aString, int aSize)
     throws NegativeArraySizeException  {
      return (formatString (aString, aSize, LeftJustify));
   }

   /**
    * This method formats a Java primitive "String" value into a new
    * String of specified length and specified justification.
    *  
    * @param       aString:String
    *                 The original string into which the secondary
    *                 string is to be embedded.
    * @param       aEmbedString:String
    *                 The string to be embedded into the original
    *                 string.
    * @param       aJustification:int
    *                 The justification style to be used (i.e. left-,
    *                 right- or center-justified).
    * @return      :String -
    *                 The original string with the secondary string
    *                 embedded in it at the appropriate justification.
    */
   public static  String  embedString (String  aString,
                                       String  aEmbedString,
                                       int     aJustification
				       ) {
      /*======================================================*/
      /* Zero size requested - return the original string     */
      /*======================================================*/
      if (aEmbedString.length () == 0) {
	 return (aString);
      }

      /*======================================================*/
      /* Copy the original string to the target buffer        */
      /*======================================================*/
      return (embeddedString (aString.toCharArray (), aEmbedString, aJustification));
   }

   /**
    * This method forms a String of specified length, filled with
    * blank space characters.
    *  
    * @param       aSize:int
    *                 The length of the blank string.
    * @return      :String -
    *                 The blank string of requested size.
    */
   public static  String  blankString (int  aSize) {
      return (stringOfCharacters (' ', aSize));
   }

   /**
    * This method forms a String of given length, filled with the
    * specified character.
    *  
    * @param       aCharacter:char
    *                 The character to be repeated in the string.
    * @param       aSize:int
    *                 The length of the string of repeat characters.
    * @return      :String -
    *                 The string of specified length filled with the
    *                 supplied character.
    */
   public static  String  stringOfCharacters (char  aCharacter,
                                              int   aSize) {
      /*======================================================*/
      /* Zero size specified - return an empty string         */
      /*======================================================*/
      if (aSize <= 0) {
	 return ("");
      }

      /*======================================================*/
      /* Create a buffer filled with the repeat character     */
      /*======================================================*/
      char [] myBuffer = new char [aSize];
      for (int i = 0; i < aSize; i++) {
	 myBuffer [i] = aCharacter;
      }

      /*======================================================*/
      /* Return a string based upon the character buffer      */
      /*======================================================*/
      return (new String (myBuffer));
   }


   /**
    * This method escapes quotes that are embedded in a string.
    *  
    * @param       aString:String
    *                 The string to escape.
    * @return      :String -
    *                 The string with the quotes escaped.
    */
   public static  String  escapeQuotes (String  aString){
      StringBuffer MyStringBuffer = new StringBuffer(aString);

      for (int index = 0; index < MyStringBuffer.length() ; index++) {
	 if (MyStringBuffer.charAt(index) == '\'') {
	    MyStringBuffer.insert(index , '\\');	 	 
	    index++;
	 }
	 else if (MyStringBuffer.charAt(index) == '\"') {
	    MyStringBuffer.insert(index , '\\');	 	 
	    index++;
	 }
      }

      aString = MyStringBuffer.toString();
      return (aString);
   }


   /**
    * This method formats a Java primitive "String" value into a new
    * String of specified length and specified justification.
    *  
    * @param       aBuffer:char[]
    *                 The original buffer into which the secondary
    *                 string is to be embedded.
    * @param       aString:String
    *                 The string to be embedded into the original
    *                 string.
    * @param       aJustification:int
    *                 The justification style to be used (i.e. left-,
    *                 right- or center-justified).
    * @return      :String -
    *                 The original buffer with the secondary string
    *                 embedded in it at the appropriate justification,
    *                 and converted into a String.
    */
   private static  String  embeddedString (char[]  aBuffer,
                                           String  aString,
                                           int     aJustification) {
      int             myLength     = aString.length ();
      /*======================================================*/
      /* Non-zero size requested - embed the string           */
      /*======================================================*/
      if (myLength > 0) {
	 /*======================================================*/
	 /* Copy the original string to the target buffer        */
	 /*======================================================*/
	 int mySize        = aBuffer.length;
	 int myCopyLength  = ((myLength < mySize) ? myLength : mySize);
	 int mySourceStart = 0;
	 int myTargetStart = 0;

	 /*======================================================*/
	 /* Calculate the parts to copy based upon justification */
	 /*======================================================*/
	 switch (aJustification) {

	    /*==============================================*/
	    /* Left   justification                         */
	    /*==============================================*/
	    case LeftJustifyEllipsis:
	    case LeftJustify:
	       break;

	       /*==============================================*/
	       /* Center justification                         */
	       /*==============================================*/
	    case Center:
	       if (myLength > mySize) {
		  mySourceStart = ((myLength - mySize) / 2);
	       }
	       else {
		  myTargetStart = ((mySize - myLength) / 2);
	       }
	       break;

	       /*==============================================*/
	       /* Right  justification                         */
	       /*==============================================*/
	    case RightJustify:
	       if (myLength > mySize) {
		  mySourceStart = (myLength - mySize);
	       }
	       else {
		  myTargetStart = (mySize - myLength);
	       }
	       break;
	 }

	 /*======================================================*/
	 /* Perform the actual copy                              */
	 /*======================================================*/
	 for (int i = 0; i < myCopyLength; i++) {
	    aBuffer [myTargetStart + i] = aString.charAt (mySourceStart + i);
	 }

	 /*======================================================*/
	 /* Special case: ellipsis for "too-long" source string  */
	 /*======================================================*/
	 if (aJustification == LeftJustifyEllipsis) {
	    if (myLength > mySize) {
	       aBuffer [mySize - 1] = '.';
	    }
	 }
      }
      /*======================================================*/
      /* Return the processed buffer as a string              */
      /*======================================================*/
      return (new String (aBuffer));
   }

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>java COM.novusnet.vision.java.utility.textformatting.Formatter
    * <br>will result in the following output to the console <p>
    * <br>Formatter.formatString("Test",10,Formatter.LeftJustifyEllipsis)=[Test      ]
    * <br>Formatter.formatString("Test",10,Formatter.LeftJustify)=[Test      ]
    * <br>Formatter.formatString("Test",10,Formatter.RightJustify)=[      Test]
    * <br>Formatter.formatString("Test",10,Formatter.Center)=[   Test   ]
    * <br>Formatter.formatString("Test",2,Formatter.LeftJustifyEllipsis)=[T.]
    * <br>
    * <br>Formatter.formatString("Test",10)=[Test      ]
    * <br>Formatter.embedString("Test String","Embed",Formatter.LeftJustifyEllipsis)=[EmbedString]
    * <br>Formatter.embedString("Test String","Embed",Formatter.LeftJustify)=[EmbedString]
    * <br>
    * <br>Formatter.embedString("Test String","Embed",Formatter.RightJustify)=[Test SEmbed]
    * <br>Formatter.embedString("Test String","Embed",Formatter.Center)=[TesEmbeding]
    * <br>Formatter.embedString("Test","Embed",Formatter.LeftJustifyEllipsis)=[Emb.]
    * <br>
    * <br>Formatter.blankString(10)=[          ]
    * <br>
    * <br>Formatter.stringOfCharacters('a', 8)=[aaaaaaaa]
    * <br>
    * <br>Formatter.escapeQuotes("Test "String" with quotes.")=[Test \"String\" with quotes.]
    * <br>
    */
   public  static  void  main (String  args []) {
      try {
	 System.out.println("Formatter.formatString(\"Test\",10,Formatter.LeftJustifyEllipsis)=[" + Formatter.formatString("Test",10,Formatter.LeftJustifyEllipsis) + "]");
	 System.out.println("Formatter.formatString(\"Test\",10,Formatter.LeftJustify)=[" + Formatter.formatString("Test",10,Formatter.LeftJustify) + "]");
	 System.out.println("Formatter.formatString(\"Test\",10,Formatter.RightJustify)=[" + Formatter.formatString("Test",10,Formatter.RightJustify) + "]");
	 System.out.println("Formatter.formatString(\"Test\",10,Formatter.Center)=[" + Formatter.formatString("Test",10,Formatter.Center) + "]");
	 System.out.println("Formatter.formatString(\"Test\",2,Formatter.LeftJustifyEllipsis)=[" + Formatter.formatString("Test",2,Formatter.LeftJustifyEllipsis) + "]");

	 System.out.println("\nFormatter.formatString(\"Test\",10)=[" + Formatter.formatString("Test",10) + "]");

	 System.out.println("Formatter.embedString(\"Test String\",\"Embed\",Formatter.LeftJustifyEllipsis)=[" + Formatter.embedString("Test String","Embed",Formatter.LeftJustifyEllipsis) + "]");
	 System.out.println("Formatter.embedString(\"Test String\",\"Embed\",Formatter.LeftJustify)=[" + Formatter.embedString("Test String","Embed",Formatter.LeftJustify) + "]");
	 System.out.println("Formatter.embedString(\"Test String\",\"Embed\",Formatter.RightJustify)=[" + Formatter.embedString("Test String","Embed",Formatter.RightJustify) + "]");
	 System.out.println("Formatter.embedString(\"Test String\",\"Embed\",Formatter.Center)=[" + Formatter.embedString("Test String","Embed",Formatter.Center) + "]");
	 System.out.println("Formatter.embedString(\"Test\",\"Embed\",Formatter.LeftJustifyEllipsis)=[" + Formatter.embedString("Test","Embed",Formatter.LeftJustifyEllipsis) + "]");

	 System.out.println("\nFormatter.blankString(10)=[" + Formatter.blankString(10) + "]");

	 System.out.println("\nFormatter.stringOfCharacters(\'a\', 8)=[" + Formatter.stringOfCharacters('a', 8) + "]");

	 System.out.println("\nFormatter.escapeQuotes(\"Test \"String\" with quotes.\")=[" + Formatter.escapeQuotes("Test \"String\" with quotes.") + "]");
      }catch(Exception e) {
	 e.printStackTrace();
      }
   }

}



