/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility;

import java.util.Calendar;
import java.util.GregorianCalendar;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.regex.PatternSyntaxException;
/**
 * Provides utility methods that do not belong in other more specific
 * utilities packages.
 * @version 1.0, 5/1/98
 */
public  class  CommonUtility {

   /**
    * Returns the number of days in between the 2 calendar paramaters 
    * supplied.  This method assumes no ordering of  the
    * params, strictly returns a positive (+) number of days. 
    * @param       aCalendar1:Calendar
    *                  A Calendar which has month, year, and day set.
    * @param       aCalendar2:Calendar
    *                  A Calendar which has month, year, and day set.
    * @return      :long -
    *                  The number of days between the two calendars 
    *                  given.
    *  
    */
   public static  long  differenceInDays (
                                          Calendar  aCalendar1,
                                          Calendar  aCalendar2
					  )
      {
	 Calendar earlierDate = new GregorianCalendar();
	 Calendar laterDate = new GregorianCalendar();

	 /*===========================================================*/
	 /* Order the dates given via the params and use ealier and   */
	 /* later GregorianCalendars to keep track.                   */
	 /*===========================================================*/
	 if (aCalendar1.after(aCalendar2)) {
	    earlierDate.set(aCalendar2.get(Calendar.YEAR), 
			    aCalendar2.get(Calendar.MONTH), 
			    aCalendar2.get(Calendar.DAY_OF_MONTH), 
			    0, 0, 0);    

	    laterDate.set(aCalendar1.get(Calendar.YEAR), 
			  aCalendar1.get(Calendar.MONTH), 
			  aCalendar1.get(Calendar.DAY_OF_MONTH), 
			  0, 0, 0);    
	 }
	 else {
	    earlierDate.set(aCalendar1.get(Calendar.YEAR), 
			    aCalendar1.get(Calendar.MONTH), 
			    aCalendar1.get(Calendar.DAY_OF_MONTH), 
			    0, 0, 0);

	    laterDate.set(aCalendar2.get(Calendar.YEAR), 
			  aCalendar2.get(Calendar.MONTH), 
			  aCalendar2.get(Calendar.DAY_OF_MONTH), 
			  0, 0, 0);
	 }

	 /*===========================================================*/
	 /* The first getTime() returns a Date, the second takes      */
	 /* that Date object and returns millesecs since 1/1/70.      */
	 /* The API has misleading and horrible naming here, sorry.   */
	 /*===========================================================*/
	 long duration =    laterDate.getTime().getTime() - earlierDate.getTime().getTime();   
                    
	 /*===========================================================*/
	 /* Do the math (teacher always said your units are important)*/
	 /*                                                           */
	 /*    1000 msec/sec * 60 sec/min * 60 min/hr * 24 hr/day     */
	 /* Cancel your units and you get msec/day.  Duration is in   */
	 /* msecs. Duration divided by (#msecs per day) gives us      */
	 /* number of days.                                           */
	 /*===========================================================*/
	 long nDays = duration / (24 * 60 * 60 * 1000);   
      
	 return (nDays);
      }

   /**
    * Returns a string from within the source string that matches a 
    * regular expression. 
    * @param       source:String
    *                 The source string 
    * @param       aPattern:String
    *                  The regualar expression
    * @return      :String -
    *                  The string from with the source that matches
    *                  the regualar expression.
    */
   public static  java.lang.String  findPatternInString (
                                                         java.lang.String  source,
                                                         java.lang.String  aPattern
							 )
      {
	 Pattern myPattern = null;
	 Matcher matcher = null;
	 	 
	 try {
	    myPattern = Pattern.compile(aPattern);
	 }
	 catch (PatternSyntaxException e) {
	    e.printStackTrace();
	    return ( "" );
	 }
	 
	 matcher = myPattern.matcher(source);
	 if (matcher.find()) {
	    return (matcher.group(0));
	 }
	 else {
	    return ( "" );
	 }
      }

   /**
    * Determines whether a string is valid or not based on the supplied array 
    * of valid characters.
    * @param      inputString:String
    *                 The source string 
    * @param       validChars:String
    *                  The regualar expression
    * @return      :int 
    *                  Returns -1 to indicate that the string is valid, any 
    *                  other value indicates failure
    */
   public static int isValidString( String inputString, char[] validChars)  {
      //i.e no invalid chars right now
      int invalidChar = -1;

      // if String is empty return whatever emptyIsValid says(using null char)
      if ( inputString == null || inputString.length() < 1 ) 
      {
	 return ' ';
      }

      char[] inputArray = inputString.toCharArray();

      // for each char in the input array
      for ( int i = 0; i < inputArray.length; i++)
      {
	 // compare it to each char in the valid array
	 int j = 0;
	 boolean bFound = false;
	 for ( ; j < validChars.length; j++)
	 {
	    if ( validChars[j] == inputArray[i] ) 
	    {
	       bFound = true;
	       break;
	    }
	 }
	 if (!bFound) {
	    invalidChar = inputArray[i]; 
	    return invalidChar;
	 }
      }
      return  invalidChar;
   }

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility.CommonUtility
    * <br>will result in the following output to the console
    * <p>CommonUtility.differenceInDays(today, Nov 27, 2004)=204
    * <br>findPatternInString("CMS4", "cms(\d{1})" =cms4
    * <br>CommonUtility.isValidString( "johndoe", 0123abcdefghijkmnopABCDEFGHIJKMNOP$~#+-_.)=-1
    * <br>CommonUtility.isValidString( "john@doe", 0123abcdefghijkmnopABCDEFGHIJKMNOP$~#+-_.)=64
    */
   public  static  void  main (
                               String  args []
			       ) {

   Calendar cal1 = Calendar.getInstance();
   Calendar cal2 = Calendar.getInstance();
   cal2.set(2004,10,27); //Nov 27, 2004
   System.out.println("\nCommonUtility.differenceInDays(today, Nov 27, 2004)=" + CommonUtility.differenceInDays(cal1, cal2));
   System.out.println("CommonUtility.findPatternInString(\"The code is located in the CMS4 directory on the P: drive\", \"cms(\\d{1})\" =" + CommonUtility.findPatternInString("cms4", "cms(\\d{1})"));
   String validChars = "0123abcdefghijkmnopABCDEFGHIJKMNOP$~#+-_.";
   System.out.println("CommonUtility.isValidString( \"johndoe\", " + validChars + ")=" + CommonUtility.isValidString( "johndoe", validChars.toCharArray()));
   System.out.println("CommonUtility.isValidString( \"john@doe\", " + validChars + ")=" + CommonUtility.isValidString( "john@doe", validChars.toCharArray()));

   }

}
