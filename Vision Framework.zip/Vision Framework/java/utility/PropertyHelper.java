/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

package COM.novusnet.vision.java.utility;

import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * This helper class allows "property" values to be retrieved. In the case
 * of an application, the property value is first accessed from
 * the system properties (as specified on the command line). If not present
 * in the system properties, the property value is read from the specified
 * file. The property file can to be found relative  to the "user.home" 
 * directory (as specified in the system properties) or the directory can 
 * be specified in the contructor.
 * @version 1.0, 3/27/98
 */
public  class  PropertyHelper {

   /**
    * The properties associated with the specified properties file.
    */
   protected Properties properties      = null;


   /**
    * This constructor loads the properties file looking in the 
    * user.home directory for the specified file.
    * <p>
    * Note: It is not necessary that the specified properties file
    * exist (even in the case of an application), so no exception will
    * be thrown if it can not be found.
    * <p>
    * @param fileName:String  The properties file name.
    */
   public    PropertyHelper (String  fileName)  {
      loadProperties(System.getProperty ("user.home"), fileName);
   }

   /**
    * This constructor loads the properties file looking in the 
    * specified directory for the specified file.
    * <p>
    * Note: It is not necessary that the specified properties file
    * exist (even in the case of an application), so no exception will
    * be thrown if it can not be found.
    * <p>
    * @param directoryName:String  The directory containing the properties file.
    * @param fileName:String  The properties file name.
    */
   public PropertyHelper (String directoryName, String  fileName)  {
      loadProperties(directoryName, fileName);
   }

   /**
    * Loads the properties file looking in the specified directory for
    * the specified file.
    * <p>
    * Note: It is not necessary that the specified properties file
    * exist (even in the case of an application), so no exception will
    * be thrown if it can not be found.
    * <p>
    * @param directoryName:String  The directory containing the properties file.
    * @param fileName:String  The properties file name.
    */
   private void loadProperties (String directoryName, String fileName) {
      properties = new Properties ();
      // Attempt to load the property value from the given properties file.                                     
      try {
	 properties.load (new BufferedInputStream (
						   new FileInputStream (directoryName +
									fileName)));
      }catch (IOException e) {
	 // The properties file's existence is not mandatory so we eat
	 // this exception
	 System.out.println("Property file << " + directoryName +
			    fileName + " >>can not be loaded!  ");
      }

   }

   /**
    * Returns the property value corresponding to the given property
    * name. This value will be accessed from the command line
    * specified system properties or the previously specified
    * properties file (in the case of an application), or the applet
    * parameters (in the case of an applet).
    * <p>
    * @param propertyName:String  The name of the property value to be retrieved.
    * @return String The property value.
    */
   public  String  getProperty (String  propertyName)   {
      String propertyValue  = null;

      /* Application: first attempt to retrieve the property value from the
	 system properties (as specified on the command line). If not 
	 present, retrieve the property value from the previously specified
	 properties file.
      */
      if (System.getProperty (propertyName) != null) {
	 return System.getProperty     (propertyName);
      }else {
	 propertyValue = properties.getProperty (propertyName);
	 if(propertyValue != null)
	   propertyValue = propertyValue.trim();
	 
	 return propertyValue;
      }
   }

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility.PropertyHelper
    * <br>will result in the following output to the console
    * <p>
    * testProperty=This is the test property value
    * <p>
    * Or if it cannot find the property file, you may see something similar
    * to the following:
    * <p>
    * Property file << C:\WINNT\Profiles\oflanne\test.properties >>can not be loaded!
    * <br>
    * testProperty=null
    */
   public static  void  main (java.lang.String  args[])  {
      PropertyHelper helper = new PropertyHelper("\\test.properties");
      System.out.println("testProperty=" + helper.getProperty("testProperty"));
   }
}



