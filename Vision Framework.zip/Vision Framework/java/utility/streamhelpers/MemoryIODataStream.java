package COM.novusnet.vision.java.utility.streamhelpers;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;


/**
This class allows input and output to a memory based stream. Currently,
Java supplies either input or output memory based streams but not
both.

A MemoryIODataStream delegates input/out methods to the aggregates
ObjectInputStream and ObjectOutputStreams. It supports a subset of ObjectInput/ObjectOutput
interfaces. The destination stream is set based on the method type.

*/
public class MemoryIODataStream {

    private int                     m_hashCode;
    private boolean               m_OutputStreamActive;
    private ObjectInputStream     m_InputStream;
    private ObjectOutputStream    m_OutputStream;
    private ByteArrayInputStream  m_InputByteArray;
    private ByteArrayOutputStream m_OutputByteArray;
    
    public MemoryIODataStream() {
       try {
          initialize();
       }
       catch (Exception e) {
       }   
    }

    /**
    Reads a 32 bit int.

    @return the 32 bit integer read.

    */
    public final int readInt() throws IOException {
       int result;
       setInputStream ();
       result = m_InputStream.readInt ();
       m_hashCode -= result;
       return result;
    }

    /**
    Reads a 16 bit char.

    @return the read 16 bit char.
    */
    public final char readChar() throws IOException {
       char result;
       setInputStream ();
       result = m_InputStream.readChar ();
       m_hashCode -= result;
       return result;
    }


    /**
    Reads a 64 bit long.

    @return the 64 bit long read.

    */
    public final long readLong() throws IOException {
       long result;
       setInputStream ();
       result = m_InputStream.readLong ();
       m_hashCode -= result;
       return result;
    }

    /**
    Reads an 8 bit byte.

    @return the 8 bit byte read
    */
    public final byte readByte() throws IOException {
       byte result;
       setInputStream ();
       result = m_InputStream.readByte ();
       m_hashCode -= result;
       return result;
    }

    /**
    Writes a 32 bit int.

    @param v the integer value to be written
    */
    public final void writeInt(int v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeInt (v);
       m_hashCode += v;
    }

    /**
    Reads a 32 bit float.

    @return the read 32 bit float.

    */
    public final float readFloat() throws IOException {
       setInputStream ();
       float result;
       setInputStream ();
       result = m_InputStream.readFloat ();
       m_hashCode -= result;
       return result;
    }


    /**
    Writes a 16 bit char.

    @param v the char value to be written

    */
    public final void writeChar(int v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeChar (v);
        m_hashCode += v;
    }

    /**
    Reads a 16 bit short.

    @return the 16 bit short read.

    */
    public final short readShort() throws IOException {
       setInputStream ();
       short result;
       setInputStream ();
       result = m_InputStream.readShort ();
       m_hashCode -= result;
       return result;
    }

    /**
    Writes a 64 bit long.

    @param v the long value to be written

    */
    public final void writeLong(long v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeLong (v);
        m_hashCode += v;
    }

    /**
    Writes an 8 bit byte.

    @param v the byte value to be written

    */
    public final void writeByte(int v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeByte (v);
        m_hashCode += v;
    }

    /**
    Reads a 64 bit double.

    @return the 64 bit double read.

    */
    public final double readDouble() throws IOException {
       setInputStream ();
       double result;
       setInputStream ();
       result = m_InputStream.readDouble ();
       m_hashCode -= result;
       return result;
    }

    /**
    Writes a 32 bit float.

    @param v the float value to be written

    */
    public final void writeFloat(float v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeFloat (v);
        m_hashCode += v;
    }

    /**
    Writes a 16 bit short.

    @param v the short value to be written

    */
    public final void writeShort(int v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeShort (v);
        m_hashCode += v;
    }

    /**
    Reads a boolean.
    @return the boolean read.

    */
    public final boolean readBoolean() throws IOException {
       setInputStream ();
       boolean result;
       setInputStream ();
       result = m_InputStream.readBoolean ();
       m_hashCode -= result ? 1 : 0;
       return result;
    }

    /**
    Writes a 64 bit double.
    @param v the double value to be written

    */
    public final void writeDouble(double v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeDouble (v);
       m_hashCode -= v;
    }

    /**
    Writes a boolean.

    @param v the boolean to be written

    */
    public final void writeBoolean(boolean v) throws IOException {
       setOutputStream ();
       m_OutputStream.writeBoolean (v);
        m_hashCode += v ? 1 : 0;
    }

    /**
    Reads a UTF format String.

    @return the String.

    */
    public final String readUTF() throws IOException {
       setInputStream ();
       String result;
       setInputStream ();
       result = m_InputStream.readUTF ();
       m_hashCode -= result.hashCode();
       return result;
    }


    /**
    Writes a String in UTF format.

    @param str the String in UTF format

    */
    public final void writeUTF(String str) throws IOException {
       setOutputStream ();
       m_OutputStream.writeUTF (str);
         m_hashCode += str.hashCode();
    }


    /**
     * Read an object from the ObjectInputStream.
     * The class of the object, the signature of the class, and the values
     * of the non-transient and non-static fields of the class and all
     * of its supertypes are read.  Default deserializing for a class can be
     * overriden using the writeObject and readObject methods.
     * Objects referenced by this object are read transitively so
     * that a complete equivalent graph of objects is reconstructed by readObject. <p>
     *
     * The root object is completly restored when all of its fields
     * and the objects it references are completely restored.  At this
     * point the object validation callbacks are executed in order
     * based on their registered priorities. The callbacks are
     * registered by objects (in the readObject special methods)
     * as they are individually restored.
     *
     * Exceptions are thrown for problems with the InputStream and for classes
     * that should not be deserialized.  All exceptions are fatal to the
     * InputStream and leave it in an indeterminate state; it is up to the caller
     * to ignore or recover the stream state.
     * @exception java.lang.ClassNotFoundException Class of a serialized object
     *      cannot be found.
     * @exception InvalidClassException Something is wrong with a class used by
     *     serialization.
     * @exception StreamCorruptedException Control information in the
     *     stream is inconsistent.
     * @exception OptionalDataException Primitive data was found in the
     * stream instead of objects.
     * @exception IOException Any of the usual Input/Output related exceptions.
     */
    public final Object readObject() throws ClassNotFoundException, IOException
    {
       setInputStream ();
       Object result;
       setInputStream ();
       result = m_InputStream.readObject ();
       m_hashCode -= result.hashCode();
       return result;
    }

    /**
     * Write the specified object to the ObjectOutputStream.
     * The class of the object, the signature of the class, and the values
     * of the non-transient and non-static fields of the class and all
     * of its supertypes are written.  Default serialization for a class can be
     * overridden using the writeObject and the readObject methods.
     * Objects referenced by this object are written transitively so
     * that a complete equivalent graph of objects can be
     * reconstructed by an ObjectInputStream.  <p>
     *
     * Exceptions are thrown for
     * problems with the OutputStream and for classes that should not be
     * serialized.  All exceptions are fatal to the OutputStream, which
     * is left in an indeterminate state, and it is up to the caller
     * to ignore or recover the stream state.
     * @exception IOException Any exception thrown by the underlying OutputStream.
     */
    public final void writeObject(Object obj) throws IOException
    {
       setOutputStream ();
       m_OutputStream.writeObject (obj);
       m_hashCode += obj.hashCode();
    }



    /**
    Switches the stream to point to the input stream. If there is any
    data in the output stream it is inserted into the input stream.
    */
    private void setInputStream() throws IOException{
                /*======================================================*/
                /* Input Stream is already active - just return         */
                /*======================================================*/
       if ( ! m_OutputStreamActive) {
          return;
       }
       
       if (m_OutputStream != null) {
          m_OutputStream.flush();
       }   
       
                  /*======================================================*/
                   /* Create a byte array stream, copying any data from    */
                   /* the existing output byte array stream.               */
                   /*======================================================*/
       m_InputByteArray  = new ByteArrayInputStream(m_OutputByteArray.toByteArray ());

                   /*======================================================*/
                   /* Associate a data input stream with the byte stream   */
                   /*======================================================*/
       m_InputStream     = new ObjectInputStream (m_InputByteArray);
       
                   /*======================================================*/
                   /* Turn off the output stream active flag               */
                   /*======================================================*/
       m_OutputStreamActive = false;
    }

    /**
    Switches the stream to point to the out stream. If there is any data
    in the input stream it is inserted into the output stream.
    */
    private void setOutputStream()  throws IOException {
                /*======================================================*/
                /* Output Stream is already active - just return        */
                /*======================================================*/
       if (m_OutputStreamActive) {
          return;
       }
              
       if (m_InputStream != null) {
	  // stream has been set to input mode so re initialize it.
	  initialize();
       }
                /*======================================================*/
                /* Create a new output byte array stream                */
                /*======================================================*/
       m_OutputByteArray = new ByteArrayOutputStream ();
       
                /*======================================================*/
                /* Associate a data output stream with the byte stream  */
                /*======================================================*/
       m_OutputStream    = new ObjectOutputStream (m_OutputByteArray);

                        /*==============================================*/
                        /* Copy any input stream data                   */
                        /*==============================================*/
  
                /*======================================================*/
                /* Set the output stream active flag                    */
                /*======================================================*/
       m_OutputStreamActive = true;
    }


  
    /**
     * Clears the contents of the MemoryIODataStream. This effectively 
     * reinitializes the streams to null.
     *
     * @exception 
     * IOException  If an I/O error has occurred.
     */
    public final void clear()  throws IOException
    {
       initialize();
    }
    
    /**
     * Initializes this instance
     */
    private final void initialize() throws IOException
    {
       m_OutputStreamActive = false;
       m_OutputStream       = null;
       m_InputStream        = null;
       m_InputByteArray     = null;
       m_OutputByteArray    = null;
       m_hashCode = 0;
       setOutputStream();
    }
    
    /**
     * Calculate the hash code for a MemoryIODataStream instance, based
     * on its contents.
     *
     * @return  
     * The hash code calculated for the stream.
     *
     * @exception 
     * IOException  If an I/O error has occurred.
     */

    public int hashCode()
    {
       return m_hashCode;
    }


    /**
     * Returns the number of bytes that can be read without blocking.
     *
     * @return  
     * The number of bytes that can be read.
     * 
     * @exception 
     * IOException  If an I/O error has occurred.
     */
    public int available() throws IOException
    {
       setInputStream ();
       return (m_InputStream.available ());
    }

    public static void main(String[] argv) throws IOException {
       MemoryIODataStream myStream = new MemoryIODataStream ();
       
       Object anObject = new Object();
       
       try {
          System.out.println(anObject);
          myStream.writeObject(anObject);           
          anObject = myStream.readObject();           
          System.out.println(anObject);
       }
       catch (Exception e) {
          e.printStackTrace();
       }   
       myStream.writeFloat (6.5F);           
       myStream.writeUTF   ("North Carolina");
       System.out.println(myStream.hashCode());              
                                    
       System.out.println  ("At "   + myStream.readFloat () + " ft.,");

       myStream.writeInt   (23);
       System.out.println  ("From " + myStream.readUTF   () + ",");
       myStream.writeUTF   ("Michael Jordan");
       System.out.println  ("No. "  + myStream.readInt   () +
                            ", "    + myStream.readUTF   () + ".");
                                                        
    }


    /**
     * Read an object reference from the ObjectInputStream.
     * @exception java.lang.ClassNotFoundException Class of a serialized object
     *      cannot be found.
     * @exception InvalidClassException Something is wrong with a class used by
     *     serialization.
     * @exception StreamCorruptedException Control information in the
     *     stream is inconsistent.
     * @exception OptionalDataException Primitive data was found in the
     * stream instead of objects.
     * @exception IOException Any of the usual Input/Output related exceptions.
     */
    public final Object readObjectReference() throws ClassNotFoundException, IOException
    {
       setInputStream ();       
       ReferenceHolder aHolder           = (ReferenceHolder) m_InputStream.readObject ();
       Object          anObjectReference = aHolder.getObjectReference ();
       m_hashCode -= aHolder.hashCode();
       aHolder.releaseReference ();
       return (anObjectReference);
    }

    /**
     * Write the specified object reference to the ObjectOutputStream.
     * @exception IOException Any exception thrown by the underlying OutputStream.
     */
    public final void writeObjectReference(Object obj) throws IOException
    {
       setOutputStream ();       
       m_OutputStream.writeObject (new ReferenceHolder(obj));
       m_hashCode += obj.hashCode();
    }

}

