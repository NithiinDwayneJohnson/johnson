package COM.novusnet.vision.java.utility.streamhelpers;

import java.io.Serializable;

import java.util.HashMap;

/**
 * The Reference Holder class allows Java object references to be written
 * to a stream. It adds the object reference provided to a static collection
 * of references (typically before the Reference Holder is written to
 * the stream) and later retrieves the reference from the collection
 * (after the holder is read from the stream).
 * 
 * <br>Each Reference Holder instance stores its associated reference
 * in the static collection and identifies it by means of a unique object
 * key.
 * @version 1.0, 5/1/98
*/
public class ReferenceHolder implements Serializable {

   /**
    * This is a static collection of object references. It holds object
    *  references while the Reference Holder is streamed.
    */
   private static HashMap s_ObjectReferences = new HashMap();
   /**
    *  This object is used to lock the static object reference collection.
    */
   private static Object s_Lock = new Object ();
   /**
    *  This static counter is used to provide a key to uniquely identify
    * references in the static object reference collection.
    */
   private static long s_KeyCounter = 0;
   /**
    *  This is a unique key which identifies the object reference associated
    *  with this Reference Holder instance.
    */
   private long m_ObjectKey;

   /**
    *  The Reference Holder constructor, which takes the object reference
    *  provided, creates a unique object key for it and adds the object
    *  reference to the static collection of object references.
    *
    * @param anObject:Object  The object that will be contained within this
    * Reference Holder instance.
    *
    */
   public ReferenceHolder(Object anObject) {
      /*======================================================*/
      /* Increment the static key counter. This is used to    */
      /* provide a unique Long key to identify the object     */
      /* reference associated with this Reference Holder      */
      /* instance. Add the reference to the static collection */
      /* of object references.                                */
      /* NOTE: the counter will eventually wrap-around, but   */
      /* given that it is a 64-bit number, the probability of */
      /* it happening in a single session is infinitesimal.   */
      /*======================================================*/
      synchronized (s_Lock) {
	 m_ObjectKey = s_KeyCounter;
	 s_ObjectReferences.put (new Long (s_KeyCounter++), anObject);
      }
   }

   /**
    * Returns the object reference associated with this Reference Holder
    * instance. The object reference is located in the static collection
    * of references using a unique object key and returned.
    *
    * @return Object The object reference associated with this Reference Holder
    * instance.
    */
   public Object getObjectReference() {
      /*======================================================*/
      /* Use the object key to locate the object reference    */
      /* associated with this instance from within the static */
      /* collection and return it to the caller.              */
      /*======================================================*/    
      return (s_ObjectReferences.get (new Long (m_ObjectKey)));
   }

   /**
    * Releases (removes) the object reference associated with this Reference
    * Holder instance. The object reference is located in the static collection
    * of references using a unique object key and removed.
    */
   public void releaseReference() {
      /*======================================================*/
      /* Use the object key to locate the object reference    */
      /* associated with this instance from within the static */
      /* collection and remove it.                            */
      /*======================================================*/        
      s_ObjectReferences.remove (new Long (m_ObjectKey));
   }

   /**
    *  Main method, used for command line unit testting and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder
    * <br>will result in the following output to the console
    * <p>
    * <br>
    * <br>Create a new object.
    * <br>        Object anObject = new Object()
    * <br>        Original  Object Hash Code = 7474923
    * <br>Create a new ReferenceHolder.
    * <br>        ReferenceHolder aReferenceHolder = new ReferenceHolder (anObject)
    * <br>Get the Object from the ReferenceHolder and see if it's hash code is the same as the original object's.
    * <br>        aReferenceHolder.getObjectReference ().hashCode=7474923
    * <br>Release the reference and show that the object is no longer accessible.
    * <br>        aReferenceHolder.releaseReference ()
    * <br>        aReferenceHolder.getObjectReference()=null
    */
   public static void main(String args[]) {
      System.out.println("Create a new object.");
      Object anObject                  = new Object          ();          
      System.out.println("\tObject anObject = new Object()");
      System.out.println ("\tOriginal  Object Hash Code = " + anObject.hashCode ());    
      System.out.println("Create a new ReferenceHolder.");    
      ReferenceHolder aReferenceHolder = new ReferenceHolder (anObject);
      System.out.println("\tReferenceHolder aReferenceHolder = new ReferenceHolder (anObject)");
      System.out.println("Get the Object from the ReferenceHolder and see if it's hash code is the same as the original object's.");
      System.out.println("\taReferenceHolder.getObjectReference ().hashCode=" +  aReferenceHolder.getObjectReference ().hashCode());
      System.out.println("Release the reference and show that the object is no longer accessible.");    
      aReferenceHolder.releaseReference ();
      System.out.println("\taReferenceHolder.releaseReference ()");
      System.out.println("\taReferenceHolder.getObjectReference()=" + aReferenceHolder.getObjectReference());
   }
}


