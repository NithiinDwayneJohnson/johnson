/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.streamhelpers;

import java.io.Serializable;
/**
 * May be used as a semaphore to synchronize blocks of code. It is an
 * java.lang.Object and it implements Serializable so that it may be
 * serialized correctly and thus any class using it may be serialized
 * also.
 * <p> Eg
 *    Lock lock  = new Lock();
 *    ....
 *    synchronized(lock) {
 *       //statements to be synchronized
 *    }
 * @version 1.0, 5/1/98
 */

public  class  Lock  extends  Object implements  Serializable {
}
