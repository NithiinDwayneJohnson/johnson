package COM.novusnet.vision.java.utility;

/**
 * Implements Runnable but allows up to 5 parameters to be passed. A user does
 * not have to create a separate subclass of runnable but can simply use this class.
 * <br>The Runnable interface should be implemented by any class whose instances
 * are intended to be executed by a thread. 
 * The class must define a method of no arguments called run. 
 */
public abstract class RunnableWithParams implements Runnable {
   protected Object param1;
   protected Object param2;
   protected Object param3;
   protected Object param4;
   protected Object param5;
   
   /**
    * Constructor that takes 5 parameters.
    * @param param1:Object 
    * @param param2:Object 
    * @param param3:Object 
    * @param param4:Object 
    * @param param5:Object 
    */
   public RunnableWithParams(Object param1, Object param2, Object param3, Object param4, Object param5) {
      this.param1 = param1;
      this.param2 = param2;
      this.param3 = param3;
      this.param4 = param4;
      this.param5 = param5;
   }

   /**
    * Constructor that takes 4 parameters.
    * @param param1:Object 
    * @param param2:Object 
    * @param param3:Object 
    * @param param4:Object 
    */
   public RunnableWithParams(Object param1, Object param2, Object param3, Object param4) {
      this.param1 = param1;
      this.param2 = param2;
      this.param3 = param3;
      this.param4 = param4;
   }

   /**
    * Constructor that takes 3 parameters.
    * @param param1:Object 
    * @param param2:Object 
    * @param param3:Object 
    */
   public RunnableWithParams(Object param1, Object param2, Object param3) {
      this.param1 = param1;
      this.param2 = param2;
      this.param3 = param3;
   }
   
   /**
    * Constructor that takes 2 parameters.
    * @param param1:Object 
    * @param param2:Object 
    */
   public RunnableWithParams(Object param1, Object param2) {
      this(param1, param2, null);
   }
   
   /**
    * Constructor that takes 1 parameter.
    * @param param1:Object 
    */
   public RunnableWithParams(Object param1) {
      this(param1, null, null);
   }
   
   /**
    * Returns the first parameter.
    * @return Object 
    */
   public Object getFirstParameter() {
      return param1;
   }
   
   /**
    * Returns the second parameter.
    * @return Object 
    */
   public Object getSecondParameter() {
      return param2;
   }
   
   /**
    * Returns the third parameter.
    * @return Object 
    */
   public Object getThirdParameter() {
      return param3;
   }

   /**
    * Returns the fourth parameter.
    * @return Object 
    */
   public Object getFourthParameter() {
      return param4;
   }

   /**
    * Returns the fifth parameter.
    * @return Object 
    */
   public Object getFifthParameter() {
      return param5;
   }


   /**
    * The run() method needs to be implmented by the user of this class.
    */
   public abstract void run();      

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility..RunnableWithParams
    * <br>will result in the following output to the console
    * <p>
    * <br>myThread is running...param 1.param 2.param 3......
    */
   public static  void  main (java.lang.String  args[])  {
      String param1 = new String("param 1");
      String param2 = new String("param 2");
      String param3 = new String("param 3");

      Thread myThread = new Thread( new RunnableWithParams(param1, param2, param3){
	 public void run() {
	    System.out.print("\nmyThread is running.");
	    for (int i=0;i<10;i++) {
	       try {
		  Thread.sleep(1000);
	       }catch (InterruptedException e) {
		  e.printStackTrace();
	       }
	       System.out.print(".");
	       if (i == 1) {
		  System.out.print(getFirstParameter());
	       }else if (i == 2) {
		  System.out.print(getSecondParameter());
	       }else if (i == 3) {
		  System.out.print(getThirdParameter());
	       }
	    }
	 }
      });
      myThread.start();
   }

}
