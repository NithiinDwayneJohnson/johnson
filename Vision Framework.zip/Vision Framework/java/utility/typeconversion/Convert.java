/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.typeconversion;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import java.util.Calendar;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
//++ CI 212 Used for locale object
import java.util.Locale; 

/**
 * Methods to convert between various Java primitive types.
 * @version 1.0, 4/26/1997
 */
public class  Convert {

   static Calendar calendar = Calendar.getInstance();

   /**
    * Converts a Java primitive "char" value into a
    * primitive boolean.
    * <p>
    * The byte value of 0.0 and the character values of '0' (zero),
    * 'N' (no), and 'F' (false) in both upper and lower case, are
    * considered to represent boolean false.
    * <p>
    * All other values are considered to represent true.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the char value
    */
   public  final  static  boolean  intoBoolean (char aValue) {
      return (intoBoolean (aValue, "0NnFf"));
   }

   /**
    * Converts a Java primitive "char" value into a
    * primitive boolean, based upon a string of allowable "false"
    * values.
    *
    * <b>Note:</b> A value of integer zero will always be
    * mapped to false.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @param       aFalseValues:String
    *                   a string containing all of the characters
    *                   that would correspond to a boolean value
    *                   of false. (All other values will be mapped
    *                   to true.)
    * @return      :boolean
    *                 - the boolean equivalent of the char value
    */
   public final static boolean intoBoolean (char aValue, String aFalseValues) {
      if (aValue == 0) {
         return (false);
      }
      else {
         return (aFalseValues.indexOf (aValue) == -1);
      }
   }

   /**
    * Converts a Java primitive "double" value into a
    * primitive boolean.
    * <p>
    * A value of 0 is considered to represent boolean false, while
    * all other values are considered to represent true.
    *
    * @param       aValue:double
    *                   the double value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the double value
    */
   public  final  static  boolean  intoBoolean (double    aValue) {
      return (aValue != 0.0);
   }

   /**
    * Converts a Java primitive "float" value into a
    * primitive boolean.
    * <p>
    * A value of 0.0 is considered to represent boolean false, while
    * all other values are considered to represent true.
    *
    * @param       aValue:float
    *                   the float value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the float value
    */
   public  final  static  boolean  intoBoolean (float aValue) {
      return (aValue != 0.0F);
   }

   /**
    * Converts a Java primitive "int" value into a
    * primitive boolean.
    * <p>
    * A value of 0 is considered to represent boolean false, while
    * all other values are considered to represent true.
    *
    * @param       aValue:int
    *                   the int value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the int value
    */
   public  final  static  boolean  intoBoolean (int aValue) {
      return (aValue != 0);
   }

   /**
    * Converts a Java primitive "long" value into a
    * primitive boolean.
    * <p>
    * A value of 0 is considered to represent boolean false, while
    * all other values are considered to represent true.
    *
    * @param       aValue:long
    *                   the long value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the long value
    */
   public  final  static  boolean  intoBoolean (long aValue) {
      return (aValue != 0);
   }

   /**
    * Converts a Java primitive "short" value into a
    * primitive boolean.
    * <p>
    * A value of 0 is considered to represent boolean false, while
    * all other values are considered to represent true.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the short value
    */
   public  final  static  boolean  intoBoolean (short  aValue) {
      return (aValue != 0);
   }

   /**
    * Converts a Java primitive "String" value into a
    * primitive boolean.
    * <p>
    * The rules for conversion of the string follow the rules
    * specified in the Boolean class object constructor which takes
    * a String parameter.
    *
    * @param       aValue:String
    *                   the String value to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the String value
    */
   public  final  static  boolean  intoBoolean (String aValue) {
      if ( aValue == null || aValue.equals("") ) 
	return false;

      return ((new Boolean (aValue)).booleanValue ());
   }

   /**
    * Converts a Java Integer object into a
    * primitive boolean.
    * <p>
    * A primitive integer value is obtained from the integer object,
    * and, at that point, a value of 0 is considered to represent
    * boolean false, while all other values are considered to
    * represent true.
    *
    * @param       aValue:Integer
    *                   the Integer object to be converted
    * @return      :boolean
    *                 - the boolean equivalent of the Integer object
    */
   public  final  static  boolean  intoBoolean (Integer aValue) {
      return (aValue.intValue () != 0);
   }

   /**
    * Converts a Java primitive boolean value into a
    * primitive char of either the supplied true or false
    * character.
    *
    * @param       aValue:boolean
    *                   the boolean value to be converted
    * @param       aTrueValue:char
    *                   the character to be returned if the boolean
    *                   value is true.
    * @param       aFalseValue:char
    *                   the character to be returned if the boolean
    *                   value is false.
    * @return      :double
    *                 - the char equivalent of the boolean value
    */
   public  final  static  char  intoChar (boolean   aValue,
                                          char      aTrueValue,
                                          char      aFalseValue) {
      return ((aValue) ? aTrueValue : aFalseValue);
   }

   /**
    * Converts a Java primitive char value into a
    * primitive double.
    * <p>
    * The primitive char value is converted into an Integer object,
    * from which a double value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @return      :double
    *                 - the double equivalent of the char value
    */
   public  final  static  double  intoDouble (char aValue){
      return ((new Integer (aValue)).doubleValue ());
   }

   /**
    * Converts a Java primitive float value into a
    * primitive double.
    * <p>
    * The primitive float value is converted into a Float object,
    * from which a double value is obtained using the appropriate
    * Float class method.
    *
    * @param       aValue:float
    *                   the float value to be converted
    * @return      :double
    *                 - the double equivalent of the float value
    */
   public  final  static  double  intoDouble (float aValue) {
      return ((new Float (aValue)).doubleValue ());
   }

   /**
    * Converts a Java primitive int value into a
    * primitive double
    * <p>
    * The primitive int value is converted into an Integer object,
    * from which a double value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:int
    *                   the int value to be converted
    * @return      :double
    *                 - the double equivalent of the int value
    */
   public  final  static  double  intoDouble (int aValue){
      return ((new Integer (aValue)).doubleValue ());
   }

   /**
    * Converts a Java primitive long value into a
    * primitive double.
    * <p>
    * The primitive long value is converted into an Long object,
    * from which a double value is obtained using the appropriate
    * Long class method.
    *
    * @param       aValue:long
    *                   the long value to be converted
    * @return      :double
    *                 - the double equivalent of the long value
    */
   public  final  static  double  intoDouble (long aValue) {
      return ((new Long (aValue)).doubleValue ());
   }

   /**
    * Converts a Java primitive short value into a
    * primitive double.
    * <p>
    * The primitive short value is converted into an Integer object,
    * from which a double value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :double
    *                 - the double equivalent of the short value
    */
   public  final  static  double  intoDouble (short aValue){
      return ((new Integer (aValue)).doubleValue ());
   }

   /**
    * Converts a Java primitive String value into a
    * primitive double.
    * <p>
    * The primitive String value is converted into a new Double
    * object, using the appropriate constructor, from which a
    * double value is obtained using the appropriate Double class
    * method.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :double
    *                 - the double equivalent of the String value
    */
   public final static double  intoDouble (String aValue) {

      /*======================================================*/
      /* Avoid any exceptions caused by passing a null string */
      /*                                                      */
      /* Note: A null string passed to the constructor of a   */
      /*       Double object results in an exception.         */
      /*======================================================*/
      if (aValue == null || aValue.equals ("")) {
         return (0.0);
      }
      try {
	      return ((new Double (aValue)).doubleValue ());
      } catch ( NumberFormatException nfe ) {
      	return 0.0;
      }
   }

   /**
    * Converts a Java Integer object into a
    * primitive double value.
    *
    * @param       aValue:Integer
    *                   the Integer object to be converted
    * @return      :double
    *                 - the double equivalent of the Integer object.
    */
   public  final  static  double  intoDouble (Integer aValue) {
      return (aValue.doubleValue ());
   }

   /**
    * Converts a Java primitive char value into a
    * primitive float.
    * <p>
    * The primitive char value is converted into an Integer object,
    * from which a float value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @return      :float
    *                 - the float equivalent of the char value
    */
   public  final  static  float  intoFloat (char aValue){
      return ((new Integer (aValue)).floatValue ());
   }

   /**
    * Converts a Java primitive double value into a
    * primitive float.
    * <p>
    * The primitive double value is converted into a Double object,
    * from which a float value is obtained using the appropriate
    * Double class method.
    *
    * @param       aValue:double
    *                   the double value to be converted
    * @return      :float
    *                 - the float equivalent of the double value
    */
   public  final  static  float  intoFloat (double aValue)  {
      return ((new Double (aValue)).floatValue ());
   }

   /**
    * Converts a Java primitive int value into a
    * primitive float.
    * <p>
    * The primitive int value is converted into an Integer object,
    * from which a float value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:int
    *                   the int value to be converted
    * @return      :float
    *                 - the float equivalent of the int value
    */
   public  final  static  float  intoFloat (int aValue) {
      return ((new Integer (aValue)).floatValue ());
   }

   /**
    * Converts a Java primitive long value into a
    * primitive float.
    * <p>
    * The primitive long value is converted into a Long object,
    * from which a float value is obtained using the appropriate
    * Long class method.
    *
    * @param       aValue:long
    *                   the long value to be converted
    * @return      :float
    *                 - the float equivalent of the long value
    */
   public  final  static  float  intoFloat (long aValue) {
      return ((new Long (aValue)).floatValue ());
   }

   /**
    * Converts a Java primitive short value into a
    * primitive float.
    * <p>
    * The primitive short value is converted into an Integer object,
    * from which a float value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :float
    *                 - the float equivalent of the short value
    */
   public  final  static  float  intoFloat (short aValue) {
      return ((new Integer (aValue)).floatValue ());
   }

   /**
    * Converts a Java primitive String value into a
    * primitive float.
    * <p>
    * The primitive String value is converted into a new Float
    * object, using the appropriate constructor, from which a
    * float value is obtained using the appropriate Float class
    * method.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :float
    *                 - the float equivalent of the String value
    */
   public  final  static  float  intoFloat (String aValue) {

      /*======================================================*/
      /* Avoid any exceptions caused by passing a null string */
      /*                                                      */
      /* Note: A null string passed to the constructor of a   */
      /*       Float object results in an exception.          */
      /*======================================================*/
      if (aValue == null || aValue.equals ("")) {
         return (0.0F);
      }

      return ((new Float (aValue)).floatValue ());
   }

   /**
    * Converts a Java Integer object into a
    * primitive float value.
    *
    * @param       aValue:Integer
    *                   the Integer object to be converted
    * @return      :float
    *                 - the float equivalent of the Integer object.
    */
   public  final  static  float  intoFloat (Integer aValue){
      return (aValue.floatValue ());
   }

   /**
    * Converts a Java primitive char value into a
    * primitive int.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @return      :int
    *                 - the int equivalent of the char value
    */
   public  final  static  int  intoInt (char aValue) {
      return ((int) aValue);
   }

   /**
    * Converts a Java primitive double value into a
    * primitive int.
    * <p>
    * The primitive double value is converted into a Double object,
    * from which an int value is obtained using the appropriate
    * Double class method.
    *
    * @param       aValue:double
    *                   the double value to be converted
    * @return      :int
    *                 - the int equivalent of the double value
    */
   public  final  static  int  intoInt (double aValue) {
      return ((new Double (aValue)).intValue ());
   }
 
   /**
    * Converts a Java primitive float value into a
    * primitive int.
    * <p>
    * The primitive float value is converted into a Float object,
    * from which an int value is obtained using the appropriate
    * Float class method.
    *
    * @param       aValue:float
    *                   the float value to be converted
    * @return      :int
    *                 - the int equivalent of the float value
    */
   public  final  static  int   intoInt (float aValue) {
      return ((new Float (aValue)).intValue ());
   }

   /**
    * Converts a Java primitive long value into a
    * primitive int.
    *
    * @param       aValue:long
    *                   the long value to be converted
    * @return      :int
    *                 - the int equivalent of the long value
    */
   public  final  static  int  intoInt (long aValue) {
      return ((int) aValue);
   }

   /**
    * Converts a Java primitive short value into a
    * primitive int.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :int
    *                 - the int equivalent of the short value
    */
   public  final  static  int  intoInt (short aValue) {
      return ((int) aValue);
   }

   /**
    * Converts a Java primitive String value into a
    * primitive int.
    * <p>
    * The primitive String value is converted into an Integer object,
    * from which an int value is obtained using the appropriate
    * Integer class method.
    *
    * @param       aValue:String
    *                   the String value to be converted
    * @return      :int
    *                 - the int equivalent of the String value
    */
   public  final  static  int  intoInt (String aValue) {

      /*======================================================*/
      /* Avoid any exceptions caused by passing a null string */
      /*                                                      */
      /* Note: A null string passed to the constructor of an  */
      /*       Integer object results in an exception.        */
      /*======================================================*/
      if (aValue == null || aValue.equals ("")) {
         return (0);
      }
      try {
	 return ((new Integer (aValue)).intValue ());
      }
      catch (NumberFormatException e)  {
	 return (0);
      }
      
   }

   /**
    * Converts a Java Integer object into a
    * primitive int.
    *
    * @param       aValue:Integer
    *                   the Integer value to be converted
    * @return      :int
    *                 - the int equivalent of the Integer object.
    */
   public  final  static  int  intoInt (Integer   aValue){
      return (aValue.intValue ());
   }


   /**
    * Converts a Java primitive String value into a
    * primitive long.
    * 
    * The primitive String value is converted into a Long object,
    * from which an long value is obtained using the appropriate
    * Long class method.
    *
    * @param       aValue:String
    *                   the String value to be converted
    * @return      :long
    *                 - the long equivalent of the String value
    * @see         java.lang.Long#Long(String)
    * @see         java.lang.Long#intValue
    */
   public  final  static  long  intoLong (String    aValue){

                /*======================================================*/
                /* Avoid any exceptions caused by passing a null string */
                /*                                                      */
                /* Note: A null string passed to the constructor of an  */
                /*       Long object results in an exception.           */
                /*======================================================*/
      if (aValue == null || aValue.equals ("")) {
         return (0L);
      }
      try {
          return ((new Long (aValue)).longValue ());
      }
      catch (NumberFormatException e)  {
        return (0);
      }
      
   }

   /**
    * Converts a Java primitive boolean value into a
    * primitive String.
    *
    * @param       aValue:boolean
    *                   the boolean value to be converted
    * @return      :String
    *                 - the String equivalent of the boolean value.
    */
   public  final  static  String  intoString (boolean   aValue) {
      return (String.valueOf (aValue));
   }

   /**
    * Converts a Java primitive boolean value into a
    * primitive String.
    *
    * @param       aValue:boolean
    *                   the boolean value to be converted
    * @param       aTrueValue:String
    *                   the string to be returned if the boolean
    *                   value is true.
    * @param       aFalseValue:String
    *                   the string to be returned if the boolean
    *                   value is false.
    * @return      :String
    *                 - the String equivalent of the boolean value.
    */
   public  final  static  String  intoString (boolean aValue, 
					      String aTrueValue,
                                              String aFalseValue) {
      return ((aValue) ? aTrueValue : aFalseValue);
   }

   /**
    * Converts a Java primitive char value into a
    * primitive String.
    *
    * @param       aValue:char
    *                   the char value to be converted
    * @return      :String
    *                 - the String equivalent of the char object.
    */
   public  final  static  String  intoString (char aValue) {
      return (String.valueOf (aValue));
   }

   /**
    * Converts a Java primitive double value into a
    * primitive String.
    *
    * @param       aValue:double
    *                   the double value to be converted
    * @return      :String
    *                 - the String equivalent of the double value.
    */
   public  final  static  String  intoString (double aValue) {
      return (String.valueOf (aValue));
   }

   /**
    * Converts a Java primitive float value into a
    * primitive String.
    *
    * @param       aValue:float
    *                   the float value to be converted
    * @return      :String
    *                 - the String equivalent of the float value.
    */
   public  final  static  String  intoString (float aValue) {
      return (String.valueOf (aValue));
   }

   /**
    * Converts a Java primitive int value into a
    * primitive String.
    *
    * @param       aValue:int
    *                   the int value to be converted
    * @return      :String
    *                 - the String equivalent of the int value.
    */
   public  final  static  String  intoString (int aValue) {
      return (Integer.toString (aValue));
   }

   /**
    * Converts a Java primitive long value into a
    * primitive String.
    *
    * @param       aValue:long
    *                   the long value to be converted
    * @return      :String
    *                 - the String equivalent of the long value.
    */
   public  final  static  String  intoString (long aValue) {
      return (Long.toString (aValue));
   }

   /**
    * Converts a Java primitive short value into a
    * primitive String.
    *
    * @param       aValue:short
    *                   the short value to be converted
    * @return      :String
    *                 - the String equivalent of the short value.
    */
   public  final  static  String  intoString (short aValue) {
      return (Integer.toString (aValue));
   }

   /**
    * Converts a Java Calendar object into a
    * primitive String value, based upon a supplied mask.
    * f the Mask is null or "" it uses a 
    * locale dependent default Stringi Mask
    *
    * @param       aValue:Calendar
    *                   the Calendar object to be converted
    * @param       aaMask:String
    *                   the mask string that defines the various
    *                   date and time fields to be included and in
    *                   what form.
    * @return      :String
    *                 - the String equivalent of the Calendar object,
    *                   according to the supplied mask string.
    */
   public final static String  intoString (Calendar aValue, String aMask) {
      String          myMask        = "";

      if (aValue == null) {
	 return ("");
      }
      if ( aMask == null || aMask.length()<1 ) {
          
	 /*==============================================================*/
	 /*  Have to set the TimeZone on the DateFormat and so have to   */
	 /*  up-cast to SimpleDateFormat. Else could have done  just this*/
	 /*  DateFormat myFormat = DateFormat.getDateInstance();         */
	 /*  return myFormat.format( aValue.getTime() );                 */ 
	 /*==============================================================*/
	 SimpleDateFormat myFormat = (SimpleDateFormat)
	 DateFormat.getDateInstance();

	 myFormat.setTimeZone( aValue.getTimeZone() );
	 return myFormat.format( aValue.getTime() ); 
      }

      char            myLastChar = aMask.charAt (0);

      /*==============================================*/
      /* Add field delimiters into the mask as needed */
      /*==============================================*/
      for (int i = 0; i < aMask.length (); i++) {
         char myThisChar = aMask.charAt (i);
         if (myThisChar != myLastChar) {
            if ((Convert.isAlpha (myThisChar)) &&
                (Convert.isAlpha (myLastChar)))  {
               myMask  = myMask  + ".";
            }
            myLastChar = myThisChar;
         }
         myMask  = myMask  + myThisChar;
      }

      /*==============================================*/
      /* Format the calendar into the mask            */
      /*==============================================*/
      FieldPosition    myFieldPosition    = new FieldPosition    (0);
      SimpleDateFormat mySimpleDateFormat = new SimpleDateFormat (aMask);
      StringBuffer     myStringBuffer     = new StringBuffer     ("");
      String           myString;
      java.util.Date   myDate             = aValue.getTime ();

      mySimpleDateFormat.setTimeZone (aValue.getTimeZone ());
      myString = new String (
                             mySimpleDateFormat.format (
                                                        myDate,
                                                        myStringBuffer,
                                                        myFieldPosition
							)
			     );

      /*==============================================*/
      /* Remove the delimiters, if necessary          */
      /*==============================================*/
      if (aMask.length () != myMask.length ()) {

	 String      myShortenedString = "";

         for (int i = 0; i < myString.length (); i++) {
            char myThisChar = myString.charAt (i);
            if (myThisChar != '.') {
               myShortenedString = myShortenedString + myThisChar;
            }
         }
         return (myShortenedString);
      }
      else {
         return (myString);
      }
   }

   /**
    * Converts a Java Integer object into a
    * primitive String.
    *
    * @param       aValue:Integer
    *                   the Integer value to be converted
    * @return      :String
    *                 - the String equivalent of the Integer object.
    */
   public final static String  intoString (Integer   aValue){
      return (aValue.toString ()) ;
   }

   /**
    * Converts a Java primative int object into a
    * primitive String padded with a mask string.
    *
    * @param       aValue:int
    *                   the Integer value to be converted         
    * @param       aMask:String
    *                   the mask of the string to be returned
    * @return      :String
    *                 - the String equivalent of the Integer object.
    */
   public final static String  intoLeftPaddedString (int   aValue,
						     String    aMask){      
      // workString is the mask to be used
      // whatever value of sourceCode that is supplied in value
      // must be overlaid on top of workString.
      StringBuffer workString = new StringBuffer(aMask);
      String stringValue = new String(Integer.toString (aValue));
      
      workString.insert((workString.length() - stringValue.length()), stringValue);
      workString.setLength(aMask.length());  // will truncate extra characters
      return new String(workString.toString());
   }

   /**
    * Converts a Java String object into a
    * primitive String padded with a mask string.
    *
    * @param       aValue:String
    *                   the String value to be converted         
    * @param       aMask:String
    *                   the mask of the string to be returned
    * @return      :String
    *                 - the String equivalent of the String object.
    */
   public final static String  intoLeftPaddedString (String    aValue,
						     String    aMask) {      
      // workString is the mask to be used
      // whatever value of sourceCode that is supplied in value
      // must be overlaid on top of workString.
      StringBuffer workString = new StringBuffer(aMask);
      
      workString.insert((workString.length() - aValue.length()), aValue);
      workString.setLength(aMask.length());  // will truncate extra characters
      return new String(workString.toString());
   }

	        /*==============================================================*/
        /*  OPERATION:  intoRightPaddedString                            */
        /*                                                              */
        /**
         * This method converts a Java String object into a
         * primitive String padded with a mask string.
         *
         * @param       aValue:String
         *                   the String value to be converted         
         * @param       aMask:String
         *                   the mask of the string to be returned
         * @return      :String
         *                 - the String equivalent of the String object.
         * @see         java.lang.String#toString
         */
        /*==============================================================*/
   public final static String intoRightPaddedString(String aValue, String aMask) {      
      // workString is the mask to be used
      // whatever value of sourceCode that is supplied in value
      // must be overlaid on top of workString.
      StringBuffer workString = new StringBuffer(aMask);
      workString.insert(0, aValue);
      workString.setLength(aMask.length());  // will truncate extra characters
      return new String(workString.toString());
   }

   /**
    * Converts a primitive String value into a Java
    * Calendar object, based upon a supplied mask.
    *
    * @param       aValue:String
    *                   the String value to be converted
    * @param       aaMask:String
    *                   the mask string that defines the various
    *                   date and time fields to be included and in
    *                   what form.
    * @return      :String
    *                 - the Calendar object equivalent to the
    *                   supplied value string, and according to
    *                   the supplied mask string.
    */
   public final static  Calendar  intoCalendar (String  aValue,
                                                String  aMask) {
      char            myLastChar = aMask.charAt (0);
      Calendar        myCalendar = null;

      if (aValue == null)
	return null;

      if (aValue.equals(""))
	return null;

      /*======================================================*/
      /* If aValue is a string of zeros, do not attempt to    */
      /* create a Calendar object.
	 /*======================================================*/

      char[] arr = aValue.toCharArray();
      boolean foundNonZeroNumber = false;
      for ( int i = 0; i < arr.length; i++)
      {
	 if ( arr[i] >= '1' && arr[i] <= '9' ) {
	    foundNonZeroNumber = true;
	    break;
	 }
      }
      if ( !foundNonZeroNumber ) 
	return null;
      

      try {

	 /*======================================================*/
	 /* Handle well-known mask types (for speed reasons)     */
	 /*                                                      */
	 /* Note: Standard Calendar / SimpleDateFormat parsing   */
	 /*       is close to an order of magnitude slower than  */
	 /*       using the year/month/day "set" method.         */
	 /*======================================================*/
	 /*==============================================*/
	 /* MMddyyyy                                     */
	 /*==============================================*/
         if (aMask.equals ("MMddyyyy")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (4)),
                         Integer.parseInt (aValue.substring (0, 2)),
                         Integer.parseInt (aValue.substring (2, 4)),
                         0,0,0);
            return (myCalendar);
         }

	 /*==============================================*/
	 /* MMddyy                                       */
	 /*==============================================*/
         else if (aMask.equals ("MMddyy")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (4)),
                         Integer.parseInt (aValue.substring (0, 2)),
                         Integer.parseInt (aValue.substring (2, 4)),
                         0,0,0);
            return      (myCalendar);
         }

                        /*==============================================*/
                        /* yyMM                                       */
                        /*==============================================*/
//devices begins
                        
         else if (aMask.equals ("yyMM")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0, 2)),
                         Integer.parseInt (aValue.substring (2,4)),
                         0,0,0,0);
            return      (myCalendar);
         }

//devices ends

	 /*==============================================*/
	 /* yyMMdd                                       */
	 /*==============================================*/
         else if (aMask.equals ("yyMMdd")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0, 2)),
                         Integer.parseInt (aValue.substring (2, 4)),
                         Integer.parseInt (aValue.substring (4)),
                         0,0,0);
            return      (myCalendar);
         }

	 /*==============================================*/
	 /* yyyyMMdd                                     */
	 /*==============================================*/
         else if (aMask.equals ("yyyyMMdd")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0, 4)),
                         Integer.parseInt (aValue.substring (4, 6)),
                         Integer.parseInt (aValue.substring (6)),
                         0,0,0);
            return (myCalendar);
         }
	 /*==============================================*/
	 /* yyyyMMddHHmmss                               */
	 /*==============================================*/
         else if (aMask.equals ("yyyyMMddHHmmss")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0,  4)),
                         Integer.parseInt (aValue.substring (4,  6)),
                         Integer.parseInt (aValue.substring (6,  8)),
                         Integer.parseInt (aValue.substring (8, 10)),
                         Integer.parseInt (aValue.substring (10,12)),
                         Integer.parseInt (aValue.substring (12)));

            return (myCalendar);
         }
//devices begins
                        /*==============================================*/
                        /* yyyy-MM-dd-HH-mm                             */
                        /*==============================================*/
         else if (aMask.equals ("yyyy-MM-dd-HH-mm")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0,  4)),
                         Integer.parseInt (aValue.substring (4,  6)),
                         Integer.parseInt (aValue.substring (6,  8)),
                         Integer.parseInt (aValue.substring (8, 10)),
                         Integer.parseInt (aValue.substring (10,12)),
                         Integer.parseInt (aValue.substring (12)));

            return (myCalendar);
         }

                        /*==============================================*/
                        /* yyyyMMddHHmmss                               */
                        /*==============================================*/
         else if (aMask.equals ("MM-dd-yyyy-HH-mm-SS")) 
         {
            myCalendar  = (Calendar)calendar.clone ();
         	

            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0,4)),
                         Integer.parseInt (aValue.substring (5, 7)),
                         Integer.parseInt (aValue.substring (8,10)),
                         Integer.parseInt (aValue.substring (11,13)),
                         Integer.parseInt (aValue.substring (14,16)),
                         Integer.parseInt (aValue.substring (17,19)));
            return (myCalendar);
         }

//devices ends         

	 /*==============================================*/
	 /* yyyy-MM-dd                                   */
	 /*==============================================*/
         else if (aMask.equals ("yyyy-MM-dd")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (0, 4)),
                         Integer.parseInt (aValue.substring (5, 7)),
                         Integer.parseInt (aValue.substring (8)),
                         0,0,0);
            return (myCalendar);
         }

	 /*==============================================*/
	 /* MM/dd/yyyy                                   */
	 /*==============================================*/
         else if (aMask.equals ("MM/dd/yyyy")) {
            myCalendar  = (Calendar)calendar.clone ();
            setCalendar (
                         myCalendar,
                         Integer.parseInt (aValue.substring (6)),
                         Integer.parseInt (aValue.substring (0, 2)),
                         Integer.parseInt (aValue.substring (3, 5)),
                         0,0,0);

            return (myCalendar);
         }

	 /*======================================================*/
	 /* Add field delimiters into the strings, as needed     */
	 /* Handle mask types not included in the if-test above  */
	 /* move the data from aMask and aValue to myMask,myValue*/    
	 /*======================================================*/
	 /*  
	     for (int i = 0; i < aMask.length (); i++) {
             char myThisChar = aMask.charAt (i);
             if (myThisChar != myLastChar) {
	     if ((Convert.isAlpha (myThisChar)) &&
	     (Convert.isAlpha (myLastChar)))  {
	     myMask  = myMask  + ".";
	     myValue = myValue + ".";
	     }
	     myLastChar = myThisChar;
             }
             myMask  = myMask  + myThisChar;
             myValue = myValue + aValue.charAt (i);
	     }
	 */
	 /*======================================================*/
	 /* Now create a calendar from the given format string   */
	 /*======================================================*/
         myCalendar = (Calendar)calendar.clone ();
         ParsePosition    myParsePosition    = new ParsePosition    (0);
         SimpleDateFormat mySimpleDateFormat = new SimpleDateFormat (aMask);
         mySimpleDateFormat.setTimeZone( myCalendar.getTimeZone() );
         java.util.Date myDate = mySimpleDateFormat.parse (aValue, myParsePosition);
         myCalendar.setTime (myDate);
      }

      catch (Throwable myThrowable) {
         System.out.println (
                             "Convert.intoCalendar (value \"" +
                             aValue                           +
                             "\"; mask \""                    +
                             aMask                            +
                             "\"): "                          +
                             myThrowable.toString ()
			     );
      }
      return (myCalendar);
   }

   /**
    * Determines whether or not two primitive boolean
    * values are equal.
    *
    * @param       aValue1:boolean
    *                   the first  boolean value to be compared.
    * @param       aValue2:boolean
    *                   the second boolean value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (boolean aValue1,boolean aValue2){
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive char
    * values are equal.
    *
    * @param       aValue1:char
    *                   the first  char value to be compared.
    * @param       aValue2:char
    *                   the second char value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (char aValue1, char aValue2) {
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive double
    * values are equal.
    *
    * @param       aValue1:double
    *                   the first  double value to be compared.
    * @param       aValue2:double
    *                   the second double value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (double aValue1,double aValue2) {
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive float
    * values are equal.
    *
    * @param       aValue1:float
    *                   the first  float value to be compared.
    * @param       aValue2:float
    *                   the second float value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (float aValue1, float aValue2) {
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive int
    * values are equal.
    *
    * @param       aValue1:int
    *                   the first  int value to be compared.
    * @param       aValue2:int
    *                   the second int value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (int aValue1,int aValue2) {
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive long
    * values are equal.
    *
    * @param       aValue1:long
    *                   the first  long value to be compared.
    * @param       aValue2:long
    *                   the second long value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (long aValue1,long aValue2) {
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive short
    * values are equal.
    *
    * @param       aValue1:short
    *                   the first  short value to be compared.
    * @param       aValue2:short
    *                   the second short value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (short aValue1,short aValue2){
      return (aValue1 == aValue2);
   }

   /**
    * Determines whether or not two primitive String
    * values are equal.
    *
    * @param       aValue1:String
    *                   the first  String value to be compared.
    * @param       aValue2:String
    *                   the second String value to be compared.
    * @return      :boolean
    *                 - true, if the two values can be considered
    *                   to be equal.
    */
   public  final  static  boolean  areEqual (String aValue1,String aValue2) {
      return (aValue1.equals (aValue2));
   }

   /**
    * Determines whether or not two Integer objects'
    * values are equal.
    *
    * @param       aValue1:Integer
    *                   the first  Integer object to be compared.
    * @param       aValue2:Integer
    *                   the second Integer object to be compared.
    * @return      :boolean
    *                 - true, if the two objects' values can be
    *                   considered to be equal.
    */
   public  final  static  boolean  areEqual (Integer aValue1,Integer aValue2){
      return (aValue1.intValue () == aValue2.intValue ());
   }

   /**
    * Determines whether or not a primitive char value
    * represents an alphabetical character (ie a-z or A-Z).
    *
    * @param       aValue:char
    *                   the char value which is to be tested.
    * @return      :boolean
    *                 - true, if the char value is a character of
    *                   the alphabet.
    */
   public  final static  boolean  isAlpha (char  aValue){
      return (((aValue >= 'A') && (aValue <= 'Z')) ||
	      ((aValue >= 'a') && (aValue <= 'z')));
   }

   /**
    * This method sets the year, month and day-of-month fields of
    * the provided Calendar object.
    *
    * @param       aCalendar:calendar
    *                   the Calendar object whose fields are to be set.
    * @param       aYear:int
    *                   the year value to be set.
    * @param       aMonth:int
    *                   the month value to be set. (Unlike the
    *                   internal format of the Calendar class, this
    *                   month number must be one-based, not
    *                   zero-based.)
    * @param       aDay:int
    *                   the day of the month value to be set.
    * @return      :void
    */
   private  final  static  void  setCalendar (Calendar  aCalendar,
                                              int       aYear,
                                              int       aMonth,
                                              int       aDay,
                                              int       anHour,
                                              int       aMinute,
                                              int       aSecond){
          
      /*==============================================*/
      /* Add a check to add the century if absent     */
      /* This is a temporary(40 years) fix!           */
      /* Changed to Y2K Std. To 84 from 30(dbritta)   */
      /*==============================================*/
     
      if ( aYear < 84 ) {
	 aYear += 2000 ;          
      } else if ( aYear < 100 ) {
	 aYear += 1900 ;          
      }

      /*======================================================*/
      /* Convert the month to zero-based (from one-based)     */
      /*======================================================*/
      if (--aMonth < 0) {
         aMonth = 0;
      }


      /*======================================================*/
      /* The update to the comment below                      */
      /* With the 1.1.4 release of JDK wedont have to ++ the  */
      /* date anymore                                         */   
      /*======================================================*/
      /*======================================================*/
      /* The Calendar class assumes that the day will be      */
      /* passed as zero-based and so will decrement it to     */
      /* convert it to one-based -> increment the day.        */
      /*======================================================*/
      //aDay++;

      /*======================================================*/
      /* If the day is left blank, convert to the last day of */
      /* the month.                                           */
      /*                                                      */
      /* Note: A day value of zero is represents the last day */
      /*       of the previous month, so to get the last day  */
      /*       of THIS month, simply increment the month.     */
      /*======================================================*/
      if (aDay == 0) {
         aMonth++;
      }

      /*======================================================*/
      /* Set the year/month/day on the provided calendar      */
      /*======================================================*/
      aCalendar.set (aYear, aMonth, aDay, anHour, aMinute, aSecond);
   }

   /**
    * This method prints to standard output, on a single line,
    * the expected value, input mask, output mask, and the actual
    * value of the provided Calendar object.
    *
    * @param       aCalendar:calendar
    *                   the Calendar object whose fields are to be set.
    * @param       aValue:String
    *                   the expected Calendar string (the string with
    *                   which the Calendar was constructed).
    * @param       aInputMask:String
    *                   the input mask with which the Calendar was
    *                   original constructed from the value string.
    * @param       aOutputMask:String
    *                   the output mask with which the Calendar is
    *                   to be converted back into a string and
    *                   printed.
    * @return      :void
    */
   private  final  static  void  printCalendar (Calendar  aCalendar,
                                                String    aValue,
                                                String    aInputMask,
                                                String    aOutputMask) {
      System.out.println (
                          "Calendar (\""                              +
                          aValue                                      +
                          "\" @ \""                                   +
                          aInputMask                                  +
                          "\" -> \""                                  +
                          aOutputMask                                 +
                          "\") = String \""                           +
                          Convert.intoString (aCalendar, aOutputMask) +
                          "\""
			  );
   }


   /*==============================================================*/
   /*  OPERATION:  isAlpha                                        */
   /*                                                              */
   /**
    * This method determine whether or not a primitive char value
    * represents an alphabetical character (i.e. a-z or A-Z).
    *
    * @param       aValue:char
    *                   the char value which is to be tested.
    * @return      :boolean
    *                 - true, if the char value is a character of
    *                   the alphabet.
    */
   /*==============================================================*/
   public  final static  boolean  isNumeric (
					     String  aValue
					     ) {
      if ( aValue == null ) return false;
      char[] srcArray = aValue.toCharArray();
      for ( int i = 0; i < srcArray.length; i++)
      {
	 if ( (srcArray[i] < '0' || srcArray[i] > '9') 
	      && srcArray[i]!='-' 
	      && srcArray[i]!='+' 
	      )
	   return false;
      }
      return true;
   }
   /**
    * Utility method to write a string to a file. Will be moved to utility class
    */
   public static void writeFileAsString(String filename, String text, boolean append) throws IOException {
      BufferedWriter out = new BufferedWriter(new FileWriter(filename, append));
      out.write(text);
      out.close();
   }
   /**
    * Utility method to read a file as a string . Will be moved to utility class
    */
   public static String readFileAsString(String filename) throws FileNotFoundException, IOException {
      BufferedReader in = new BufferedReader(new FileReader(filename));
      
      StringBuffer input = new StringBuffer();
      String inputLine = null;
      
      while ((inputLine = in.readLine()) != null) {
	 input.append(inputLine);
      }
      in.close();
      return input.toString();
   }
   
   public static byte[] readAllBytes(InputStream is) throws IOException {
      if ( is == null ) 
	throw new IOException("Invalid null inputstream");
      
      byte[] tmp = new byte[8192];
      byte[] readBytes = new byte[0];
      int tmplength = 0;
      do {
	 //read 8192 bytes
	 tmplength = is.read(tmp);
	 if ( tmplength == -1 ) break;
	 //create an array to hold what we have alreadyRead plus what we read above
	 byte[] newtmp = new byte[readBytes.length + tmplength];
	 //COPY already read into newtmp
	 System.arraycopy(readBytes,0,newtmp,0,readBytes.length);
	 //COPY newly read right after already read into newtmp
	 System.arraycopy(tmp,0,newtmp,readBytes.length,tmplength);
	 readBytes = newtmp;
      } while ( true );		
      is.close();
      return readBytes;
   }
   
   public static byte[] compress(byte[] plainArray) throws IOException {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      GZIPOutputStream gos = new GZIPOutputStream(baos);
      gos.write(plainArray);
      gos.flush();
      gos.close();
      baos.close();
      byte[] compressedArray = baos.toByteArray();
      return compressedArray;
   }
   
   public static byte[] decompress(byte[] compressedArray) throws IOException {
      ByteArrayInputStream bais = new ByteArrayInputStream(compressedArray);
      GZIPInputStream gis = new GZIPInputStream(bais);
      byte[] plainArray = readAllBytes(gis);
      bais.close();
      return plainArray;
   }
   
   	/**
 	* @version 1.0 . This method converts a Calendar date according to the mask provided.
 	* 				 In addition the method will create a Locale object converting the
 	* 				 date in to en_US or sp_SP
 	* @param : 		-aValue : This is an instance of a Calendar.
 	* @param :		-aMask	: This is a String object used to Mask, or format a date.
 	* @param :		-Country : This is a String representation for a Locale object
 	* @return:		Return a date according to the format and Country.
 	* @since :		++ CI212
 	* 
 	*/ 
	public final static String  intoString (Calendar aValue, String aMask, String Country) {
   		String          myMask        = "";

   		if (aValue == null) {
  			return ("");
   		}
   		if ( aMask == null || aMask.length()<1 ) {
          
  			/*==============================================================*/
  			/*  Have to set the TimeZone on the DateFormat and so have to   */
  			/*  up-cast to SimpleDateFormat. Else could have done  just this*/
  			/*  DateFormat myFormat = DateFormat.getDateInstance();         */
  			/*  return myFormat.format( aValue.getTime() );                 */ 
  			/*==============================================================*/
  			SimpleDateFormat myFormat = (SimpleDateFormat)
  			DateFormat.getDateInstance();

  			myFormat.setTimeZone( aValue.getTimeZone() );
  			return myFormat.format( aValue.getTime() ); 
   		}

   		char            myLastChar = aMask.charAt (0);

   		/*==============================================*/
   		/* Add field delimiters into the mask as needed */
   		/*==============================================*/
   		for (int i = 0; i < aMask.length (); i++) {
	  		char myThisChar = aMask.charAt (i);
	 		 if (myThisChar != myLastChar) {
		 		if ((Convert.isAlpha (myThisChar)) && (Convert.isAlpha (myLastChar)))  {
					myMask  = myMask  + ".";
		 		}
		 		myLastChar = myThisChar;
	  		}
	  		myMask  = myMask  + myThisChar;
   		}

   		/*==============================================*/
   		/* Format the calendar into the mask            */
   		/*==============================================*/
   		FieldPosition    myFieldPosition    = new FieldPosition    (0);
   		SimpleDateFormat mySimpleDateFormat;
   		//for right now this is not on. In the future use property files
   		if (Country.equalsIgnoreCase("USA"))
	 		mySimpleDateFormat = new SimpleDateFormat (aMask,new Locale("en", "US")); 
   		else
	 		mySimpleDateFormat = new SimpleDateFormat (aMask,new Locale("es", "es_ES"));
      
   		StringBuffer     myStringBuffer     = new StringBuffer     ("");
   		String           myString;
   		java.util.Date   myDate             = aValue.getTime ();	
   		mySimpleDateFormat.setTimeZone (aValue.getTimeZone ());
   		myString = new String (mySimpleDateFormat.format (myDate,myStringBuffer,myFieldPosition));

   		/*==============================================*/
   		/* Remove the delimiters, if necessary          */
   		/*==============================================*/
   		if (aMask.length () != myMask.length ()) {

  			String      myShortenedString = "";

	  		for (int i = 0; i < myString.length (); i++) {
		 		char myThisChar = myString.charAt (i);
		 		if (myThisChar != '.') {
					myShortenedString = myShortenedString + myThisChar;
		 		}
	 	 	}
	  		return (myShortenedString);
   		}
   		else {
	  		return (myString);
   		}
	}//end of method.

   /**
    * Main method, used for command line unit testing and to demonstrate
    * usage of this class.
    * <br>eg. executing the following command from a command prompt 
    * <br>>java COM.novusnet.vision.java.utility.Convert
    * <br>will result in the following output to the console
    * <p>
    * <br>Convert.intoBoolean ('n')=false
    * <br>Convert.intoBoolean ('n', "nN0")=false
    * <br>Convert.intoBoolean (3.1456789d)=true
    * <br>Convert.intoBoolean (3.1456789f)=true
    * <br>Convert.intoBoolean (0)=false
    * <br>Convert.intoBoolean (9223372036854775807L)=true
    * <br>Convert.intoBoolean (-1)=true
    * <br>Convert.intoBoolean ("No")=false
    * <br>Convert.intoBoolean (new Integer(100))=true
    * <br>
    * <br>Convert.intoChar (true, 'T', 'F')=T
    * <br>
    * <br>Convert.intoDouble ('n'))=110.0
    * <br>Convert.intoDouble (3.1456789f)=3.145678997039795
    * <br>Convert.intoDouble (3)=3.0
    * <br>Convert.intoDouble (9223372036854775807L)=9.223372036854776E18
    * <br>Convert.intoDouble (32768)=32768.0
    * <br>Convert.intoDouble ("500")=500.0
    * <br>Convert.intoDouble (new Integer(300))=300.0
    * <br>
    * <br>Convert.intoFloat ('y')=121.0
    * <br>Convert.intoFloat (3.1456789d)=3.145679
    * <br>Convert.intoFloat (300)=300.0
    * <br>Convert.intoFloat (9223372036854775807L)=9.223372E18
    * <br>Convert.intoFloat (32768)=32768.0
    * <br>Convert.intoFloat ("500")=500.0
    * <br>Convert.intoFloat (new Integer(300))=300.0
    * <br>
    * <br>Convert.intoInt  ('y')=121
    * <br>Convert.intoInt  (3.1456789d)=3
    * <br>Convert.intoInt  (3.1456789f)=3
    * <br>Convert.intoInt  (9223372036854775807L)=-1
    * <br>Convert.intoInt  (300)=300
    * <br>Convert.intoInt  ("500")=500
    * <br>Convert.intoInt  (new Integer(300))=300
    * <br>
    * <br>Convert.intoString  (true)=true
    * <br>Convert.intoString  (true, "Yes", "No")=Yes
    * <br>Convert.intoString  ('n')=n
    * <br>Convert.intoString  (3.1456789d)=3.1456789
    * <br>Convert.intoString  (3.1456789f)=3.145679
    * <br>Convert.intoString  (300)=300
    * <br>Convert.intoString  (9223372036854775807L)=9223372036854775807
    * <br>Convert.intoString  (32768)=32768
    * <br>Convert.intoString  (Calender.getInstance(), "ddMMyyyy")=07052004
    * <br>Convert.intoString  (new Integer(300))=300
    * <br>
    * <br>Convert.intoLeftPaddedString  (32768,"000000000")=000032768
    * <br>Convert.intoLeftPaddedString  ("32768","---------")=----32768
    * <br>
    * <br>Convert.intoCalendar  ("12252004")=java.util.GregorianCalendar[time=1137045600000,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=java.util.SimpleTimeZone[id=America/Chicago,offset=-21600000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=3,startDay=1,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=2,endMonth=9,endDay=-1,endDayOfWeek=1,endTime=7200000,endTimeMode=0],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=2006,MONTH=0,WEEK_OF_YEAR=2,WEEK_OF_MONTH=2,DAY_OF_MONTH=12,DAY_OF_YEAR=12,DAY_OF_WEEK=5,DAY_OF_WEEK_IN_MONTH=2,AM_PM=0,HOUR=0,HOUR_OF_DAY=0,MINUTE=0,SECOND=0,MILLISECOND=0,ZONE_OFFSET=-21600000,DST_OFFSET=0]
    * <br>
    * <br>Convert.areEqual  (true, false)=false
    * <br>Convert.areEqual  ('y', 'y')=true
    * <br>Convert.areEqual  (3.1456789f, 3.1456789f)=true
    * <br>Convert.areEqual  (3.1456789d, 5.1456789d)=false
    * <br>Convert.areEqual  (300, 500)=false
    * <br>Convert.areEqual  (9223372036854775807L, 9223372036854775807L)=true
    * <br>Convert.areEqual  (32768, 32768)=true
    * <br>Convert.areEqual  ("Test", "Test")=true
    * <br>Convert.areEqual  (new Integer(300), new Integer(500))=false
    * <br>
    * <br>Convert.isAlpha  ('$')=false
    * <br>
    * @param   aArgs:String[]
    *             the array of command line arguments. [Unused]
    * @return  void.
    */
   public  static  void  main (String  args []) {

      System.out.println("\nConvert.intoBoolean ('n')=" + Convert.intoBoolean ('n'));
      System.out.println("Convert.intoBoolean ('n', \"nN0\")=" + Convert.intoBoolean ('n', "nNO"));
      System.out.println("Convert.intoBoolean (3.1456789d)=" + Convert.intoBoolean (3.1456789d));
      System.out.println("Convert.intoBoolean (3.1456789f)=" + Convert.intoBoolean (3.1456789f));
      System.out.println("Convert.intoBoolean (0)=" + Convert.intoBoolean (0));
      System.out.println("Convert.intoBoolean (9223372036854775807L)=" + Convert.intoBoolean (9223372036854775807L));
      System.out.println("Convert.intoBoolean (-1)=" + Convert.intoBoolean (-1));
      System.out.println("Convert.intoBoolean (\"No\")=" + Convert.intoBoolean ("No"));
      System.out.println("Convert.intoBoolean (new Integer(100))=" + Convert.intoBoolean (new Integer(100)));
      System.out.println("\nConvert.intoChar (true, 'T', 'F')=" + Convert.intoChar (true, 'T', 'F'));
      System.out.println("\nConvert.intoDouble ('n'))=" + Convert.intoDouble ('n'));
      System.out.println("Convert.intoDouble (3.1456789f)=" + Convert.intoDouble (3.1456789f));
      System.out.println("Convert.intoDouble (3)=" + Convert.intoDouble (3));
      System.out.println("Convert.intoDouble (9223372036854775807L)=" + Convert.intoDouble (9223372036854775807L));
      System.out.println("Convert.intoDouble (32768)=" + Convert.intoDouble (32768));
      System.out.println("Convert.intoDouble (\"500\")=" + Convert.intoDouble ("500"));
      System.out.println("Convert.intoDouble (new Integer(300))=" + Convert.intoDouble (new Integer(300)));
      System.out.println("\nConvert.intoFloat ('y')=" + Convert.intoFloat ('y'));
      System.out.println("Convert.intoFloat (3.1456789d)=" + Convert.intoFloat (3.1456789d));
      System.out.println("Convert.intoFloat (300)=" + Convert.intoFloat (300));
      System.out.println("Convert.intoFloat (9223372036854775807L)=" + Convert.intoFloat (9223372036854775807L));
      System.out.println("Convert.intoFloat (32768)=" + Convert.intoFloat (32768));
      System.out.println("Convert.intoFloat (\"500\")=" + Convert.intoFloat ("500"));
      System.out.println("Convert.intoFloat (new Integer(300))=" + Convert.intoFloat (new Integer(300)));
      System.out.println("\nConvert.intoInt  ('y')=" + Convert.intoInt ('y'));
      System.out.println("Convert.intoInt  (3.1456789d)=" + Convert.intoInt (3.1456789d));
      System.out.println("Convert.intoInt  (3.1456789f)=" + Convert.intoInt (3.1456789f));
      System.out.println("Convert.intoInt  (9223372036854775807L)=" + Convert.intoInt (9223372036854775807L));
      System.out.println("Convert.intoInt  (300)=" + Convert.intoInt (300));
      System.out.println("Convert.intoInt  (\"500\")=" + Convert.intoInt ("500"));
      System.out.println("Convert.intoInt  (new Integer(300))=" + Convert.intoInt (new Integer(300)));
      System.out.println("\nConvert.intoString  (true)=" + Convert.intoString (true));
      System.out.println("Convert.intoString  (true, \"Yes\", \"No\")=" + Convert.intoString (true, "Yes", "No"));
      System.out.println("Convert.intoString  ('n')=" + Convert.intoString ('n'));
      System.out.println("Convert.intoString  (3.1456789d)=" + Convert.intoString (3.1456789d));
      System.out.println("Convert.intoString  (3.1456789f)=" + Convert.intoString (3.1456789f));
      System.out.println("Convert.intoString  (300)=" + Convert.intoString (300));
      System.out.println("Convert.intoString  (9223372036854775807L)=" + Convert.intoString (9223372036854775807L));
      System.out.println("Convert.intoString  (32768)=" + Convert.intoString (32768));
      System.out.println("Convert.intoString  (Calender.getInstance(), \"ddMMyyyy\")=" + Convert.intoString (Calendar.getInstance(), "ddMMyyyy"));
      System.out.println("Convert.intoString  (new Integer(300))=" + Convert.intoString (new Integer(300)));
      System.out.println("\nConvert.intoLeftPaddedString  (32768,\"000000000\")=" + Convert.intoLeftPaddedString (32768, "000000000"));
      System.out.println("Convert.intoLeftPaddedString  (\"32768\",\"---------\")=" + Convert.intoLeftPaddedString ("32768", "---------"));
      System.out.println("\nConvert.intoCalendar  (\"12252004\")=" + Convert.intoCalendar ("12252004" , "ddMMyyyy"));
      System.out.println("\nConvert.areEqual  (true, false)=" + Convert.areEqual (true, false));
      System.out.println("Convert.areEqual  ('y', 'y')=" + Convert.areEqual ('y', 'y'));
      System.out.println("Convert.areEqual  (3.1456789f, 3.1456789f)=" + Convert.areEqual (3.1456789f, 3.1456789f));
      System.out.println("Convert.areEqual  (3.1456789d, 5.1456789d)=" + Convert.areEqual (3.1456789d, 5.1456789d));
      System.out.println("Convert.areEqual  (300, 500)=" + Convert.areEqual (300, 500));
      System.out.println("Convert.areEqual  (9223372036854775807L, 9223372036854775807L)=" + Convert.areEqual (9223372036854775807L,9223372036854775807L));
      System.out.println("Convert.areEqual  (32768, 32768)=" + Convert.areEqual (32768, 32768));
      System.out.println("Convert.areEqual  (\"Test\", \"Test\")=" + Convert.areEqual ("Test", "Test"));
      System.out.println("Convert.areEqual  (new Integer(300), new Integer(500))=" + Convert.areEqual (new Integer(300), new Integer(500)));
      System.out.println("\nConvert.isAlpha  ('$')=" + Convert.isAlpha ('$'));
      System.out.println("\n");

      /*======================================================*/
      /* Calendar conversions                                 */
      /*======================================================*/
      Calendar        myCalendar;
      String          myValue;
      String          myInputMask;
      String          myOutputMask;

      /*==============================================*/
      /* Day = 0 (should set to last day of month)    */
      /*==============================================*/
      myValue      = "12001999";
      myInputMask  = "MMddyyyy";
      myCalendar   = Convert.intoCalendar (myValue, myInputMask);
      myOutputMask = "dd-MMM-yyyy @ HH:mm:ss zzz";
      printCalendar  (myCalendar, myValue, myInputMask, myOutputMask);
   
      /*==============================================*/
      /* Day = 0 (leap year should set to 29-FEB)     */
      /*==============================================*/
      myValue      = "02001996";
      myInputMask  = "MMddyyyy";
      myCalendar   = Convert.intoCalendar (myValue, myInputMask);
      myOutputMask = "dd-MMM-yyyy @ HH:mm:ss zzz";
      printCalendar  (myCalendar, myValue, myInputMask, myOutputMask);
   
      /*==============================================*/
      /* Day > 31 (should roll to next month / year)  */
      /*==============================================*/
      myValue      = "12321999";
      myInputMask  = "MMddyyyy";
      myCalendar   = Convert.intoCalendar (myValue, myInputMask);
      myOutputMask = "dd-MMM-yyyy @ HH:mm:ss zzz";
      printCalendar  (myCalendar, myValue, myInputMask, myOutputMask);
   }

}

