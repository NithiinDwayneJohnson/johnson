/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.utility.runtime;

import java.io.StreamTokenizer;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;

import java.applet.Applet;

/**
 * This singleton class provides the classes that make up the Vision
 * framework with centralized access to global entities and classes. These
 * entities could include error logging (Cortex), security and user
 * information An instance of this class can be obtained by calling the
 * instance() method.
 * @version 1.0, 12-21-1999
 */
public  class  VisionRuntime {
   private static final String VISION_PROFILE = "/COM/novusnet/vision/etc/vision.ini";
   public static final int    PERSISTENCE_SERVICE         = 0;
   public static final int    PERSISTENCE_FACTORIES       = 1;
   public static final int    NAMING_SERVICE              = 2;
   public static final int    TRANSACTION_SERVICE         = 3;
   public static final int    BUSINESS_OBJECTS            = 4;
   public static final int    UTILITY                     = 5;
   public static final int    DAS_PACKAGER                = 6;
   public static final int    DAS_JDBCDRIVER              = 7;

   private        String          userName   = null;
   private        String          password   = null;
   private        String          center     = "";

   /**
    * This is the singleton instance of the VisionRuntime class. It is created
    * by static initialization when the class is first loaded.
    */
   private static VisionRuntime   singleton  = new VisionRuntime ();
   private static Applet          applet     = null;

        /**
         * The VisionRuntime constructor which is responsible for creating
         * all the shared entities that the runtime makes available. This
         * method is private so instance access can only be performed
         * through the instance() method.
         */
   private    VisionRuntime () {
      try {
	 /*==============================================*/
	 /* Read the Vision profile                      */
	 /*==============================================*/
         readProfile ();      
      } catch (Throwable e) {
         System.out.println ("Exception caught in VisionRuntime constructor : " +
                             e.toString ());
      }                                             
   }



   /**
    * Returns the value of the currently running applet.
    * @return      :Applet -
    */
   public static  Applet  getApplet () {
	 return (applet);
      }

   /**
    * Returns the name of the application user.
    * @return      :String -
    */
   public  String  getUserName () {
	 return (userName);
      }

   /**
    * Returns the password of the application user.
    * @return      :String -
    */
   public  String  getPassword ()  {
	 return (password);
   }

   /**
    * Returns the local operation center in which the client application is running..
    * @return      :String -
    */
   public  String  getCenter () {
	 return (center);
   }


   /**
    * Sets the value of the currently running applet.
    * @param       aValue:Applet
    */
   public static  void  setApplet (Applet  aValue) {
	 applet = aValue;
   }

   /**
    * Sets the name of the application user.
    * @param       aValue:String
    */
   public  void  setUserName (String  aValue) {
	 userName = aValue;
   }

   /**
    * Sets the password of the application user.
    * @param       aValue:String
    */
   public  void  setPassword (String  aValue) {
      password = aValue;
   }

   /**
    * This method sets the value of this is the local operation center
    * in which the client application is running..
    * @param       aValue:String
    */
   public  void  setCenter (String  aValue) {
	 center = aValue;
   }


   /**
    * This method is used to print out the current state of this
    * object instance.
    */
   public  void  printOut () {
      try {
	 System.out.println ("VisionRuntime:");
	 System.out.println ("   userName: " + getUserName ());
	 System.out.println ("   password: " + getPassword ());
	 System.out.println ("   center: " + getCenter ());
      }catch (Throwable myThrowable) {
	 myThrowable.printStackTrace ();
	 throw new RuntimeException (myThrowable.toString ());
      }
   }


   /**
    * This method reads the Vision profile file.
    */
   private  void  readProfile (){
      StreamTokenizer aStreamTokenizer = null;
      InputStream       aFileStream    = null;
      InputStreamReader aFileReader    = null;
      
      try {   
	 aFileStream = getClass ().getResourceAsStream (VISION_PROFILE);
	 
	 if (aFileStream == null) {
	    System.err.println ("Failed to load resource as stream for: " + 
				VISION_PROFILE);
	    return;
	 }
	 
	 // Create a FileReader instance to read the profile and 
	 // a StreamTokenizer instance to parse it.              
	 aFileReader      = new InputStreamReader (aFileStream);
	 aStreamTokenizer = new StreamTokenizer   (aFileReader);
	 
	 // Loop, parsing the profile file. Extract the center  name from a 
	 // line which has the form:
	 // <application>  CENTER  "<center name>"               
	 while (aStreamTokenizer.nextToken   () != StreamTokenizer.TT_EOF){
	    if (aStreamTokenizer.nextToken   () == StreamTokenizer.TT_WORD &&
		aStreamTokenizer.sval.equals ("CENTER"))  {
	       aStreamTokenizer.nextToken    ();
	       center = aStreamTokenizer.sval;
	    }
	 }            
      }catch (IOException e) {
	 center = "";
      }                                             
   }


   /**
    * This method returns the singleton VisionRuntime instance, 
    * @return VisionRuntime
    */
   public static final synchronized  VisionRuntime  instance () {
	 return singleton;
      }

   /**
    * This method is represents the command-line executable entry
    * point for the VisionRuntime class.
    *  
    * @param       aArgs:String[]
    *                 The command-line arguments.
    */
   public static  void  main (String[]  aArgs){
      
      long N = 1;
      
      // Extract iteration count from command line arguments  
      if (aArgs.length > 0)  {
	 N = Long.parseLong (aArgs[0]);
      }
   }
}
