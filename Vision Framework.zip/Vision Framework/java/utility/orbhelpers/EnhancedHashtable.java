package COM.novusnet.vision.java.utility.orbhelpers;
/**
This hashtable has a key value pairs where the value is the array
of object refs and the name of the nth element of the array is 
key+index n
*/
class EnhancedHashtable extends java.util.Hashtable
{

   static int maxSize;
  
   public int getMaxSize()
   {
      return maxSize;
   } 
   public int removeRef( Object keyName, Object objRef )
   {
      Object[] arr = (Object[])super.get(keyName);
      if ( arr == null )
         return -1;
      for ( int i = 0; i < maxSize; i++ )
      {
          if ( objRef.equals(arr[i]) ) {
             arr[i] = null;
             return i;
          }
      }
      return -1;
   }

   /**
      This returns a true if table has no record
      for this name
   */
   public boolean isNew( Object keyName )
   {
      Object[] arr = (Object[])super.get(keyName);
      if ( arr == null )
         return true;
      else 
         return false;
   }

   /**
      This returns a false if arr is not null and
      and one of the arr elements are also not null
   */
   public boolean isEmpty( Object keyName )
   {
      Object[] arr = (Object[])super.get(keyName);
      for ( int i = 0; arr != null && i < arr.length; i++ )
      {
         if ( arr[i] != null )
            return false;
      }
      return true;
   }
   /**
      This returns a number where there is no slot 
      and an Object Ref where there is
   */
   public Object getRef( Object keyName)
   {
      Object[] arr = (Object[])super.get(keyName);
      if ( arr == null )
         return new Integer(0);

      int pickOne = getRandom(); 
//System.err.println("*****Picked" + pickOne );
      if ( arr[ pickOne ] == null )
      {
         return new Integer(pickOne);
      } 
      else 
      {
         return arr[ pickOne ];
      }
   }

   /**
      This returns a number where there is no slot
      and an Object Ref where there is
   */
   public Object getAssuredRef( Object keyName)
   {
      Object[] arr = (Object[])super.get(keyName);
      if ( arr == null )
         return new Integer(0);

      int pickOne = getRandom();
      if ( arr[ pickOne ] != null )
      {
         return arr[pickOne];
      }
      else
      {
         for ( int i = 0; i < maxSize; i++ )
         {
            if ( arr[ (i+pickOne)%maxSize ] != null )
               return arr[ (i+pickOne)%maxSize ];
         }
      }

      return null;
   }

   public Object putRef( Object keyName, Object objRef)
   {
      return putRef(keyName, objRef, -1);
   }
   public Object putRef( Object keyName, Object objRef, int slot)
   {
      Object[] arr = (Object[])super.get(keyName);
      if ( arr == null )
      {
         arr = new Object[maxSize];
         super.put(keyName, arr);
      }
      if ( slot > -1 && slot < maxSize )
      {
        arr[slot] = objRef;
        return objRef;
      }
      else 
      {
         int pickOne = getRandom(); 
         for ( int i = 0; i < maxSize; i++)
         { 
            if ( arr[ (i+pickOne)%maxSize ] == null )
            {
               arr[ (i+pickOne)%maxSize ] = objRef;
               return objRef;
            }
         }    
      }
      return null;  
   }

   protected int getRandom()
   {
       return (((int)(Math.random() * 10)) % maxSize) ; 
   }

   static {
      String         propertyValue  = null;

                /*======================================================*/
                /* Default Hostname                                     */
                /*======================================================*/
      if ((propertyValue   = System.getProperty ("default_connections"))   != null)
      {
         maxSize = Integer.parseInt(propertyValue);
      } else {
         maxSize = 1;
      }

   }

   public static void main(String[] args)
   {
      EnhancedHashtable et = new EnhancedHashtable();
      et.putRef( "parag", new Integer(1) );
      et.putRef( "parag", new Integer(2) );
      et.putRef( "parag", new Integer(3) );

      et.putRef( "monica", new Integer(1), 2 );
      et.putRef( "monica", new Integer(2) );
      et.putRef( "monica", new Integer(3) );

      System.out.println( et ); 

      System.out.println("getMonica" + et.getRef("monica" ));
      System.out.println("getParag" + et.getRef("parag" ));

      System.out.println("----------------------------------");
      et.removeRef( "parag", new Integer(2) );
      et.removeRef( "monica", new Integer(2) );

      System.out.println("getMonica" + et.getRef("monica" ));
      System.out.println("getParag" + et.getRef("parag" ));



   }
}
