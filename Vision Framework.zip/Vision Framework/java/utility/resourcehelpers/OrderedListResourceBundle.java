package COM.novusnet.vision.java.utility.resourcehelpers;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;
import java.util.Enumeration;
import java.util.Vector;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for StatementHoldStatuses in the en_US locale.
 */
/*======================================================================*/
public abstract class OrderedListResourceBundle extends ListResourceBundle {
   public Enumeration getKeys() {
      Object[][] contents = getContents();
      Vector keys = new Vector();
      for(int i = 0; i < contents.length; ++i) {
         keys.add(contents[i][0]);
      }
      //Thread.dumpStack();
      return keys.elements();
   }
}

