package COM.novusnet.vision.java.utility.resourcehelpers;

import java.util.Locale;
import java.util.Hashtable;
import java.util.Vector;
import java.util.ListResourceBundle;
import COM.novusnet.vision.java.utility.helpers.ClassHelper;

/**
 * Provides facilities for locating resources for a given class. Its main 
 * features center around the ability to pull resources from several possible
 * locations. The JDK provided resource locator does not take inheritance or
 * default search paths into consideration. It also assumes that the resource 
 * file will be located in the same directory as the class. 
 *
 * <br>This class assumes that the resource files are always placed under a
 * specific locale path. For example, resources for class A should be stored
 * in <location of A>/locale/specific locale name.  
 * <br>&nbsp;&nbsp;&nbsp;Eg com.novusnet.cms.java.accounts.locale.en_US.
 *
 * <p>The search tree of candidate resources are determined as follows:
 * <br>&nbsp;&nbsp;&nbsp;Create a search list of candidate resources.
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If the policy is set to POLICY_EXACT_CLASS then add the class to the
 * search list.
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If the policy is set to the POLICY_NORMAL then until you get to the
 * terminating class add the class and its superclass and it's superclasses 
 * superclass and so on to the search list. java.lang.Object is the default
 * terminating class.
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Then if there is a fallback resource class for this application then
 * add this to the search list.
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Then for each entry in the search list compose the name of the resource class. 
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ie <package name>.locale.<locality>.<classname>
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If the policy is POLICY_PACKAGE then compose the name of the resource class 
 * <package name>.locale.<locality>.Resources" and insert it at the top of the list.
 * <br>&nbsp;&nbsp;&nbsp;Then add search through each resource bundle in the search list to find a match
 * with the resource name that we require.
 * <br>&nbsp;&nbsp;&nbsp;There are caching schemes employed so the search is not quite as labourious as it seems.
 * <p>
 * <br>package com.novusservices.cms.java.testers;
 * <br>public class TestApp extends  com.novusservices.cms.java.global.AccountApplication  
 * <br>&nbsp;&nbsp;&nbsp;public static  void  main (String[]  aArgs)  {
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Application myApp  = new TestApp();
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ResourceResolver    myResourceResolver = new ResourceResolver();
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myResourceResolver.setPolicy(ResourceResolver.POLICY_???????);
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myResourceResolver.registerApplicationFallback("com.novusservices.cms", 
 * "com.novusservices.cms.java.Resources");
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;String appTitle = myResourceResolver.getStringResource("applicationTitle", myApp.getClass());
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;myApp.getFrame().setTitle(); 
 * <br>&nbsp;&nbsp;&nbsp;}
 * <br>}
 * <br> In the above code example the where the locale is the US. The table below 
 * shows the Resource bundles available depending on which policy we choose to
 * set on the ResourceResolver.
 *
 * <p>You can see the way different policies affect the way searches are done. The
 * EXACT_POLICY ignores any super classes but respects a default fallback class. 
 * The PACKAGE policy ignore the class and its superclasses and looks for a files
 * named Resource.java in the directory of the locale. The package policy also
 * respects the default fallback.
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Searching for ResourceBundles</B></FONT></TD>
 * </TR>
 * <TR BGCOLOR="white" CLASS="TableRowColor">
 * <TD ALIGN="right" VALIGN="top" WIDTH="1%"><FONT SIZE="-1">
 * POLICY_EXACT_CLASS</FONT></TD>
 * <TD>com.novusservices.cms.java.testers.locale.en_US.TestApp
 * <br>com.novusservices.cms.java.locale.en_US.Resources</TD></TR>
 * <TR BGCOLOR="white" CLASS="TableRowColor">
 * <TD ALIGN="right" VALIGN="top" WIDTH="1%"><FONT SIZE="-1">
 * POLICY_EXACT_NORMAL</FONT></TD>
 * <TD>com.novusservices.cms.java.testers.locale.en_US.TestApp
 * <br>com.novusservices.cms.java.global.locale.en_US.AccountApplication
 * <br>com.novusservices.vision.java.gui.locale.en_US.Application
 * <br>com.novusservices.cms.java.locale.en_US.Resources</TD></TR>
 * <TR BGCOLOR="white" CLASS="TableRowColor">
 * <TD ALIGN="right" VALIGN="top" WIDTH="1%"><FONT SIZE="-1">
 * POLICY_PACKAGE</FONT></TD>
 * <TD>com.novusservices.cms.java.testers.locale.en_US.Resources
 * <br>com.novusservices.cms.java.locale.en_US.Resources</TD></TR>
 * <TR BGCOLOR="white" CLASS="TableRowColor">
 * <TD ALIGN="right" VALIGN="top" WIDTH="1%"><FONT SIZE="-1">
 * Default fallback</FONT></TD>
 * <TD>com.novusservices.cms.java.locale.en_US.Resources</TD></TR>
 * </TABLE>
 *
 * <br>A typical resource bundle looks like this:
 * <br>
 * <br>public class Resources extends java.util.ListResourceBundle {
 * <br>&nbsp;&nbsp;&nbsp;public Object[][] getContents() {
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return contents;
 * <br>&nbsp;&nbsp;&nbsp;}
 * <br>
 * <br>&nbsp;&nbsp;&nbsp;static final Object[][] contents =
 * <br>&nbsp;&nbsp;&nbsp;{
 * <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{"applicationTitle" , "My Test Application"},
 * <br>&nbsp;&nbsp;&nbsp;};
 * <br>}
 */
public class ResourceResolver {

   /**
      Represents the super class name by which the search terminates.
   */
   private String m_terminatingClass = null;
   /**
      Contains the instance of the list resource bundle that contained
      the key search for last.
   */
   private ListResourceBundle m_lastMatch = null;
   /**
      This policy matches the exact class name, (i.e no superclasess or
      fallback classes are matched).
   */
   public static int POLICY_EXACT_CLASS = 1;
   /**
      This is the default normal policy. Look at class description for
      more information.
   */
   public static int POLICY_NORMAL = 0;
   /**
      This policy matches the package resource in addition oto the application
      default if one is registered.
   */
   public static int POLICY_PACKAGE = 2;
   /**
      The current search policy.
   */
   private int m_policy = POLICY_NORMAL;
   private static Hashtable fallbackList = new Hashtable();;
   private Locale m_Locale = null;

   /**
      This class computes the names of the resource classes that are candidates
      to be searched for. This method enforces the  search order described
      in the class description section. Given a class object myPackage.
      B with superclass myPackage.A, fallback resource class name "global.Resources
      the following list is produced:
    
      - myPackage.A.locale.en_US.A
      - myPackage.A.locale.en_US.B
      -
      myPackage.locale.en_US.A
      - global.locale.en_US.Resources
    
   */
   public Vector getResourceCandidateList(Class aClass) {
      Vector         aClassList        = new Vector();
      String         aSuperClassName   = "";
      String         aClassName        = null;
      Class          originalClass     = aClass;
      String         aPackageName      = null;
      int            index;      


      //=================================================================
      // Compose the classes that we will use to look for the resource
      //=================================================================
      if (getPolicy() != POLICY_PACKAGE) {
	 while ( (aClass != null) && (!aClass.getName().equals(m_terminatingClass)) ) {

	    // Ignore system classes

	    if ( !(aClass.getName().startsWith("javax.swing")) &&
		 !(aClass.getName().startsWith("java")) ) {
	       aClassList.addElement(aClass.getName());
	    }

	    if (getPolicy() == POLICY_EXACT_CLASS) {
	       break;
	    }
	    
	    aClass = aClass.getSuperclass();
	 }
      }

      //=========================================================================
      // If the class has an application registered fallback class, then add it
      // to the list.
      //=========================================================================
      String fallBackResourceName = null;
      
      if ( (fallBackResourceName = getFallbackResource(originalClass)) != null) {
	 aClassList.addElement(fallBackResourceName);
      }          

      //=================================================================
      // Go thru the list fixing up the name to match that of the locale.
      // If the resource name is that of the application fallback, then
      // instantiate and add to application resource cache.
      //=================================================================
      for (int i = 0; i < aClassList.size(); i++) {

         String             anObject;
         ListResourceBundle aResource;
	 boolean            fallback = false;

         anObject     = null;
         aResource    = null;
         aPackageName = null;
         index        = 0;
                          
	 //===================================================
         // Compose the name of the class. It is the
         // package name + "locale" + locality + classname
	 //===================================================
         aClassName = (String) aClassList.elementAt(i);

	 if (aClassName.equals(fallBackResourceName)) {
	    fallback = true;
	 }

         if ( (index = aClassName.lastIndexOf('.') ) != -1 ) {
            aPackageName = aClassName.substring(0, index);
            aClassName   = aClassName.substring(index + 1);
         }

         if (aPackageName != null) {
            aClassName = aPackageName + ".locale." + m_Locale.toString() + "." + aClassName;
         }
	 else {
            aClassName = "locale." + m_Locale.toString() + "." + aClassName;
	 }
         
         aClassList.setElementAt(aClassName, i);
      }

      //============================================
      // Package scope processing
      //============================================
      if (getPolicy() == POLICY_PACKAGE) { 

	 aClassName = originalClass.getName();

         if ( (index = aClassName.lastIndexOf('.') ) != -1 ) {
            aPackageName = aClass.getName().substring(0, index);
            aClassName   = aClassName.substring(index + 1);
         }

         if (aPackageName != null) {
            aClassName = aPackageName + ".locale." + m_Locale.toString() + ".Resources";
         }
	 else {
            aClassName = "locale." + m_Locale.toString() + ".Resources";
	 }
         
         aClassList.insertElementAt(aClassName, 0);
      }

      return (aClassList);
   }

   /**
      Locates a String resource that has the supplied key in the possible
      resource locations.
    
      @param key Use the key during the search.
      @return stringResource
      if the key is found or null otherwise.
    
    
    
   */
   public String getStringResource(String key, Class aClass) {
      Vector             aClassList = getResourceCandidateList(aClass);
      String             aString    = null;
      for(int i = 0; i < aClassList.size(); i++) {              
	 try {
	    ListResourceBundle aResource = null;
	    String aClassName = (String)aClassList.elementAt(i);
	    Class myClass = Class.forName(aClassName);
	    aResource = (ListResourceBundle)myClass.newInstance();
	    aString = aResource.getString(key);
	    myClass = null;
	    aResource = null;
	    if(aString != null) break;
	 }
	 catch(Throwable ignore) {}       
      }
      if(aString == null) System.out.println("Null resource. Class:" + aClass.getName() + " key is:" + key);
      return(aString);       
   }

   /**
      Locates a character resource that has the supplied key in the possible
      resource locations.
    
      @param key Use the key during the search.
      @return accelarator
      resource if the key is found or ' '.
    

    
   */
   public char getAccelaratorResource(String key, Class aClass) {
      return (getStringResource(key, aClass).charAt(0));  
   }

   /**
      If a hit was made looking for a given resource, this method returns
      the ListResourceBundle that contained the key.
   */
   public ListResourceBundle getLastMatchResourceClass() {
      return (m_lastMatch);
   }

   /**
      A constructor that accepts a terminating class name but uses the
      default locale.
   */
   public ResourceResolver(String aTerminatingClass) {
      this(aTerminatingClass, null);
   }

   /**
      A constructor that accepts a terminating class name and the locale
      supplied.
   */
   public ResourceResolver(String aTerminatingClass, Locale aLocale) {
      m_terminatingClass  = aTerminatingClass;
      m_Locale            = aLocale;
       
      if (m_Locale == null) {
	 m_Locale = Locale.getDefault();
      }
       
      if (m_terminatingClass == null) {
	 m_terminatingClass = "java.lang.Object";
      }
   }

   /**
      A constructor that uses the default locale.
   */
   public ResourceResolver() {
      this(null , null);
   }

   /**
      Sets the resource locator policy.
   */
   public void setPolicy(int aPolicy)throws IllegalArgumentException
      {
	 if ( (aPolicy != POLICY_PACKAGE)     && 
	      (aPolicy != POLICY_EXACT_CLASS) && 
	      (aPolicy != POLICY_NORMAL)) {
	    throw new IllegalArgumentException("Invalid search policy");
	 }

	 m_policy = aPolicy;
      }

   /**
      Returns the current policy.
   */
   public int getPolicy() {
      return m_policy;
   }

   /**
      This method registers an application fallback class. For example,
      an application com.company.someapplication can be registered to have
      a fallback resource class of com.company.someapplication.java.Resources.
      The fallback class name will be manipluated to have the locale information
      embedded in it. For the en_US locale, the ResourceResolver will look
      in com.company.someapplication.java.locale.en_US.Resources.
   */
   public static void registerApplicationFallback(String applicationName, String aClassName) {
      fallbackList.put(applicationName, aClassName);
   }

   /**
      Removes the registered application.
   */
   public static void deregisterApplicationFallback(String applicationName) {
      fallbackList.remove(applicationName);
   }

   /**
      Returns the application name of a given class. The application name
      is the first three words of the class name.
   */
   private String getFallbackResource(Class aClass) {
      // Extract the application name from the class name
      String appName = ClassHelper.getApplicationNameFromClass (aClass);
      //Owen Flannery 04.06.2004
      //added this test for null here so that we will not get nullpointer exception
      if (appName != null) {
 	 return (String) fallbackList.get (appName);
      }else {
 	 return null;
      }
   }

   /**
      This method locates and creates a resource for a given class. This
      method is usefull when a class implementation needs a locale specific
      class to be present. Thus the search order is based on the class
      descriptor passed in and a class name to match.
    
      The search is relative to the package where the class descriptor
      resides. If the class is not found, then a null is returned.
   */
   public Object getResourceForClass(Class aClass, String aClassName) {
      String         aPackageName      = null;
      int            index;    
      Object         myObject          = null;

      if ( (index = aClass.getName().lastIndexOf('.') ) != -1 ) {
	 aPackageName = aClass.getName().substring(0, index);
      }

      if (aPackageName != null) {
	 aClassName = aPackageName + ".locale." + Locale.getDefault().toString() + "." + aClassName;
      }
      else {
	 aClassName = "locale." + Locale.getDefault().toString() + "." + aClassName;
      }

      try {
	 Class myClass = Class.forName(aClassName);
	 myObject =  myClass.newInstance();
	 myClass = null;
      }
      catch(Throwable ignore) {
	 System.out.println(ignore);
      }

      return (myObject);
   }

}

