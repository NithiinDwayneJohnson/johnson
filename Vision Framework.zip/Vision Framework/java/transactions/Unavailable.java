package COM.novusnet.vision.java.transactions;

import java.lang.RuntimeException;


class Unavailable extends RuntimeException {
}

