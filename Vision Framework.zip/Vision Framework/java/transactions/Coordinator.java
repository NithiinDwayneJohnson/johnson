package COM.novusnet.vision.java.transactions;
/**
   The Coordinator interface provides operations that are used by participants
   in a transaction. Each object supporting the Coordinator interface
   is implicitly associated with a single transaction.
 @version 1.1, 7-13-2004
*/
public class Coordinator {
   private boolean m_Prepared;
   private boolean m_RollbackOnly;
   public Control m_Control;

   /**
      Returns true if the transaction has been prepared. False otherwise.
   */
   boolean isPrepared() {
      return(m_Prepared);
   }

   /**
      Sets the state of the "Prepared". Used internally.
   */
   void setPrepared(boolean aPrepared) {
      m_Prepared = aPrepared;
   }

   /**
      Force the outcome of the transaction so that it can not be
      committed but only rolled back.Typically called by Synchronization
      objects.
   */
   public void rollbackOnly() {
      m_RollbackOnly = true;
   }

   /**
      The constructor of a coordinator. This method takes a control object
      as its sole parameter.
   */
   public Coordinator(Control aControl) {
      m_Control  = aControl;
   }

   /**
      Returns true if the outcome can only be rollback.
   */
   boolean isRollbackOnly() {
      return(m_RollbackOnly);
   }

   /**
      This operation registers the specified resource as a participant
      in the transaction represented by the target object. The Inactive
      exception is raised if the transaction has already been prepared.
      If the resource is already registered in this transaction, then the
      method is a nop.
    
   */
   public void registerResource(Resource aResource)throws Inactive , TransactionRolledBack
      {
	 //**************************************************************//
	 // if we have already prepared, then throw the exception        //
	 //**************************************************************//
	 if (m_Prepared) {
	    throw new Inactive();
	 }
      
	 //*****************************************************************//
	 // if we have been marked as rollback only then throw an exception
	 //*****************************************************************//
	 if (m_RollbackOnly) {
	    throw new TransactionRolledBack();
	 }

	 //**************************************************************//
	 // Add to list only if the resource has not already been        //
	 // added.                                                       //
	 //**************************************************************//
	 if (m_Control.getResourceTable().indexOf(aResource) < 0) {
	    ResourceManager aResourceManager = new ResourceManager(aResource);
	    m_Control.getResourceTable().addElement(aResourceManager);
	 }
    
	 return;
      }

// No one has ever implemented the Synchronization interface so I am going to 
// take it out of Vision.
// Eoin Flannery, July 13th 2004
//    /**
//       This operation registers the specified object such that it will be
//       notified immediately before and after completion of the transaction
//       associated with the target object.
    
//    */
//    public void registerSynchronization(Synchronization aSync)throws Inactive
//       {
// 	 //**************************************************************//
// 	 // if we have already prepared, then throw the exception        //
// 	 //**************************************************************//
// 	 if (m_Prepared) {
// 	    throw new Inactive();
// 	 }

// 	 //**************************************************************//
// 	 // Add to list only if the sync has not already been            //
// 	 // added.                                                       //
// 	 //**************************************************************//
// 	 if (m_Control.getSyncTable().indexOf(aSync) <0) {
// 	    m_Control.getSyncTable().addElement(aSync);
// 	 }
//       }
}

