package COM.novusnet.vision.java.transactions;

/**
This interface is used by objects that want to be notified of an
impending start and end of a two phase commit. This interface is
useful for persistent objects whose persistent state is being managed
by one PDS.

 An object that implements this interface is notified before any
resource of the pending start of a two-phase commit by calling beforeCompletion().
The transaction manager also notifies the the Synchronization object
of the end of the transaction by calling the afterCompletion() method.
*/
interface Synchronization {

    abstract void afterCompletion(boolean committed);

    abstract void beforeCompletion();

}

