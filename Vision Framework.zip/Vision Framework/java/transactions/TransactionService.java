package COM.novusnet.vision.java.transactions;

import java.util.Hashtable;

/**
 * A singleton class that allows access to the current transaction context.
 */
public class TransactionService {
   public static final int VOTE_COMMIT = 0;
   public static final int VOTE_NOVOTE = 1;
   public static final int VOTE_ROLLBACK = 2;
   public static final int VOTE_READONLY = 3;
   private Hashtable m_ControlTable;
   private static TransactionService TxnService;

   static {
      TxnService = new TransactionService();
   }

   /**
      The constructor is private since this class is a singleton. Object
      reference can only be obtained by calling the static instance() method.
    
   */
   private TransactionService() {
      //**************************************************************//
      // Create the table for active control objects                  //
      //**************************************************************//
      m_ControlTable = new Hashtable();
   }

   /**
      Returns the Control object already associated with the supplied thread.
      If a Thread is null, returns the Control
      associated with the current thread.
    
   */
   public Control getControl(Thread aThread) {
    
      //**************************************************************//
      // If null thread is specified, then use the current thread.    //
      //**************************************************************//
      if (aThread == null) {
         aThread = Thread.currentThread();
      }

      return((Control)m_ControlTable.get(aThread));
   }

   /**
      Sets the Transaction Control in the supplied context. If the Control
      object supplied is null, then the association between the Control
      object and the thread is broken. Otherwise the Control object is
      associated with the supplied thread.
    
   */
   public void setControl(Control aControl, Thread aThread) {
      //**************************************************************//
      // If null thread is specified, then use the current thread.    //
      //**************************************************************//

      if (aThread == null) {
	 aThread = Thread.currentThread();
      }

      //**************************************************************//
      // Handle the case when the control object is null              //                                               //
      //**************************************************************//
      if (aControl == null) {    
	 m_ControlTable.remove(aThread);
      }
      else {

	 //**************************************************************//
	 // Using the current thread , find if there is a control        //
	 // object already associated.                                   //
	 //**************************************************************//
	 if ( getControl (aThread) == null) {
	    m_ControlTable.put(aThread , aControl);
	 }
	 else {
	    m_ControlTable.remove(aThread);
	 }
      }
      return;
   }

   /**
      The constructor is private since this class is a singleton. Object
      reference can only be obtained by calling the static  instance()
      method.
    
   */
   public static TransactionService instance() {
      return(TxnService);
   }

   /**
      Returns the Current that represents the active transaction.
   */
   public Current getCurrent() {
      Control aControl = getControl(null);
       
      if (getControl(null) != null) {
	 return new Current(aControl);
      }

      return(null);
   }
}

