package COM.novusnet.vision.java.transactions;

/**
A ResourceManager class holds the information of a Resource. This
class is used internally by the transaction manager for storing resources.
*/
class ResourceManager {
   /**
      The vote that the resource returned.
   */
   private int m_Vote;
   private Resource m_Resource;

   /**
      Returns the vote of the resource.
   */
   int getVote() {
      return(m_Vote);
   }

   /**
      Sets the vote of the resource.
   */
   void setVote(int aVote) {
      m_Vote = aVote;
   }

   /**
      Constructor that takes a Resource as an argument.
   */
   ResourceManager(Resource aResource) {
      m_Resource    = aResource;
      m_Vote        = TransactionService.VOTE_NOVOTE;
   }

   /**
      Returns a reference to the resource.
   */
   Resource getResource() {
      return(m_Resource);
   }

   /**
      Checks the resource equality.
   */
   public boolean equals(Object anObject) {
      return ( ((ResourceManager)anObject).getResource().equals(getResource()));
   }

   /**
      Returns the resource object hashCode.
   */
   public int hashCode() {
      return (getResource().hashCode());
   }

}

