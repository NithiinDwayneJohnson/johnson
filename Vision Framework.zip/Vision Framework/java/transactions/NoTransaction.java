package COM.novusnet.vision.java.transactions;

import java.lang.Exception;

class NoTransaction extends RuntimeException {

}

