package COM.novusnet.vision.java.transactions;

import java.util.Vector;
/**
The Control interface allows a program to explicitly manage or propagate
a transaction context. An object supporting the Control interface
is implicitly associated with one specific transaction.
@version 1.1, 7-13-2004
*/
public class Control {

// No one has ever implemented the Synchronization interface so I am going to 
// take it out of Vision.
// Eoin Flannery, July 13th 2004
//    private Vector m_SyncTable;
   public Terminator m_Terminator;
   private Vector m_ResourceTable;
   public Coordinator m_Coordinator;

   public Control() {
      m_Coordinator    = new Coordinator(this);
      m_Terminator     = new Terminator(this); 
      m_ResourceTable  = new Vector();      
//       m_SyncTable      = new Vector();      
   }

//    /**
//       Returns the Synchronization table. Used internally by the transaction
//       manager components during registration and commits/rolbacks.
//    */
//    Vector getSyncTable() {
//       return(m_SyncTable);
//    }

   /**
      An object is returned that supports the Terminator interface. The
      object can be used to commit or rollback transactions.
    
   */
   public Terminator getTerminator() {
      return(m_Terminator);
   }

   /**
      Returns the Resource table. Used internally by the transaction manager
      components during registration and commits/rolbacks.
   */
   Vector getResourceTable() {
      return(m_ResourceTable);
   }

   /**
      An object is returned that supports the Coordinator interface. The
      object can be used to register resources for the transaction associated
      with the Control object. 
    
   */
   public Coordinator getCoordinator() {
      return(m_Coordinator);
   }
}

