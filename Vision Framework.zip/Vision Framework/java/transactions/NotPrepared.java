package COM.novusnet.vision.java.transactions;

import java.lang.RuntimeException;
class NotPrepared extends RuntimeException {
}

