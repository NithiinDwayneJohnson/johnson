package COM.novusnet.vision.java.transactions;

import java.lang.RuntimeException;
public class Inactive extends RuntimeException {
   /**
      Constructor
   */
   public Inactive(String text) {
      super(text);
   }

   /**
    Constructor
    */
   public Inactive() {
   }
}

