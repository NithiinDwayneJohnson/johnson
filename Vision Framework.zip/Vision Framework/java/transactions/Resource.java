package COM.novusnet.vision.java.transactions;

/**
 * The Transaction Service uses a two-phase commit protocol to complete
 * a top-level transaction with each registered resource. The Resource
 * interface defines the operations invoked by the transaction service
 * on each resource.  Each object supporting the Resource interface
 * is implicitly associated with a single top-level transaction.
 */
public interface Resource {
   /**
    *    If necessary, the resource should commit all changes made as part
    *    of the transaction. If the resource has forgotten the transaction
    *    it should do nothing.
    */
   public void commit();

   /**
    *   This operation is invoked to begin the two-phase commit protocol
    *    on the resource. The resource can respond in several ways, represented
    *    by the Vote result.    
    */
   int prepare();

   /**
    *    If necessary, the resource should rollback all changes made as part
    *    of the transaction.  If the resource has forgotten the transaction,
    *    it should do nothing.                                           
    */
   void rollback();

   public boolean isLastCalled();

}


