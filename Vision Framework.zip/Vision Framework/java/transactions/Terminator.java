package COM.novusnet.vision.java.transactions;

import java.util.Enumeration;
import java.util.Vector;
import COM.novusnet.vision.java.businessobjects.BusinessObjectTxnResource;

/**
The Terminator interface supports operations to commit or rollback
a transaction.
@version 1.1, 7-13-2004
*/
class Terminator {

   public Control m_Control;
   public Coordinator m_Coordinator;

   /**
      If the transaction has not been marked rollback only, and all of
      the participants in the transaction agree to commit, the transaction
      is committed and the operation terminates normally. Otherwise the
      transaction is rolled back, and the TransactionRolledBack standard
      exception is raised.    
   */
   public void commit()throws TransactionRolledBack
      {
	 Enumeration      anEnum;
	 ResourceManager  aResourceManager;
// No one has ever implemented this Synchronization interface so I am going to 
// take it out of Vision.
// Eoin Flannery, July 13th 2004
// 	 Synchronization  aSync;
	 int              aVote = TransactionService.VOTE_NOVOTE;
	 boolean          votedRollBack = false;       

	 //**************************************************************//
	 // Did somebody set the result to be rollback-only?             //
	 //**************************************************************//
	 if (m_Coordinator.isRollbackOnly()) {
	    rollback();
	    throw new TransactionRolledBack();
	 }

// 	 //**************************************************************//
// 	 // Go thru our collection notifying Synchronization objects     //
// 	 // of an impending two-phase commit.                            //
// 	 //**************************************************************//

// 	 anEnum = m_Control.getSyncTable().elements();

// 	 while(anEnum.hasMoreElements() && (m_Coordinator.isRollbackOnly() == false) ) {
// 	    aSync = (Synchronization) anEnum.nextElement();
// 	    aSync.beforeCompletion();
// 	 }

	 //**************************************************************//
	 // If the Sync objects set the result to be rollback only then  //
	 // don't start the two phase commit.                            //
	 //**************************************************************//
	 if (!m_Coordinator.isRollbackOnly()) {

	    //**************************************************************//
	    // Go through all the resource objects calling the prepare      //
	    // method on them. Note that durring the prepare, other objects //
	    // might get involved in the transaction. So we will keep       //
	    // preparing until all objects have a vote. Out enumeration     //
	    // can thus be invalidated during the run.                      //
	    //**************************************************************//

	    boolean allvoted = false;

	    while (allvoted == false) {

	       Vector resources = (Vector)m_Control.getResourceTable().clone();	     	     
	       anEnum           = resources.elements();

	       allvoted = true;

	       while(anEnum.hasMoreElements()) {

		  aResourceManager = (ResourceManager) anEnum.nextElement();

		  if (aResourceManager.getVote() == TransactionService.VOTE_NOVOTE) {

// 		     System.out.println("Terminator.commit() -- prepare ");
// 		     ((BusinessObjectTxnResource)aResourceManager.getResource()).printOut();

		     aVote = aResourceManager.getResource().prepare();

		     aResourceManager.setVote(aVote);

		     if (aVote == TransactionService.VOTE_ROLLBACK) {
			votedRollBack = true;
		     }

		     //**************************************
		     // Found someone who did not vote
		     //**************************************
		     allvoted = false;		   
		  }				
	       }
	    }

	    anEnum = m_Control.getResourceTable().elements();
          
	    m_Coordinator.setPrepared(true);

	    //**************************************************************//
	    // If nobody voted ROLLBACK, then call commit on all objects    //
	    // that voted to commit. This will exclude readonly             //
	    //**************************************************************//
	    if (votedRollBack == false) {

	       Resource lastCalledResource = null;

	       while(anEnum.hasMoreElements()) {

		  aResourceManager = (ResourceManager) anEnum.nextElement();

		  if (aResourceManager.getVote() == TransactionService.VOTE_COMMIT) {

		     //**************************************
		     // Skip any resource marked as "last"
		     //**************************************
		     if (aResourceManager.getResource().isLastCalled ()) {
			lastCalledResource = aResourceManager.getResource();
		     }
		     else {
// 			System.out.println("Terminator.commit() -- commit ") ;
// 			((BusinessObjectTxnResource)aResourceManager.getResource()).printOut();
		     
			aResourceManager.getResource().commit();
		     }
		  }
	       }

	       //**************************************************************//
	       // Commit the last resource (if one was encountered).           //
	       //**************************************************************//
	       if (lastCalledResource != null) {
		  lastCalledResource.commit ();
	       }

// 	       //**************************************************************//
// 	       // Go thru our collection notifying Synchronization objects     //
// 	       // of the end of the two phase commit.                          //
// 	       //**************************************************************//

// 	       anEnum = m_Control.getSyncTable().elements();

// 	       while(anEnum.hasMoreElements()) {
// 		  aSync = (Synchronization) anEnum.nextElement();
// 		  aSync.afterCompletion(true);
// 	       }

	       //**************************************************************//
	       // Get rid of all the resources.                                //
	       //**************************************************************//
	       m_Control.getResourceTable().removeAllElements();
	    }

	    //**************************************************************//
	    // Somebody wants to rollback. Ask all resources that have      //
	    // voted to commit to rollback.                                 //
	    //**************************************************************//
	    else {
	       rollback();
	       throw new TransactionRolledBack();
	    }
	 }
	 else {
	    rollback();
	    throw new TransactionRolledBack();
	 }
      }

   /**
      Rollsback a transaction.
   */
   public void rollback() {
      Enumeration      anEnum;
      ResourceManager  aResourceManager;
      int              aVote;
//       Synchronization  aSync;
      RuntimeException anException = null;

      anEnum = m_Control.getResourceTable().elements();

      Resource lastCalledResource = null;


      while(anEnum.hasMoreElements()) {

	 aResourceManager = (ResourceManager) anEnum.nextElement();

	 System.out.println("Terminator.rollback() -- rollback ");
	 ((BusinessObjectTxnResource)aResourceManager.getResource()).printOut();

	 //**************************************
	 // Skip any resource marked as "last"
	 //**************************************
	 if (aResourceManager.getResource().isLastCalled ()) {
	    lastCalledResource = aResourceManager.getResource();
	    continue;
	 }

	 aVote = aResourceManager.getVote();
	  
	 if (aVote == TransactionService.VOTE_READONLY) {
	    continue;
	 }

	 //==================================================================
	 // Surround the rollback by try an catch blocks. This way,
	 // if the rollback code threw an exception, we still rollback other
	 // resources.
	 //==================================================================
	 try {
	    System.out.println("Terminator.rollback() -- calling rollback on the resource ");

	    aResourceManager.getResource().rollback();
	 }
	 catch(RuntimeException e) {
	    anException = e;
	 }
      }
      //**************************************************************//
      // Rollback the last resource (if one was encountered).         //
      //**************************************************************//
      if (lastCalledResource != null) {
	 //==================================================================
	 // Surround the rollback by try an catch blocks. This way,
	 // if the rollback code threw an exception, we still rollback other
	 // resources.
	 //==================================================================
	 try {
	    lastCalledResource.rollback ();
	 }
	 catch(RuntimeException e) {
	    anException = e;
	 }
      }

//       //**************************************************************//
//       // Go thru our collection notifying Synchronization objects     //
//       // of the end of the two phase commit.                          //
//       //**************************************************************//
//       anEnum = m_Control.getSyncTable().elements();

//       while(anEnum.hasMoreElements()) {
// 	 aSync = (Synchronization) anEnum.nextElement();
// 	 aSync.afterCompletion(false);
//       }

      //**************************************************************//
      // Get rid of all the resources.                                //
      //**************************************************************//
      m_Control.getResourceTable().removeAllElements();

      if (anException != null) {
	 throw anException;
      } 
   }

   public Terminator(Control aControl) {
      m_Control         = aControl;
      m_Coordinator     = aControl.getCoordinator();
   }

}

