package COM.novusnet.vision.java.transactions;
/**
   The Current class defines operations that allow a client of the Transaction
   Service to explicitly manage the association between threads and
   transactions.
   @version 1.1, 7-13-2004
*/
public class Current {
   private Control m_Control;
   public static TransactionService s_TxnService;

   static {
      s_TxnService = TransactionService.instance();         
   }

   /**
      A new transaction is created. the transaction context of the client
      thread is modified so that the thread is associated with the new
      transaction. If the client thread is already associated with a  transaction,
      the new transaction is a subtransaction of that transaction, otherwise
      the new transaction is a top-level transaction. The subtransactionsUnavailable
      exception is raised if the client thread already has an associated
      transaction and the Transaction Service implementation does not support
      nested transactions.                        
   */
   public void begin()throws SubtransactionsUnavailable {
      Current myCurrent  = TransactionService.instance().getCurrent();

      if (myCurrent != null) {
	 throw new RuntimeException("A previous transaction was not properly terminated.");
      }

      if (m_Control != null) {
	 throw new SubtransactionsUnavailable();
      } 
      else {
	 m_Control = new Control();
	 s_TxnService.setControl(m_Control , null);
      }      
      return;    
   }

   public Current() {

   }

   /**
      This method commits the transaction. If there is no transaction associated
      with the client thread, the NoTransaction exception is raised. Otherwise,
      the transaction associated with the client thread is completed.    
   */
   public void commit()throws NoTransaction ,TransactionRolledBack {
      try {  
         if (m_Control == null) {
            throw new NoTransaction();
         }
         else {
            m_Control.getTerminator().commit();
         }
      } 
      // An exception is equivelant to a rollback ??
      catch (RuntimeException e) {
	 rollback();
	 throw e;
      }
      finally {
	 // Transaction is over                                          
	 s_TxnService.setControl(null , null);
	 m_Control = null;    
      }  
   }

   /**
      This method rollsback a transaction. If there is no transaction associated
      with the client thread, the NoTransaction exception is raised.  If
      the client thread does not have permission to rollback the transaction,
      the standard NO_PERMISSION exception is raised.  Otherwise, the transaction
      associated with the client thread is rolled back.    
   */
   public void rollback()throws NoTransaction {
      try {
	 if (m_Control == null) {
	    throw new NoTransaction();
	 }
	 else {
	    m_Control.getTerminator().rollback();
	 }
      }
      finally { 
	 // Transaction is over                                          
	 s_TxnService.setControl(null , null);
	 m_Control = null;
      }

      return;      
   }

// These methods are not used so I will remove them from the framework.
// Eoin Flannery, July 13th 2004.
//    /**
//       Associates the client thread with the Current execution context in
//       place of any previous transaction    
//    */
//    public void resume(Control aControl) {
//       m_Control = aControl;
//       s_TxnService.setControl(m_Control, null);
//    }

//    /**
//       Suspends the current trnascation. This method returns a 
//       control object that can be used by the resume method to 
//       re-establish
//       this transaction context in the same or a different thread. 
//    */
//    public Control suspend() {
//       Control   aControl = m_Control;           
//       s_TxnService.setControl(null , null);
//       m_Control = null;
//       return(aControl);
//    }

   /**
      If the client thread is not associated with a transaction, a null
      object reference is returned.  Otherwise a Control object that represents
      the transaction context currently associated with the client thread.
   */
   public static Control getControl() {
      return(s_TxnService.getControl(null)); 
   }

   /**
      Constructor that takes a control object.
   */
   public Current(Control aControl) {
      m_Control = aControl;
   }

}

