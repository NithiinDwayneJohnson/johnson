package COM.novusnet.vision.java.transactions;

import java.lang.Exception;



class SubtransactionsUnavailable extends RuntimeException {

}

