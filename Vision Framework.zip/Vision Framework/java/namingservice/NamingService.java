//## //## Source file:  d:\develop/COM/novusnet/vision/java/namingservice/NamingService.java
//## //## Subsystem:  namingservice
//## //## Module: NamingService

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
import java.util.*;
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
The naming service keeps track of object to name bindings. This light
weight naming service is intended to be of general pupose. It is
a local naming service unlike CORBA's which is remote.

The naming service can be viewed as a tree that mimics the a heirarechal
file system. The path name scheme that is used by the naming service
follows that of the UNIX file system. For example: /businessObjects/Account/Customer.

Typically,
only one naming service exists in a given virtual machine.

*/
public class NamingService {
    //##begin NamingService.initialDeclarations preserve=yes
    //##end NamingService.initialDeclarations

    private Hashtable m_FileEntries = new Hashtable();
    private NameComponent m_NameComponent;

    /**
    Creates a binding between an object and a given name. The name follows
    the unix file system naming convention.
    
    <p> Example </p>
    
    myNamingService.bind(myCustomer, "/businessobjects/customers/601100004"):
    
    binds
    myCustomer object to the supplied directory entry.
    
    @param anObject The object to bind.
    @param path         The binding
    name
    
    @exception ObjectAlreadyBound If the object is already bound to
    the given name.
    @exception  InvalidPathName If the pathname supplied is invalid
    */
    public synchronized void bind(Object anObject, String path)throws ObjectAlreadyBound, InvalidPathName
 {
    //##begin NamingService::bind%33634A4C014A.body preserve=yes
    
       //**********************************************************
       // Extract the directory name and file name from the path
       //**********************************************************
       NameComponent aNameComponent = new NameComponent(path);
       
       //**********************************************************       
       // Change to that directory
       //**********************************************************       
       FileEntry aFileEntry = chdir(aNameComponent.getPathComponents());
       
       //**********************************************************              
       // If the directory does not exist, then create it
       //**********************************************************
       if (aFileEntry == null) {
          aFileEntry = mkdir(aNameComponent.getPathComponents());
       }

       //**********************************************************       
       // Ensure that the object has not already been bound.
       //**********************************************************       
       if (aFileEntry.getFileEntry(aNameComponent.getFileName()) != null) {
          throw new ObjectAlreadyBound(path);
       }
       
       //**********************************************************       
       // Add the binding.
       //**********************************************************
       FileEntry aNewFileEntry = new FileEntry(aNameComponent.getFileName());
       
       aNewFileEntry.setBoundObject(anObject);
       aFileEntry.addFileEntry(aNewFileEntry);                     
       
    //##end NamingService::bind%33634A4C014A.body

    }

    /**
    Removes a binding between an object and a given name.
    
    <p> Example </p>
    
    myNamingService.unbind("/businessobjects/customers/601100004"):
    
    removes
    the binding to the supplied name.
    
    @param path         The binding name to unbind.
    
    @exception
    ObjectNotFound If the binding is not found
    @exception  InvalidPathName If the pathname supplied is invalid
    */
    public synchronized void unbind(String path)throws ObjectNotFound, InvalidPathName
 {
    //##begin NamingService::unbind%33634A9A0084.body preserve=yes
    
       NameComponent aNameComponent = null;
    
       //**********************************************************
       // Extract the directory name and file name from the path
       //**********************************************************
       try {
          aNameComponent = new NameComponent(path);
       } 
       catch (Exception anException) {
          throw new ObjectNotFound(anException.toString() +
                                   ":"                    +
                                   anException.getMessage());
       }   
       
       //**********************************************************       
       // Change to that direcory
       //**********************************************************       
       FileEntry aFileEntry = chdir(aNameComponent.getPathComponents());
       
       //**********************************************************              
       // If the directory does not exist, then create it
       //**********************************************************
       if (aFileEntry == null) {
          throw new InvalidPathName("Invalid path:" + path);
       }
       
       //**********************************************************       
       // Ensure that the object has already been bound.
       //**********************************************************       
       if (aFileEntry.getFileEntry(aNameComponent.getFileName()) == null) {
          throw new ObjectNotFound(path);
       }
       
       //**********************************************************       
       // Remove the binding.
       //**********************************************************
       aFileEntry.removeFileEntry(aNameComponent.getFileName());
                         
    //##end NamingService::unbind%33634A9A0084.body

    }

    /**
    Rebinds an object to another key. The old binding is removed.
    
    <p> Example </p>
    
    myNamingService.rbind(myCustomer, "/businessobjects/customers/601100005"):
    
    rebinds
    myCustomer object to the new directory entry name.
    
    @param anObject The object to rebind.
    @param path         The
    new binding name.
    
    @exception ObjectNotFound If the binding is not found
    @exception
    InvalidPathName If the pathname supplied is invalid
    */
    public void rebind(Object anObject, String path)throws ObjectNotFound, InvalidPathName
 {
    //##begin NamingService::rebind%3363B1DB0173.body preserve=yes
    
       NameComponent aNameComponent = null;
       FileEntry     aFileEntry     = null;
    
       //**********************************************************
       // Extract the directory name and file name from the path
       //**********************************************************
       try {
          aNameComponent = new NameComponent(path);
          aFileEntry = chdir(aNameComponent.getPathComponents());
       } 
       catch (Exception anException) {
          throw new ObjectNotFound("Object not found for " + path);
       }   
                     
       //**********************************************************              
       // If the FileEntry does not exist, then throw an exception.
       //**********************************************************
       if (aFileEntry == null) {
          throw new ObjectNotFound("Object not found for " + path);       
       }
       
       aFileEntry = aFileEntry.getFileEntry(aNameComponent.getFileName());
       
       if (aFileEntry == null) {
          throw new ObjectNotFound("Object not found for " + path);       
       }
              
       aFileEntry.setBoundObject(anObject);
        
    //##end NamingService::rebind%3363B1DB0173.body

    }

    /**
    Returns all entries in a given directory.
    
    @param path  The path to resolve. This must be an existing path
    name.
    @return The file entries in the directory.
    @exception  InvalidPathName
    If the pathname supplied is invalid
    */
    public synchronized FileEntry[] resolveMany(String path)throws InvalidPathName
 {
    //##begin NamingService::resolveMany%3363B3970135.body preserve=yes
    
       NameComponent aNameComponent = null;
       FileEntry     aFileEntry     = null;
    
       //**********************************************************
       // Extract the directory name and file name from the path
       //**********************************************************
       try {
          aNameComponent = new NameComponent(path);
          aNameComponent.setFileNameToDirectory();
          
          aFileEntry = chdir(aNameComponent.getPathComponents());
       } 
       catch (Exception anException) {
          throw new InvalidPathName(path);
       }   
                     
       //**********************************************************              
       // If the FileEntry does not exist, then throw an exception.
       //**********************************************************
       if (aFileEntry == null) {
          throw new InvalidPathName(path);       
       }
                     
       FileEntry[] aFileEntryArray[];
       
       return (aFileEntry.getFileEntries()) ;
    
    //##end NamingService::resolveMany%3363B3970135.body

    }

    /**
    Locates an object with a given name.
    
    @param path The path to resolve. This must be an existing path
    name.
    @return Object associated with the given binding name.
    @exception
    ObjectNotFound If the binding is not found
    @exception  InvalidPathName If the pathname supplied is invalid
    */
    public synchronized Object resolve(String path)throws ObjectNotFound, InvalidPathName
 {
    //##begin NamingService::resolve%33634ADA0375.body preserve=yes
    
       NameComponent aNameComponent = null;
       FileEntry     aFileEntry     = null;
    
       //**********************************************************
       // Extract the directory name and file name from the path
       //**********************************************************
       try {
          aNameComponent = new NameComponent(path);
          aFileEntry = chdir(aNameComponent.getPathComponents());
       } 
       catch (Exception anException) {
          throw new ObjectNotFound("Object not found for " + path);
       }   
                     
       //**********************************************************              
       // If the FileEntry does not exist, then throw an exception.
       //**********************************************************
       if (aFileEntry == null) {
          throw new ObjectNotFound("Object not found for " + path);       
       }
       
       aFileEntry = aFileEntry.getFileEntry(aNameComponent.getFileName());
       
       if (aFileEntry == null) {
          throw new ObjectNotFound("Object not found for " + path);       
       }
              
       return(aFileEntry.getBoundObject());
    //##end NamingService::resolve%33634ADA0375.body

    }

    /**
    Constructor. This methods creates the root directory.
    */
    public NamingService() {
    //##begin NamingService::NamingService%336374FC00FE.body preserve=yes

       //**********************************************************    
       // Add the root file entry.
       //**********************************************************
       FileEntry aFileEntry = new FileEntry("/");              
       m_FileEntries.put("/", aFileEntry);
       
    //##end NamingService::NamingService%336374FC00FE.body

    }

    /**
    Returns the FileEntry associated with the pathname directory. If
    the path name does not exist, a null is returned. If the path name
    contains a file name, an exception is thrown.
    
    @param pathComponents This is the list of components that make
    up the path to a given entry.
    @return The file entry that represents the name specified.
    */
    private FileEntry chdir(Vector pathComponents)throws InvalidPathName
 {
    //##begin NamingService::chdir%33637BB7005B.body preserve=yes
    
       FileEntry aFileEntry = null;
           
       //**********************************************************    
       // Traverse the path components.
       //**********************************************************
       
       aFileEntry = (FileEntry) m_FileEntries.get(pathComponents.elementAt(0));
       
       for (int i = 1; i < pathComponents.size() ; i++) {
       
          aFileEntry = aFileEntry.getFileEntry((String) pathComponents.elementAt(i));
                    
          if (aFileEntry == null) {
             return(null);
          }
          
          //***************************************************************
          // if the file entry has a binding, then it is not a directory
          // but a file. throw an Invalid path exception.
          //***************************************************************          
          
          if (aFileEntry.getBoundObject() != null) {
             throw new InvalidPathName("Path contains a file. Should be all directories.");
          }
       }   
       
       return(aFileEntry);
    //##end NamingService::chdir%33637BB7005B.body

    }

    /**
    Creates a path with the supplied path name. If the path name contains
    a file name, an exception is thrown.
    
    @param pathComponents This is the list of components that make
    up the path to a given entry.
    @return The newly created file entry that represents the name specified.
    */
    private FileEntry mkdir(Vector pathComponents)throws InvalidPathName
 {
    //##begin NamingService::mkdir%33637BED03AC.body preserve=yes
    
       FileEntry  aFileEntry    = null;
       FileEntry  nextFileEntry = null;
           
       //**********************************************************    
       // Traverse the path components. If the FileEntry exists,
       // make sure its is a directory.
       //**********************************************************
       
       aFileEntry = (FileEntry) m_FileEntries.get(pathComponents.elementAt(0));
       
       for (int i = 1; i < pathComponents.size() ; i++) {
       
          aFileEntry = aFileEntry.getFileEntry((String) pathComponents.elementAt(i));

          //******************************************************************          
          // If an object was not found, there is no sense continuing since
          // no direcotry exists and there is no way we can find a file
          // amongst the path name entries.
          //******************************************************************
          
          if (aFileEntry == null) {
             break;
          }
          
          //***************************************************************
          // if the file entry has a binding, then it is not a directory
          // but a file. throw an Invalid path exception.
          //***************************************************************          
          
          if (aFileEntry.getBoundObject() != null) {
             throw new InvalidPathName("Path contains a file. Should be all directories.");
          }             
       }
       
       //**********************************************************    
       // Traverse the path components. Insert missing directories
       //**********************************************************
       
       aFileEntry = (FileEntry) m_FileEntries.get(pathComponents.elementAt(0));
       
       for (int i = 1; i < pathComponents.size() ; i++) {
                
          nextFileEntry = aFileEntry.getFileEntry((String) pathComponents.elementAt(i));

          //******************************************************************          
          // If the directory does not exist, then create it underneath the
          // current one.
          //******************************************************************
          
          if (nextFileEntry == null) {
             nextFileEntry = new FileEntry((String)pathComponents.elementAt(i));
             aFileEntry.addFileEntry(nextFileEntry);             
          }
          
          aFileEntry = nextFileEntry;
       }
       
       return(aFileEntry);
       
    //##end NamingService::mkdir%33637BED03AC.body

    }

    /**
    Test routine.
    
    @exception InvalidPathName If the given path name is invalid.
    */
    public static final void main(String[] args)throws InvalidPathName    
 {
    //##begin NamingService::main%3363BDE7029A.body preserve=yes
       NamingService ns = new NamingService();
       
       try {         

          System.out.println("bind test");
          System.out.println("*********");
       
          ns.bind("Page 1 security object" , "/security/pcsolar/screens/page1");
          ns.bind("Page 2 security object" , "/security/pcsolar/screens/page2");
          ns.bind("temp"                   , "/security/pcsolar/screens/Statments/temp/junk");
                    
          System.out.println(ns.resolve("/security/pcsolar/screens/page1"));          
          System.out.println(ns.resolve("/security/pcsolar/screens/page2"));          
          System.out.println(ns.resolve("/security/pcsolar/screens/Statments/temp/junk"));         
          
          System.out.println("\nrebind test");
          System.out.println("*********");
                    
          ns.rebind("Enhanced Page 1 security object","/security/pcsolar/screens/page1");
          ns.rebind("Enhanced Page 2 security object","/security/pcsolar/screens/page2");
          ns.rebind("temp2                          ", "/security/pcsolar/screens/Statments/temp/junk");          
          
          try {
             System.out.println(ns.resolve("/security/pcsolar/screens/page1"));          
             System.out.println(ns.resolve("/security/pcsolar/screens/page2"));          
             System.out.println(ns.resolve("/security/pcsolar/screens/Statments/temp/junk"));                    
          }   
          catch(ObjectNotFound anExcetion) {             
          }
          
          System.out.println("\nResolve many test");
          System.out.println("*****************");
          
          FileEntry[] aFileEntryArray = ns.resolveMany("/security/pcsolar/screens/");
          
          for (int i = 0; i < aFileEntryArray.length ; i++) {          
             System.out.println(" Name  : " + aFileEntryArray[i].getBindingName() +
                                " Object: " + aFileEntryArray[i].getBoundObject());  
          }

          System.out.println("\nunbind test");
          System.out.println("***********");
          
          ns.unbind("/security/pcsolar/screens/page1");
          ns.unbind("/security/pcsolar/screens/page2");
          ns.unbind("/security/pcsolar/screens/Statments/temp/junk");          
          
          System.out.println(ns.resolve("/security/pcsolar/screens/page1"));          
          System.out.println(ns.resolve("/security/pcsolar/screens/page2"));          
          System.out.println(ns.resolve("/security/pcsolar/screens/Statments/temp/junk"));                                     
       }
       catch (Exception anException) {
          System.out.println(anException.getMessage());
          anException.printStackTrace();
       }   
        
    //##end NamingService::main%3363BDE7029A.body

    }

    //##begin NamingService.additionalDeclarations preserve=yes
    //##end NamingService.additionalDeclarations

}

