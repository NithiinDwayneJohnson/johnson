//## //## Source file:  x:\tarek\wip/COM/novusnet/vision/java/namingservice/NameComponent.java
//## //## Subsystem:  namingservice
//## //## Module: NameComponent

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
import java.io.*;
import java.util.*;
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
A name component class is responsible for name/path mappings. It
is constructed given a file name. The name can contain multiple directories.
This class breaks the name down into separate path components and
a file name. All the name parsing logic is embedded in this class.
*/
class NameComponent {
    //##begin NameComponent.initialDeclarations preserve=yes
    //##end NameComponent.initialDeclarations

    private String m_fileName = null;
    private Vector m_pathComponents = new Vector();

    /**
    This constructor takes a file name and breaks it down into path components
    and a leaf file name.
    
    @param fullPathName The full path name that represents this file
    name.
    
    @exception InvalidPathName If the name is invalid.
    */
    public NameComponent(String fullPathName)throws InvalidPathName
 {
    //##begin NameComponent::NameComponent%336378010087.body preserve=yes

       //******************************************************//    
       // The pathname must start with a forward slash         //
       //******************************************************//
           
       if (fullPathName.charAt(0) != '/') {
          throw new InvalidPathName("path name must start with a / character:" + 
                                    fullPathName);
       }
       
      
          //******************************************************//
          // Separate the path from the file name.                //
          //******************************************************//
          
       StringTokenizer aStringTokenizer = new StringTokenizer(fullPathName,"/" , false);
       
       //******************************************************************       
       // Add root entry.
       //******************************************************************       
       m_pathComponents.addElement("/");             
                     
       try {
          for (;;) {                          
          
             String component = aStringTokenizer.nextToken();
             m_pathComponents.addElement(component);
          }
       }
       catch (NoSuchElementException anException) {          
       }
       catch (Exception anException) {          
          throw new InvalidPathName(anException.toString() +
                                    ":"                    +
                                    anException.getMessage());
       }
       
       
       m_fileName = (String) m_pathComponents.lastElement();
       m_pathComponents.removeElementAt(m_pathComponents.size() - 1);
       
       //******************************************************//      
       //
    //##end NameComponent::NameComponent%336378010087.body

    }

    /**
    Returns the file name associated with the name component.
    */
    public String getFileName() {
    //##begin NameComponent::getFileName%3363792C0113.body preserve=yes
       return(m_fileName);
    //##end NameComponent::getFileName%3363792C0113.body

    }

    /**
    Returns a vector of path components.
    */
    public Vector getPathComponents() {
    //##begin NameComponent::getPathComponents%33637D8200DD.body preserve=yes
       return(m_pathComponents);
    //##end NameComponent::getPathComponents%33637D8200DD.body

    }

    /**
    Forces the file name to be part of the directory name.
    */
    public void setFileNameToDirectory() {
    //##begin NameComponent::setFileNameToDirectory%3363C57E0370.body preserve=yes
       m_pathComponents.addElement(getFileName());
       m_fileName = null;
    //##end NameComponent::setFileNameToDirectory%3363C57E0370.body

    }

    //##begin NameComponent.additionalDeclarations preserve=yes
    //##end NameComponent.additionalDeclarations

}

