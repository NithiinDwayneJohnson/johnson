//## //## Source file:  c:\dev\wip/COM/novusnet/vision/java/namingservice/NamingException.java
//## //## Subsystem:  namingservice
//## //## Module: NamingException

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import java.lang.Exception;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public class NamingException extends Exception {
    //##begin NamingException.initialDeclarations preserve=yes
    //##end NamingException.initialDeclarations


    public NamingException(String exceptionString) {
    //##begin NamingException::NamingException%33638A330360.body preserve=yes
       super(exceptionString);
    //##end NamingException::NamingException%33638A330360.body

    }

    //##begin NamingException.additionalDeclarations preserve=yes
    //##end NamingException.additionalDeclarations

}

