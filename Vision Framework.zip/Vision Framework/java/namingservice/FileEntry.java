//## //## Source file:  d:\develop/COM/novusnet/vision/java/namingservice/FileEntry.java
//## //## Subsystem:  namingservice
//## //## Module: FileEntry

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
import java.util.*;
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
A file system is made up of 0 or more file entries. These entries
can represent a leaf or point to another subtree of files (direcotries)
and leafs. A directory can not be bound to an object. Only a leaf
entry in a directory can.

If a leaf is bound to an object, then an attempt to bind a path
that includes the leaf as a component (i.e treat the leaf as a directory)
,  will cause an exception to be raised.
*/
public class FileEntry {
    //##begin FileEntry.initialDeclarations preserve=yes
    //##end FileEntry.initialDeclarations

    private Object m_boundObject = null;
    private String m_name = null;
    private Hashtable m_FileEntries = new Hashtable();

    /**
    Returns the file entry with the supplied name. If the entry is not
    found, a null is returned.
    
    @param name The file name to search for. This name must exist
    in the current directory.
    
    @return null if entry is not found or FileEntry if name is found.
    */
    public FileEntry getFileEntry(String name) {
    //##begin FileEntry::getFileEntry%33639B24006D.body preserve=yes
       return((FileEntry) m_FileEntries.get(name));
    //##end FileEntry::getFileEntry%33639B24006D.body

    }

    /**
    Adds a file entry to the FielEntry. Caller should ensure that the
    file entry represents a directory.
    */
    void addFileEntry(FileEntry aFileEntry) {
    //##begin FileEntry::addFileEntry%33639B310058.body preserve=yes
       m_FileEntries.put(aFileEntry.getBindingName() , aFileEntry);
    //##end FileEntry::addFileEntry%33639B310058.body

    }

    /**
    Binds a file entry to an object.
    */
    void setBoundObject(Object anObject) {
    //##begin FileEntry::setBoundObject%3363A164029F.body preserve=yes
    
       if (anObject == null) {
          throw new NullPointerException();
       }
       
       m_boundObject = anObject;
    //##end FileEntry::setBoundObject%3363A164029F.body

    }

    /**
    Returns the bound object (if any) of this file entry. A directory
    does not have bound objects.
    */
    public Object getBoundObject() {
    //##begin FileEntry::getBoundObject%3363948A00D1.body preserve=yes
       return(m_boundObject);
    //##end FileEntry::getBoundObject%3363948A00D1.body

    }

    /**
    Removes a file entry from the directory.
    */
    void removeFileEntry(String name) {
    //##begin FileEntry::removeFileEntry%3363A2260239.body preserve=yes
       m_FileEntries.remove(name);
    //##end FileEntry::removeFileEntry%3363A2260239.body

    }

    /**
    Returns true if the entry is a directory.
    */
    public boolean isDirectory() {
    //##begin FileEntry::isDirectory%3363AEA001EC.body preserve=yes
      
       if (m_boundObject == null) {
          return(true);
       }   
       else {
          return(false);
       }   
    //##end FileEntry::isDirectory%3363AEA001EC.body

    }

    /**
    Returns all file entries in the given FileEntry. If the entry has
    no entries, then a null is returned.
    
    
    */
    public FileEntry[] getFileEntries() {
    //##begin FileEntry::getFileEntries%3363B4D80079.body preserve=yes
    
       Enumeration  anEnum;       
       FileEntry[]  aFileEntryArray;
       int          i = 0;
       
       if (m_FileEntries.size() == 0) {
          return(null);
       }
              
       aFileEntryArray = new FileEntry[m_FileEntries.size()];
       anEnum          = m_FileEntries.elements();
              
       while(anEnum.hasMoreElements()) {
          aFileEntryArray[i] = (FileEntry) anEnum.nextElement();
          i++;
       }
       
       return(aFileEntryArray);
       
    //##end FileEntry::getFileEntries%3363B4D80079.body

    }

    /**
    Returns the binding name of the file entry.
    */
    public String getBindingName() {
    //##begin FileEntry::getBindingName%3363BA670364.body preserve=yes
       return(m_name);
    //##end FileEntry::getBindingName%3363BA670364.body

    }

    /**
    Construct a file entry with a given name.
    */
    FileEntry(String name) {
    //##begin FileEntry::FileEntry%3363BA7E033F.body preserve=yes
       m_name = name;
    //##end FileEntry::FileEntry%3363BA7E033F.body

    }

    //##begin FileEntry.additionalDeclarations preserve=yes
    //##end FileEntry.additionalDeclarations

}

