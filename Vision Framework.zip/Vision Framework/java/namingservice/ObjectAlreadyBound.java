//## //## Source file:  c:\dev\wip/COM/novusnet/vision/java/namingservice/ObjectAlreadyBound.java
//## //## Subsystem:  namingservice
//## //## Module: ObjectAlreadyBound

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public class ObjectAlreadyBound extends NamingException {
    //##begin ObjectAlreadyBound.initialDeclarations preserve=yes
    //##end ObjectAlreadyBound.initialDeclarations


    public ObjectAlreadyBound(String exceptionString) {
    //##begin ObjectAlreadyBound::ObjectAlreadyBound%33639145031D.body preserve=yes
       super(exceptionString);
    //##end ObjectAlreadyBound::ObjectAlreadyBound%33639145031D.body

    }

    //##begin ObjectAlreadyBound.additionalDeclarations preserve=yes
    //##end ObjectAlreadyBound.additionalDeclarations

}

