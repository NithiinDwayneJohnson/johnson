//## //## Source file:  c:\dev\wip/COM/novusnet/vision/java/namingservice/InvalidPathName.java
//## //## Subsystem:  namingservice
//## //## Module: InvalidPathName

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public class InvalidPathName extends NamingException {
    //##begin InvalidPathName.initialDeclarations preserve=yes
    //##end InvalidPathName.initialDeclarations


    public InvalidPathName(String exceptionString) {
    //##begin InvalidPathName::InvalidPathName%33638A0900DF.body preserve=yes
       super(exceptionString);
    //##end InvalidPathName::InvalidPathName%33638A0900DF.body

    }

    //##begin InvalidPathName.additionalDeclarations preserve=yes
    //##end InvalidPathName.additionalDeclarations

}

