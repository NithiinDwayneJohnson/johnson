//## //## Source file:  c:\dev\wip/COM/novusnet/vision/java/namingservice/ObjectNotFound.java
//## //## Subsystem:  namingservice
//## //## Module: ObjectNotFound

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package COM.novusnet.vision.java.namingservice;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public class ObjectNotFound extends NamingException {
    //##begin ObjectNotFound.initialDeclarations preserve=yes
    //##end ObjectNotFound.initialDeclarations


    public ObjectNotFound(String exceptionString) {
    //##begin ObjectNotFound::ObjectNotFound%336391540198.body preserve=yes
       super(exceptionString);
    //##end ObjectNotFound::ObjectNotFound%336391540198.body

    }

    //##begin ObjectNotFound.additionalDeclarations preserve=yes
    //##end ObjectNotFound.additionalDeclarations

}

