package COM.novusnet.vision.java.gui;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;


/**
 * BeanInfo for FormattedTextField.
 *
 */

public class FormattedTextFieldBeanInfo extends SimpleBeanInfo {

	/**
	 * Constructs a FormattedTextFieldBeanInfo object.
	 */
	public FormattedTextFieldBeanInfo() {
	}

	/**
	 * Gets a BeanInfo for the superclass of this bean.
	 * @return BeanInfo[] containing this bean's superclass BeanInfo
	 */
	public BeanInfo[] getAdditionalBeanInfo() {
		try {
            BeanInfo[] bi = new BeanInfo[1];
            bi[0] = Introspector.getBeanInfo(beanClass.getSuperclass());
            return bi;
		}
		catch (IntrospectionException e) { throw new Error(e.toString());}
	}


	/**
	 * Gets an image that may be used to visually represent this bean
	 * (in the toolbar, on a form, etc).
	 * @param iconKind the type of icon desired, one of: BeanInfo.ICON_MONO_16x16,
	 * BeanInfo.ICON_COLOR_16x16, BeanInfo.ICON_MONO_32x32, or BeanInfo.ICON_COLOR_32x32.
	 * @return an image for this bean, always color even if requested monochrome
	 * @see BeanInfo#ICON_MONO_16x16
	 * @see BeanInfo#ICON_COLOR_16x16
	 * @see BeanInfo#ICON_MONO_32x32
	 * @see BeanInfo#ICON_COLOR_32x32
	 */
	public java.awt.Image getIcon(int iconKind) {
		if (iconKind == BeanInfo.ICON_MONO_16x16 ||
			iconKind == BeanInfo.ICON_COLOR_16x16) {
			java.awt.Image img = loadImage("FormattedTextFieldC16.gif");
			return img;
		}

		if (iconKind == BeanInfo.ICON_MONO_32x32 ||
			iconKind == BeanInfo.ICON_COLOR_32x32) {
			java.awt.Image img = loadImage("FormattedTextFieldC32.gif");
			return img;
		}

		return null;
	}


	/**
	 * Returns desecriptions of this bean's properties.
	 */
	public PropertyDescriptor[] getPropertyDescriptors() {
		try{
		PropertyDescriptor mask = new PropertyDescriptor("mask", beanClass);
		mask.setBound(true);
		mask.setConstrained(false);
		mask.setDisplayName("Mask");

		PropertyDescriptor editFont = new PropertyDescriptor("editFont", beanClass);
		editFont.setBound(true);
		editFont.setConstrained(false);
		editFont.setDisplayName("Edit Font");

		PropertyDescriptor[] rv = {
			mask,
			editFont};
		return rv;
		} catch (IntrospectionException e) { throw new Error(e.toString()); }
	}

	private final static Class beanClass = FormattedTextField.class;

	}	//  end of class FormattedTextFieldBeanInfo
