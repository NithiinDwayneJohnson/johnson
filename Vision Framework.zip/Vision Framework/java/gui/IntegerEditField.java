package COM.novusnet.vision.java.gui;

import java.text.DecimalFormat;

/**
 * The IntegerEditField is a number field suitable for manipulating integer numbers.
 * The default format allows for negative numbers.
 */
public class IntegerEditField extends NumberEditField
{
   /**
    * Constructor that takes the number of columns to display
    * @param columns Number of columns to display.
    */
   public IntegerEditField(int columns)
   {
      super(columns);
   }

   /**
    * Default constructor.
    */
   public IntegerEditField()
   {      
      this(10);
   }

  protected DecimalFormat createEditFormatter()
   {
      DecimalFormat df = new DecimalFormat();
      df.setMaximumFractionDigits(0);
      return df;
   }

   /**
    * This method creates a decimal display formatter. Subclassers can override this method
    * to provide custom formatters (subclasses of DecimalFormat).
    */
   protected DecimalFormat createDisplayFormatter()
   {
      DecimalFormat df = new DecimalFormat();
      df.setMaximumFractionDigits(0);
      return df;
   }
}
