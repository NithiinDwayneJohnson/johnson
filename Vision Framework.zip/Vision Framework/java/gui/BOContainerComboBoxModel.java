/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      BOContainerComboBoxModel.java                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 May 27 at 10:33:45 GMT+00:00                       */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.businessobjects.BusinessObjectContainer;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       BOContainerComboBoxModel                                */
/**
 *  The BOContainerComboBoxModel is an Abstract Base class meant to be
 * extended for creation of a specific BOContainerComboBoxModel. It extends
 * AbstractListModel and implments ComboBoxModel. The getElementAt provides
 * default implementation which will give out the object. It is the Derived
 * classes responsibility to override it to extract meaningful information.
 * <p>
 *  Example usage:
 * <p>
 *  Available : BOContainer called StatementDates
 * <p>
 *  Aim : To create a StatementDatesComboBox
 * <p>
 *  public class StatementDatesComboBoxModel
 * <p>
 *     extends BOContainerComboBoxModel {
 * <p>
 *        public Object getElementAt( int index ) {
 * <p>
 *           StatementDate myDate =
 * <p>
 *  (StatementDates)super.getElementAt(index);
 * <p>
 *           return Convert.intoString( myDate.getStatementDate(),
 * <p>
 *  "yyyyMMdd")
 * <p>
 *  The way to use such a class would be:
 * <p>
 *  StatementDatesComboBox myComboBoxModel = new StatementDatesComboBox(
 * <p>
 *  myAccount.getStatementDates() );
 * <p>
 *  JComboBox aCB = new JComboBox( myComboBoxModel );
 */
/*======================================================================*/
public  class  BOContainerComboBoxModel  extends  AbstractListModel
                                      implements  ComboBoxModel
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin BOContainerComboBoxModel:Attributes preserve=yes

//##End   BOContainerComboBoxModel:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private Object                  selectedItem;
   private BusinessObjectContainer model;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  BOContainerComboBoxModel                         */
        /*                                                              */
        /**
         * @param       aModel:BusinessObjectContainer
         */
        /*==============================================================*/
   public    BOContainerComboBoxModel (
                                       BusinessObjectContainer  aModel
                                      )
   {
//##Begin BOContainerComboBoxModel:BOContainerComboBoxModel(BusinessObjectContainer) preserve=yes
      setModel( aModel );
//##End   BOContainerComboBoxModel:BOContainerComboBoxModel(BusinessObjectContainer)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getSize                                          */
        /*                                                              */
        /**
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getSize (
                        )
   {
//##Begin BOContainerComboBoxModel:getSize() preserve=yes
       if ( model != null ) {
          return model.getSize();
       } else {
          return 0;
       }
//##End   BOContainerComboBoxModel:getSize()
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin BOContainerComboBoxModel:printOut() preserve=yes

      try {
         System.out.println ("BOContainerComboBoxModel:");
         System.out.println ("   selectedItem: " + getSelectedItem ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   BOContainerComboBoxModel:printOut()
   }

        /*==============================================================*/
        /* OPERATION:  indexOf                                          */
        /*                                                              */
        /**
         * @param       anObject:Object
         * @return      :int -
         */
        /*==============================================================*/
   public  int  indexOf (
                         Object  anObject
                        )
   {
//##Begin BOContainerComboBoxModel:indexOf(Object) preserve=yes
      if ( model != null ) {
         return model.indexOf( anObject );
      } else {
         return -1;
      } 
//##End   BOContainerComboBoxModel:indexOf(Object)
   }

        /*==============================================================*/
        /* OPERATION:  getElementAt                                     */
        /*                                                              */
        /**
         * @param       anIndex:int
         * @return      :Object -
         */
        /*==============================================================*/
   public  Object  getElementAt (
                                 int  anIndex
                                )
   {
//##Begin BOContainerComboBoxModel:getElementAt(int) preserve=yes
      if ( model != null ) {
        /*==============================================================*/
        /* We can have 1 of the three types of BOs as our model.        */
        /* 1. BusinessObjectIndexedContainer                            */
        /* 2. BusinessObjectOrderedContainer or BusinessObjectLookupList*/  
        /* 3. BusinessObjectKeyedContainer                              */
        /*==============================================================*/

        return model.getElementAt( anIndex ); 

      } else {

         return null;

      }
//##End   BOContainerComboBoxModel:getElementAt(int)
   }

        /*==============================================================*/
        /* OPERATION:  getSelectedItem                                  */
        /*                                                              */
        /**
         * @return      :Object -
         */
        /*==============================================================*/
   public  Object  getSelectedItem (
                                   )
   {
//##Begin BOContainerComboBoxModel:getSelectedItem() preserve=yes

      return (selectedItem);

//##End   BOContainerComboBoxModel:getSelectedItem()
   }

        /*==============================================================*/
        /* OPERATION:  setSelectedItem                                  */
        /*                                                              */
        /**
         * @param       aValue:Object
         */
        /*==============================================================*/
   public  void  setSelectedItem (
                                  Object  aValue
                                 )
   {
//##Begin BOContainerComboBoxModel:setSelectedItem(Object) preserve=yes

      selectedItem = aValue;
      fireContentsChanged(this,-1,-1);

//##End   BOContainerComboBoxModel:setSelectedItem(Object)
   }

        /*==============================================================*/
        /* OPERATION:  getModel                                         */
        /*                                                              */
        /**
         * @return      :BusinessObjectContainer -
         */
        /*==============================================================*/
   public  BusinessObjectContainer  getModel (
                                             )
   {
//##Begin BOContainerComboBoxModel:getModel() preserve=yes

      return (model);

//##End   BOContainerComboBoxModel:getModel()
   }

        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * @param       aValue:BusinessObjectContainer
         */
        /*==============================================================*/
   public  void  setModel (
                           BusinessObjectContainer  aValue
                          )
   {
//##Begin BOContainerComboBoxModel:setModel(BusinessObjectContainer) preserve=yes

      model = aValue;

//##End   BOContainerComboBoxModel:setModel(BusinessObjectContainer)
   }

        /*==============================================================*/
        /* OPERATION:  getBusinessObjectAt                              */
        /*                                                              */
        /**
         * The items in a combobox are usually strings of some BO. This
         * method returns the actual BO at a given index.
         *  
         * @param       index:int
         * @return      :BusinessObject -
         */
        /*==============================================================*/
   public  BusinessObject  getBusinessObjectAt (
                                                int  index
                                               )
   {
//##Begin BOContainerComboBoxModel:getBusinessObjectAt(int) preserve=yes
      BusinessObjectContainer   boc  = getModel();      
      return (BusinessObject)boc.getElementAt(index);
//##End   BOContainerComboBoxModel:getBusinessObjectAt(int)
   }
}
