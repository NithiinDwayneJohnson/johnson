/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ChildWindowAction.java                                  */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 February 15 at 10:36:45 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.beans.*;
import java.lang.reflect.*;
import COM.novusnet.vision.java.utility.resourcehelpers.*;
import COM.novusnet.vision.java.utility.*;
// Readonly 
import COM.novusnet.vision.java.persistence.*;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ChildWindowAction                                       */
/**
 * A Child open action is a base class for child window actions. A subclass
 * of this class is normally attached to a button or a menu item which
 * triggers a child window open when cliked or selected. The user supplies
 * a class name for a form and a model. When the action performed method is
 * invoked, this class (or actually a subclass) creates an instance of a
 * child window an instance of the form and sets the model on the form.
 * <p>
 * The same instance can be attached to different components. Please refer
 * to AbstractAction and Action for more information on this powerful
 * feature of Swing.
 * <p>
 * It is important to note that when setting the model on the form,
 * introspection is used to find a set method that takes the model class as
 * an argument. If such a method is found, then it is invoked otherwise the
 * default FormComponent setModel is used.
 * <p>
 * If another open action is invoked while the child window is up, this
 * action simply resurfaces the exiting child. A subclass of this action
 * type should enable or disable the action based on the model contents.
 * Please note that this Action by default enables/disables itself if the
 * model is null.
 * <p>
 * On a model change, the new model is set on the open form if the
 * autoPassModelToOpenWindow is set. If autoDiscardWindowOnModelChange is
 * set, the window is discarded and the option takes precedence over the
 * autoPassModelToOpenWindow. The autoDiscardWindowOnModelChange
 * automatically discards the window without giving the window a chance of
 * rejecting the new model.
 * <p>
 * Most child windows have a set of actions (e.g Ok , Add cancel or Help).
 * There are a set of default actions provided by this class. The action
 * container is placed in the south end of the window. The default action
 * styles provided are, the add, change Ok , delete and cancel actions.
 * Very little management from the user is needed when the default actions
 * are used.
 * <p>
 *  A user can supply his/her own action container but must manage all
 * interactions with the buttons themselves (install listeners and so
 * forth).
 * <p>
 * The window by default automatically closes if the escape key is pressed
 * while the window has focus. the closeOnEscape attribute controls this
 * behavior.
 * <p>
 * When a window is created, its size is set to the preferred size of the
 * form and the button container. Hoever, the user can override the
 * preferred size by calling setFormPreferredSize(). The action will still
 * add the size of the buttons container to this new size.
 * <p>
 * Any system baseed KeyStrokes that are registered with the Application's
 * root pane are registered with each FormComponent that is poped up,
 * (in the actionPerformed method) provided that the form is an instance of
 * FormComponent. So AWT controls will not handle system based keyboard
 * events eg. F1, as expected.
 */
/*======================================================================*/
public  class  ChildWindowAction  extends  AbstractAction
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ChildWindowAction:Attributes preserve=yes
   boolean    createdActionContainer = false;
   Hashtable  actions;
   Method     setModelMethod = null;
   // Big todo. Use a stategy to encapsulate the differences between
   // and internal frame and a Window subclass.
//##End   ChildWindowAction:Attributes

    /*==================================================================*/
    /* Protected Attributes                                             */
    /*==================================================================*/
   protected           Container     window;

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private             boolean       autoResurfaceWindow            = true;
   private             boolean       autoPassModelToOpenWindow      = false;
   private             boolean       autoDiscardWindowOnModelChange = false;
   private             boolean       closeOnEscape                  = true;
   private             String        style                          = null;
   private             boolean       autoCenterWindow               = true;
   private             char          cancelButtonAccelCharacter     = DEFAULT_CANCEL_ACCEL_CHAR;
   private             char          OKButtonAccelCharacter         = DEFAULT_OK_ACCEL_CHAR;
   private             String        OKButtonText                   = DEFAULT_OK_TEXT;
   private             String        title                          = "Untitled";
   private             String        formClassName                  = null;
   private             Container     actionContainer                = null;
   private             Object        model                          = null;
   private             boolean       autoEnableOrDisableAction      = true;
   private             Component     form;
   private             int           initialPosition                = POSITION_CENTER;
   private             int           defaultOKAction                = OK_ACTION_STORE;
   private             String        cancelButtonText               = DEFAULT_CANCEL_TEXT;
   private             int           childType                      = CHILD_TYPE_INTERNAL_FRAME;
   private             Frame         frame;
   private             boolean       modal                          = true;
   private             Component     relativeComponent              = null;
   private             boolean       closable                       = true;
   private             boolean       resizable                      = true;
   private             boolean       maximizable                    = true;
   private             boolean       iconifiable                    = true;
   private             EventListener windowListener                 = null;
   private             Dimension     formPreferredSize              = null;
   private             Border        myBorder                       = null;
   private             JButton       myOKButton     				= null;
   private             JButton       myCancelButton 				= null;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_CENTER                          */
                /*                                                      */
                /**
                 * Center the child window.
                /*======================================================*/
   public static final int           POSITION_CENTER                = 0;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_NORTHWEST                       */
                /*                                                      */
                /**
                 * Position the child at the "NorthWest" corner.
                /*======================================================*/
   public static final int           POSITION_NORTHWEST             = 1;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_SOUTHWEST                       */
                /*                                                      */
                /**
                 * Position the child at the "SouthWest" corner.
                /*======================================================*/
   public static final int           POSITION_SOUTHWEST             = 2;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_NORTHEAST                       */
                /*                                                      */
                /**
                 * Position the child at the "NorthEast" corner.
                /*======================================================*/
   public static final int           POSITION_NORTHEAST             = 3;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_SOUTHEAST                       */
                /*                                                      */
                /**
                 * Position the child at the "SouthEast" corner.
                /*======================================================*/
   public static final int           POSITION_SOUTHEAST             = 4;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_NORTH                           */
                /*                                                      */
                /**
                 * Position the child at the "North".
                /*======================================================*/
   public static final int           POSITION_NORTH                 = 5;

                /*======================================================*/
                /* ATTRIBUTE:  POSITION_SOUTH                           */
                /*                                                      */
                /**
                 * Position the child at the "South".
                /*======================================================*/
   public static final int           POSITION_SOUTH                 = 6;

                /*======================================================*/
                /* ATTRIBUTE:  ACTIONPANEL_STYLE_OKCANCEL               */
                /*                                                      */
                /**
                 * Creates a panel with an OK and Cancel buttons.
                /*======================================================*/
   public static       String        ACTIONPANEL_STYLE_OKCANCEL     = "OKCancelStyle";

                /*======================================================*/
                /* ATTRIBUTE:  ACTIONPANEL_STYLE_OK                     */
                /*                                                      */
                /**
                 * Creates a panel with an OK button.
                /*======================================================*/
   public static       String        ACTIONPANEL_STYLE_OK           = "OKStyle";

                /*======================================================*/
                /* ATTRIBUTE:  ACTIONPANEL_STYLE_CANCEL                 */
                /*                                                      */
                /**
                 * Creates a panel with a Cancel button.
                /*======================================================*/
   public static       String        ACTIONPANEL_STYLE_CANCEL       = "CancelStyle";
   public static       String        DEFAULT_CANCEL_TEXT;
   public static       String        DEFAULT_OK_TEXT;
   public static       String        DEFAULT_UNDO_SEND_TEXT;
   public static       String        DEFAULT_CHANGE_TEXT;
   public static       String        DEFAULT_DELETE_TEXT;
   public static       String        DEFAULT_ADD_TEXT;
   public static       String        DEFAULT_SEND_TEXT;
   public static       String        DEFAULT_UPDATE_TEXT;
   public static       String        DEFAULT_UNDO_TEXT;
   public static       char          DEFAULT_CANCEL_ACCEL_CHAR;
   public static       char          DEFAULT_OK_ACCEL_CHAR;
   public static       char          DEFAULT_CHANGE_ACCEL_CHAR;
   public static       char          DEFAULT_DELETE_ACCEL_CHAR;
   public static       char          DEFAULT_ADD_ACCEL_CHAR;
   public static       char          DEFAULT_UPDATE_ACCEL_CHAR;
   public static       char          DEFAULT_UNDO_ACCEL_CHAR;

                /*======================================================*/
                /* ATTRIBUTE:  OK_ACTION_STORE                          */
                /*                                                      */
                /**
                 * This action stores the form thus validating and
                 * commiting the data to the database. This is the default
                 * action. To store and destory the form after OK is
                 * pressed you should call,
                 * setDefaultOKAction(DialogOpenAction.OK_ACTION_STORE |
                 * DialogOpenAction.OK_ACTION_DESTROY);
                 * <p>
                 * The above combination is the default.
                /*======================================================*/
   public static       int           OK_ACTION_STORE                = 1;

                /*======================================================*/
                /* ATTRIBUTE:  OK_ACTION_VALIDATE                       */
                /*                                                      */
                /**
                 * This action validates the form by calling prepareStore()
                 * on the form.
                /*======================================================*/
   public static       int           OK_ACTION_VALIDATE             = 2;

                /*======================================================*/
                /* ATTRIBUTE:  OK_ACTION_DESTROY                        */
                /*                                                      */
                /**
                 * This action causes the form to be destoryed after either
                 * the store or validate were processed. This is the
                 * default action.
                /*======================================================*/
   public static       int           OK_ACTION_DESTROY              = 4;

                /*======================================================*/
                /* ATTRIBUTE:  OK_ACTION_HIDE                           */
                /*                                                      */
                /**
                 * This action causes the form to be hidden after a store
                 * or validation.
                /*======================================================*/
   public static       int           OK_ACTION_HIDE                 = 8;

                /*======================================================*/
                /* ATTRIBUTE:  OK_ACTION_KEEPUP                         */
                /*                                                      */
                /**
                 * This action causes the form to be left event after a
                 * store or validation.
                /*======================================================*/
   public static       int           OK_ACTION_KEEPUP               = 16;
   public static final int           CHILD_TYPE_DIALOG              = 1;
   public static final int           CHILD_TYPE_INTERNAL_FRAME      = 2;


                 /*======================================================*/
                /* ATTRIBUTE:  ACTION_ID_OK                             */
                /*                                                      */
                /**
                 * The ID for the OK action.
                /*======================================================*/
   public static final String        ACTION_ID_OK                   = "OK_ACTION";

                /*======================================================*/
                /* ATTRIBUTE:  ACTION_ID_CANCEL                         */
                /*                                                      */
                /**
                 * The ID for the cancel action.
                /*======================================================*/
   public static final String        ACTION_ID_CANCEL               = "CANCEL_ACTION";

                /*======================================================*/
                /* ATTRIBUTE:  ACTION_ID_DEFAULT                        */
                /*                                                      */
                /**
                 * The ID for the created default action.
                /*======================================================*/
   public static final String        ACTION_ID_DEFAULT              = "DEFAULT_ACTION";

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ChildWindowAction                                */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public    ChildWindowAction (
                               )
   {
//##Begin ChildWindowAction:ChildWindowAction() preserve=yes
      setModel(null);
      actions = new Hashtable();
//##End   ChildWindowAction:ChildWindowAction()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isAutoResurfaceWindow                            */
        /*                                                              */
        /**
         * This method returns the value of if set, the action causes the
         * existing window to resurface to the front. This attribute is set
         * to true by default.
         *
         * @return      :boolean -
         *                 The value of if set, the action causes the
         *                 existing window to resurface to the front. This
         *                 attribute is set to true by default.
         */
        /*==============================================================*/
   public  boolean  isAutoResurfaceWindow (
                                          )
   {
//##Begin ChildWindowAction:isAutoResurfaceWindow() preserve=no

      return (autoResurfaceWindow);

//##End   ChildWindowAction:isAutoResurfaceWindow()
   }

        /*==============================================================*/
        /* OPERATION:  isAutoPassModelToOpenWindow                      */
        /*                                                              */
        /**
         * This method returns the value of this option sets whether the
         * action automatically passes a new model to an already open
         * window. The default is no.
         *
         * @return      :boolean -
         *                 The value of this option sets whether the action
         *                 automatically passes a new model to an already
         *                 open window. The default is no.
         */
        /*==============================================================*/
   public  boolean  isAutoPassModelToOpenWindow (
                                                )
   {
//##Begin ChildWindowAction:isAutoPassModelToOpenWindow() preserve=no

      return (autoPassModelToOpenWindow);

//##End   ChildWindowAction:isAutoPassModelToOpenWindow()
   }

        /*==============================================================*/
        /* OPERATION:  isAutoDiscardWindowOnModelChange                 */
        /*                                                              */
        /**
         * This method returns the value of if set, the windows is
         * automatically discarded (if open) on a model change.
         *
         * @return      :boolean -
         *                 The value of if set, the windows is
         *                 automatically discarded (if open) on a model
         *                 change.
         */
        /*==============================================================*/
   public  boolean  isAutoDiscardWindowOnModelChange (
                                                     )
   {
//##Begin ChildWindowAction:isAutoDiscardWindowOnModelChange() preserve=no

      return (autoDiscardWindowOnModelChange);

//##End   ChildWindowAction:isAutoDiscardWindowOnModelChange()
   }

        /*==============================================================*/
        /* OPERATION:  isCloseOnEscape                                  */
        /*                                                              */
        /**
         * This method returns the value of automatically closes the window
         * is the use hits the escape key.
         *
         * @return      :boolean -
         *                 The value of automatically closes the window is
         *                 the use hits the escape key.
         */
        /*==============================================================*/
   public  boolean  isCloseOnEscape (
                                    )
   {
//##Begin ChildWindowAction:isCloseOnEscape() preserve=no

      return (closeOnEscape);

//##End   ChildWindowAction:isCloseOnEscape()
   }

        /*==============================================================*/
        /* OPERATION:  getStyle                                         */
        /*                                                              */
        /**
         * This method returns the value of the default action panel style.
         *
         * @return      :String -
         *                 The value of the default action panel style.
         */
        /*==============================================================*/
   public  String  getStyle (
                            )
   {
//##Begin ChildWindowAction:getStyle() preserve=no

      return (style);

//##End   ChildWindowAction:getStyle()
   }

        /*==============================================================*/
        /* OPERATION:  isAutoCenterWindow                               */
        /*                                                              */
        /**
         * This method returns the value of automaticaly centers the window
         * when the window is created. The window size by default is the
         * preferred size of the form.
         *
         * @return      :boolean -
         *                 The value of automaticaly centers the window
         *                 when the window is created. The window size by
         *                 default is the preferred size of the form.
         */
        /*==============================================================*/
   public  boolean  isAutoCenterWindow (
                                       )
   {
//##Begin ChildWindowAction:isAutoCenterWindow() preserve=no

      return (autoCenterWindow);

//##End   ChildWindowAction:isAutoCenterWindow()
   }

        /*==============================================================*/
        /* OPERATION:  getCancelButtonAccelCharacter                    */
        /*                                                              */
        /**
         * This method returns the value of accelarator character for the
         * cancel button.
         *
         * @return      :char -
         *                 The value of accelarator character for the
         *                 cancel button.
         */
        /*==============================================================*/
   public  char  getCancelButtonAccelCharacter (
                                               )
   {
//##Begin ChildWindowAction:getCancelButtonAccelCharacter() preserve=no

      return (cancelButtonAccelCharacter);

//##End   ChildWindowAction:getCancelButtonAccelCharacter()
   }

        /*==============================================================*/
        /* OPERATION:  getOKButtonAccelCharacter                        */
        /*                                                              */
        /**
         * This method returns the value of accelarator character for the
         * OK button.
         *
         * @return      :char -
         *                 The value of accelarator character for the OK
         *                 button.
         */
        /*==============================================================*/
   public  char  getOKButtonAccelCharacter (
                                           )
   {
//##Begin ChildWindowAction:getOKButtonAccelCharacter() preserve=no

      return (OKButtonAccelCharacter);

//##End   ChildWindowAction:getOKButtonAccelCharacter()
   }

        /*==============================================================*/
        /* OPERATION:  getOKButtonText                                  */
        /*                                                              */
        /**
         * This method returns the value of the "OKButtonText" attribute.
         *
         * @return      :String -
         *                 The value of the "OKButtonText" attribute.
         */
        /*==============================================================*/
   public  String  getOKButtonText (
                                   )
   {
//##Begin ChildWindowAction:getOKButtonText() preserve=no

      return (OKButtonText);

//##End   ChildWindowAction:getOKButtonText()
   }

        /*==============================================================*/
        /* OPERATION:  getTitle                                         */
        /*                                                              */
        /**
         * This method returns the value of the title to be set on the
         * window.
         *
         * @return      :String -
         *                 The value of the title to be set on the window.
         */
        /*==============================================================*/
   public  String  getTitle (
                            )
   {
//##Begin ChildWindowAction:getTitle() preserve=no

      return (title);

//##End   ChildWindowAction:getTitle()
   }

        /*==============================================================*/
        /* OPERATION:  getFormClassName                                 */
        /*                                                              */
        /**
         * This method returns the value of the class name is used to
         * instantiate the proper form when the action is performed.
         *
         * @return      :String -
         *                 The value of the class name is used to
         *                 instantiate the proper form when the action is
         *                 performed.
         */
        /*==============================================================*/
   public  String  getFormClassName (
                                    )
   {
//##Begin ChildWindowAction:getFormClassName() preserve=no

      return (formClassName);

//##End   ChildWindowAction:getFormClassName()
   }

        /*==============================================================*/
        /* OPERATION:  getActionContainer                               */
        /*                                                              */
        /**
         * This method returns the value of the action container that will
         * be placed at the bottom of the dialog. The usually is and
         * OK/cancel or a help button panel.
         *
         * @return      :Container -
         *                 The value of the action container that will be
         *                 placed at the bottom of the dialog. The usually
         *                 is and OK/cancel or a help button panel.
         */
        /*==============================================================*/
   public  Container  getActionContainer (
                                         )
   {
//##Begin ChildWindowAction:getActionContainer() preserve=no

      return (actionContainer);

//##End   ChildWindowAction:getActionContainer()
   }

        /*==============================================================*/
        /* OPERATION:  getModel                                         */
        /*                                                              */
        /**
         * This method returns the value of the model to set on the form. A
         * user can set a model and later create a model derived from this
         * model which gets set on the form. For example, an action
         * displays a list of orders of an account, the form takes a list
         * of orders. Setting the orders object too early on the action
         * will have a serious performance impact. Rather, the user can set
         * the root object account as a model on the action and later
         * resolve the orders object just in time for display.
         *
         * @return      :Object -
         *                 The value of the model to set on the form. A
         *                 user can set a model and later create a model
         *                 derived from this model which gets set on the
         *                 form. For example, an action displays a list of
         *                 orders of an account, the form takes a list of
         *                 orders. Setting the orders object too early on
         *                 the action will have a serious performance
         *                 impact. Rather, the user can set the root object
         *                 account as a model on the action and later
         *                 resolve the orders object just in time for
         *                 display.
         */
        /*==============================================================*/
   public  Object  getModel (
                            )
   {
//##Begin ChildWindowAction:getModel() preserve=no

      return (model);

//##End   ChildWindowAction:getModel()
   }

        /*==============================================================*/
        /* OPERATION:  isAutoEnableOrDisableAction                      */
        /*                                                              */
        /**
         * This method returns the value of disables the action if the
         * model set is null.
         *
         * @return      :boolean -
         *                 The value of disables the action if the model
         *                 set is null.
         */
        /*==============================================================*/
   public  boolean  isAutoEnableOrDisableAction (
                                                )
   {
//##Begin ChildWindowAction:isAutoEnableOrDisableAction() preserve=no

      return (autoEnableOrDisableAction);

//##End   ChildWindowAction:isAutoEnableOrDisableAction()
   }

        /*==============================================================*/
        /* OPERATION:  getForm                                          */
        /*                                                              */
        /**
         * This method returns the value of this attribute represents the
         * form currently active. This attribute is null until the form is
         * loaded by an actionPerformed.
         *
         * @return      :Component -
         *                 The value of this attribute represents the form
         *                 currently active. This attribute is null until
         *                 the form is loaded by an actionPerformed.
         */
        /*==============================================================*/
   public  Component  getForm (
                              )
   {
//##Begin ChildWindowAction:getForm() preserve=no

      return (form);

//##End   ChildWindowAction:getForm()
   }

        /*==============================================================*/
        /* OPERATION:  getInitialPosition                               */
        /*                                                              */
        /**
         * This method returns the value of the position property controls
         * the placement of the child window within the desktop pane. The
         * default position centers the child window within its parent.
         *
         * @return      :int -
         *                 The value of the position property controls the
         *                 placement of the child window within the desktop
         *                 pane. The default position centers the child
         *                 window within its parent.
         */
        /*==============================================================*/
   public  int  getInitialPosition (
                                   )
   {
//##Begin ChildWindowAction:getInitialPosition() preserve=no

      return (initialPosition);

//##End   ChildWindowAction:getInitialPosition()
   }

        /*==============================================================*/
        /* OPERATION:  getDefaultOKAction                               */
        /*                                                              */
        /**
         * This method returns the value of the action that takes place
         * when the OK button is pressed. This action called
         * OKButtonPressed of the action.
         *
         * @return      :int -
         *                 The value of the action that takes place when
         *                 the OK button is pressed. This action called
         *                 OKButtonPressed of the action.
         */
        /*==============================================================*/
   public  int  getDefaultOKAction (
                                   )
   {
//##Begin ChildWindowAction:getDefaultOKAction() preserve=no

      return (defaultOKAction);

//##End   ChildWindowAction:getDefaultOKAction()
   }

        /*==============================================================*/
        /* OPERATION:  getCancelButtonText                              */
        /*                                                              */
        /**
         * This method returns the value of the text that will be set on
         * the cancel button.
         *
         * @return      :String -
         *                 The value of the text that will be set on the
         *                 cancel button.
         */
        /*==============================================================*/
   public  String  getCancelButtonText (
                                       )
   {
//##Begin ChildWindowAction:getCancelButtonText() preserve=no

      return (cancelButtonText);

//##End   ChildWindowAction:getCancelButtonText()
   }

        /*==============================================================*/
        /* OPERATION:  getChildType                                     */
        /*                                                              */
        /**
         * This method returns the value of the type of the child window to
         * be created. This can be a dialog or an internal frame.
         *
         * @return      :int -
         *                 The value of the type of the child window to be
         *                 created. This can be a dialog or an internal
         *                 frame.
         */
        /*==============================================================*/
   public  int  getChildType (
                             )
   {
//##Begin ChildWindowAction:getChildType() preserve=no

      return (childType);

//##End   ChildWindowAction:getChildType()
   }

        /*==============================================================*/
        /* OPERATION:  getFrame                                         */
        /*                                                              */
        /**
         * This method returns the value of the frame of the child. This is
         * resolved using the relativeComponent set on the action.
         *
         * @return      :Frame -
         *                 The value of the frame of the child. This is
         *                 resolved using the relativeComponent set on the
         *                 action.
         */
        /*==============================================================*/
   public  Frame  getFrame (
                           )
   {
//##Begin ChildWindowAction:getFrame() preserve=yes
      if (getRelativeComponent() instanceof Frame) {
	 return (Frame)getRelativeComponent();
      }

      Frame myFrame =  (Frame)SwingUtilities.getAncestorOfClass(Frame.class, getRelativeComponent());

      if (myFrame == null) {
	 myFrame = ExtendedDialog.getRootFrame();
      }

      return myFrame;
//##End   ChildWindowAction:getFrame()
   }

        /*==============================================================*/
        /* OPERATION:  isModal                                          */
        /*                                                              */
        /**
         * This method returns the value of this flag affects children of
         * the dialog type. It causes the child to be modal.
         *
         * @return      :boolean -
         *                 The value of this flag affects children of the
         *                 dialog type. It causes the child to be modal.
         */
        /*==============================================================*/
   public  boolean  isModal (
                            )
   {
//##Begin ChildWindowAction:isModal() preserve=no

      return (modal);

//##End   ChildWindowAction:isModal()
   }

        /*==============================================================*/
        /* OPERATION:  getRelativeComponent                             */
        /*                                                              */
        /**
         * This method returns the value of the relative component is used
         * to determine the frame of the window. Many times when an action
         * is being created a frame is not available. If the relative
         * component is null, the global frame set in the ExtendedDialog is
         * used as a frame.
         *
         * @return      :Component -
         *                 The value of the relative component is used to
         *                 determine the frame of the window. Many times
         *                 when an action is being created a frame is not
         *                 available. If the relative component is null,
         *                 the global frame set in the ExtendedDialog is
         *                 used as a frame.
         */
        /*==============================================================*/
   public  Component  getRelativeComponent (
                                           )
   {
//##Begin ChildWindowAction:getRelativeComponent() preserve=no

      return (relativeComponent);

//##End   ChildWindowAction:getRelativeComponent()
   }

        /*==============================================================*/
        /* OPERATION:  isClosable                                       */
        /*                                                              */
        /**
         * This method returns the value of a flag to indicate whenther the
         * internal frame is closeable. The default is true. This flag does
         * not apply o children of the dialog type.
         *
         * @return      :boolean -
         *                 The value of a flag to indicate whenther the
         *                 internal frame is closeable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  boolean  isClosable (
                               )
   {
//##Begin ChildWindowAction:isClosable() preserve=no

      return (closable);

//##End   ChildWindowAction:isClosable()
   }

        /*==============================================================*/
        /* OPERATION:  isResizable                                      */
        /*                                                              */
        /**
         * This method returns the value of a flag to indicate whenther the
         * internal frame is resizable. The default is true. This flag does
         * not apply o children of the dialog type.
         *
         * @return      :boolean -
         *                 The value of a flag to indicate whenther the
         *                 internal frame is resizable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  boolean  isResizable (
                                )
   {
//##Begin ChildWindowAction:isResizable() preserve=no

      return (resizable);

//##End   ChildWindowAction:isResizable()
   }

        /*==============================================================*/
        /* OPERATION:  isMaximizable                                    */
        /*                                                              */
        /**
         * This method returns the value of a flag to indicate whenther the
         * internal frame is maximizable. The default is true. This flag
         * does not apply o children of the dialog type.
         *
         * @return      :boolean -
         *                 The value of a flag to indicate whenther the
         *                 internal frame is maximizable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  boolean  isMaximizable (
                                  )
   {
//##Begin ChildWindowAction:isMaximizable() preserve=no

      return (maximizable);

//##End   ChildWindowAction:isMaximizable()
   }

        /*==============================================================*/
        /* OPERATION:  isIconifiable                                    */
        /*                                                              */
        /**
         * This method returns the value of a flag to indicate whenther the
         * internal frame can be iconified. The default is true. This flag
         * does not apply o children of the dialog type.
         *
         * @return      :boolean -
         *                 The value of a flag to indicate whenther the
         *                 internal frame can be iconified. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  boolean  isIconifiable (
                                  )
   {
//##Begin ChildWindowAction:isIconifiable() preserve=no

      return (iconifiable);

//##End   ChildWindowAction:isIconifiable()
   }

        /*==============================================================*/
        /* OPERATION:  getFormPreferredSize                             */
        /*                                                              */
        /**
         * This method returns the value of the form preferred size. If
         * set, the action will ignore the preferred size of the form and
         * use this attribute.
         *
         * @return      :Dimension -
         *                 The value of the form preferred size. If set,
         *                 the action will ignore the preferred size of the
         *                 form and use this attribute.
         */
        /*==============================================================*/
   public  Dimension  getFormPreferredSize (
                                           )
   {
//##Begin ChildWindowAction:getFormPreferredSize() preserve=no

      return (formPreferredSize);

//##End   ChildWindowAction:getFormPreferredSize()
   }

        /*==============================================================*/
        /* OPERATION:  getWindow                                        */
        /*                                                              */
        /**
         * This method returns the value of the "window" attribute.
         *
         * @return      :Container -
         *                 The value of the "window" attribute.
         */
        /*==============================================================*/
   public  Container  getWindow (
                                )
   {
//##Begin ChildWindowAction:getWindow() preserve=no

      return (window);

//##End   ChildWindowAction:getWindow()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setAutoResurfaceWindow                           */
        /*                                                              */
        /**
         * This method sets the value of if set, the action causes the
         * existing window to resurface to the front. This attribute is set
         * to true by default.
         *
         * @param       aValue:boolean
         *                 The value of if set, the action causes the
         *                 existing window to resurface to the front. This
         *                 attribute is set to true by default.
         */
        /*==============================================================*/
   public  void  setAutoResurfaceWindow (
                                         boolean  aValue
                                        )
   {
//##Begin ChildWindowAction:setAutoResurfaceWindow(boolean) preserve=no

      autoResurfaceWindow = aValue;

//##End   ChildWindowAction:setAutoResurfaceWindow(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setAutoPassModelToOpenWindow                     */
        /*                                                              */
        /**
         * This method sets the value of this option sets whether the
         * action automatically passes a new model to an already open
         * window. The default is no.
         *
         * @param       aValue:boolean
         *                 The value of this option sets whether the action
         *                 automatically passes a new model to an already
         *                 open window. The default is no.
         */
        /*==============================================================*/
   public  void  setAutoPassModelToOpenWindow (
                                               boolean  aValue
                                              )
   {
//##Begin ChildWindowAction:setAutoPassModelToOpenWindow(boolean) preserve=no

      autoPassModelToOpenWindow = aValue;

//##End   ChildWindowAction:setAutoPassModelToOpenWindow(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setAutoDiscardWindowOnModelChange                */
        /*                                                              */
        /**
         * This method sets the value of if set, the windows is
         * automatically discarded (if open) on a model change.
         *
         * @param       aValue:boolean
         *                 The value of if set, the windows is
         *                 automatically discarded (if open) on a model
         *                 change.
         */
        /*==============================================================*/
   public  void  setAutoDiscardWindowOnModelChange (
                                                    boolean  aValue
                                                   )
   {
//##Begin ChildWindowAction:setAutoDiscardWindowOnModelChange(boolean) preserve=no

      autoDiscardWindowOnModelChange = aValue;

//##End   ChildWindowAction:setAutoDiscardWindowOnModelChange(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setCloseOnEscape                                 */
        /*                                                              */
        /**
         * This method sets the value of automatically closes the window is
         * the use hits the escape key.
         *
         * @param       aValue:boolean
         *                 The value of automatically closes the window is
         *                 the use hits the escape key.
         */
        /*==============================================================*/
   public  void  setCloseOnEscape (
                                   boolean  aValue
                                  )
   {
//##Begin ChildWindowAction:setCloseOnEscape(boolean) preserve=no

      closeOnEscape = aValue;

//##End   ChildWindowAction:setCloseOnEscape(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setStyle                                         */
        /*                                                              */
        /**
         * This method sets the value of the default action panel style.
         *
         * @param       aValue:String
         *                 The value of the default action panel style.
         */
        /*==============================================================*/
   public  void  setStyle (
                           String  aValue
                          )
   {
//##Begin ChildWindowAction:setStyle(String) preserve=yes

      if ( (aValue != null) &&
	   !aValue.equals(ACTIONPANEL_STYLE_OKCANCEL) &&
	   !aValue.equals(ACTIONPANEL_STYLE_CANCEL)   &&
	   !aValue.equals(ACTIONPANEL_STYLE_OK)) {
	 throw new IllegalArgumentException("Illegal styles for the action panel.");
      }

      style = aValue;
//##End   ChildWindowAction:setStyle(String)
   }

        /*==============================================================*/
        /* OPERATION:  setAutoCenterWindow                              */
        /*                                                              */
        /**
         * This method sets the value of automaticaly centers the window
         * when the window is created. The window size by default is the
         * preferred size of the form.
         *
         * @param       aValue:boolean
         *                 The value of automaticaly centers the window
         *                 when the window is created. The window size by
         *                 default is the preferred size of the form.
         */
        /*==============================================================*/
   public  void  setAutoCenterWindow (
                                      boolean  aValue
                                     )
   {
//##Begin ChildWindowAction:setAutoCenterWindow(boolean) preserve=no

      autoCenterWindow = aValue;

//##End   ChildWindowAction:setAutoCenterWindow(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setCancelButtonAccelCharacter                    */
        /*                                                              */
        /**
         * This method sets the value of accelarator character for the
         * cancel button.
         *
         * @param       aValue:char
         *                 The value of accelarator character for the
         *                 cancel button.
         */
        /*==============================================================*/
   public  void  setCancelButtonAccelCharacter (
                                                char  aValue
                                               )
   {
//##Begin ChildWindowAction:setCancelButtonAccelCharacter(char) preserve=no

      cancelButtonAccelCharacter = aValue;

//##End   ChildWindowAction:setCancelButtonAccelCharacter(char)
   }

        /*==============================================================*/
        /* OPERATION:  setOKButtonAccelCharacter                        */
        /*                                                              */
        /**
         * This method sets the value of accelarator character for the OK
         * button.
         *
         * @param       aValue:char
         *                 The value of accelarator character for the OK
         *                 button.
         */
        /*==============================================================*/
   public  void  setOKButtonAccelCharacter (
                                            char  aValue
                                           )
   {
//##Begin ChildWindowAction:setOKButtonAccelCharacter(char) preserve=no

      OKButtonAccelCharacter = aValue;

//##End   ChildWindowAction:setOKButtonAccelCharacter(char)
   }

        /*==============================================================*/
        /* OPERATION:  setOKButtonText                                  */
        /*                                                              */
        /**
         * This method sets the value of the "OKButtonText" attribute.
         *
         * @param       aValue:String
         *                 The value of the "OKButtonText" attribute.
         */
        /*==============================================================*/
   public  void  setOKButtonText (
                                  String  aValue
                                 )
   {
//##Begin ChildWindowAction:setOKButtonText(String) preserve=no

      OKButtonText = aValue;

//##End   ChildWindowAction:setOKButtonText(String)
   }

        /*==============================================================*/
        /* OPERATION:  setTitle                                         */
        /*                                                              */
        /**
         * This method sets the value of the title to be set on the window.
         *
         * @param       aValue:String
         *                 The value of the title to be set on the window.
         */
        /*==============================================================*/
   public  void  setTitle (
                           String  aValue
                          )
   {
//##Begin ChildWindowAction:setTitle(String) preserve=yes

      title = aValue;

      if (window == null) {
	 return;
      }

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 ExtendedDialog myDialog = (ExtendedDialog)getWindow();
	 myDialog.setTitle(title);
      }
      else {
	 ExtendedInternalFrame myFrame = (ExtendedInternalFrame)getWindow();
	 myFrame.setTitle(title);
      }
//##End   ChildWindowAction:setTitle(String)
   }

        /*==============================================================*/
        /* OPERATION:  setFormClassName                                 */
        /*                                                              */
        /**
         * This method sets the value of the class name is used to
         * instantiate the proper form when the action is performed.
         *
         * @param       aValue:String
         *                 The value of the class name is used to
         *                 instantiate the proper form when the action is
         *                 performed.
         */
        /*==============================================================*/
   public  void  setFormClassName (
                                   String  aValue
                                  )
   {
//##Begin ChildWindowAction:setFormClassName(String) preserve=no

      formClassName = aValue;

//##End   ChildWindowAction:setFormClassName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setActionContainer                               */
        /*                                                              */
        /**
         * This method sets the value of the action container that will be
         * placed at the bottom of the dialog. The usually is and OK/cancel
         * or a help button panel.
         *
         * @param       aValue:Container
         *                 The value of the action container that will be
         *                 placed at the bottom of the dialog. The usually
         *                 is and OK/cancel or a help button panel.
         */
        /*==============================================================*/
   public  void  setActionContainer (
                                     Container  aValue
                                    )
   {
//##Begin ChildWindowAction:setActionContainer(Container) preserve=no

      actionContainer = aValue;

//##End   ChildWindowAction:setActionContainer(Container)
   }

        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * This method sets the value of the model to set on the form. A
         * user can set a model and later create a model derived from this
         * model which gets set on the form. For example, an action
         * displays a list of orders of an account, the form takes a list
         * of orders. Setting the orders object too early on the action
         * will have a serious performance impact. Rather, the user can set
         * the root object account as a model on the action and later
         * resolve the orders object just in time for display.
         *
         * @param       aValue:Object
         *                 The value of the model to set on the form. A
         *                 user can set a model and later create a model
         *                 derived from this model which gets set on the
         *                 form. For example, an action displays a list of
         *                 orders of an account, the form takes a list of
         *                 orders. Setting the orders object too early on
         *                 the action will have a serious performance
         *                 impact. Rather, the user can set the root object
         *                 account as a model on the action and later
         *                 resolve the orders object just in time for
         *                 display.
         */
        /*==============================================================*/
   public  void  setModel (
                           Object  aValue
                          )
   {
//##Begin ChildWindowAction:setModel(Object) preserve=yes

      model = aValue;

      if (isAutoEnableOrDisableAction()) {
	 setEnabled ( !(model == null) );
      }

      if (isAutoDiscardWindowOnModelChange()) {
	 windowClosing();
      }
      else if ( (getWindow() != null )        &&
	   isAutoPassModelToOpenWindow() &&
	   (getForm() instanceof FormComponent) ) {
	setModelOnForm(model, (FormComponent)getForm());
      }

//##End   ChildWindowAction:setModel(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setAutoEnableOrDisableAction                     */
        /*                                                              */
        /**
         * This method sets the value of disables the action if the model
         * set is null.
         *
         * @param       aValue:boolean
         *                 The value of disables the action if the model
         *                 set is null.
         */
        /*==============================================================*/
   public  void  setAutoEnableOrDisableAction (
                                               boolean  aValue
                                              )
   {
//##Begin ChildWindowAction:setAutoEnableOrDisableAction(boolean) preserve=no

      autoEnableOrDisableAction = aValue;

//##End   ChildWindowAction:setAutoEnableOrDisableAction(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setForm                                          */
        /*                                                              */
        /**
         * This method sets the value of this attribute represents the form
         * currently active. This attribute is null until the form is
         * loaded by an actionPerformed.
         *
         * @param       aValue:Component
         *                 The value of this attribute represents the form
         *                 currently active. This attribute is null until
         *                 the form is loaded by an actionPerformed.
         */
        /*==============================================================*/
   protected  void  setForm (
                             Component  aValue
                            )
   {
//##Begin ChildWindowAction:setForm(Component) preserve=no

      form = aValue;

//##End   ChildWindowAction:setForm(Component)
   }

        /*==============================================================*/
        /* OPERATION:  setInitialPosition                               */
        /*                                                              */
        /**
         * This method sets the value of the position property controls the
         * placement of the child window within the desktop pane. The
         * default position centers the child window within its parent.
         *
         * @param       aValue:int
         *                 The value of the position property controls the
         *                 placement of the child window within the desktop
         *                 pane. The default position centers the child
         *                 window within its parent.
         */
        /*==============================================================*/
   public  void  setInitialPosition (
                                     int  aValue
                                    )
   {
//##Begin ChildWindowAction:setInitialPosition(int) preserve=no

      initialPosition = aValue;

//##End   ChildWindowAction:setInitialPosition(int)
   }

        /*==============================================================*/
        /* OPERATION:  setDefaultOKAction                               */
        /*                                                              */
        /**
         * This method sets the value of the action that takes place when
         * the OK button is pressed. This action called OKButtonPressed of
         * the action.
         *
         * @param       aValue:int
         *                 The value of the action that takes place when
         *                 the OK button is pressed. This action called
         *                 OKButtonPressed of the action.
         */
        /*==============================================================*/
   public  void  setDefaultOKAction (
                                     int  aValue
                                    )
   {
//##Begin ChildWindowAction:setDefaultOKAction(int) preserve=no

      defaultOKAction = aValue;

//##End   ChildWindowAction:setDefaultOKAction(int)
   }

        /*==============================================================*/
        /* OPERATION:  addDefaultAction                                 */
        /*                                                              */
        /**
         * This method adds a created action as the default. This is used
         * for when ENTER is pressed.
         *
         * @param       action:AbstractAction
         *                 The action added to the hash of existing actions
         */
        /*==============================================================*/
   public void addDefaultAction(
				AbstractAction  action
				)
      {
	 actions.put(ACTION_ID_DEFAULT, action);
      }

        /*==============================================================*/
        /* OPERATION:  setCancelButtonText                              */
        /*                                                              */
        /**
         * This method sets the value of the text that will be set on the
         * cancel button.
         *
         * @param       aValue:String
         *                 The value of the text that will be set on the
         *                 cancel button.
         */
        /*==============================================================*/
   public  void  setCancelButtonText (
                                      String  aValue
                                     )
   {
//##Begin ChildWindowAction:setCancelButtonText(String) preserve=no

      cancelButtonText = aValue;

//##End   ChildWindowAction:setCancelButtonText(String)
   }

        /*==============================================================*/
        /* OPERATION:  setChildType                                     */
        /*                                                              */
        /**
         * This method sets the value of the type of the child window to be
         * created. This can be a dialog or an internal frame.
         *
         * @param       aValue:int
         *                 The value of the type of the child window to be
         *                 created. This can be a dialog or an internal
         *                 frame.
         */
        /*==============================================================*/
   public  void  setChildType (
                               int  aValue
                              )
   {
//##Begin ChildWindowAction:setChildType(int) preserve=no

      childType = aValue;

//##End   ChildWindowAction:setChildType(int)
   }

        /*==============================================================*/
        /* OPERATION:  setFrame                                         */
        /*                                                              */
        /**
         * This method sets the value of the frame of the child. This is
         * resolved using the relativeComponent set on the action.
         *
         * @param       aValue:Frame
         *                 The value of the frame of the child. This is
         *                 resolved using the relativeComponent set on the
         *                 action.
         */
        /*==============================================================*/
   private  void  setFrame (
                            Frame  aValue
                           )
   {
//##Begin ChildWindowAction:setFrame(Frame) preserve=no

      frame = aValue;

//##End   ChildWindowAction:setFrame(Frame)
   }

        /*==============================================================*/
        /* OPERATION:  setModal                                         */
        /*                                                              */
        /**
         * This method sets the value of this flag affects children of the
         * dialog type. It causes the child to be modal.
         *
         * @param       aValue:boolean
         *                 The value of this flag affects children of the
         *                 dialog type. It causes the child to be modal.
         */
        /*==============================================================*/
   public  void  setModal (
                           boolean  aValue
                          )
   {
//##Begin ChildWindowAction:setModal(boolean) preserve=no

      modal = aValue;

//##End   ChildWindowAction:setModal(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setRelativeComponent                             */
        /*                                                              */
        /**
         * This method sets the value of the relative component is used to
         * determine the frame of the window. Many times when an action is
         * being created a frame is not available. If the relative
         * component is null, the global frame set in the ExtendedDialog is
         * used as a frame.
         *
         * @param       aValue:Component
         *                 The value of the relative component is used to
         *                 determine the frame of the window. Many times
         *                 when an action is being created a frame is not
         *                 available. If the relative component is null,
         *                 the global frame set in the ExtendedDialog is
         *                 used as a frame.
         */
        /*==============================================================*/
   public  void  setRelativeComponent (
                                       Component  aValue
                                      )
   {
//##Begin ChildWindowAction:setRelativeComponent(Component) preserve=no

      relativeComponent = aValue;

//##End   ChildWindowAction:setRelativeComponent(Component)
   }

        /*==============================================================*/
        /* OPERATION:  setClosable                                      */
        /*                                                              */
        /**
         * This method sets the value of a flag to indicate whenther the
         * internal frame is closeable. The default is true. This flag does
         * not apply o children of the dialog type.
         *
         * @param       aValue:boolean
         *                 The value of a flag to indicate whenther the
         *                 internal frame is closeable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  void  setClosable (
                              boolean  aValue
                             )
   {
//##Begin ChildWindowAction:setClosable(boolean) preserve=no

      closable = aValue;

//##End   ChildWindowAction:setClosable(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setResizable                                     */
        /*                                                              */
        /**
         * This method sets the value of a flag to indicate whenther the
         * internal frame is resizable. The default is true. This flag does
         * not apply o children of the dialog type.
         *
         * @param       aValue:boolean
         *                 The value of a flag to indicate whenther the
         *                 internal frame is resizable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  void  setResizable (
                               boolean  aValue
                              )
   {
//##Begin ChildWindowAction:setResizable(boolean) preserve=no

      resizable = aValue;

//##End   ChildWindowAction:setResizable(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setMaximizable                                   */
        /*                                                              */
        /**
         * This method sets the value of a flag to indicate whenther the
         * internal frame is maximizable. The default is true. This flag
         * does not apply o children of the dialog type.
         *
         * @param       aValue:boolean
         *                 The value of a flag to indicate whenther the
         *                 internal frame is maximizable. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  void  setMaximizable (
                                 boolean  aValue
                                )
   {
//##Begin ChildWindowAction:setMaximizable(boolean) preserve=no

      maximizable = aValue;

//##End   ChildWindowAction:setMaximizable(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setIconifiable                                   */
        /*                                                              */
        /**
         * This method sets the value of a flag to indicate whenther the
         * internal frame can be iconified. The default is true. This flag
         * does not apply o children of the dialog type.
         *
         * @param       aValue:boolean
         *                 The value of a flag to indicate whenther the
         *                 internal frame can be iconified. The default is
         *                 true. This flag does not apply o children of the
         *                 dialog type.
         */
        /*==============================================================*/
   public  void  setIconifiable (
                                 boolean  aValue
                                )
   {
//##Begin ChildWindowAction:setIconifiable(boolean) preserve=no

      iconifiable = aValue;

//##End   ChildWindowAction:setIconifiable(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setFormPreferredSize                             */
        /*                                                              */
        /**
         * This method sets the value of the form preferred size. If set,
         * the action will ignore the preferred size of the form and use
         * this attribute.
         *
         * @param       aValue:Dimension
         *                 The value of the form preferred size. If set,
         *                 the action will ignore the preferred size of the
         *                 form and use this attribute.
         */
        /*==============================================================*/
   public  void  setFormPreferredSize (
                                       Dimension  aValue
                                      )
   {
//##Begin ChildWindowAction:setFormPreferredSize(Dimension) preserve=no

      formPreferredSize = aValue;

//##End   ChildWindowAction:setFormPreferredSize(Dimension)
   }

        /*==============================================================*/
        /* OPERATION:  setWindow                                        */
        /*                                                              */
        /**
         * This method sets the value of the "window" attribute.
         *
         * @param       aValue:Container
         *                 The value of the "window" attribute.
         */
        /*==============================================================*/
   protected  void  setWindow (
                               Container  aValue
                              )
   {
//##Begin ChildWindowAction:setWindow(Container) preserve=no

      window = aValue;

//##End   ChildWindowAction:setWindow(Container)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin ChildWindowAction:printOut() preserve=no

      try {
         System.out.println ("ChildWindowAction:");
         System.out.println ("   formPreferredSize: " + getFormPreferredSize ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   ChildWindowAction:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  resurfaceWindow                                  */
        /*                                                              */
        /**
         * Abstract method that must implement a window resurface logic.
         *
         */
        /*==============================================================*/
   public  void  resurfaceWindow (
                                 )
   {
//##Begin ChildWindowAction:resurfaceWindow() preserve=yes

      getWindow().setVisible(true);

      if (getChildType() == CHILD_TYPE_INTERNAL_FRAME) {
	 ((JInternalFrame)getWindow()).moveToFront();
	 try {
	    ((JInternalFrame)getWindow()).setSelected(true);
	 }
	 catch(PropertyVetoException e) {}
      }
      else {
	 ((Dialog)getWindow()).toFront();
      }

//##End   ChildWindowAction:resurfaceWindow()
   }

        /*==============================================================*/
        /* OPERATION:  actionPerformed                                  */
        /*                                                              */
        /**
         * @param       e:ActionEvent
         */
        /*==============================================================*/
   public  void  actionPerformed (
                                  ActionEvent  e
                                 )
   {
//##Begin ChildWindowAction:actionPerformed(ActionEvent) preserve=yes

      StatusBar  myStatusBar  = FormComponent.getStatusBar(relativeComponent);

      myStatusBar.setMinimum(0);
      myStatusBar.setMaximum(10);

      //=========================================================================
      // Must be an open request. Check for an existing one first and resurface
      //=========================================================================
      if ((getWindow() != null) && isAutoResurfaceWindow()) {
	 resurfaceWindow();
	 return;
      }

      try {
	 myStatusBar.setText("Creating window");
	 myStatusBar.setValue(myStatusBar.getValue() + 1);

	 //=========================================================================
	 // Need to create a new window
	 //=========================================================================
	 setWindow(createWindow());

	 Application myApplication = Application.getApplication(getFrame());
	 Component   myAncestor    = null;

	 if (myApplication != null) {
	    myAncestor = myApplication.getApplet();
	 }
	 else {
	    myAncestor = getFrame();
	 }

	 try {
	    myAncestor .setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	    myStatusBar.setText("Creating form");
	    myStatusBar.setValue(myStatusBar.getValue() + 1);
	    setForm( (Component)Class.forName (getFormClassName()).newInstance () );
	 }
	 catch(Throwable exception) {
	    ExceptionPane pane = new ExceptionPane(exception);
	    setForm( new JButton("Failed to load form with class:" + getFormClassName()));
	 }
	 finally {
	    myAncestor .setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	 }


	 //=========================================================================
	 // Any system baseed KeyStrokes that are registered with the Application's
	 // root pane are registered with each FormComponent that is poped up,
	 // (in the actionPerformed method) provided that the form is an instance of
	 // FormComponent. So AWT controls will not handle system based keyboard
	 // events eg. F1, as expected.
	 //=========================================================================
	 if (getForm() instanceof JComponent) {
	    myStatusBar.setText("Register keyboard Action(s)");
	    myStatusBar.setValue(myStatusBar.getValue() + 1);

	    if (myApplication != null) {
	       KeyStroke keyStroke[] =  myApplication.getRootPane().getRegisteredKeyStrokes();
	       for (int i = 0; i < keyStroke.length; i++) {
		  ((JComponent)getForm()).registerKeyboardAction(myApplication.getRootPane().getActionForKeyStroke(keyStroke[i]),
								 keyStroke[i],
								 myApplication.getRootPane().getConditionForKeyStroke(keyStroke[i]));
	       }
	    }
	 }

	 myStatusBar.setText("Creating buttons panel");
	 myStatusBar.setValue(myStatusBar.getValue() + 1);

	 setActionContainer(createActionContainer());


	 // For each FormComponent we wish to have the ENTER key default to either a registered
	 // default action, the default OK action, or the default CANCEL action.
	 // All Actions that override createActionContainer and do not use the default ok action
	 // will have to add their action to be considered the default. We wish to guard against the
	 // problem of there being a OK action and a CANCEL action but the only action that is registered
	 // is the CANCEL action, the OK SHOULD BE THE DEFAULT!
	 if (getAction(ACTION_ID_DEFAULT) != null) {
	    ((JComponent)getForm()).registerKeyboardAction(getAction(ACTION_ID_DEFAULT),
							   KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
							   JComponent.WHEN_IN_FOCUSED_WINDOW);
	 }
	 else  if (getAction(ACTION_ID_OK) != null) {
	    ((JComponent)getForm()).registerKeyboardAction(getAction(ACTION_ID_OK),
							   KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
							   JComponent.WHEN_IN_FOCUSED_WINDOW);
	 }
	 //For now we will not consider the CANCEL action a possible default
//  	 //For this screens that don't have an OK button, check to see if there is a CANCEL button.
//  	 else if (getAction(ACTION_ID_CANCEL) != null) {
//  	    ((JComponent)getForm()).registerKeyboardAction(getAction(ACTION_ID_CANCEL),
//  							   KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
//  							   JComponent.WHEN_IN_FOCUSED_WINDOW);
//  	 }

	 // Get all the buttons from the actionContainer. For each
	 // button that has a mnemonic set, make that a reserved char.
	 char reservedChars[]  = new char[255];
	 char reservedChars2[] = null;
	 int  k               = 0;

	 if (actionContainer != null) {
	    Component components[] = actionContainer.getComponents();
	    for (int i = 0; i < components.length; i++) {
	       if (components[i] instanceof AbstractButton) {
		  char myChar = (char)((AbstractButton)components[i]).getMnemonic();
		  if (myChar != '\0') {
		     reservedChars[k++] = myChar;
		  }
	       }
	    }
	 }

	 if (k != 0) {
	    reservedChars2 = new char[k];
	    System.arraycopy(reservedChars,
			     0,
			     reservedChars2,
			     0,
			     k);
	 }

	 if (getForm() instanceof JComponent) {
	    GUIToolKit.setMnemonics ((JComponent)getForm(), reservedChars2);
	    if ( myBorder!=null)
   	       ((JComponent)getForm()).setBorder( myBorder );
	 }

	 myStatusBar.setText("Putting all forms together.");
	 myStatusBar.setValue(myStatusBar.getValue() + 1);
	 addWindowComponents();

	 //============================================================
	 // set the model on the form if the form is a FormComponent
	 //============================================================
	 myStatusBar.setText("Creating and setting data on form.");
	 myStatusBar.setValue(myStatusBar.getValue() + 1);

	 if (getForm() instanceof FormComponent) {
	    setModelOnForm(resolveModel(getModel()), (FormComponent)getForm());
	 }

	 myStatusBar.setText("Showing window.");
	 myStatusBar.setValue(myStatusBar.getValue() + 1);

	 myStatusBar.setText("Ready");
	 myStatusBar.setValue(0);

	 if (getChildType() == CHILD_TYPE_DIALOG) {
	    windowListener = new WindowListener () {

	       public void windowOpened(WindowEvent e) {
		  ChildWindowAction.this.windowOpened();
	       }

	       public void windowClosed(WindowEvent e) {
		  ChildWindowAction.this.windowClosed();
	       }

	       public void windowClosing(WindowEvent e) {
		  ChildWindowAction.this.windowClosing();
	       }

	       public void windowIconified(WindowEvent e) {
		  ChildWindowAction.this.windowIconified();
	       }

	       public void windowDeiconified(WindowEvent e) {
		  ChildWindowAction.this.windowDeiconified();
	       }

	       public void windowActivated(WindowEvent e) {
		  ChildWindowAction.this.windowActivated();
	       }

	       public void windowDeactivated(WindowEvent e) {
		  ChildWindowAction.this.windowDeactivated();
	       }

	    };
       if(getWindow() != null) {
          ((JDialog)getWindow()).addWindowListener((WindowListener)windowListener);
          sizeAndShowWindow(getFrame().getSize());
       }
	 }
	 else {
	    windowListener = new InternalFrameListener () {
	       public void internalFrameOpened(InternalFrameEvent e) {
		  ChildWindowAction.this.windowOpened();
	       }

	       public void internalFrameClosed(InternalFrameEvent e) {
		  ChildWindowAction.this.windowClosed();
	       }

	       public void internalFrameClosing(InternalFrameEvent e) {
		  ChildWindowAction.this.windowClosing();
	       }

	       public void internalFrameIconified(InternalFrameEvent e) {
		  ChildWindowAction.this.windowIconified();
	       }

	       public void internalFrameDeiconified(InternalFrameEvent e) {
		  ChildWindowAction.this.windowDeiconified();
	       }

	       public void internalFrameActivated(InternalFrameEvent e) {
		  ChildWindowAction.this.windowActivated();
	       }

	       public void internalFrameDeactivated(InternalFrameEvent e) {
		  ChildWindowAction.this.windowDeactivated();
	       }
	    };
       if(getWindow() != null) {
          JInternalFrame myFrame = (JInternalFrame)getWindow();
          ((JDesktopPane)getRelativeComponent()).add(myFrame, JLayeredPane.DEFAULT_LAYER);
          myFrame.getContentPane().add(getForm());

          ((JInternalFrame)getWindow()).addInternalFrameListener((InternalFrameListener)windowListener);
          sizeAndShowWindow(((JDesktopPane)getRelativeComponent()).getSize());
          resurfaceWindow();
       }
	 }
      }
      catch(RuntimeException exception) {
	 setWindow(null);
	 throw exception;
      }
      finally {
	 myStatusBar.setText("Ready");
	 myStatusBar.setValue(0);
      }
//##End   ChildWindowAction:actionPerformed(ActionEvent)
   }

        /*==============================================================*/
        /* OPERATION:  closeWindow                                      */
        /*                                                              */
        /**
         * An explicit method to close the window.
         *
         */
        /*==============================================================*/
   public  void  closeWindow (
                             )
   {
//##Begin ChildWindowAction:closeWindow() preserve=yes

//##End   ChildWindowAction:closeWindow()
   }

        /*==============================================================*/
        /* OPERATION:  createDefaultCancelAction                        */
        /*                                                              */
        /**
         * Creates the default cancel action for standard dialogs.
         *
         * @return      :AbstractAction -
         */
        /*==============================================================*/
   public  AbstractAction  createDefaultCancelAction (
                                                     )
   {
//##Begin ChildWindowAction:createDefaultCancelAction() preserve=yes

      AbstractAction myAction =  new AbstractAction() {
	 public void actionPerformed(ActionEvent e) {
	    cancelButtonPressed();
	 }
      };

      actions.put(ACTION_ID_CANCEL, myAction);

      return myAction;
//##End   ChildWindowAction:createDefaultCancelAction()
   }

        /*==============================================================*/
        /* OPERATION:  windowClosed                                     */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowClosed (
                              )
   {
//##Begin ChildWindowAction:windowClosed() preserve=yes

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 ((Dialog)window).removeWindowListener((WindowListener)windowListener);
      }
      else {
	 ((JInternalFrame)window).removeInternalFrameListener((InternalFrameListener)windowListener);
	 ((JDesktopPane)getRelativeComponent()).remove(window);
      }

      // Help out the collecter. These don't need to stay around across invocations.
      setModelMethod         = null;
      actionContainer        = null;
      window                 = null;
      form                   = null;
      windowListener         = null;
      createdActionContainer = false;
//##End   ChildWindowAction:windowClosed()
   }

        /*==============================================================*/
        /* OPERATION:  windowOpened                                     */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowOpened (
                              )
   {
//##Begin ChildWindowAction:windowOpened() preserve=yes

//##End   ChildWindowAction:windowOpened()
   }

        /*==============================================================*/
        /* OPERATION:  windowClosing                                    */
        /*                                                              */
        /**
         * The default behavior calls dispose() on the internal frame.
         *
         */
        /*==============================================================*/
   public  void  windowClosing (
                               )
   {
//##Begin ChildWindowAction:windowClosing() preserve=yes

      // Give the guy a chance to remove listeners. By setting the UI to null.
      //
//       if (form != null && form instanceof FormComponent) {
// 	 ((FormComponent)form).setUI(null);
//       }
      // Removing the windowListener will help Garbage Collecting
      // The JDialog/JInternalFrame window after its closing. Mike P. 6/29/2001

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 if (getWindow() != null) {
            Dialog dialog = (Dialog)getWindow();
	    dialog.setVisible(false);
	    //BUG FIX : The model was not getting updated always when the window is closed. With the IBM JDK1.4 upgrade
	    //it appears that the message wasn't getting out about the window closing. Letting everyone
	    //know that the window lost focus updates attached listeners correctly.
	    dialog.dispatchEvent(new WindowEvent((Window)getWindow(), WindowEvent.WINDOW_LOST_FOCUS));;
	    dialog.dispose();
//            ((JDialog)dialog).removeWindowListener((WindowListener)windowListener);

	 }
      }
      else {
	 if (getWindow() != null) {
            JInternalFrame internalFrame = (JInternalFrame)getWindow();
	    internalFrame.setVisible(false);
	    internalFrame.dispose();
//            internalFrame.removeInternalFrameListener((InternalFrameListener)windowListener);

	 }
      }
      // Clear all the actions.
      actions.clear();
//##End   ChildWindowAction:windowClosing()
   }

        /*==============================================================*/
        /* OPERATION:  windowIconified                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowIconified (
                                 )
   {
//##Begin ChildWindowAction:windowIconified() preserve=yes

//##End   ChildWindowAction:windowIconified()
   }

        /*==============================================================*/
        /* OPERATION:  windowActivated                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowActivated (
                                 )
   {
//##Begin ChildWindowAction:windowActivated() preserve=yes

//##End   ChildWindowAction:windowActivated()
   }

        /*==============================================================*/
        /* OPERATION:  windowDeiconified                                */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowDeiconified (
                                   )
   {
//##Begin ChildWindowAction:windowDeiconified() preserve=yes

//##End   ChildWindowAction:windowDeiconified()
   }

        /*==============================================================*/
        /* OPERATION:  windowDeactivated                                */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  windowDeactivated (
                                   )
   {
//##Begin ChildWindowAction:windowDeactivated() preserve=yes

//##End   ChildWindowAction:windowDeactivated()
   }

        /*==============================================================*/
        /* OPERATION:  getAction                                        */
        /*                                                              */
        /**
         * Returns the action associated with a given action ID.
         *
         * @param       actionID:String
         * @return      :Action -
         */
        /*==============================================================*/
   public  Action  getAction (
                              String  actionID
                             )
   {
//##Begin ChildWindowAction:getAction(String) preserve=yes
      return (Action)(actions.get(actionID));
//##End   ChildWindowAction:getAction(String)
   }

   public void setAction (
			  AbstractAction action,
			  String actionID
			  )
      {
	 actions.put(actionID, action);
      }

    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  sizeAndShowWindow                                */
        /*                                                              */
        /**
         * A method that sizes and shows the windw. Subclassers can
         * override this method to alter the size of the window. The
         * default is to center the window.
         *
         * @param       parentDim:Dimension
         */
        /*==============================================================*/
   protected  void  sizeAndShowWindow (
                                       Dimension  parentDim
                                      )
   {
//##Begin ChildWindowAction:sizeAndShowWindow(Dimension) preserve=yes

      //==============================================
      // Size the child window.
      //==============================================
      Dimension dimWindow    = getFormPreferredSize();
      Dimension dimContainer = (actionContainer != null) ? actionContainer.getPreferredSize() :
                               new Dimension();

      getForm().invalidate();

      if (dimWindow != null) {
	 ((JComponent)getForm()).setPreferredSize(dimWindow);
      }

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 ((Dialog)window).pack();
      }
      else {
	 ((JInternalFrame)window).pack();
      }

      dimWindow = window.getSize();


      int width  = dimWindow.width;
      int height = dimWindow.height;

      Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();

      if (dimWindow.width  > screenDim.width ||
	  dimWindow.height > screenDim.height) {
	 dimWindow.width  = Math.min(dimWindow.width, screenDim.width);
	 dimWindow.height = Math.min(dimWindow.height, screenDim.height);
	 window.setSize(dimWindow.width, dimWindow.height);
      }

      int x = 0;
      int y = 0;

      switch(getInitialPosition()) {
	 case POSITION_CENTER:
	    x = ( parentDim.width  - width) / 2;
	    y = ( parentDim.height - height ) / 2 ;
	    break;

	 case POSITION_SOUTHWEST:
	    x = 0;
	    y = parentDim.height - height;
	    break;

	 case POSITION_NORTHWEST:
	    x = 0;
	    y = 0;
	    break;

	 case POSITION_NORTH:
	    x = ( parentDim.width  - width  ) / 2;
	    y = 0;
	    break;

	 case POSITION_SOUTH:
	    x = ( parentDim.width - width  ) / 2;
	    // When we have a Status Bar we do not want the component to overlap
	    // it. Rather the south most point should be the north most point of
	    // the status bar.
	    // This is probably true no matter what the initial position that we
	    // use however to minimise risk (I didn't have time to test all the
	    // other views) I will just change the POSITION_SOUTH settings.
	    StatusBar  myStatusBar  = FormComponent.getStatusBar(relativeComponent);
	    if (myStatusBar != null) {
	       parentDim.height  = parentDim.height - myStatusBar.getHeight();
	    }
	    y = parentDim.height - height;
	    break;

	 case POSITION_SOUTHEAST:
	    x = parentDim.width  - width;
	    y = parentDim.height - height;
	    break;

	 case POSITION_NORTHEAST:
	    x = parentDim.width  - width;
	    y = 0;
	    break;
      }

      window.setLocation( x , y);
      window.setVisible(true);
//##End   ChildWindowAction:sizeAndShowWindow(Dimension)
   }

        /*==============================================================*/
        /* OPERATION:  setModelOnForm                                   */
        /*                                                              */
        /**
         * Sets the model on the given form.
         *
         * @param       model:Object
         * @param       form:FormComponent
         */
        /*==============================================================*/
   protected  void  setModelOnForm (
                                    Object         model,
                                    FormComponent  form
                                   )
   {
//##Begin ChildWindowAction:setModelOnForm(Object,FormComponent) preserve=yes

      //===========================================================
      // Find a set model method that takes an instance of a class
      // with the same model. to do this, we use introspection.
      //===========================================================
      // commented out the setModelMethod == null because if a single action can
      // have multiple forms depending on the type of the model eg. cms\productviews\OptionsAction
      // then this setModelMethod will change as the model changes and the old code
      // would not reflect that change. It would try to call the setModelMethod for the form
      // used by the previous model.
      if (model != null) { //  && setModelMethod == null) {
         setModelMethod = form.findProperSetMethod( model.getClass(), "setModel" );
      }

      try {
	 if (setModelMethod != null) {
	    Object  args[] = { model };
	    setModelMethod.invoke(form , args);
	 }
	 //======================================
	 // Use the generic set model
	 //======================================
	 else {
	    form.setModel(model);
	 }
      }
      catch(InvocationTargetException e) {
	 Throwable throwable = e.getTargetException();
	 ExceptionPane pane = new ExceptionPane(throwable);
      }
      catch(Throwable exception) {
	 ExceptionPane pane = new ExceptionPane(exception);
      }
//##End   ChildWindowAction:setModelOnForm(Object,FormComponent)
   }

        /*==============================================================*/
        /* OPERATION:  createWindow                                     */
        /*                                                              */
        /**
         * @return      :Container -
         */
        /*==============================================================*/
   protected  Container  createWindow (
                                      )
   {
//##Begin ChildWindowAction:createWindow() preserve=yes
      if (getChildType() == CHILD_TYPE_DIALOG) {
	 ExtendedDialog myDialog = new ExtendedDialog(getFrame(),
						      getTitle(),
						      isModal());
	 myDialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	 return myDialog;
      }
      else {
	 ExtendedInternalFrame myFrame = new ExtendedInternalFrame();
	 myFrame.setTitle(getTitle());
	 myFrame.setIconifiable(iconifiable);
	 myFrame.setResizable(resizable);
	 myFrame.setMaximizable(maximizable);
	 myFrame.setClosable(closable);
	 myFrame.setDefaultCloseOperation(JInternalFrame.DO_NOTHING_ON_CLOSE);
	 return myFrame;
      }
//##End   ChildWindowAction:createWindow()
   }

        /*==============================================================*/
        /* OPERATION:  cancelButtonPressed                              */
        /*                                                              */
        /**
         * Called when the user presses the cancel button if one of the
         * standard styles of the action panel is used. The default
         * behavior is to hide and dispose the dialog.
         *
         */
        /*==============================================================*/
   protected  void  cancelButtonPressed (
                                        )
   {
//##Begin ChildWindowAction:cancelButtonPressed() preserve=yes
      if (getForm() instanceof FormComponent) {
	    ((FormComponent)getForm()).undo();
      }

      windowClosing();
//##End   ChildWindowAction:cancelButtonPressed()
   }

        /*==============================================================*/
        /* OPERATION:  OKButtonPressed                                  */
        /*                                                              */
        /**
         * Called when the user presses the OK button if one of the
         * standard styles of the action panel is used. The default
         * behavior is to hide and dispose the dialog. If the form in the
         * dialog is of a FormComponent class, then  a store() is called on
         * the form.
         *
         */
        /*==============================================================*/
   protected  void  OKButtonPressed (
                                    )
   {
//##Begin ChildWindowAction:OKButtonPressed() preserve=yes
      if ((getDefaultOKAction() & OK_ACTION_STORE) > 0) {

	 if (getForm() instanceof FormComponent) {
	    try {
	       getForm().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	       ((FormComponent)getForm()).store();
	    }
        // Readonly 
        catch ( ReadonlyException e ) {
            new ExceptionPane( e );
        }
	    catch(PrepareFormException e) {
	       if (!e.isNoGUI()) {
		  new ExceptionPane(e);
	       }
	       throw e;
	    }
	    catch(RuntimeException e) {
//	       new ExceptionPane(e);
	       throw e;
	    }
	    finally {
	       getForm().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	    }
	 }
      }
      else if ( (getDefaultOKAction() & OK_ACTION_VALIDATE) > 0) {
	 ((FormComponent)getForm()).prepareStore();
      }

      if ( (getDefaultOKAction() & OK_ACTION_DESTROY) > 0) {
	 windowClosing();
      }
      else if ( (getDefaultOKAction() & OK_ACTION_HIDE) > 0) {
	 getWindow().setVisible(false);
      }
      else if ( (getDefaultOKAction() & OK_ACTION_KEEPUP) > 0) {
      }

//##End   ChildWindowAction:OKButtonPressed()
   }


        /*==============================================================*/
        /* OPERATION:  createDefaultOKAction                            */
        /*                                                              */
        /**
         * Creates the default OK action for standard dialogs.
         *
         * @return      :AbstractAction -
         */
        /*==============================================================*/
   protected  AbstractAction  createDefaultOKAction (
                                                    )
   {
//##Begin ChildWindowAction:createDefaultOKAction() preserve=yes

      AbstractAction myAction =  new AbstractAction() {
	 public void actionPerformed(ActionEvent e) {
	    OKButtonPressed();
	 }
      };
      actions.put(ACTION_ID_OK, myAction);

      return myAction;
//##End   ChildWindowAction:createDefaultOKAction()
   }

        /*==============================================================*/
        /* OPERATION:  addWindowComponents                              */
        /*                                                              */
        /**
         * Adds the window components. These are the form which is placed
         * in center of the content pane and the optional actionPanel to be
         * placed at the south end of the content pane.
         *
         */
        /*==============================================================*/
   protected  void  addWindowComponents (
                                        )
   {
//##Begin ChildWindowAction:addWindowComponents() preserve=yes
      Container myContainer;

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 myContainer = ((JDialog)getWindow()).getContentPane();
      }
      else {
	 myContainer = ((JInternalFrame)getWindow()).getContentPane();
      }

      myContainer.setLayout(new BorderLayout());
      myContainer.add(getForm(), BorderLayout.CENTER);

      if (getActionContainer() != null) {
	 myContainer.add(getActionContainer(), BorderLayout.SOUTH);
      }

      if (getChildType() == CHILD_TYPE_DIALOG) {
	 ((JDialog)getWindow()).pack();
      }
      else {
	 ((JInternalFrame)getWindow()).pack();
      }
//##End   ChildWindowAction:addWindowComponents()
   }

        /*==============================================================*/
        /* OPERATION:  resolveModel                                     */
        /*                                                              */
        /**
         * This method is called just when a model is about to be set on
         * the form. The default impementation returns a model that was set
         * using setModel(). However, this method gives a developer the
         * opportunity to create a model from the model previously set.
         *
         * @param       model:Object
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  resolveModel (
                                    Object  model
                                   )
   {
//##Begin ChildWindowAction:resolveModel(Object) preserve=yes
      return model;
//##End   ChildWindowAction:resolveModel(Object)
   }

        /*==============================================================*/
        /* OPERATION:  createActionContainer                            */
        /*                                                              */
        /**
         * This method is provided for subclassers to create their own
         * custom action container. The default implementation creates
         * actions based on the specified  action styles.
         *
         * @return      :Container -
         */
        /*==============================================================*/
   protected  Container  createActionContainer (
                                               )
   {
//##Begin ChildWindowAction:createActionContainer() preserve=yes

      JPanel myPanel = new JPanel();

      createdActionContainer = true;

      if ( style != null ) {

	 FlowLayout     layout      = (FlowLayout)myPanel.getLayout();
	 myOKButton     			= null;
	 myCancelButton 			= null;
	 Action         al;

	 layout.setAlignment(FlowLayout.LEFT);

	 if (style.equals(ACTIONPANEL_STYLE_OK) ||
	     style.equals(ACTIONPANEL_STYLE_OKCANCEL)) {

	    myOKButton = new JButton(getOKButtonText());
	    al         = createDefaultOKAction();

	    if (al != null) {
	       myOKButton.addActionListener(al);
	       al.addPropertyChangeListener(new ActionChangedListener(al, myOKButton));
	    }

	    myOKButton.setMnemonic(getOKButtonAccelCharacter());
	 }

	 if (style.equals(ACTIONPANEL_STYLE_OKCANCEL) ||
	     style.equals(ACTIONPANEL_STYLE_CANCEL)) {

	    myCancelButton = new JButton(getCancelButtonText());

	    al = createDefaultCancelAction();

	    if (al != null) {
	       myCancelButton.addActionListener(al);
	       al.addPropertyChangeListener(new ActionChangedListener(al, myCancelButton));
	    }

	       myCancelButton.setMnemonic(getCancelButtonAccelCharacter());
	 }

	 if (myOKButton != null) {
	    myPanel.add(myOKButton);
	 }

	 if (myCancelButton != null) {
	    myPanel.add(myCancelButton);
	 }
      }

      //================================================================
      // If close on escape is set , then register the keyboard
      // hooks.
      //================================================================
      if (isCloseOnEscape() && (getForm() instanceof JComponent))  {

	 AbstractAction cancelAction = (AbstractAction)actions.get(ACTION_ID_CANCEL);

	 if (cancelAction == null) {
	    cancelAction = new AbstractAction() {
	       public void actionPerformed(ActionEvent e) {
		  windowClosing();
	       }
	    };
	 }

	 ((JComponent)getForm()).registerKeyboardAction(cancelAction,
							KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
							JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

	 myPanel.registerKeyboardAction(cancelAction,
					KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
					JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
      }

      return myPanel;
//##End   ChildWindowAction:createActionContainer()
   }

   public Border getBorder( )
   {
      return myBorder;
   }

   public void setBorder( Border b )
   {
      myBorder = b;
   }

   public JButton getOKButton()
   {
		return myOKButton;
   }
   
   public JButton getCancelButton()
   {
		return myCancelButton;
   }   

    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin ChildWindowAction:StaticInitializer preserve=yes
   static {
      ResourceResolver aResolver = new ResourceResolver ();
      aResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
      DEFAULT_CANCEL_TEXT        = aResolver.getStringResource("cancel", ChildWindowAction.class);
      DEFAULT_OK_TEXT            = aResolver.getStringResource("ok", ChildWindowAction.class);
      DEFAULT_CHANGE_TEXT        = aResolver.getStringResource("change", ChildWindowAction.class);
      DEFAULT_DELETE_TEXT        = aResolver.getStringResource("delete", ChildWindowAction.class);
      DEFAULT_ADD_TEXT           = aResolver.getStringResource("add", ChildWindowAction.class);
      DEFAULT_SEND_TEXT          = aResolver.getStringResource("send", ChildWindowAction.class);
      DEFAULT_UPDATE_TEXT        = aResolver.getStringResource("update", ChildWindowAction.class);
      DEFAULT_CANCEL_ACCEL_CHAR  = aResolver.getStringResource("cancelAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_OK_ACCEL_CHAR      = aResolver.getStringResource("OKAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_CHANGE_ACCEL_CHAR  = aResolver.getStringResource("changeAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_DELETE_ACCEL_CHAR  = aResolver.getStringResource("deleteAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_ADD_ACCEL_CHAR     = aResolver.getStringResource("addAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_UNDO_SEND_TEXT     = aResolver.getStringResource("undoSend", ChildWindowAction.class);
      DEFAULT_UNDO_TEXT          = aResolver.getStringResource("undo", ChildWindowAction.class);
      DEFAULT_UPDATE_ACCEL_CHAR  = aResolver.getStringResource("updateAccel", ChildWindowAction.class).charAt(0);
      DEFAULT_UNDO_ACCEL_CHAR    = aResolver.getStringResource("undoAccel", ChildWindowAction.class).charAt(0);
   }
//##End   ChildWindowAction:StaticInitializer

}
