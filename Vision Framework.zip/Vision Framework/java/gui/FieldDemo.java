package COM.novusnet.vision.java.gui;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class FieldDemo extends JPanel
{
   public FieldDemo()
   {
      setLayout(new GridLayout(1, 2 , 5 , 5));

      Locale.setDefault(Locale.US);
      JPanel panelAmerican = createFields();
      panelAmerican.setBorder(new TitledBorder("USA"));

      Locale.setDefault(Locale.FRANCE);
      JPanel panelFrench   = createFields();
      panelFrench.setBorder(new TitledBorder("France (Picture the labels in French)"));

      add(panelAmerican);
      add(panelFrench);
   }

   JPanel createFields()
   {
      JPanel              panel              = new JPanel();
      JLabel              percentFieldLabel  = new JLabel("Percent Field");
      PercentEditField    percentEditField   = new PercentEditField(10);
      JLabel              currencyFieldLabel = new JLabel("Currency Field");
      CurrencyEditField   currencyEditField  = new CurrencyEditField(10);
      JLabel              integerFieldLabel  = new JLabel("Integer");
      IntegerEditField    integerEditField   = new IntegerEditField(10);
      JLabel              decimalFieldLabel  = new JLabel("Decimal");
      DecimalEditField    decimalEditField   = new DecimalEditField(10);
      JLabel              socialEditFieldLabel  = new JLabel("Social security number");
      FormattedTextField  socialTextField    = new FormattedTextField();
      
      percentEditField.setMaxNumberOfFractionDigits(2);
      percentEditField.setMaxNumberOfDisplayFractionDigits(2);

      socialTextField.setMask("000-00-0000");

      panel.setLayout(new GridLayout(5, 2, 5, 5));
      panel.add(percentFieldLabel);
      panel.add(percentEditField);	      

      panel.add(currencyFieldLabel);
      panel.add(currencyEditField);	      

      panel.add(integerFieldLabel);	      
      panel.add(integerEditField);

      panel.add(decimalFieldLabel);	      
      panel.add(decimalEditField);

      panel.add(socialEditFieldLabel);	      
      panel.add(socialTextField);
      return panel;
   }

   public static void main( String[]  aArgs)
   {
      JFrame     myFrame   = new JFrame();
      Component component  = new FieldDemo();

      myFrame.setTitle("Field demo");
      myFrame.getContentPane().add("Center", component);
      myFrame.pack();
      myFrame.setVisible(true);

      myFrame.addWindowListener( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
	    System.exit(0);
	 }
      });
   }
}


