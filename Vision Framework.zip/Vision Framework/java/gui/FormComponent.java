/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      FormComponent.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 November 09 at 18:10:46 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextPane;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;
import javax.swing.plaf.ComponentUI;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ReadonlyException;
import COM.novusnet.vision.java.transactions.Current;
import COM.novusnet.vision.java.transactions.TransactionService;
import COM.novusnet.vision.java.utility.helpers.ClassHelper;
import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       FormComponent                                           */
/**
 * <h3>Forms</h3>
 * <p>A FormComponent is a class that provides services that are typically
 * used in a data entry application. Every form has a model. The content of
 * the form is usually a set of GUI components. Any changes made by a user
 * is reflected on the underlying model. When the user is done making
 * changes the form is saved. A form is typically made up of several
 * embedded forms. Each of the embedded forms have their own model. The
 * parent form is the root form. The root form primary responsibility is to
 * set the appropriate model on the children. The root model main roles
 * are: </p>
 * <p>
 * <ol>
 * <p>
 *     <li>Have enough information to populate the child forms.</li>
 * <p>
 *     <li>Update its model based on changes being made to child
 * <p>
 *         models.</li>
 * <p>
 *     <li>Validation</li>
 * <p>
 *     <li>Store the information to the database</li>
 * <p>
 * </ol>
 * <p>In a typical database application, a model of some sort is populated
 * from a database. The user is then allowed to modify some portion of the
 * model. We will call this model, the main database model. A form is a
 * view to a subset of data in the main model. The form model is rarely if
 * ever (unless read-only)&nbsp; the same as the main model. A client
 * typically constructs the destructive form model from a subset of the
 * main model and assigns the model to the form.&nbsp; Any changes made by
 * the form are not reflected by the main model until the form is saved.
 * The model supplied to the form is a very important model. Its main roles
 * are: <br>
 * <p>
 * &nbsp; </p>
 * <p>
 * <ol>
 * <p>
 *     <li>Ensures that all the data needed to satisfy the task at hand is
 * collected. This can be done at the pre_store of the root model. These
 * validations ensure that attributes needed to complete the task at hand
 * are supplied or all constraints have been checked. Please note that all
 * field validation is typically done at the GUI component level.</li>
 * <p>
 *     <li>It encapsulates the task at hand in a reusable fashion.</li>
 * <p>
 *     <li>It ensures that all the BO's that need to be updated are
 * updated. This is typically done at the pre-store level. All changes by
 * the root model itself or any of its submodels are applied to the main
 * database model. A transaction should be started for this. For this to
 * successful , the root model typically contains a reference to some mail
 * model. In order for this to work properly, all views and models of the
 * root form must stay in sync. Please refer to the
 * <ahref="#DataComponentController">DataComponentController</a> section
 * for more information on this.</li>
 * <p>
 * </ol>
 * <p>
 * <h4>The store process</h4>
 * <p>This section describes how a form is stored. A Form is stored by
 * storing is model. The process can be broken down into these steps: </p>
 * <p>
 * <ol>
 * <p>
 *     <li><a href="#Form level validation">Validate</a> the form (and its
 * sub forms) in preparation for a store. The prepareStore() method is
 * invoked on the form and its sub forms.</li>
 * <p>
 *     <li>Start a transaction</li>
 * <p>
 *     <li>Store the root form model. We simply obtain a reference to the
 * model of the the form at which the store() was directed and store
 * it.</li>
 * <p>
 *     <li>End the transaction</li>
 * <p>
 * </ol>
 * <p>The FormComponent has a store method that automatically performs
 * these steps. </p>
 * <p>
 * <h4>Form and model validation</h4>
 * <p>Many levels of validations are typically needed by an application.
 * These are broken down into two main areas: </p>
 * <p>
 * <ol>
 * <p>
 *     <li>GUI level validation</li>
 * <p>
 *     <li>Model level assertions. The term assertion is used because this
 * step is optional but highly recommended. In order to avoid duplicate
 * validation logic at the GUI and model level. Please refer to the book
 * <i>Object Oriented Analysis and Design by Betrand Meyers </i>for more
 * information on design by contract.</li>
 * <p>
 * </ol>
 * <p>
 * <h5>GUI level validation</h5>
 * <p>This level can be further broken down into two sections: </p>
 * <p>
 * <ol>
 * <p>
 *     <li><i>Field level validation</i>. Any data entered by the user
 * should be validated against the constraints imposed by the model. The
 * model imposes these constraints in the documentation section for its
 * properties. This level of validation is best done while the user is
 * entering data. However, not all field level validation can be done at
 * this stage.</li>
 * <p>
 *     <li><a name="Form level validation"></a><i>Form level validation.
 * </i>This level of validation is triggered just before a form (and its
 * sub forms) is about to be stored. Here a form can ensure that all the
 * data that is needed by the model is available and correct. It also
 * allows a developer to prompt the user for more options and to make last
 * second changes. Any exception raised at this level stops the save
 * process. It is important to note that any piece of information needed by
 * the model is supplied otherwise the model will throw some form of an
 * assertion violation before being stored.</li>
 * <p>
 * </ol>
 * <p>
 * <h5>I18N support</h5>
 * <p>The FormComponent provides some helper methods to easily extract
 * resources from the resource files. It delegates most of the work to the
 * ResourceResolver. All gui packages typically share one resource file at
 * the package scope. The getStringResource() obtains a string resource
 * while the getAccelCharacter(0 obtains a character that can be used as an
 * accelerator key in a locale independent fashion. <br>
 * <p>
 * &nbsp; </p>
 * <p>
 * <h5>Undo facilities. TBD</h5>
 * <p>The FormComponent provides undo facilities that developers can
 * leverage.&nbsp; Undoable actions are recorded and stored in the form
 * component undo manager. An undoAll method on a FormComponent undoes all
 * changes made by a user. This method also recurses into all embedded form
 * components and calls the undoAll method.
 * <ahref="#DataComponentController">DataComponentControllers</a> are heavy
 * users of this interface. </p>
 */
/*======================================================================*/
public  class  FormComponent  extends  JPanel
                           implements  PropertyChangeListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin FormComponent:Attributes preserve=yes
   private Vector tabOrderVector = null;
//##End   FormComponent:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private Class            resourceOwnerClass;
   private boolean          editable           = true;
   private boolean          required           = true;
   private Object           model;
   private ResourceResolver resourceResolver;
   private Vector           listeners;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  FormComponent                                    */
        /*                                                              */
        /**
         * This is the default constructor. It calls
         * createDefaultController in order to associate a controller to
         * itself. The default controller, is a controller created by the
         * designer of the view to handle input. A subclasser can override
         * this method to provide an alternative controller. In any case a
         * controller can be set on the FormComponent at runtime to change
         * its "feel".
         *  
         */
        /*==============================================================*/
   public    FormComponent (
                           )
   {
//##Begin FormComponent:FormComponent() preserve=yes
      setLayout(new BorderLayout());
      setResourceOwnerClass(getClass());      
//##End   FormComponent:FormComponent()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getResourceOwnerClass                            */
        /*                                                              */
        /**
         * This method returns the value of the resource owner class
         * designates the class that owns a set of resources. Typically
         * when retrieving resource, the getResource() methods use the
         * current class as the resource owner. This works fine most of a
         * time but can fail in case an inner class is making the request.
         * The inner class typically does not have its own resource file
         * but uses that of its enclosing parent class.
         * <p>
         * The inner class in this case should set the resource owner to
         * the class of its parent class.
         *  
         * @return      :Class -
         *                 The value of the resource owner class designates
         *                 the class that owns a set of resources.
         *                 Typically when retrieving resource, the
         *                 getResource() methods use the current class as
         *                 the resource owner. This works fine most of a
         *                 time but can fail in case an inner class is
         *                 making the request. The inner class typically
         *                 does not have its own resource file but uses
         *                 that of its enclosing parent class.
         * <p>
         *                 The inner class in this case should set the
         *                 resource owner to the class of its parent class.
         */
        /*==============================================================*/
   public  Class  getResourceOwnerClass (
                                        )
   {
//##Begin FormComponent:getResourceOwnerClass() preserve=no

      return (resourceOwnerClass);

//##End   FormComponent:getResourceOwnerClass()
   }
        /*==============================================================*/
        /* OPERATION:  isEditable                                       */
        /*                                                              */
        /**
         * This method returns the value of the "editable" attribute.
         *  
         * @return      :boolean -
         *                 The value of the "editable" attribute.
         */
        /*==============================================================*/
   public  boolean  isEditable (
                               )
   {
//##Begin FormComponent:isEditable() preserve=no

      return (editable);

//##End   FormComponent:isEditable()
   }


        /*==============================================================*/
        /* OPERATION:  isRequired                                       */
        /*                                                              */
        /**
         * This method returns the value of the "Required" attribute.
         *  
         * @return      :boolean -
         *                 The value of the "Required" attribute.
         */
        /*==============================================================*/
   public  boolean  isRequired (
                               )
   {
//##Begin FormComponent:isRequired() preserve=no

      return (required);

//##End   FormComponent:isRequired()
   }

        /*==============================================================*/
        /* OPERATION:  getModel                                         */
        /*                                                              */
        /**
         * This method returns the value of the "model" attribute.
         *  
         * @return      :Object -
         *                 The value of the "model" attribute.
         */
        /*==============================================================*/
   public  Object  getModel (
                            )
   {
//##Begin FormComponent:getModel() preserve=no

      return (model);

//##End   FormComponent:getModel()
   }

        /*==============================================================*/
        /* OPERATION:  getResourceResolver                              */
        /*                                                              */
        /**
         * This method returns the value of the "resourceResolver"
         * attribute.
         *  
         * @return      :ResourceResolver -
         *                 The value of the "resourceResolver" attribute.
         */
        /*==============================================================*/
   public  ResourceResolver  getResourceResolver (
                                                 )
   {
//##Begin FormComponent:getResourceResolver() preserve=yes

      if (resourceResolver == null) {
	 resourceResolver = new ResourceResolver();
	 resourceResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
      }

      return (resourceResolver);

//##End   FormComponent:getResourceResolver()
   }

        /*==============================================================*/
        /* OPERATION:  getListeners                                     */
        /*                                                              */
        /**
         * This method returns the value of the "listeners" attribute.
         *  
         * @return      :Vector -
         *                 The value of the "listeners" attribute.
         */
        /*==============================================================*/
   public  Vector  getListeners (
                                )
   {
//##Begin FormComponent:getListeners() preserve=no

      return (listeners);

//##End   FormComponent:getListeners()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setResourceOwnerClass                            */
        /*                                                              */
        /**
         * This method sets the value of the resource owner class
         * designates the class that owns a set of resources. Typically
         * when retrieving resource, the getResource() methods use the
         * current class as the resource owner. This works fine most of a
         * time but can fail in case an inner class is making the request.
         * The inner class typically does not have its own resource file
         * but uses that of its enclosing parent class.
         * <p>
         * The inner class in this case should set the resource owner to
         * the class of its parent class.
         *  
         * @param       aValue:Class
         *                 The value of the resource owner class designates
         *                 the class that owns a set of resources.
         *                 Typically when retrieving resource, the
         *                 getResource() methods use the current class as
         *                 the resource owner. This works fine most of a
         *                 time but can fail in case an inner class is
         *                 making the request. The inner class typically
         *                 does not have its own resource file but uses
         *                 that of its enclosing parent class.
         * <p>
         *                 The inner class in this case should set the
         *                 resource owner to the class of its parent class.
         */
        /*==============================================================*/
   public  void  setResourceOwnerClass (
                                        Class  aValue
                                       )
   {
//##Begin FormComponent:setResourceOwnerClass(Class) preserve=no

      resourceOwnerClass = aValue;

//##End   FormComponent:setResourceOwnerClass(Class)
   }

        /*==============================================================*/
        /* OPERATION:  setEditable                                      */
        /*                                                              */
        /**
         * This method sets the value of the "editable" attribute.
         *  
         * @param       aValue:boolean
         *                 The value of the "editable" attribute.
         */
        /*==============================================================*/
   public  void  setEditable (
                              boolean  aValue
                             )
   {
//##Begin FormComponent:setEditable(boolean) preserve=yes
      Component[] arr = this.getComponents();

      for ( int i = 0; i < arr.length; i++ ) {
	 COM.novusnet.vision.java.utility.GUIToolKit.setEditable(arr[i], aValue);
      } 

      editable = aValue;
      repaint();
//##End   FormComponent:setEditable(boolean)
   }
        /*==============================================================*/
        /* OPERATION:  setRequired                                      */
        /*                                                              */
        /**
         * This method sets the value of the "required" attribute.
         *  
         * @param       aValue:boolean
         *                 The value of the "required" attribute.
         */
        /*==============================================================*/
 
   public  void  setRequired (
                              boolean  aValue
                             )
   {
//##Begin FormComponent:setEditable(boolean) preserve=yes
      Component[] arr = this.getComponents();

      for ( int i = 0; i < arr.length; i++ ) {
	 if (arr[i] instanceof ExtendedTextField) {
            ((ExtendedTextField)arr[i]).setRequired(aValue);
         }
      } 

      editable = aValue;
      repaint();
//##End   FormComponent:setEditable(boolean)
   }


        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * This method sets the value of the "model" attribute.
         *  
         * @param       aValue:Object
         *                 The value of the "model" attribute.
         */
        /*==============================================================*/
   public  void  setModel (
                           Object  aValue
                          )
   {
//##Begin FormComponent:setModel(Object) preserve=yes
      Object oldModel = model;

      if (oldModel instanceof BusinessObject) {
	 if (oldModel != null) {
	    ((BusinessObject)oldModel).removePropertyChangeListener(this);
	 }
      }

      model = aValue;

      if (model instanceof BusinessObject) {
	 if (model != null) {
	    ((BusinessObject)model).addPropertyChangeListener(this);
	 }
      }

      if ( (oldModel != null) && (model != null) && oldModel.equals(model)) {
	 System.out.println("(Form component): A new model was set. However, the new and old model are equal. Check the equals of you model object. Model change event not fired. Any attached DCC's will fail." + this);
	 System.out.println("(Form component): Model is " + model);
      }

      firePropertyChange("model", oldModel, model);

      // Commented out next two lines per ICE requirements. Eoin F. 9-7-04
      //Readded because of problems with table scrolling.
       invalidate();
       validate();
//##End   FormComponent:setModel(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setResourceResolver                              */
        /*                                                              */
        /**
         * This method sets the value of the "resourceResolver" attribute.
         *  
         * @param       aValue:ResourceResolver
         *                 The value of the "resourceResolver" attribute.
         */
        /*==============================================================*/
   private  void  setResourceResolver (
                                       ResourceResolver  aValue
                                      )
   {
//##Begin FormComponent:setResourceResolver(ResourceResolver) preserve=no

      resourceResolver = aValue;

//##End   FormComponent:setResourceResolver(ResourceResolver)
   }

        /*==============================================================*/
        /* OPERATION:  setListeners                                     */
        /*                                                              */
        /**
         * This method sets the value of the "listeners" attribute.
         *  
         * @param       aValue:Vector
         *                 The value of the "listeners" attribute.
         */
        /*==============================================================*/
   public  void  setListeners (
                               Vector  aValue
                              )
   {
//##Begin FormComponent:setListeners(Vector) preserve=no

      listeners = aValue;

//##End   FormComponent:setListeners(Vector)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getStringResource                                */
        /*                                                              */
        /**
         * This method returns the resource string associated with a key.
         * If the resource is not found, a "Not found" is returned to
         * caller.
         *  
         * @param       aKey:String
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getStringResource (
                                      String  aKey
                                     )
   {
//##Begin FormComponent:getStringResource(String) preserve=yes

      String resource = "Not found";

      resource = getResourceResolver().getStringResource(aKey,getResourceOwnerClass());
      
      return(resource);
//##End   FormComponent:getStringResource(String)
   }

        /*==============================================================*/
        /* OPERATION:  getAccelCharacter                                */
        /*                                                              */
        /**
         * Returns an accelarator associated with a given string key. If
         * the char is not found, a default 'X' is returned.
         *  
         * @param       aKey:String
         * @return      :char -
         */
        /*==============================================================*/
   public  char  getAccelCharacter (
                                    String  aKey
                                   )
   {
//##Begin FormComponent:getAccelCharacter(String) preserve=yes
      String resource = "X";
      resource = getStringResource(aKey);     
      return (resource.charAt(0));
//##End   FormComponent:getAccelCharacter(String)
   }

        /*==============================================================*/
        /* OPERATION:  getInstalledUI                                   */
        /*                                                              */
        /**
         * Returns the currently installed UI class.
         *  
         * @return      :ComponentUI -
         */
        /*==============================================================*/
   public  ComponentUI  getInstalledUI (
                                       )
   {
//##Begin FormComponent:getInstalledUI() preserve=yes
      return (ui);
//##End   FormComponent:getInstalledUI()
   }

        /*==============================================================*/
        /* OPERATION:  store                                            */
        /*                                                              */
        /**
         * This method is implemented to perform store on the FormComponent
         * being represented. A FormComponent implements the store using a
         * variant of the 2 phase commit scheme. These phases are executed
         * on the children of the FormComponent.
         * <p>
         * The first phase is the prepareForStore() method which is invoked
         * on the child forms. In this phase, the component must ensure
         * that the user has entered all the information that satisfies the
         * "contract" with its business object. An example will be missing
         * information that must be supplied or any inconsistencies. Please
         * note field validation usually takes place when the user is
         * entering information on the view. If the component does not
         * detect any errors, then it simply does nothing and returns to
         * caller. 
         * <p>
         * Before starting the second phase, the main component (i.e the
         * one whose store() method was called) starts a new transaction. 
         * <p>
         * In the second phase, (commit phase), the store() method calls
         * the commit() method on the form. The default implementation of
         * the commit method is to call store() on the model currently set
         * on the form. The model should have been synced up with the view
         * by using DCC's or moving data to the business object (model)
         * during the prepare phase.
         * <p>
         * <b>Errors</b>
         * <p>
         * If a component, during the prepare phase, detects that it can
         * not fulfill the contract with the BO it should raise an error
         * condition so that the user can correct the error. A simple
         * implementaion to display an error to the user would be  for the
         * component to simply display the error message. 
         *  
         */
        /*==============================================================*/
   public  void  store (
                       )
   {
//##Begin FormComponent:store() preserve=yes

      boolean    startedTxn   = false;
      boolean    success      = false;
      StatusBar  myStatusBar  = getStatusBar();
      
      fireFormComponentEvent(FormComponentEvent.STORE_STARTED, false);

      try {
	 myStatusBar.setValue(0);
	 myStatusBar.setMinimum(0);
	 myStatusBar.setMaximum(3);

	 myStatusBar.setValue(myStatusBar.getValue() + 1);
	 myStatusBar.setText("Verifying:" + ClassHelper.getClassNameFromTypeString (this.getClass().getName()));

	 //========================================================
	 // Prepare the controllers for a store
	 //========================================================
	 prepareStore();

	 //===========================================================
	 // All the controller are ready to commit. Go ahead, start a 
	 // transaction and ask them to commit.
	 //============================================================
	 Current aCurrent  = TransactionService.instance().getCurrent();

	 if (aCurrent == null) {
	    startedTxn = true;
	    aCurrent   = new Current();
	    aCurrent.begin();
	 }

	 myStatusBar.setText("Storing:" + ClassHelper.getClassNameFromTypeString (this.getClass().getName()));
	 myStatusBar.setValue(myStatusBar.getValue() + 1);

	 //===========================================================
	 // If an exception took place during the form commit
	 // but before calling the transaction commit, then we must
	 // not depend on the transaction service clean up mechanism
	 // since we have not called Current.commit. i.e We must
	 // terminate the transaction ourselves.
	 //===========================================================
	 try {	
	    // Call commit so people can write out things if they want to under the context
	    // of a transaction.
	    commit();
	    // Call store on the model.
	    if (model instanceof BusinessObject) {
	       System.out.println("Calling store on the model");
	       ((BusinessObject)model).store(null);
	    }
	 }
	 catch(Throwable  e) {
	    new ExceptionPane(e);
	    if (startedTxn) {
	       try {
		  aCurrent.rollback();	    
	       }
	       catch(RuntimeException ignore) {
	       }
	    }
	    throw new RuntimeException(e.getMessage());
	 }

	 if (startedTxn == true) {
	    try {
	       aCurrent.commit();
	    }
	    catch(Throwable  e) {
	       new ExceptionPane(e);
	       throw new RuntimeException(e.getMessage());
	    }
	 }
	 success = true;
      }
      // Readonly 
      catch ( ReadonlyException e ) {
          new ExceptionPane( e );
      }
      finally {
	 fireFormComponentEvent(FormComponentEvent.STORE_ENDED, success);
	 postStore(success);
	 myStatusBar.setText("Ready");
	 myStatusBar.setValue(0);
      }
//##End   FormComponent:store()
   }

        /*==============================================================*/
        /* OPERATION:  propertyChange                                   */
        /*                                                              */
        /**
         * @param       event:PropertyChangeEvent
         */
        /*==============================================================*/
   public  void  propertyChange (
                                 PropertyChangeEvent  event
                                )
   {
//##Begin FormComponent:propertyChange(PropertyChangeEvent) preserve=yes
//##End   FormComponent:propertyChange(PropertyChangeEvent)
   }

        /*==============================================================*/
        /* OPERATION:  getFrame                                         */
        /*                                                              */
        /**
         * @return      :Frame -
         */
        /*==============================================================*/
   public  Frame  getFrame (
                           )
   {
//##Begin FormComponent:getFrame() preserve=yes
      return(getFrame(this));
//##End   FormComponent:getFrame()
   }

        /*==============================================================*/
        /* OPERATION:  findProperSetMethod                              */
        /*                                                              */
        /**
         * Looks for a set method in the form component that takes a
         * specific parameter. The class of the parameter is matched
         * against the found set methods. If no match is found, a super
         * class (if available) of the parameter is tried. The method, can
         * be any method that takes one parameter.
         *  
         * @param       parameterType:Class
         * @param       methodName:String
         * @return      :Method -
         */
        /*==============================================================*/
   public  Method  findProperSetMethod (
                                        Class   parameterType,
                                        String  methodName
                                       )
   {
//##Begin FormComponent:findProperSetMethod(Class,String) preserve=yes
      Class           aClass       = getClass();
      Method          aMethod      = null;
      Class []        params       = { parameterType };
 
      try {
        aMethod = ClassHelper.getClosestMatchingMethod(methodName , aClass, params);
      }
      catch(Throwable e) {
         e.printStackTrace();
      }

      return (aMethod);
//##End   FormComponent:findProperSetMethod(Class,String)
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * This method returns the status bar associated with the root pane
         * of this form. If not status area is establised by the
         * application, the method will create a status bar. The created
         * status area will act like the UNIX /dev/nul. This has the
         * advantage of not having developers test for the existence of the
         * status bar.
         *  
         * @return      :StatusBar -
         */
        /*==============================================================*/
   public  StatusBar  getStatusBar (
                                   )
   {
//##Begin FormComponent:getStatusBar() preserve=yes
      return getStatusBar(this);
//##End   FormComponent:getStatusBar()
   }

        /*==============================================================*/
        /* OPERATION:  addFormComponentListener                         */
        /*                                                              */
        /**
         * Adds a form component listener.
         *  
         * @param       l:FormComponentListener
         */
        /*==============================================================*/
   public  void  addFormComponentListener (
                                           FormComponentListener  l
                                          )
   {
//##Begin FormComponent:addFormComponentListener(FormComponentListener) preserve=yes
      if (listeners == null) {
	 listeners = new Vector();
      }

      listeners.addElement(l);
//##End   FormComponent:addFormComponentListener(FormComponentListener)
   }

        /*==============================================================*/
        /* OPERATION:  removeFormComponentListener                      */
        /*                                                              */
        /**
         * Removes a form component listener.
         *  
         * @param       l:FormComponentListener
         */
        /*==============================================================*/
   public  void  removeFormComponentListener (
                                              FormComponentListener  l
                                             )
   {
//##Begin FormComponent:removeFormComponentListener(FormComponentListener) preserve=yes
       listeners.removeElement(l);
//##End   FormComponent:removeFormComponentListener(FormComponentListener)
   }

        /*==============================================================*/
        /* OPERATION:  undo                                             */
        /*                                                              */
        /**
         * When called, this method calls the reset method on this form and
         * any other nested forms.
         *  
         */
        /*==============================================================*/
   public  void  undo (
                      )
   {
//##Begin FormComponent:undo() preserve=yes
      reset();
//##End   FormComponent:undo()
   }

        /*==============================================================*/
        /* OPERATION:  getReservedAccelarators                          */
        /*                                                              */
        /**
         * In some situations, a form might want to reserve accelkeys. For
         * example, a Wizard should not allow embedded forms to to override
         * any accel keys that the Wizard is using.
         *  
         * @return      :char[] -
         */
        /*==============================================================*/
   public  char[]  getReservedAccelarators (
                                           )
   {
//##Begin FormComponent:getReservedAccelarators() preserve=yes
      char[] retArray = null;
      Component[] fca = (Component[])getComponents();
      for ( int i = 0; fca != null && i > fca.length; i++)
      {
         if ( fca[i] instanceof WizardComponent )
         {
            retArray =  ((WizardComponent)fca[i]).getReservedAccelarators();
            break;
         } else if ( fca[i] instanceof FormComponent ) {
            retArray =  ((FormComponent)fca[i]).getReservedAccelarators();
            break;
         }
      }
      return retArray;
//##End   FormComponent:getReservedAccelarators()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  prepareStore                                     */
        /*                                                              */
        /**
         * This method is called part of the store process. This method
         * recurses into all contained components invoking the
         * prepareStore() method on them.  In addition, this method fires a
         * STORE_PREPARE event to notify any listeners that a commit is
         * taking place. This is typically used by DCC's to validate data..
         * If you override, this method, you should fire the event  so that
         * any DCC's will work properly.
         *  
         * @exception   PrepareFormException -
         */
        /*==============================================================*/
   protected  void  prepareStore (
                                 )
                           throws PrepareFormException
   {
//##Begin FormComponent:prepareStore() preserve=yes
      fireFormComponentEvent(FormComponentEvent.STORE_PREPARE,  false);
      prepareStoreWorker(this);
      return;   
//##End   FormComponent:prepareStore()
   }

   protected void postStore(boolean storeSuccessful) {
		postStoreWorker(this, storeSuccessful);
      return;   
   }

        /*==============================================================*/
        /* OPERATION:  prepareStoreWorker                               */
        /*                                                              */
        /**
         * This method recurses into the chidren represented by a
         * controller and calls prepareStore() on them.
         *  
         * @param       aContainer:Container
         */
        /*==============================================================*/
   private  void  prepareStoreWorker (
                                        Container  aContainer
                                       )
   {
//##Begin FormComponent:prepareStoreWorker(Container) preserve=yes
      Component[]    myComponents = aContainer.getComponents();

      for (int i = 0 ; i < myComponents.length ; i++) {

	 if (myComponents[i] instanceof FormComponent) {
	    ((FormComponent)myComponents[i]).prepareStore();
	 }

 	 if (myComponents[i] instanceof Container) {
 	    prepareStoreWorker((Container)myComponents[i]);
 	 }
      }

      return;      
//##End   FormComponent:prepareStoreWorker(Container)
   }


   private  void  postStoreWorker(Container aContainer, boolean storeSuccessful) {
      Component[] myComponents = aContainer.getComponents();
      for(int i = 0 ; i < myComponents.length; i++) {
         if(myComponents[i] instanceof FormComponent) {
            ((FormComponent)myComponents[i]).postStore(storeSuccessful);
         }
         if(myComponents[i] instanceof Container) {
            postStoreWorker((Container)myComponents[i], storeSuccessful);
         }
      }
      return;
   }

        /*==============================================================*/
        /* OPERATION:  setUI                                            */
        /*                                                              */
        /**
         * The JComponet setUI.
         *  
         * @param       aComponentUI:FormComponentUI
         */
        /*==============================================================*/
   protected  void  setUI (
                           FormComponentUI  aComponentUI
                          )
   {
//##Begin FormComponent:setUI(FormComponentUI) preserve=yes
      super.setUI(aComponentUI);

      if (aComponentUI == null) {
	 setModel(null);
      }

      fireFormComponentEvent(FormComponentEvent.DISENGAGE,  false);
//##End   FormComponent:setUI(FormComponentUI)
   }

        /*==============================================================*/
        /* OPERATION:  fireFormComponentEvent                           */
        /*                                                              */
        /**
         * @param       id:int
         * @param       success:boolean
         */
        /*==============================================================*/
   protected  void  fireFormComponentEvent (
                                            int      id,
                                            boolean  success
                                           )
   {
//##Begin FormComponent:fireFormComponentEvent(int,boolean) preserve=yes

      if (listeners == null) {
	 return;
      }

      Vector myListeners = (Vector) listeners.clone();
      
      for (int i = 0; i < myListeners.size() ; i++) {

	 FormComponentListener aListener = (FormComponentListener)myListeners.elementAt(i);

	 switch (id) {
	    case FormComponentEvent.STORE_STARTED:
	       aListener.storeStarted( new FormComponentEvent(this) );
	       break;
	       
	    case FormComponentEvent.STORE_ENDED:
	       FormComponentEvent event = new FormComponentEvent(this);
	       event.setSuccess(success);
	       aListener.storeEnded(event);
	       break;

	    case FormComponentEvent.STORE_PREPARE:
	       aListener.storePrepare( new FormComponentEvent(this) );
	       break;

	    case FormComponentEvent.STORE_COMMIT:
	       aListener.storeCommit( new FormComponentEvent(this) );
	       break;

	    case FormComponentEvent.RESET:
	       aListener.reset( new FormComponentEvent(this) );
	       break;

	    case FormComponentEvent.DISENGAGE:
	       aListener.disengage( new FormComponentEvent(this) );
	       break;

	 }
      }
//##End   FormComponent:fireFormComponentEvent(int,boolean)
   }

        /*==============================================================*/
        /* OPERATION:  commit                                           */
        /*                                                              */
        /**
         * This method drills down any child forms and calls commit on
         * them. In addition, this method fires a STORE_COMMIT event to
         * notify any listeners that a commit is taking place. This is
         * typically used by DCC's to commit the data to the model. If you
         * override, this method, you should fire the event  so that any
         * DCC's will work properly.
         *  
         */
        /*==============================================================*/
   protected  void  commit (
                           )
   {
//##Begin FormComponent:commit() preserve=yes
      fireFormComponentEvent(FormComponentEvent.STORE_COMMIT, false);
      commitWorker(this);
//##End   FormComponent:commit()
   }

        /*==============================================================*/
        /* OPERATION:  commitWorker                                     */
        /*                                                              */
        /**
         * This method recurses into the chidren represented by a
         * controller and calls commit on them.
         *  
         * @param       aContainer:Container
         */
        /*==============================================================*/
   private  void  commitWorker (
                                  Container  aContainer
                                 )
   {
//##Begin FormComponent:commitWorker(Container) preserve=yes
      Component[]    myComponents = aContainer.getComponents();

      for (int i = 0 ; i < myComponents.length ; i++) {

	 if (myComponents[i] instanceof FormComponent) {
	    ((FormComponent)myComponents[i]).commit();
	 }

 	 if (myComponents[i] instanceof Container) {
 	    commitWorker((Container)myComponents[i]);
 	 }
      }

      return;      
//##End   FormComponent:commitWorker(Container)
   }

        /*==============================================================*/
        /* OPERATION:  reset                                            */
        /*                                                              */
        /**
         * This method is called by undo. The default action is to fire a
         * "reset" preoperty change which can be intercepted by attached
         * controllers that do the actual data rollback logic.
         *  
         */
        /*==============================================================*/
   protected  void  reset (
                          )
   {
//##Begin FormComponent:reset() preserve=yes
      fireFormComponentEvent(FormComponentEvent.RESET,  false);
      resetWorker(this);
//##End   FormComponent:reset()
   }

        /*==============================================================*/
        /* OPERATION:  disengage                                        */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  disengage (
                              )
   {
//##Begin FormComponent:disengage() preserve=yes
      setModel(null);
      fireFormComponentEvent(FormComponentEvent.DISENGAGE,  false);
//##End   FormComponent:disengage()
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  resetWorker                                      */
        /*                                                              */
        /**
         * Internal method to perform reset.
         *  
         * @param       container:Container
         */
        /*==============================================================*/
   private  void  resetWorker (
                               Container  container
                              )
   {
//##Begin FormComponent:resetWorker(Container) preserve=yes
      Component[]    myComponents = container.getComponents();

      for (int i = 0 ; i < myComponents.length ; i++) {

	 if (myComponents[i] instanceof FormComponent) {
	    ((FormComponent)myComponents[i]).reset();
	 }

 	 if (myComponents[i] instanceof Container) {
 	    resetWorker((Container)myComponents[i]);
 	 }
      }

      return;      
//##End   FormComponent:resetWorker(Container)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getFrame                                         */
        /*                                                              */
        /**
         * @param       aComponent:Component
         * @return      :Frame -
         */
        /*==============================================================*/
   public static  Frame  getFrame (
                                   Component  aComponent
                                  )
   {
//##Begin FormComponent:getFrame(Component) preserve=yes
      return((Frame)SwingUtilities.getAncestorOfClass(Frame.class, aComponent));
//##End   FormComponent:getFrame(Component)
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * This method returns the status bar associated with the root pane
         * of any component. If not status area is establised by the
         * application, the method will create a status bar. The created
         * status area will act like the UNIX /dev/nul. This has the
         * advantage of not having developers test for the existence of the
         * status bar.
         *  
         * @param       component:Component
         * @return      :StatusBar -
         */
        /*==============================================================*/
   public static  StatusBar  getStatusBar (
                                           Component  component
                                          )
   {
//##Begin FormComponent:getStatusBar(Component) preserve=yes

      JRootPane  rootPane; 
      StatusBar  statusBar = null;

      if (component instanceof RootPaneContainer) {
	 rootPane = ((RootPaneContainer)component).getRootPane();
      }
      else {
	 rootPane = SwingUtilities.getRootPane(component);
      }

      if ( (rootPane != null) && (rootPane instanceof ExtendedRootPane) ) {
	 ExtendedRootPane extendedRootPane = (ExtendedRootPane) rootPane;
	 statusBar = (StatusBar)extendedRootPane.getStatusBar();
      }

      if (statusBar == null) {
	 Application myApp = Application.getApplication(component);

	 if (myApp != null) {
	    ExtendedApplet myApplet = (ExtendedApplet)myApp.getApplet();
	    ExtendedRootPane extendedRootPane = (ExtendedRootPane) myApplet.getRootPane();
	    statusBar = (StatusBar)extendedRootPane.getStatusBar();	 
	 }

	 if (statusBar == null) {
	    statusBar = new StatusBar();
	 }
      }

      return statusBar;
//##End   FormComponent:getStatusBar(Component)
   }

   // Default implementations for non HTML action forms
   // HTML action forms override these to return appropriate  values
   public String getURLString() { return null; }
   public String getEncodedPostString() { return null; }
   public boolean isUsingProxy() { return false; }
   public boolean manipulateRequest(HttpURLConnection aConnection) 
   { 
      if ( aConnection == null ) return false;
      aConnection.setRequestProperty("Cookie", "family=Parag&Monica$Rohan");
      return false; 
   }

   // default handling gets the http response 's content and pops it up in a JOptionPane
   public boolean handleHTTPResponse(HttpURLConnection aConnection)
   {
      if ( aConnection == null ) return false;

      try {
         // Check for cookies and other header info
         for ( int i = 0; aConnection.getHeaderField(i) != null; i++)
         {
            System.out.println("Header field " + i + " |" + aConnection.getHeaderFieldKey(i) + "|=|"+ aConnection.getHeaderField(i) ); 
         }
         Object messageObject = null;
         BufferedReader in = new BufferedReader(
               new InputStreamReader(aConnection.getInputStream()));
         String inputLine;
                                                                                                                            
         // read the reply POST or GET
         StringBuffer buf = new StringBuffer();
         while ((inputLine = in.readLine()) != null)
         {
            buf.append(inputLine);
         }
         in.close();
         String s = buf.toString();
         System.out.println("Code = " + aConnection.getResponseCode() + " Message = " + aConnection.getResponseMessage() );
         // show the reply in html 
         JTextPane t = new JTextPane();
         t.setContentType("text/html");
         t.setText(s);
         System.out.println("|"+s+"|");
         messageObject = t; 
         // display the new data /( result or GET OR POST ) in a new window
         JOptionPane.showMessageDialog(null, messageObject);  
      } catch ( Throwable t ) {
        t.printStackTrace();
      } finally {
        aConnection.disconnect();
      }
      return true;
   }

   public void addToTabOrder( JComponent c )
   {
      if ( tabOrderVector == null )
      {
          tabOrderVector = new Vector();
          tabOrderVector.addElement( c );
      } else {
          JComponent lc = (JComponent)tabOrderVector.lastElement();
          ((JComponent)lc).setNextFocusableComponent(c);
          tabOrderVector.addElement(c);
      }
   }

   public void enableAllEditableFields(boolean enableFlag) {
      Component[] components = this.getComponents();       // All components on this form
      Class[]     paramTypes = {boolean.class};            // getMethod() arg
      Object      args[]     = {new Boolean (enableFlag)}; // invoke method arg

      // Loop through all components of this form.  For those componnents
      // that are instances of a class which has a setEnabled and a setEditable
      // method, enable/disable based on the passed in argument "enableFlag."
      for (int i = 0; i < components.length; ++i) {
         try {
            // Search for the "setEnabled" method
            Method mySetEnabledMethod  = ((Object) components[i]).getClass().getMethod("setEnabled", paramTypes);

            // Search for the "setEditable" method
            Method mySetEditableMethod = ((Object) components[i]).getClass().getMethod("setEditable", paramTypes);

            // If both the "setEnabled" and "setEditable" methods
            // were found enable/disable the current component based
            // on the passed in argument "enableFlag."
            if ((mySetEnabledMethod != null) &&
                (mySetEditableMethod != null)) {
               mySetEnabledMethod.invoke(((Object) components[i]), args);
	       if (!(((Object)components[i]) instanceof JComboBox)) {
		  mySetEditableMethod.invoke(((Object) components[i]), args);
	       }
            }
         } catch (java.lang.NoSuchMethodException e) {
            // Do nothing.  It is fine if a particular Component does not
            // have a "setEnabled" or a "setEditable" method.  This catch
            // is present because it is required when calling getMethod()
            // and we do not consider it a catastrophic exeception.
         } catch (java.lang.IllegalAccessException e) {
            e.printStackTrace ();
	    new ExceptionPane(e);
         } catch (java.lang.reflect.InvocationTargetException e) {
            e.printStackTrace ();
	    new ExceptionPane(e);
         } catch (Throwable myThrowable) {
            // Catch every other possible exception
            myThrowable.printStackTrace ();
	    new ExceptionPane(myThrowable);
         }
      }
   }
}
