package COM.novusnet.vision.java.gui;


/**
 * The CurrencyEditField is a number field suitable for manipulating currencies.
 * The default edit format does not display the currency whereas the display format
 * does. Negatives are allowed. There is no limit in the number of integers that 
 * can be entered, whereas the fraction portion is determined by the locale.
 */
public class CurrencyEditField extends NumberEditField
{
   /**
    * Constructor that takes the number of columns to display
    * @param columns Number of columns to display.
    */
   public CurrencyEditField(int columns)
   {
      super(columns);
   }

   /**
    * Default constructor.
    */
   public CurrencyEditField()
   {      
      super();
   }
}
