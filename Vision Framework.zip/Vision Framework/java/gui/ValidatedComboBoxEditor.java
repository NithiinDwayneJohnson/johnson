package COM.novusnet.vision.java.gui;

import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.ComboBoxEditor;

public class ValidatedComboBoxEditor implements ComboBoxEditor,FocusListener {

   FormattedTextField editor = null;

   public ValidatedComboBoxEditor() {
      editor = createComboBoxEditor();
      editor.addFocusListener(this);
   }

   protected FormattedTextField createComboBoxEditor()
   {
      return new FormattedTextField();
   }

   public Component getEditorComponent() {
      return editor;
   }
   
   public void setItem(Object anObject) {
      if(anObject != null)
	editor.setText(anObject.toString());
      else
	editor.setText("");
   }
   
   public Object getItem() {
      return editor.getText();
   }
   
   public void selectAll() {
      editor.selectAll();
      editor.requestFocus();
   }
   
   public void focusGained(FocusEvent e) {}
   public void focusLost(FocusEvent e) {
      editor.postActionEvent();
   }
   
   public void addActionListener(ActionListener l) {
      editor.addActionListener(l);
   }
   
   public void removeActionListener(ActionListener l) {
      editor.removeActionListener(l);
   }
}
