package COM.novusnet.vision.java.gui;


/**
 * This validator checks whether the number is valid and withing range.
 */
public class NumberEditFieldValidator extends DefaultValidator
{
   /**
    * Checks the validity of a number edit field.
    * @param component The ExtendedTextField component to check against.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component)
   {
      boolean         valid  = true;
      Number          number;
      NumberEditField numberField = (NumberEditField)component;

      number = numberField.getValue();

      if (number == null) {
	 return false;
      }

      if ( (number.doubleValue() <  numberField.getLowerRange()) || 
	   (number.doubleValue() >  numberField.getUpperRange())) {
	 valid = false;
      }

      if (number.doubleValue() < 0 && 
	  !numberField.isNegativeAllowed()) {
	 valid   = false;
      }

      return valid;
   }
}
