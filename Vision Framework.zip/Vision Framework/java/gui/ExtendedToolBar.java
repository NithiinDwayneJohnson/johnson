package COM.novusnet.vision.java.gui;
import java.awt.Image;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

/**
  The need for this was felt when we were trying to use a single abstractAction
  to be represented in 2 slightly different ways; on the toolbar with icon only
  and on the menu bar with icon and text. We also need the ability to "fallback"
  on the text whenever an icon was not present.

  The ExtendedToolBar class extends JToolBar by adding a single method
  addAction( AbstractAction ) so as to allow special handling of Actions'
  icons & their names. If an icon is present on the Action the Name is
  suppressed else the name is displayed. This is achieved by creating
  a DependentAction from an the AbstractAction which was to be added.
  The DependentAction is identical to AbstractAction in all respects
  except the following
  1. The tooltip is enabled for the DependentAction so that the Action.SHORT_DESCRIPTION
     becomes the ToolTip.
  2. The icon is displayed instead of the name & icon. If the icon is 
     absent then the name is displayed.
*/
public class ExtendedToolBar extends JToolBar
{

   public void addAction( AbstractAction action )
   {
      DependentAction toolBarAction = new DependentAction( action ); 

      JButton button = add( toolBarAction );

      //----------------------------------------------------------------
      // If the action has no SHORT_DESCRIPTION use the title
      //----------------------------------------------------------------
      String passOverText = (String)toolBarAction.getValue(Action.SHORT_DESCRIPTION);
      if ( passOverText == null || passOverText.length() < 0 )
      {
        passOverText = (String)toolBarAction.getValue(Action.NAME);
      }

      button.setToolTipText( passOverText );

      ImageIcon image = (ImageIcon)action.getValue(Action.SMALL_ICON);
      if ( image != null )
         image.setImage( image.getImage().getScaledInstance( 20,20, Image.SCALE_FAST ) );

      //----------------------------------------------------------------
      // If the action has no SHORT_DESCRIPTION use the title
      //----------------------------------------------------------------

   }
}
