package COM.novusnet.vision.java.gui;

import javax.swing.text.JTextComponent;

/**
 * A utility class to automatically update the case of a character when entered.
 *
 * Use the updateCase class method.
 *
 */
public class TextComponentCaseUpdater
{  
   /**
    * Convert text to upper case. The default.
    */
   public final static int TO_UPPER = 1;

   /**
    * Convert text to lower case.
    */
   public final static int TO_LOWER = 2;


   /** 
    * This is the default maximum character limit for updateCase(component, mode) 
    * which can be overriden with updateCase(component, mode, maxLimit);
    **/
   public final static int NO_LIMIT = -1;

   /**
    * Use this method to install a new document on the JTextComponent.
    * @param component The text component to convert the case for.
    * @param mode      The mode. This can be TO_UPPER or TO_LOWER. The default is TO_UPPER.
    */
   public static void updateCase(JTextComponent component, int mode)
   {
      component.setDocument(new ChangeCaseDocument(mode));
   }     

   /**
    * Use this method to install a new document on the JTextComponent.
    * @param component The text component to convert the case for.
    * @param mode      The mode. This can be TO_UPPER or TO_LOWER. The default is TO_UPPER.
    * @param maxLimit  The maximum number of characters allowed.
    */
   public static void updateCase(JTextComponent component, int mode, int maxLimit)
   {
      component.setDocument(new ChangeCaseDocument(mode, maxLimit));
   }     
}
