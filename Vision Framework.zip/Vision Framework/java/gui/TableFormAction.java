/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableFormAction.java                                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 January 25 at 15:18:17 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.AbstractAction;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableFormAction                                         */
/**
 * The base class of all table actions. It holds a reference to the table
 * view target associated with the subclass action.
 */
/*======================================================================*/
public abstract  class  TableFormAction  extends  AbstractAction
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableFormAction:Attributes preserve=yes

//##End   TableFormAction:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private TableForm tableForm;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getTableForm                                     */
        /*                                                              */
        /**
         * This method returns the value of the "tableForm" attribute.
         *  
         * @return      :TableForm -
         *                 The value of the "tableForm" attribute.
         */
        /*==============================================================*/
   public  TableForm  getTableForm (
                                   )
   {
//##Begin TableFormAction:getTableForm() preserve=no

      return (tableForm);

//##End   TableFormAction:getTableForm()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setTableForm                                     */
        /*                                                              */
        /**
         * This method sets the value of the "tableForm" attribute.
         *  
         * @param       aValue:TableForm
         *                 The value of the "tableForm" attribute.
         */
        /*==============================================================*/
   public  void  setTableForm (
                               TableForm  aValue
                              )
   {
//##Begin TableFormAction:setTableForm(TableForm) preserve=no

      tableForm = aValue;

//##End   TableFormAction:setTableForm(TableForm)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TableFormAction                                  */
        /*                                                              */
        /**
         * Constructor that takes a table view as the target of operations.
         *  
         * @param       aTableForm:TableForm
         */
        /*==============================================================*/
   public    TableFormAction (
                              TableForm  aTableForm
                             )
   {
//##Begin TableFormAction:TableFormAction(TableForm) preserve=yes
      setTableForm(aTableForm);
//##End   TableFormAction:TableFormAction(TableForm)
   }


}
