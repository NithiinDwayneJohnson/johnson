package COM.novusnet.vision.java.gui;

import java.text.DecimalFormat;

/**
 * The DecimalEditField is a number field suitable for manipulating decimal numbers.
 * The default format allows for negative numbers.
 */
public class DecimalEditField extends NumberEditField
{
   /**
    * Constructor that takes the number of columns to display
    * @param columns Number of columns to display.
    */
   public DecimalEditField(int columns)
   {
      super(columns);
   }

   /**
    * Default constructor.
    */
   public DecimalEditField()
   {      
      this(10);
   }

   protected DecimalFormat createEditFormatter()
   {
      return new DecimalFormat();
   }

   /**
    * This method creates a decimal display formatter. Subclassers can override this method
    * to provide custom formatters (subclasses of DecimalFormat).
    */
   protected DecimalFormat createDisplayFormatter()
   {
      return new DecimalFormat();
   }
}








