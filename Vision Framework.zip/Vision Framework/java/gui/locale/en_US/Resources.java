/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.gui.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;
/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The regions for the en_US locale
 */
/*======================================================================*/
public class Resources extends ListResourceBundle
{
   public Object[][] getContents() 
   {
      return contents;
   }
   
   static final Object[][] contents = 
   {     
     {"cancel"              , "Cancel" },
     {"ok"                  , "Ok" },
     {"change"              , "Change" },
     {"delete"              , "Delete" },
     {"add"                 , "Add" },
     {"update"              , "Update"},
     {"send"                , "Send"},
     {"cancelAccel"         , "C" },
     {"OKAccel"             , "O" },
     {"changeAccel"         , "h" },
     {"deleteAccel"         , "D" },
     {"addAccel"            , "A" },
     {"updateAccel"         , "U" },
     {"undoAccel"           , "n"},
     {"cancelText"          , "Cancel" },
     {"summaryText"         , "Summary"},
     {"detailText"          , "Detail" },
     {"errorText"           , "Error"},
     {"infoText"            , "Exception information"},
     {"deleteError"         , "An error has occurred while deleting the selected row."},
     {"deleteConfirmation"  , "Are you sure you want to delete the selected row ?"},
     {"deleteError"         , "An error has occurred while deleting the selected row(s)."},
     {"error"               , "Error"},
     {"backButton"          , "<< Back"},
     {"nextButton"          , "Next >>"},
     {"cancelButton"        , "Cancel"},
     {"finishButton"        , "Finish"},
     {"backButtonAccel"     , "B"},
     {"nextButtonAccel"     , "N"},
     {"cancelButtonAccel"   , "C"},
     {"finishButtonAccel"   , "F"},
     {"cancelWizard"        , "Cancelling this Wizard will cause all changes to be discarded. Proceed ?"},     
     {"confirmation"        , "Confirmation"},
     {"undoSend"            , "Undo Send"},
     {"undo"                , "Undo"},
     {"post"                , "POST"},
     {"get"                 , "GET"},
     {"POSTAccel"           , "P"},
     {"GETAccel"            , "G"},
     {"tableFormUItitle1"   , "{0} - Row Description"},
     {"tableFormUItitle2"   , "{0} - Cell Description"},
     {"tableFormUImsg1"     , "Table is empty.\n"},
     {"tableFormUImsg2"     , "Row is {0}.\n"},
     {"tableFormUImsg3"     , "No row currently selected.\n"},
     {"tableFormUImsg4"     , "no value"},
     {"tableFormUImsg5"     , "{0} is {1}.\n"},
     {"tableFormUImsg6"     , "Column is {0}, column name is {1}.\n"},
     {"tableFormUImsg7"     , "No column currently selected.\n"},
     {"tableFormUImsg8"     , "Value is {0}.\n"},
     {"tableFormUImsg9"     , "Table is empty.\n"}
   };
}
