/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedInternalFrame.java                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 January 25 at 15:42:19 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JRootPane;
import javax.swing.JToolBar;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedInternalFrame                                   */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  ExtendedInternalFrame  extends  JInternalFrame
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedInternalFrame:Attributes preserve=yes

//##End   ExtendedInternalFrame:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setToolBar                                       */
        /*                                                              */
        /**
         * Sets the mainRootpane's tool bar.
         *  
         * @param       aToolbar:JToolBar
         */
        /*==============================================================*/
   public  void  setToolBar (
                             JToolBar  aToolbar
                            )
   {
//##Begin ExtendedInternalFrame:setToolBar(JToolBar) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setToolBar(aToolbar);
//##End   ExtendedInternalFrame:setToolBar(JToolBar)
   }

        /*==============================================================*/
        /* OPERATION:  getToolBar                                       */
        /*                                                              */
        /**
         * Returns the tool bar associated with the root pane.
         *  
         * @return      :JToolBar -
         */
        /*==============================================================*/
   public  JToolBar  getToolBar (
                                )
   {
//##Begin ExtendedInternalFrame:getToolBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getToolBar();
//##End   ExtendedInternalFrame:getToolBar()
   }

        /*==============================================================*/
        /* OPERATION:  setStatusBar                                     */
        /*                                                              */
        /**
         * Sets the mainRootpane's status bar.
         *  
         * @param       aStatusBar:JComponent
         */
        /*==============================================================*/
   public  void  setStatusBar (
                               JComponent  aStatusBar
                              )
   {
//##Begin ExtendedInternalFrame:setStatusBar(JComponent) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setStatusBar(aStatusBar);
//##End   ExtendedInternalFrame:setStatusBar(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * Returns the statusl bar associated with the root pane.
         *  
         * @return      :JComponent -
         */
        /*==============================================================*/
   public  JComponent  getStatusBar (
                                    )
   {
//##Begin ExtendedInternalFrame:getStatusBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getStatusBar();
//##End   ExtendedInternalFrame:getStatusBar()
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedInternalFrame                            */
        /*                                                              */
        /**
         * Creates a JInternalFrame with no title, and all boolean setting
         * false.
         * <p>
         *        
         *  
         */
        /*==============================================================*/
   public    ExtendedInternalFrame (
                                   )
   {
//##Begin ExtendedInternalFrame:ExtendedInternalFrame() preserve=yes
      this(null, false, false,false,false);
//##End   ExtendedInternalFrame:ExtendedInternalFrame()
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedInternalFrame                            */
        /*                                                              */
        /**
         * Creates a JInternalFrame with title, and all boolean setting
         * false.
         * <p>
         *        
         *  
         * @param       title:String
         */
        /*==============================================================*/
   public    ExtendedInternalFrame (
                                    String  title
                                   )
   {
//##Begin ExtendedInternalFrame:ExtendedInternalFrame(String) preserve=yes
      this(title, false, false,false,false);
//##End   ExtendedInternalFrame:ExtendedInternalFrame(String)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedInternalFrame                            */
        /*                                                              */
        /**
         * @param       title:String
         * @param       resizable:boolean
         * @param       closable:boolean
         */
        /*==============================================================*/
   public    ExtendedInternalFrame (
                                    String   title,
                                    boolean  resizable,
                                    boolean  closable
                                   )
   {
//##Begin ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean) preserve=yes
      this(null, resizable, closable, false);
//##End   ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedInternalFrame                            */
        /*                                                              */
        /**
         *        
         *  
         * @param       title:String
         * @param       resizable:boolean
         * @param       closable:boolean
         * @param       maximizable:boolean
         */
        /*==============================================================*/
   public    ExtendedInternalFrame (
                                    String   title,
                                    boolean  resizable,
                                    boolean  closable,
                                    boolean  maximizable
                                   )
   {
//##Begin ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean,boolean) preserve=yes
      super(title, resizable, closable, maximizable);
//##End   ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean,boolean)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedInternalFrame                            */
        /*                                                              */
        /**
         *        
         *  
         * @param       title:String
         * @param       resizable:boolean
         * @param       closable:boolean
         * @param       maximizable:boolean
         * @param       iconifiable:boolean
         */
        /*==============================================================*/
   public    ExtendedInternalFrame (
                                    String   title,
                                    boolean  resizable,
                                    boolean  closable,
                                    boolean  maximizable,
                                    boolean  iconifiable
                                   )
   {
//##Begin ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean,boolean,boolean) preserve=yes
      super(title, resizable, closable, iconifiable);
//##End   ExtendedInternalFrame:ExtendedInternalFrame(String,boolean,boolean,boolean,boolean)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createRootPane                                   */
        /*                                                              */
        /**
         * Creates an ExtendedRootPane class.
         *  
         * @return      :JRootPane -
         */
        /*==============================================================*/
   protected  JRootPane  createRootPane (
                                        )
   {
//##Begin ExtendedInternalFrame:createRootPane() preserve=yes
      return new ExtendedRootPane();
//##End   ExtendedInternalFrame:createRootPane()
   }
}
