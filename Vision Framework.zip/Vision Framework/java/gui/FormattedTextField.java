package COM.novusnet.vision.java.gui;

import java.awt.*;
import java.util.*;
import java.beans.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.text.*;
import javax.swing.event.*;

/**
 *
 * The FormattedTextField class provides support for masked input typically used
 * in business applications. A mask is specified by calling setMask(). There are
 * reserved characters that have special meaning, the mask table below shows these
 * characters and explains there special meaning. Any reserved character can be escaped
 * by preceding the character with \ (note that you must specify \\ for the java compiler).
 *
 * <p>To specify a social security mask, call setMask("000-00-0000"); Since the '-' is
 * not reserved, it is interpreted as a literal. Some characters have been reserved
 * for future use and will throw an exception if used. These are:?@,~$%^&*()
 * Do not use these characters in your application without escaping them.
 *
 * <p>Some mask characters are marked as required, others are optional.
 *
 * <p>The getText() and setText() methods are overridden to return the unmasked text and
 * set unmasked text respectively.
 *
 *
 * Mask characters and their description
 * <br><br><br>
 *<table border >
 *
 *<tr>
 *<th> Mask Character </th>
 *<th> Description </th>
 *</tr>
 *
 *<tr>
 *<td> '0' </td>
 *<td> A digit. 0 -9, entry required. Plus (+) and minus (-) signs not allowed. </td>
 *</tr>
 *
 *<tr>
 *<td> '9' </td>
 *<td> A digit. 0 -9, entry optional. Plus (+) and minus (-) signs not allowed. </td>
 *</tr>
 *
 *<tr>
 *<td> '#' </td>
 *<td> A digit or space, entry optional. Blank positions are converted to spaces.
 *Plus (+) and minus (-) signs allowed. </td>
 *</tr>
 *
 *<tr>
 *<td> 'L' </td>
 *<td> A letter. A through Z, entry required.</td>
 *</tr>
 *
 *<tr>
 *<td> 'l' </td>
 *<td> A letter. A through Z, entry optional.</td>
 *</tr>
 *
 *<tr>
 *<td> 'A' </td>
 *<td> A letter or digit, entry required.</td>
 *</tr>
 *
 *<tr>
 *<td> 'a' </td>
 *<td> A letter or digit, entry optional.</td>
 *</tr>
 *
 *<tr>
 *<td> 'C' </td>
 *<td> A character or space, entry is required.</td>
 *</tr>
 *
 *<tr>
 *<td> 'c' </td>
 *<td> A character or space, entry is optional.</td>
 *</tr>
 *
 *<tr>
 *<td> '>' </td>
 *<td> Letters that follow will be converted to upper case.</td>
 *</tr>
 *
 *<tr>
 *<td> '<' </td>
 *<td> Letters that follow will be converted to lower case.</td>
 *</tr>
 *
 *<tr>
 *<td> '\' </td>
 *<td> Escape. Whatever character that follows is protected.</td>
 *</tr>
 *
 *</table>
 *
 *
 *
 * @see #getText
 * @see #setText
 * @see #setMask
 * @see #getMask
 */
public class FormattedTextField extends ExtendedTextField 
{
	//=============================================================//
	// Global properties                                           //
	//=============================================================//

	//=============================================================//
	// Properties                                                  //
	//=============================================================//
	private char fillChar = '_';
	private boolean autoShiftOnDelete = true;
	private boolean autoTrimText = true;

	private static OverrideActions overrideActions = new OverrideActions();
	private static ClipboardOwner aClipboardOwner = new ClipboardOwner() {
		public void lostOwnership(Clipboard clipboard, Transferable contents) {
		}
	};
	//=============================================================//
	// Privates                                                    //
	//=============================================================//
	private static final char DIGIT_R = '0';
	private static final char DIGIT_O = '9';
	private static final char DIGIT_OR_SPACE = '#';
	private static final char LETTER_R = 'L';
	private static final char LETTER_O = 'l';
	private static final char ALPHA_R = 'A';
	private static final char ALPHA_O = 'a';
	private static final char CHAR_R = 'C';
	private static final char CHAR_O = 'c';
	private static final char TO_UPPER = '>';
	private static final char TO_LOWER = '<';
	private static final char ESCAPE = '\\';

	private int DEBUG = 0;
	private String mask = null;
	private CaretListener caretListener = null;
	protected String displayString = null;
	protected Vector characterInfo = new Vector();
	private char reservedChars[] = { '?', '@', ',', '~', '$', '%', '^', 
		                           '&', '*', '(', ')' };

	private static final int CASE_UP = 0;
	private static final int CASE_LOWER = 1;
	private static final int CASE_LEAVE_ALONE = 2;

	public class CharacterInfo 
	{
		boolean required;
		char maskCharacter;
		int caseFold;
		boolean protection;
		boolean secure; //GCS
		String acceptableChars = null;

		private boolean valueProvided;

		public final boolean isProtected() 
		{
			return protection;
		}

		public final char getMaskCharacter() 
		{
			return maskCharacter;
		}

		public final boolean isRequired() 
		{
			return required;
		}

		public final int getCase() 
		{
			return caseFold;
		}
		//MS Compliance GCS START
		public final boolean isSecure()
		{
			return secure;
		}
		//MS Compliance GCS END

		public final boolean isValueProvided() 
		{
			return valueProvided;
		}

		public final String getAcceptableChars() 
		{
			return acceptableChars;
		}

		public final void setValueProvided(boolean value) 
		{
			if (isProtected()) {
				value = true;
			}
			valueProvided = value;
		}

		public final void setAcceptableChars(String acceptableChars) 
		{
			this.acceptableChars = acceptableChars;
		}

		//MS Compliance GCS START
		public final void setProtection(boolean value)
		{
			protection = value;
		}

		public final void setSecure(boolean value)
		{
					secure = value;
		}
		
		public final void setMaskCharacter(char value)
		{
			maskCharacter = value;
		}
		
		public final void setCaseFold(int value)
		{
			caseFold = value;
		}
		
		public final void setRequired(boolean value)
		{
			required = value;
		}
		//		MS Compliance GCS END

		public String toString()
		{
	   return "Mask Character:" + maskCharacter +  " - " + 
	   "Required      :" + required      +  " - " + 
	   "Protected     :" + protection    +  " - " +  
	   "hasValue      :" + valueProvided;
		}
	}

	private final void debug(int level, String string)
	{
		if (DEBUG >= level) {
			System.out.println(string);
		}
	}

	/**
	 * A constructor that takes the number of colums to diplay.
	 */
	public FormattedTextField(int columns) 
	{
		super(columns);

		setCaret(new BlockCaret());
		FormattedTextField.OverrideActions.setup(this);

		caretListener = new CaretListener() {
			public void caretUpdate(CaretEvent e)
			{
					//debug(2, "Got a caret event. Position is:" + e.getDot() + "Mark is " + e.getMark());

	if (e.getDot() != e.getMark()) {
					return;
				}

				// Workaround for Swing bug.
				if (getRawText().length() == 0) {
					return;
				}

				if (getMask() != null) {

					if (e.getDot() == displayString.length()) {
						return;
					}

					//=======================================================//
					// If we landed at a position that represents a protected//
					// character, then attempt to advance to the next        //
					// non protected character. If that fails, then attempt  //
					// to backup to first non-protected character. If that   //
					// fails, then set caret at 0                            //
					//=======================================================//
					if (isProtected(e.getDot())) {
						removeCaretListener(caretListener);
						if (getNextNonProtected(e.getDot()) != -1) {
							advanceToFirstNoneProtected(e.getDot());
							//		    debug(2, "Advance from " + e.getDot());
						}
						else if (getPreviousNonProtected(e.getDot()) != -1) {
							if (isProtected(e.getDot() - 1)) {
								int temp = getPreviousNonProtected(e.getDot()) + 1;
								advanceToFirstNoneProtected(temp);
								// debug(2, "Advance from " + e.getDot());
							}
						} 
						else {
							//		    debug(2, "Setting back to 0");
							setCaretPosition(0);
						}

						addCaretListener(caretListener);
					}
				}
				//	   debug(2, "Caret change");
			}
		};

		addCaretListener(caretListener);
		addValidator(new FormattedTextFieldValidator());
	}

	/**
	 * The default constructor.
	 */

	public FormattedTextField()
	{
		this(0);
	}

	/**
	 * Given a string, this method applies the mask associated with the entry field to it. If the
	 * string is invalid, then a null is returned to caller. The string is invalid, if it contains
	 * characters that can not be placed in the slot of the mask string. For example, trying to place
	 * a letter in a numeric field will result in an exception.
	 *
	 * If the text length is less than the mask length, then a validity check is only applied
	 * up to a maximum of the text length.
	 *
	 * @param  text The text to apply the mask to.
	 * @return The text with mask applied to it.
	 * @exception IllegalArgumentException If the text does not conform to the mask specified by the component.
	 */
	public String applyMask(String text) throws IllegalArgumentException 
	{
		if (text == null) {
			text = "";
		}

		if (mask == null) {
			return text;
		}

		if (text.equals("")) {
			return displayString;
		}

		//===================================================================================//
		// Starting with the mask supplied to us initially, for each non protected character //
		// attempt an insertion into the string. At the end, check the string for validity.  //
		//===================================================================================//
		StringBuffer resultBuffer = new StringBuffer(displayString);
		int j = getNextNonProtected(-1);
		int i = 0;

		if ((j < -1) && (text.length() > 0)) {
			throw new IllegalArgumentException("2-Text:\"" + text + "\" is longer than mask specified:"	+ getMask());
		}

		for (i = 0; i < text.length(); i++) {

			if (i > j) {
				throw new IllegalArgumentException("1-Text:\""+ text+ "\" is longer than mask specified:" + getMask());
			}

			if (!isProtected(j)) {
				resultBuffer.setCharAt(j, text.charAt(i));
			}
			j = getNextNonProtected(j);
		}

		int temp = j;

		//=======================================================================//
		// If the user supplied less input than that provided by the mask, then  //
		// for all remaining non protected characters in the mask, change them   //
		// into the fill character.                                              //
		//=======================================================================//
		if (j != -1) {
			for (; j < displayString.length(); j++) {
				if (!isProtected(j)) {
					resultBuffer.setCharAt(j, fillChar);
				}
			}
		}

		if (temp == -1) {
			temp = displayString.length();
		}

		String result = resultBuffer.toString().substring(0, temp);

		if (!isAcceptable(result)) {
			throw new IllegalArgumentException("Text:" + text + " is invalid for mask specified:" + getMask());
		}

		return resultBuffer.toString();
	}


	/**
	 * Returns the mask associated with the text field.
	 * @return The mask or null if no mask is currently associated with the text field.
	 */
	public String getMask() 
	{
		return mask;
	}

	/**
	 * This method returns the text in the component with all masks set.
	 * @return The text in the component.
	 */
	public String getRawText() 
	{
		return super.getText();
	}

	/**
	 * This method returns the text in the component with all protected
	 * characters stripped out.
	 *
	 * @return text - The stripped text.
	 */
	public String getText() 
	{
		String text;

		if (mask == null) {
			text = getRawText();
		} 
		else {
			text = stripMask(getRawText());
		}

		if (isAutoTrimText()) {
			text = text.trim();
		}

		return text;
	}

	/**
	 * The fill character property. This character is used to marked non-protected fields.
	 * The default is '-'
	 *
	 * @return The fill character.
	 */
	public char getFillChar() 
	{
		return fillChar;
	}

	/**
	 * The fill character property. This character is used to marked non-protected fields.
	 * The default is '-'
	 *
	 * @param fillChar The new fill character.
	 */
	public void setFillChar(char fillChar) 
	{
		String text = getText();
		this.fillChar = fillChar;
		displayString = createDisplayString();
		setText(text);
	}

	/**
	 * The display string.
	 *
	 * @return The display string associated with this component. Used by subclassers.
	 */
	protected String getDisplayString() 
	{
		return displayString;
	}

	/**
	 * The character infomation vector.
	 *
	 * @return The character information vector. Used by subclassers.
	 */
	protected Enumeration getCharacterInfo()
	{
		return characterInfo.elements();
	}
	
	/**
	 * Checks if a given string matches the current mask.
	 *
	 * @param The text to check.
	 * @return true if the string is acceptable. false otherwise.
	 *
	 */
	protected boolean isAcceptable(String text) 
	{
		for (int i = 0; i < text.length(); i++) {
			if (!isAcceptable(text.charAt(i), i)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Checks if a given character is acceptable in the slot at the given index.
	 *
	 * @param character The character to test.
	 * @param index     The index of the character.
	 * @return true if the character is acceptable. false otherwise.
	 *
	 */
	protected boolean isAcceptable(char character, int index) 
	{
		CharacterInfo charInfo = (CharacterInfo) characterInfo.elementAt(index);

		if (charInfo.isProtected()) {
			return true;
		}

		if (charInfo.getAcceptableChars() != null) {
			if (charInfo.getAcceptableChars().indexOf(character) == -1) {
				return false;
			}
		}

		switch (charInfo.getMaskCharacter()) {
			case DIGIT_O :
			case DIGIT_R :
				return (Character.isDigit(character)||
				        (Character.isWhitespace(character)));

			case DIGIT_OR_SPACE :
				return ((character == '+')||
				    (character == '-')|| 
				    Character.isDigit(character)|| 
				    Character.isSpaceChar(character));

			case LETTER_R :
			case LETTER_O :
				return (Character.isLetter(character));

			case ALPHA_O :
			case ALPHA_R :
				return (Character.isLetterOrDigit(character) ||
				        (Character.isWhitespace(character)));

			case CHAR_R :
			case CHAR_O :
				return true;

			default :return false;
		}
	}

	/**
	 * Checks if the field at a given index relative to the display string is required.
	 *
	 * @return true if required, false otherwise.
	 */
	public boolean isCharacterRequired(int index) 
	{
		CharacterInfo charInfo = (CharacterInfo) characterInfo.elementAt(index);
		return (charInfo.isRequired());
	}

	/**
	 * The autoShiftOnDelete property.
	 *
	 * @return true if the delete key will shift characters to the left or false
	 * if the action leaves the cursor in its current position without affecting
	 * other characters.
	 *
	 * @see #setAutoShiftOnDelete
	 */
	public boolean isAutoShiftOnDelete() 
	{
		return autoShiftOnDelete;
	}

	/**
	 * The autoTrimText property. The default is true.
	 *
	 * @return true if the text returned from getText() is automatically trimmed.
	 *
	 * @see #getText
	 * @see #setAutoTrimText
	 */
	public boolean isAutoTrimText()
	{
		return autoTrimText;
	}


	/**
	 * This method processes all non-navigational key strokes. The delete and backspace
	 * key are handled in this method.
	 *
	 * @param character The character to process.
	 *
	 */
	protected void processChar(char character) 
	{
		// Must adjust cursor if someone is feeding us key strokes. Like BasicTableUI.
		if (!hasFocus()) {
			requestFocus();
		}

		String myText = getRawText();
		int mySelectionStart = getSelectionStart();
		int mySelectionEnd = getSelectionEnd();
		StringBuffer myStringBuffer = new StringBuffer(myText);
		boolean bs = (character == KeyEvent.VK_BACK_SPACE);
		boolean delete = (character == KeyEvent.VK_DELETE);

		//=====================================================================//
		// Ignore enter keys                                                   //
		//=====================================================================//
		if (character == KeyEvent.VK_ENTER) {
			return;
		}

		// Fix this. Don;t know who is sending this.
		if (character == 0x0D) {
			return;
		}

		//=====================================================================//
		// Handle selections                                                   //
		//=====================================================================//
		debug(1,"\nselectionStart:" + mySelectionStart + " selectionEnd:"+ mySelectionEnd);

		if (mySelectionStart != mySelectionEnd) {
			for (int i = mySelectionStart; i < mySelectionEnd; i++) {
				if (!isProtected(i)) {
					myStringBuffer.setCharAt(i, fillChar);
				}
			}
		}

		//=====================================================================//
		// Handle the delete key                                               //
		//=====================================================================//
		if (delete) {
			int temp = mySelectionStart;

			while ((temp < displayString.length()) && isProtected(temp)) {
				temp++;
			}

			if (temp < displayString.length()) {

				myStringBuffer.setCharAt(temp, fillChar);
				CharacterInfo myCharInfo = (CharacterInfo) (characterInfo.elementAt(temp));
				myCharInfo.setValueProvided(false);
				myText = myStringBuffer.toString();

				if (isAutoShiftOnDelete()) {

					//================================================================//
					// Now given the text we have, we attempt to left shift           //
					// the text and try a pattern match, we continue the              //
					// shifting process until we encounter an error.                  //
					// The way we shift every non protected character to the previous //
					// non protected character.                                       //
					//================================================================//
					StringBuffer shiftStringBuffer = new StringBuffer(myText);
					int currentInsertion = temp;
					int nextNonProtected = currentInsertion;

					for (;;) {
						String result;

						currentInsertion = nextNonProtected;
						nextNonProtected = getNextNonProtected(currentInsertion);

						if (nextNonProtected != -1) {
							shiftStringBuffer.setCharAt(currentInsertion,
							                            shiftStringBuffer.charAt(nextNonProtected));
							shiftStringBuffer.setCharAt(nextNonProtected, 
							                            fillChar);
							result = shiftStringBuffer.toString();
						} 
						else {
							break;
						}

						if (isAcceptable(result.substring(0, currentInsertion + 1))) {
							myText = result;
							myCharInfo = (CharacterInfo) (characterInfo.elementAt(nextNonProtected));
							myCharInfo.setValueProvided(false);
							myCharInfo =(CharacterInfo) (characterInfo.elementAt(currentInsertion));
							myCharInfo.setValueProvided(true);
						} 
						else {
							break;
						}
					}
				}

				setRawText(myText);
				setCaretPosition(temp);
			} 
			else {
				signalError();
			}
			return;
		}

		//=====================================================================//
		// Handle the backspace key                                            //
		//=====================================================================//
		if (bs) {
			int temp = mySelectionStart - 1;

			while ((temp >= 0) && isProtected(temp)) {
				temp--;
			}

			if (temp >= 0) {
				myStringBuffer.setCharAt(temp, fillChar);
				myText = myStringBuffer.toString();
				setRawText(myText);
				CharacterInfo myCharInfo =	(CharacterInfo) (characterInfo.elementAt(temp));
				myCharInfo.setValueProvided(false);
				reverseToFirstNoneProtected(temp + 1);
			} 
			else {
				signalError();
			}
			return;
		}

		if (mask != null) {
			if (mySelectionStart == mask.length()) {
				signalError();
				return;
			}
		}

		if (mySelectionStart == displayString.length()) {
			signalError();
			return;
		}


		while ((mySelectionStart < displayString.length()) && isProtected(mySelectionStart)) {
			mySelectionStart++;
		}

		if (mySelectionStart == displayString.length()) {
			signalError();
			return;
		}

		character = updateCase(character, mySelectionStart);

		try {
			myStringBuffer.setCharAt(mySelectionStart, character);
		} catch (Exception e) {
			myStringBuffer.insert(mySelectionStart, character);
			signalError();
		}
		myText = myStringBuffer.toString();

		debug(1, "Text after string buffer is:" + myText);

		//=====================================================================//
		// Based on the length of the string, we look in the pattern string    //
		// until we find the n'th group, then we match against that.           //
		//=====================================================================//
		if (isAcceptable(character, mySelectionStart)) {
			CharacterInfo myCharInfo =(CharacterInfo) (characterInfo.elementAt(mySelectionStart));
			myCharInfo.setValueProvided(true);
			debug(1, "Match for char:" + character);
			debug(1, "New text is: " + myText);
			setRawText(myText);
			if (mask != null) {
				if (advanceToFirstNoneProtected(mySelectionStart)== mySelectionStart) {
					setCaretPosition(mySelectionStart + 1);
				}
			}
		} 
		else {
			signalError();
			debug(1, "No match for char:" + character);
		}

		debug(1, "Unmasked text is " + getText());
	}

	/**
	 * Toggles the autoShiftOnDelete property. The default is true.
	 *
	 * @param autoShiftOnDelete true shifts the characters. false does not.
	 * @see #isAutoShiftOnDelete
	 */
	public void setAutoShiftOnDelete(boolean autoShiftOnDelete) 
	{
		this.autoShiftOnDelete = autoShiftOnDelete;
	}

	/**
	 * Set the input mask of this component. Please refer to the mask table for more
	 * information on the mask string. If mask is null, this component behaves like a
	 * normal JTextField.
	 *
	 * To set the mask for a US phone number:
	 * <pre>
	 * myTextField.setMask("\\(000\\)-000-0000"); // Notice the double \\ to escape
	 * the paren.
	 * </pre>
	 * @param mask The mask to be set on the component. If null, the component behaves
	 * like the JTextField class. However, the autotrim property is respected even if
	 * no mask is set.
	 */
	public void setMask(String mask) 
	{
		this.mask = mask;

		if (mask != null) {
			populateInternalVectors();
			displayString = createDisplayString();
			setRawText(displayString);
			advanceToFirstNoneProtected(-1);
			debug(1,"Number of elements in displayString is:" + displayString.length());
			debug(1,"Number of elements in protected vector is:" + characterInfo.size());
		}
	}

	/**
	 * This method sets the components text to the supplied text. No checking is done.
	 * @param text The text to set.
	 */
	protected void setRawText(String text) 
	{
		debug(1, "setRawText: " + text);
		super.setText(text);
	}

	/**
	 * This method formats and sets the text into the component. The text should not
	 * have any masked characters in it. This method updates the valid state of the component
	 * after updating the text.
	 *
	 * If the text is null or "", then the state is set to valid. It is considered valid
	 * for a user to initialize the state of the component.
	 *
	 * @param text The text to set on the component.
	 * @exception IllegalArgumentException If the text does not conform to the mask specified by the component.
	 */
	public void setText(String text) 
	{
		if (mask == null) {
			setRawText(text);
			return;
		}

		String originalText = text;

		text = applyMask(text);

		setRawText(text);
		advanceToFirstNoneProtected(-1);

		Enumeration enum = characterInfo.elements();
		int i = 0;

		while (enum.hasMoreElements()) {
			CharacterInfo myCharInfo = (CharacterInfo) enum.nextElement();
			if (myCharInfo.isProtected()) {
				continue;
			}

			if (i < originalText.length()) {
				myCharInfo.setValueProvided(true);
			} 
			else {
				myCharInfo.setValueProvided(false);
			}
			i++;
		}

		if (getText() == null || getText().length() == 0) {
			valid = true;
		} 
		else {
			updateValidState();
		}

		checkValid();
	}

	/**
	 * Sets the autoTrimText property.
	 *
	 * @param autoTrimText . If true, text will be trimmed by getText() otherwise text
	 * is returned as is.
	 *
	 * @see #getText
	 * @see #isAutoTrimText
	 */
	public void setAutoTrimText(boolean autoTrimText) 
	{
		this.autoTrimText = autoTrimText;
	}

	/**
	 * Given a string, this method removes all protected characters from the
	 * string. Fill characters will be replaced with a space.
	 * @param text The text to strip the mask from.
	 * @return The text will all mask characters stripped.
	 */
	public String stripMask(String text)
	{
		StringBuffer result = new StringBuffer(24);

		for (int i = 0; i < text.length(); i++) {
			if (!isProtected(i)) {
				char resultChar = text.charAt(i);
				if (resultChar == fillChar) {
					resultChar = ' ';
				}
				result.append(resultChar);
			}
		}
		return result.toString();
	}

	/**
	 * Returns the recommended dimensions to properly display this component.
	 * This is a standard Java AWT method which gets called to determine
	 * the recommended size of this component.
	 *
	 * @see #getMinimumSize
	 */
	public Dimension getPreferredSize() {

		Font f = getFont();

		if (f != null) {

			FontMetrics fm = getFontMetrics(f);

			if (mask != null && (getColumns() == 0)) {

				//======================================================//
				// Total all the protected characters                   //
				//======================================================//
				int length = displayString.length();
				String weightString = "9";
				int total = 0;

				// Find out if all are digits and shrink.
				for (int i = 0; i < length; i++) {

					CharacterInfo myCharInfo = (CharacterInfo) (characterInfo.elementAt(i));
					char myChar = myCharInfo.getMaskCharacter();

					if (myCharInfo.isProtected()) {
						total += fm.charWidth(myChar);
					} 
					else if ((myChar == DIGIT_R) ||(myChar == DIGIT_O)	||(myChar == DIGIT_OR_SPACE)) {
						total += fm.charWidth('9');
					} 
					else {
						total += fm.charWidth('W');
					}
				}

				return new Dimension(total + 8, fm.getHeight() + 4);
			}
		}

		return super.getPreferredSize();
	}

	/**
	 * Returns the minimum dimensions to properly display this component.
	 * This is a standard Java AWT method which gets called to determine
	 * the minimum size of this component.
	 *
	 * @see #getPreferredSize
	 */
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	/**
	 * Determines whether a character at a given index position is protected. The string
	 * this method acts on is the display string.  A character is protected if
	 * it is not one of the predefined masked characters. Escaped characters are
	 * handled specially.
	 * @param The index of the character to check. This index is relative
	 *        to the display string. The string with escape sequences removed.
	 * @return true if character is protected, false otherwise.
	 */
	protected boolean isProtected(int index) 
	{
		CharacterInfo charInfo = (CharacterInfo) characterInfo.elementAt(index);
		return (charInfo.protection);
	}

	/**
	 * Given a starting index, this method advances the caret to the first non-protected
	 * character. If none are found, the caret is left in its current position.
	 * @param The index of the character to start from. -1 starts from the beginning.
	 * @return The new index.
	 */
	protected int advanceToFirstNoneProtected(int startIndex) 
	{
		int temp = getNextNonProtected(startIndex);

		if (temp == -1) {
			temp = startIndex;
		}

		setCaretPosition(temp);
		return (temp);
	}

	/**
	 * Return the next non-protected character index.
	 * @param The index of the character to start from. -1 starts from the beginning.
	 * @return The next non-protected character index.
	 */
	protected int getNextNonProtected(int startIndex) 
	{
		int temp = startIndex + 1;

		if (temp >= displayString.length()) {
			temp = -1;
		} 
		else {
			for (;;) {
				if (!isProtected(temp)) {
					break;
				}
				if (++temp >= displayString.length()) {
					break;
				}
			}

			if (temp >= displayString.length()) {
				temp = -1;
			}
		}

		return (temp);
	}

	/**
	 * Given a starting index, this method reverses the caret to the first non-protected
	 * character. If none are found, the caret is left in its current position.
	 * @param The index of the character to start from. -1 starts from the end.
	 * @return The new index.
	 */
	protected int reverseToFirstNoneProtected(int startIndex) 
	{
		if (startIndex == -1) {
			startIndex = displayString.length();
		}

		int temp;

		temp = getPreviousNonProtected(startIndex);

		if (temp == -1) {
			temp = startIndex;
		}

		setCaretPosition(temp);
		return (temp);
	}

	/**
	 * Given a starting index, this method returns the previous non-protected index.
	 * character. If none are found 0 is returned.
	 * @param The index of the character to start from. -1 starts from the end.
	 * @return The previous non-protected index.
	 */
	protected int getPreviousNonProtected(int startIndex) 
	{
		int temp = startIndex - 1;

		if (temp < 0) return startIndex;

		for (;;) {
			if (!isProtected(temp))	break;
			temp--;
			if (temp < 0) break;
		}

		temp = (temp >= 0) ? temp : -1;

		return (temp);
	}

	protected String createDisplayString()
	{
		String result = "";

		Enumeration enum = characterInfo.elements();

		while (enum.hasMoreElements()) {
			CharacterInfo charInfo = (CharacterInfo) enum.nextElement();
			if (!charInfo.isProtected()) {
				result += fillChar;
			} 
			else {
				result += charInfo.getMaskCharacter();
			}
		}

		debug(1, "Display string is:" + result);
		return (result);
	}

	private boolean isReserved(char c)
	{
		for (int i = 0; i < reservedChars.length; i++) {
			if (reservedChars[i] == c) {
				return true;
			}
		}
		return false;
	}

	protected void populateInternalVectors() 
	{
		CharacterInfo charInfo;

		characterInfo.removeAllElements();

		if (mask != null) {

			int length = mask.length();
			int currentCase = CASE_LEAVE_ALONE;

			for (int i = 0; i < length; i++) {

				boolean protect = false;
				int fieldCase = currentCase;
				char maskChar = mask.charAt(i);
				boolean required = false;
				boolean discard = false;
				String acceptableChars = null;

				switch (maskChar) {
					case DIGIT_R :
						required = true;
						break;

					case DIGIT_O :
						required = false;
						break;

					case DIGIT_OR_SPACE :
						break;

					case LETTER_O :
						required = false;
						break;

					case LETTER_R :
						required = true;
						break;

					case ALPHA_O :
						break;

					case ALPHA_R :
						required = true;
						break;

					case CHAR_O :
						break;

					case CHAR_R :
						required = true;
						break;

					case TO_UPPER :
						discard = true;
						currentCase = CASE_UP;
						break;

					case TO_LOWER :
						discard = true;
						currentCase = CASE_LOWER;
						break;

					case ESCAPE :
						maskChar = mask.charAt(++i);

						if (length != mask.length()) {
							length++;
						}

						protect = true;
						required = true;
						fieldCase = CASE_LEAVE_ALONE;
						break;

					default :
						protect = true;
						fieldCase = CASE_LEAVE_ALONE;
						required = true;
				}

				if (!discard) {
					charInfo = new CharacterInfo();
					charInfo.protection = protect;
					charInfo.maskCharacter = maskChar;
					charInfo.caseFold = fieldCase;
					charInfo.required = required;
					charInfo.setValueProvided(false);
					characterInfo.addElement(charInfo);
				}
			}
		}
	}

	private final char updateCase(char character, int index) 
	{
		if (!Character.isLetter(character)) {
			return character;
		}

		CharacterInfo charInfo = (CharacterInfo) characterInfo.elementAt(index);

		switch (charInfo.getCase()) {
			case CASE_UP :
				character = Character.toUpperCase(character);
				break;

			case CASE_LOWER :
				character = Character.toLowerCase(character);
				break;
		}

		return character;
	}

	/**
	 *  Override to take into account the mask. The diplayed text has protected characters into
	 * account and we must skip over them. So if we have a mask of 9999-9999-9999-9999 we need to
	 * skip over the '-' when replacing the numbers when pasting.
	 */
	public void replaceSelection(String content) {

		String text = getRawText();
		if (text != null) {
			Caret aCaret = getCaret();
			StringBuffer buff = new StringBuffer(text);
			int p0 = Math.min(aCaret.getDot(), aCaret.getMark());
			int p1 = Math.max(aCaret.getDot(), aCaret.getMark());

			if (content != null && content.length() > 0) {
				int i = p0;
				int j = 0;
				buff.setCharAt(i, content.charAt(j++));

				for (;;) {
					i = getNextNonProtected(i);
					if (i < 0) {
						break;
					}
					try {
						buff.setCharAt(i, content.charAt(j++));
					} 
					catch (StringIndexOutOfBoundsException se) {
						break;
					}
				}
				setRawText(buff.toString());
				aCaret.setDot(i);
			}
		}
	}

	/**
	 * Override to properly handle the mask.
	 */
	public void copy() {
		try {
			Caret aCaret = getCaret();
			Clipboard clipboard = getToolkit().getSystemClipboard();
			int p0 = Math.min(aCaret.getDot(), aCaret.getMark());
			int p1 = Math.max(aCaret.getDot(), aCaret.getMark());
			if (p0 != p1) {
				Document doc = getDocument();
				String srcData = doc.getText(p0, p1 - p0);
				StringSelection contents = new StringSelection(stripMask(srcData));
				clipboard.setContents(contents, aClipboardOwner);
			}
		} catch (BadLocationException e) {
			getToolkit().beep();
		}
	}

	/**
	 * Override to properly handle the mask on the text.
	 */
	public void cut() 
	{
		if (isEditable() && isEnabled()) {
			try {
				Caret aCaret = getCaret();
				Clipboard clipboard = getToolkit().getSystemClipboard();
				int p0 = Math.min(aCaret.getDot(), aCaret.getMark());
				int p1 = Math.max(aCaret.getDot(), aCaret.getMark());
				if (p0 != p1) {
					Document doc = getDocument();
					String srcData = doc.getText(p0, p1 - p0);
					StringSelection contents = new StringSelection(stripMask(srcData));
					clipboard.setContents(contents, aClipboardOwner);
					replaceSelection(COM.novusnet.vision.java.utility.textformatting.Formatter.stringOfCharacters(fillChar,srcData.length() - 1));
					//  	       setText("6011");
				}
			} catch (BadLocationException e) {
			}
		} else {
			getToolkit().beep();
		}
	}

	/**
	 * Override to properly insert the text.
	 */
	public void paste() 
	{
		Clipboard clipboard = getToolkit().getSystemClipboard();
		Transferable content = clipboard.getContents(this);
		if (content != null) {
			try {
				String dstData =(String) (content.getTransferData(DataFlavor.stringFlavor));
				replaceSelection(dstData);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	static class OverrideActions
	{
		static Action actions[] = {	new LeftAction(),
				                    new RightAction(),
				                    new HomeAction(),
				                    new EndAction(),
				                    new DeleteAction(),
				                    new BackSpaceAction()};

		static Action oldLeftHandler = null;
		static Action oldRightHandler = null;
		static Action oldHomeHandler = null;
		static Action oldEndHandler = null;
		static Action oldKeyTypedHandler = null;
		static Action oldDeleteHandler = null;
		static Action oldBackSpaceHandler = null;

		public static void setup(JTextComponent component) 
		{
			init(component);

			component.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent e) 
				{
					if (e.getPropertyName().equals("UI")) {
						JTextComponent myComponent = (JTextComponent) e.getSource();
						// BUGID 4193026 Remove the if check.
						if (myComponent.getUI() != null) {
							init(myComponent);
						}
					}
				}
			});
		}

		private static void init(JTextComponent component)
		{
			String mapName = "FormattedTextFieldActionMap" + UIManager.getLookAndFeel().getName();
			Keymap map = JTextComponent.getKeymap(mapName);

			oldLeftHandler      = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0));
			oldRightHandler     = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0));
			oldHomeHandler      = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0));
			oldEndHandler       = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_END, 0));
			oldKeyTypedHandler  = component.getKeymap().getDefaultAction();
			oldDeleteHandler    = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
			oldBackSpaceHandler = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0));


			//=======================================================//
			// A key map is global so create it since none has
			//=======================================================//

			if (map == null) {
				map = JTextComponent.addKeymap(mapName, component.getKeymap());
				map.setDefaultAction(new UndefinedAction());
			}

			component.setKeymap(map);

			//  	    component.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE,0), "none");
			//  	    component.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE,0), "none");

			for (int i = 0; i < actions.length; i++) {

				component.getActionMap().put(actions[i].getValue(Action.NAME),actions[i]);
			}

			component.setCaret(new BlockCaret());
		}

		public static class LeftAction extends TextAction 
		{
			public LeftAction() 
			{
				super(DefaultEditorKit.backwardAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf = (FormattedTextField) getTextComponent(e);
				if (tf.getMask() != null) {
					int originalPosition = tf.getSelectionStart();
					int result = tf.reverseToFirstNoneProtected(originalPosition);
					if (result == originalPosition)	{
						tf.signalError();
					}
				} 
				else {
					oldLeftHandler.actionPerformed(e);
				}
			}
		}

		public static class RightAction extends TextAction 
		{
			public RightAction()
			{
				super(DefaultEditorKit.forwardAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf =	(FormattedTextField) getTextComponent(e);

				if (tf.getMask() != null){

					int originalPosition = tf.getSelectionStart();
					int result = tf.advanceToFirstNoneProtected(originalPosition);

					if (originalPosition == tf.displayString.length()) {
						tf.signalError();
					} 
					else if ((result == originalPosition)&& !tf.isProtected(originalPosition)){
						tf.setCaretPosition(result + 1);
						if (originalPosition == result + 1) {
							tf.signalError();
						}
					} 
					else if ((result == originalPosition) && tf.isProtected(originalPosition)) {
						tf.signalError();
					}
				} 
				else {
					oldRightHandler.actionPerformed(e);
				}
			}
		}

		public static class HomeAction extends TextAction
		{
			public HomeAction() 
			{
				super(DefaultEditorKit.beginAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf = (FormattedTextField) getTextComponent(e);

				if (tf.getMask() != null) {
					int originalPosition = tf.getSelectionStart();
					int result = tf.advanceToFirstNoneProtected(-1);

					if (result == originalPosition) {
						tf.signalError();
					}
				} 
				else {
					oldHomeHandler.actionPerformed(e);
				}
			}
		}

		public static class EndAction extends TextAction
		 
		{
			public EndAction() 
			{
				super(DefaultEditorKit.endAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf =	(FormattedTextField) getTextComponent(e);

				if (tf.getMask() != null) {

					int originalPosition = tf.getSelectionStart();


					//=======================================================
					// Find the first non protected field that hasno value
					//=======================================================
					Enumeration enum = tf.getCharacterInfo();
					int i = 0;

					while (enum.hasMoreElements()) {
						CharacterInfo charInfo = (CharacterInfo) enum.nextElement();
						if (!charInfo.isProtected()	&& !charInfo.isValueProvided()) {
							break;
						}
						i++;
					}

					if (i < tf.getDisplayString().length()) {
						tf.setCaretPosition(i);
					} 
					else {
						int result = tf.reverseToFirstNoneProtected(-1);

						if (!tf.isProtected(result)) {
							if (originalPosition == result + 1) {
								tf.signalError();
							}
							tf.setCaretPosition(result + 1);
						} 
						else if (result == originalPosition) {
							tf.signalError();
						} 
						else {
							oldEndHandler.actionPerformed(e);
						}
					}
				}
			}
		}

		public static class UndefinedAction extends TextAction 
		{
			public UndefinedAction() 
			{
				super(DefaultEditorKit.defaultKeyTypedAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf =	(FormattedTextField) getTextComponent(e);

				// Under some JDK's, this is sent twice once at delete/backspace and once here.
				// We ignore this one for these two cases.
				if ((e.getActionCommand() != null)	&& 
				   ((e.getActionCommand().charAt(0)	== (char) KeyEvent.VK_DELETE) ||
					(e.getActionCommand().charAt(0)	== (char) KeyEvent.VK_BACK_SPACE))) {
					return;
				}

				if (tf.isEditable() && tf.getMask() != null) {
					((FormattedTextField) getTextComponent(e)).processChar(e.getActionCommand().charAt(0));
				} 
				else {
					oldKeyTypedHandler.actionPerformed(e);
				}
			}
		}

		public static class BackSpaceAction extends TextAction 
		{
			public BackSpaceAction() 
			{
				super(DefaultEditorKit.deletePrevCharAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf = (FormattedTextField) getTextComponent(e);

				if (tf.isEditable() && tf.getMask() != null) {
					((FormattedTextField) getTextComponent(e)).processChar((char) KeyEvent.VK_BACK_SPACE);

				} 
				else {
					oldBackSpaceHandler.actionPerformed(e);
				}
			}
		}

		public static class DeleteAction extends TextAction 
		{
			public DeleteAction() 
			{
				super(DefaultEditorKit.deleteNextCharAction);
			}

			public void actionPerformed(ActionEvent e) 
			{
				FormattedTextField tf = (FormattedTextField) getTextComponent(e);

				if (tf.isEditable() && tf.getMask() != null) {
					((FormattedTextField) getTextComponent(e)).processChar((char) KeyEvent.VK_DELETE);
				} 
				else {
					oldDeleteHandler.actionPerformed(e);
				}
			}
		}

	}
}









