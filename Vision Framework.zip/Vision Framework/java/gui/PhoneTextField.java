package COM.novusnet.vision.java.gui;


/**
 * This text field represents a phone number. The mask is locale specific
 * and is extracted from the PhoneNumber locale object.
 * <p>
 * TBD
 * <p>
 * The mask is currently hardcoded, please remove the hardcode when the
 * phone code locale is move to
 * <p>
 * vision.
 */
public  class  PhoneTextField  extends  FormattedTextField
{
   /**
    * Default constructor.
    *  
    */   
   public    PhoneTextField ()
   {
      setMask("\\(000\\)\\-000\\-0000");
   }
}
