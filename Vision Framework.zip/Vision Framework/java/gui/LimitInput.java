package COM.novusnet.vision.java.gui;

import javax.swing.text.JTextComponent;

/**
 * A utility class to limit input to a JTextComponent and company. The
 * main benefit of this class is that input can be limited without
 * having to subclass the JTextComponent in addition to using the JTextComponent
 * keyboard handling framework.
 *
 * Use the limit(...) class method and supply it with the 
 * JTextComponent and an upper limit.
 *
 */
public class LimitInput
{  
   int    limit              = 32;

   /**
    * Use this method to limit the input to JTextComponent.
    * @param component The text component to limit the input to.
    * @param limit     The number of characters to limit.
    */
   public static void limit(JTextComponent component, int limit)
   {
      component.setDocument(new LimitedStyledDocument(limit));
   }  
}