package COM.novusnet.vision.java.gui;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;



public  class AccessibleTableSelectionListener
		implements javax.swing.event.ListSelectionListener {

		JTable innerTable;

		/**
		* AccessibleTableSelectionListener constructor
		*/
		public AccessibleTableSelectionListener(JTable table) {
			super();
			innerTable = table;
		}

		/**
		 * Detects selection change within Memos table
		 */
		public void valueChanged(ListSelectionEvent e) {

			if (e.getValueIsAdjusting())
					return;

			ListSelectionModel lsm = (ListSelectionModel) e.getSource();

			if (innerTable.getRowCount() > 0) //&& !lsm.isSelectionEmpty())
				System.out.println("Setting AccessibleName..Passing Table");
			    setAccessibleNameForSelectedCell(innerTable);
		}


		/**
		* Method sets the accessible name for the cell that is
		* selected. The column header and row values are concatenated
		* making the AccessibleName read the column and selected value.
		* 
		* @param table javax.swing.JTable
		*/
		
		public void setAccessibleNameForSelectedCell(JTable table) {

			int selectedRow = table.getSelectionModel().getLeadSelectionIndex();
			System.out.println("Selected Row = " + selectedRow);
			int selectedCol = table.getSelectedColumn();
			System.out.println("Selected Column = " + selectedCol);

			if (selectedRow >= 0 && selectedCol >= 0 && table.getCellRenderer(selectedRow, selectedCol)
					instanceof DefaultTableCellRenderer) {
				String selectedCellValue =
					table.getValueAt(selectedRow, selectedCol) == null
						? " "
						: table.getValueAt(selectedRow, selectedCol).toString();
				String selectedColName =
					table.getColumnName(selectedCol) == null
						? ""
						: table.getColumnName(selectedCol).toString();
						
				System.out.println("SelectedCellValue = " + selectedCellValue);
				System.out.println("SelectedColumnName = " + selectedColName);
				
				TableCellRenderer renderer = (TableCellRenderer) table.getCellRenderer(selectedRow, selectedCol);
				Component comp =
					renderer.getTableCellRendererComponent(
						table,
						selectedCellValue,
						true,
						true,
						selectedRow,
						selectedCol);
						
				comp.getAccessibleContext().setAccessibleName(
					selectedColName + " " + selectedCellValue); // Setting the AccessibleName	
			}
		}
	} //End of class AccessibleTableSelectionListener
