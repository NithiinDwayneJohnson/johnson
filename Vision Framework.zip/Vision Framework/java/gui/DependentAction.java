package COM.novusnet.vision.java.gui;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.Action;

/**
  The need for this was felt when we were trying to use a single abstractAction
  to be represented in 2 slightly different ways; on the toolbar with icon only
  and on the menu bar with icon and text. We also need the ability to "fallback"
  on the text whenever an icon was not present.

  The ExtendedToolBar class extends JToolBar by adding a single method
  addAction( AbstractAction ) so as to allow special handling of Actions'
  icons & their names. If an icon is present on the Action the Name is
  suppressed else the name is displayed. This is achieved by creating
  a DependentAction from an the AbstractAction which was to be added.
  The DependentAction is identical to AbstractAction in all respects
  except the following
  1. The tooltip is enabled for the DependentAction so that the Action.SHORT_DESCRIPTION
     becomes the ToolTip.
  2. The icon is displayed instead of the name & icon. If the icon is 
     absent then the name is displayed.
*/

class DependentAction extends AbstractAction implements PropertyChangeListener
{

   AbstractAction action;

   public DependentAction( AbstractAction action )
   {
      this.action = action;
      action.addPropertyChangeListener( this );
   }

   public AbstractAction getAction( )
   {
      return action;
   }

   public void setAction( AbstractAction action )
   {
      this.action = action;
   }

   public void actionPerformed( ActionEvent e ) 
   {
      action.actionPerformed(e);
   }

   public void propertyChange( PropertyChangeEvent e )
   {
      super.setEnabled( action.isEnabled() );
   }

   public void addPropertyChangeListener( PropertyChangeListener l )
   {
      action.addPropertyChangeListener(l);
   }

   protected Object clone() throws CloneNotSupportedException
   {
      DependentAction retValue = (DependentAction)super.clone();
      retValue.setAction( action ); 
      return retValue;
   }

   public void removePropertyChangeListener( PropertyChangeListener l )
   {
      action.removePropertyChangeListener(l);
   }

   public void putValue( String property, Object obj )
   {
      if ( Action.NAME.equals( property ) ) 
         return ;

      action.putValue( property, obj );
   }

   public boolean isEnabled()
   {
      return action.isEnabled();
   }

   public void setEnabled( boolean flag )
   {
      action.setEnabled( flag );
      // The above action will cause a propertyChange on the the delegate action
      // Since this object listens to the delegate we get that propertyChangeEvent
      // to which we respond by calling super.setEnabled
   }

   public Object getValue( String property )
   {
      if ( Action.NAME.equals( property ) && action.getValue(Action.SMALL_ICON)!=null ) 
         return null;

      return action.getValue( property );
   }
}
