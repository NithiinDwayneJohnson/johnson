/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExceptionPane.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 07 at 11:46:47 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.accessibility.Accessible;
import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleRole;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExceptionPane                                           */
/**
 * An exception pane is a JOption pane that displays exception information.
 * The user can toggle back and forth between summary and detail mode by
 * pressing the appropriate buttons.
 * <p>
 * This pane is I18N compliant.
 */
/*======================================================================*/
public  class  ExceptionPane  extends  JOptionPane implements Accessible
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExceptionPane:Attributes preserve=yes

//##End   ExceptionPane:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private Throwable exception;

    /*==================================================================*/
    /* Friend Attributes                                                */
    /*==================================================================*/
   JDialog   dialog      = null;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   static  String    cancelText  = null;
   static  String    summaryText = null;
   static  String    detailText  = null;
   static  String    errorText   = null;
   static  String    infoText    = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ExceptionPane                                    */
        /*                                                              */
        /**
         * Constructor that takes the parent component, message text and
         * exception instance. If the parent is null, then the
         * JOptionPane.getRootFrame() is used for a parent. If the message
         * text is null, the exception text is used for text.
         *  
         * @param       parent:Component
         * @param       message:String
         * @param       e:Throwable
         */
        /*==============================================================*/
   public    ExceptionPane (
                            Component  parent,
                            String     message,
                            Throwable  e
                           )
   {
//##Begin ExceptionPane:ExceptionPane(Component,String,Throwable) preserve=yes
      final    JButton      cancelButton = new JButton(cancelText);
      final    JButton      detailButton = new JButton(detailText);
      final    JTextArea    textArea     = new JTextArea();
      final    JScrollPane  scrollPane   = new JScrollPane(textArea);
               Object[]     messages     = new Object[2];

      if (parent == null) {
	 parent = JOptionPane.getRootFrame();
      }

	  	
      textArea.setEditable(false);
      textArea.setRows(6);
      textArea.setColumns(50);

      scrollPane.setVisible(false);
      scrollPane.setBorder( new TitledBorder(infoText));
      add( scrollPane );

      if (message == null) {
		 message = e.getMessage();
		 //If the message is too long, the pane will go beyond the screen size. RLS 10-2005
		 // 11-07-2005, need to avoid null pointer from e.getMessage().
		 if (message != null && message.length() > 300)
		 	message = message.substring(0,300);
      }

      messages[0] = message == null ? e.toString() : message;
      messages[1] = scrollPane;

      Object options[] = { cancelButton, detailButton };

      setOptions(options);
      setMessage(messages);
      setMessageType(JOptionPane.ERROR_MESSAGE);

      detailButton.setActionCommand("detail");
      detailButton.setNextFocusableComponent(cancelButton);

      final Component parentComponent = parent;

      cancelButton.setNextFocusableComponent(detailButton);
      cancelButton.addActionListener( new ActionListener() {
	 public void actionPerformed(ActionEvent e) 
	 {
	    dialog.setVisible(false);
	    dialog.dispose();
	    if(parentComponent instanceof JComponent) ((JComponent)parentComponent).paintImmediately(parentComponent.getBounds(new Rectangle()));
	    if(parentComponent != null) parentComponent.repaint(5); // force a repaint of the parent object to clean up
	    return;
	 } 
      });

      detailButton.addActionListener( new ActionListener() {
	 public void actionPerformed(ActionEvent e) 
	 {
	    if (e.getActionCommand().equals("detail")) {
	       StringWriter myStringWriter = new StringWriter();
	       PrintWriter  myPrintWriter  = new PrintWriter(myStringWriter);
	       exception.printStackTrace(myPrintWriter);	    
	       textArea.setText(myStringWriter.getBuffer().toString());
	       /* IKUMAR 07.26.2002 - To make the exception details accessible */
	       textArea.getAccessibleContext().setAccessibleName(myStringWriter.getBuffer().toString());
	       textArea.getAccessibleContext().setAccessibleDescription(myStringWriter.getBuffer().toString());
	       textArea.setBackground(getBackground());
	       scrollPane.setVisible(true);
	       detailButton.setText(summaryText);
	       detailButton.setActionCommand("summary");
	       //Swing bug #4343970 Remove once fixed
	       SwingUtilities.invokeLater(new Runnable() {
		      public void run() {
			 SwingUtilities.invokeLater(new Runnable() {
				public void run() {
				   scrollPane.getViewport().setViewPosition(new Point(0, 0));
				}
			     });
		      }
		   });
	    } else if (e.getActionCommand().equals("summary")) {
	       scrollPane.setVisible(false);
	       detailButton.setText(detailText);
	       detailButton.setActionCommand("detail");
	    }

	    dialog.pack();
 	    dialog.setLocationRelativeTo(dialog.getParent());
	 }
      });      

      //====================================
      // Save exception for later use
      //====================================
      exception = e;

      //====================================
      // Create and show dialog
      //====================================
      dialog = createDialog(parent, errorText); 
      dialog.show(); 
//##End   ExceptionPane:ExceptionPane(Component,String,Throwable)
   }

        /*==============================================================*/
        /* OPERATION:  ExceptionPane                                    */
        /*                                                              */
        /**
         * Constructor that takes message text and exception instance. The
         * parent is assumed to be JOptionPane.getRootFrame(). If the
         * message text is null, the exception text is used for text.
         *  
         * @param       message:String
         * @param       e:Throwable
         */
        /*==============================================================*/
   public    ExceptionPane (
                            String     message,
                            Throwable  e
                           )
   {
//##Begin ExceptionPane:ExceptionPane(String,Throwable) preserve=yes
      this(null, message, e);
//##End   ExceptionPane:ExceptionPane(String,Throwable)
   }

        /*==============================================================*/
        /* OPERATION:  ExceptionPane                                    */
        /*                                                              */
        /**
         * Constructor that takes an exception instance. The parent is
         * assumed to be JOptionPane.getRootFrame(). The summary text is
         * extracted from the exception instance.
         *  
         * @param       e:Throwable
         */
        /*==============================================================*/
   public    ExceptionPane (
                            Throwable  e
                           )
   {
//##Begin ExceptionPane:ExceptionPane(Throwable) preserve=yes
      this(null, null, e);
//##End   ExceptionPane:ExceptionPane(Throwable)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getException                                     */
        /*                                                              */
        /**
         * This method returns the value of the "exception" attribute.
         *  
         * @return      :Throwable -
         *                 The value of the "exception" attribute.
         */
        /*==============================================================*/
   public  Throwable  getException (
                                   )
   {
//##Begin ExceptionPane:getException() preserve=no

      return (exception);

//##End   ExceptionPane:getException()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setException                                     */
        /*                                                              */
        /**
         * This method sets the value of the "exception" attribute.
         *  
         * @param       aValue:Throwable
         *                 The value of the "exception" attribute.
         */
        /*==============================================================*/
   public  void  setException (
                               Throwable  aValue
                              )
   {
//##Begin ExceptionPane:setException(Throwable) preserve=no

      exception = aValue;

//##End   ExceptionPane:setException(Throwable)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getMaxCharactersPerLineCount                     */
        /*                                                              */
        /**
         * Override to return the maximum number of characters.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxCharactersPerLineCount (
                                             )
   {
//##Begin ExceptionPane:getMaxCharactersPerLineCount() preserve=yes
      return 60;
//##End   ExceptionPane:getMaxCharactersPerLineCount()
   }

   //Accessibility
    public AccessibleContext getAccessibleContext() {
        if (accessibleContext == null) {
            accessibleContext = new AccessibleExceptionPane();
        }
        return accessibleContext;
    }

    /**
     * Accessiblity support.
     * <p>
     * <strong>Warning:</strong>
     * Serialized objects of this class will not be compatible with
     * future Swing releases.  The current serialization support is appropriate
     * for short term storage or RMI between applications running the same
     * version of Swing.  A future release of Swing will provide support for
     * long term persistence.
     */
    protected class AccessibleExceptionPane extends AccessibleJComponent {

        /**
         * Get the role of this object.
         *
         * @return an instance of AccessibleRole describing the role of the object
         * @see AccessibleRole
         */
       public AccessibleRole getAccessibleRole() {
	  return AccessibleRole.OPTION_PANE;
       }
       
       public String getAccessibleName() {
	  Object[] objs = (Object[])getMessage();
	  return ( (String)objs[0] );
       }
    } // inner class AccessibleJOptionPane

    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the ExceptionPane class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin ExceptionPane:main(String[]) preserve=yes
      JFrame myFrame = new JFrame();
      myFrame.setSize(800,600);
      myFrame.setTitle("Tester app");
      JButton myButton = new JButton("Press me");

      myButton.addActionListener(new ActionListener() {
	 public void actionPerformed(ActionEvent e) {
	    String        myString = null;

	    try {
	       myString.length();
	    }
	    catch(Throwable exception) {
	       ExceptionPane myExceptionPane = new ExceptionPane(null, exception);
	    }
	 }
      });

      JOptionPane.setRootFrame(myFrame);
      myFrame.getContentPane().add(myButton, BorderLayout.NORTH);
      myFrame.setVisible(true);
//##End   ExceptionPane:main(String[])
   }


    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin ExceptionPane:StaticInitializer preserve=yes
   static {
      ResourceResolver aResolver = new ResourceResolver ();      
      aResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);

      cancelText  = aResolver.getStringResource("cancelText", ExceptionPane.class);
      summaryText = aResolver.getStringResource("summaryText", ExceptionPane.class);
      detailText  = aResolver.getStringResource("detailText", ExceptionPane.class);
      errorText   = aResolver.getStringResource("errorText", ExceptionPane.class);
      infoText    = aResolver.getStringResource("infoText", ExceptionPane.class);
   }
//##End   ExceptionPane:StaticInitializer

}
