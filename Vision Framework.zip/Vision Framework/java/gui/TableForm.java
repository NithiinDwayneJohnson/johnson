/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableForm.java                                          */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 19 at 15:26:11 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableForm                                               */
/**
 * The TablePanel class is a convenience class that contains a table. It
 * provide a scrollpane for the table. 
 */
/*======================================================================*/
public  class  TableForm  extends  FormComponent
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableForm:Attributes preserve=yes

//##End   TableForm:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private boolean     autoResizeColumns = true;
   private JTable      table             = null;
   private JTextField  msgField          = new JTextField(20);
   private JScrollPane scrollPane        = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TableForm                                        */
        /*                                                              */
        /**
         * Constructor.
         *  
         */
        /*==============================================================*/
   public    TableForm (
                       )
   {
//##Begin TableForm:TableForm() preserve=yes
      setLayout( new BoxLayout(this, BoxLayout.Y_AXIS) );
      setTable(new JTable());     
      setUI(TableFormUI.createUI(this));
      msgField.setEditable(false);
//##End   TableForm:TableForm()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isAutoResizeColumns                              */
        /*                                                              */
        /**
         * This method returns the value of when set, the table columns are
         * set to their data size.
         *  
         * @return      :boolean -
         *                 The value of when set, the table columns are set
         *                 to their data size.
         */
        /*==============================================================*/
   public  boolean  isAutoResizeColumns (
                                        )
   {
//##Begin TableForm:isAutoResizeColumns() preserve=no

      return (autoResizeColumns);

//##End   TableForm:isAutoResizeColumns()
   }
 
        /*==============================================================*/
        /* OPERATION:  getTable                                         */
        /*                                                              */
        /**
         * This method returns the value of the "table" attribute.
         *  
         * @return      :JTable -
         *                 The value of the "table" attribute.
         */
        /*==============================================================*/
   public  JTable  getTable (
                            )
   {
//##Begin TableForm:getTable() preserve=no

      return (table);

//##End   TableForm:getTable()
   }

        /*==============================================================*/
        /* OPERATION:  getScrollPane                                    */
        /*                                                              */
        /**
         * This method returns the value of the "scrollPane" attribute.
         *  
         * @return      :JScrollPane -
         *                 The value of the "scrollPane" attribute.
         */
        /*==============================================================*/
   public  JScrollPane  getScrollPane (
                                      )
   {
//##Begin TableForm:getScrollPane() preserve=no

      return (scrollPane);

//##End   TableForm:getScrollPane()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setAutoResizeColumns                             */
        /*                                                              */
        /**
         * This method sets the value of when set, the table columns are
         * set to their data size.
         *  
         * @param       aValue:boolean
         *                 The value of when set, the table columns are set
         *                 to their data size.
         */
        /*==============================================================*/
   public  void  setAutoResizeColumns (
                                       boolean  aValue
                                      )
   {
//##Begin TableForm:setAutoResizeColumns(boolean) preserve=no

      autoResizeColumns = aValue;

//##End   TableForm:setAutoResizeColumns(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setTable                                         */
        /*                                                              */
        /**
         * This method sets the value of the "table" attribute.
         *  
         * @param       aValue:JTable
         *                 The value of the "table" attribute.
         */
        /*==============================================================*/
   public  void  setTable (
                           JTable  aValue
                          )
   {
//##Begin TableForm:setTable(JTable) preserve=yes

      JTable oldValue = table;

      if (aValue == null) {
	 throw new IllegalArgumentException("Table value can not be null");
      }

      if (getScrollPane() != null) {
	 remove(getScrollPane());
      }

      table = aValue;

      setScrollPane(new JScrollPane(table));      
      add(getScrollPane(), BorderLayout.CENTER);

      firePropertyChange ( "table", oldValue, table);

      
//##End   TableForm:setTable(JTable)
   }

        /*==============================================================*/
        /* OPERATION:  setScrollPane                                    */
        /*                                                              */
        /**
         * This method sets the value of the "scrollPane" attribute.
         *  
         * @param       aValue:JScrollPane
         *                 The value of the "scrollPane" attribute.
         */
        /*==============================================================*/
   private  void  setScrollPane (
                                 JScrollPane  aValue
                                )
   {
//##Begin TableForm:setScrollPane(JScrollPane) preserve=no

      scrollPane = aValue;

//##End   TableForm:setScrollPane(JScrollPane)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * @param       aContainer:AbstractTableModel
         */
        /*==============================================================*/
   public  void  setModel (
                           AbstractTableModel  aContainer
                          )
   {
//##Begin TableForm:setModel(AbstractTableModel) preserve=yes
      super.setModel(aContainer);
//##End   TableForm:setModel(AbstractTableModel)
   }

   private void removeMsgField()
   {
      if ( this.isAncestorOf(msgField) )
      {
         remove ( msgField );
      }
   }
   private void addMsgField(String text)
   {
      if ( !this.isAncestorOf(msgField) )
      {
         add ( msgField );
      }
      msgField.setText(text);
   }
   public void setMsgtext(String text)
   {
      if ( text == null )
      {
        removeMsgField();
      } else {
        addMsgField(text);
      }
      this.revalidate();
   } 
   public String getMsgtext()
   {
     if ( msgField == null ) return null;
     return msgField.getText();
   }

    /*==============================================================*/
    /* The following methods create an API within this class to     */
    /* quickly enable and disable mouse clicks on a table,          */
    /* effectively rendering tables as read-only.                   */
    /* These functions make calls on the underlying UI object so    */
    /* users of these functions can simply enable clicks directly   */
    /* on a TableForm.                                              */
    /* This functionality was added to enforce restrictions on the  */
    /* ability to apply APRs based on mainframe security values.    */
    /*==============================================================*/

    /*==============================================================*/
    /* OPERATION: disableMouseListener                              */
    /*                                                              */
    /**
     * Convenience method to quickly disable mouse clicks on a table
     */
    /*==============================================================*/
    public void disableMouseListener() {
//##Begin TableForm:disableMouseListener() preserve=yes

	((TableFormUI)getInstalledUI()).disableTableMouseListener();

//##End   TableForm:disableMouseListener()
    }

    /*==============================================================*/
    /* OPERATION: enableMouseListener                               */
    /*                                                              */
    /**
     * Convenience method to quickly enable mouse clicks on a table
     */
    /*==============================================================*/
    public void enableMouseListener() {
//##Begin TableForm:enableMouseListener() preserve=yes

	((TableFormUI)getInstalledUI()).enableTableMouseListener();

//##End   TableForm:enableMouseListener()
    }

    /*==============================================================*/
    /* OPERATION: enableTableMouseListener                          */
    /*                                                              */
    /**
     * @param: boolean - enable/diable mouse clicks
     *
     * Convenience method to quickly enable or disable mouse clicks on a table
     */
    /*==============================================================*/
    public void enableMouseListener(boolean b) {
//##Begin TableForm:enableMouseListener(boolean) preserve=yes

	if(b) enableMouseListener();
	else disableMouseListener();

//##End   TableForm:enableMouseListener(boolean)
    }

}
