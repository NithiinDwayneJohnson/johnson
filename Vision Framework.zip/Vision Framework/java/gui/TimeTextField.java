package COM.novusnet.vision.java.gui;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * This class represents a Time entry field. Rather than have the user set
 * a mask for the Time, this class allows the user to choose for a
 * predefined set. This set will be locale independent. Please use, the
 * getTime(), setTime() methods rather than setText() and getText().
 */
public  class  TimeTextField  extends  FormattedTextField
{
   /**
    * This is the default style, in which the full Time is
    * displayed. Please note that for a given locale, the
    * elements may shift around so the client should never
    * make an assumption about the order of the fields in this
    * component.
    */

   public static final int      STYLE_HHmmss = 0;

   /**
    * This show only the month and the year portion of a Time.
    */
   public static final int      STYLE_HHmm   = 1;

   private             int      style          = STYLE_HHmm;
   private             Calendar time;

   /**
    * The default constructor.
    *  
    */   
   public TimeTextField ()
   {
      setStyle(STYLE_HHmm);
      addValidator(new TimeTextFieldValidator());
   }

   /**
    * This method returns the value of the style of the field.
    *  
    * @return      :int -
    *                 The value of the style of the field.
    */    
   public int getStyle ()
   {
      return (style);
   }

   /**
    * This method returns the value of the "Time" attribute.
    *  
    * @return      :Calendar -
    *                 The value of the "Time" attribute.
    */
   public  Calendar  getTime (
                             )
   {
      return time;
   }

   /**
    * This method sets the value of the style of the field.
    *  
    * @param  aValue The value of the style of the field.
    */   
   public  void  setStyle (int  aValue)
   {
      // Based on the style, create a mask text and set it as out mask   
      // The mask should be retrieved from the resource file. FIX        

      switch (aValue) {
	 case STYLE_HHmmss:
	    setMask("00:00:00");
	    break;

	 case STYLE_HHmm:
	    setMask("00:00");
	    break;
      }      

      style = aValue;
   }

   /**
    * This method sets the value of the "Time" attribute.
    *  
    * @param       aValue:Calendar
    *                 The value of the "Time" attribute.
    */   
   public  void  setTime (
                          Calendar  aValue
                         )
   {
      SimpleDateFormat df       = null;
      Calendar         oldValue = time;

      if (time == aValue) {
	 return;
      }

      if (time != null) {
	 if (time.equals(aValue)) {
	    return;
	 }
      }

      time = aValue;

      if (time != null) {
	 switch (style) {
	    case STYLE_HHmmss:
	       df = new SimpleDateFormat("HHmmss");
	       break;
	       
	    case STYLE_HHmm:
	       df = new SimpleDateFormat("HHmm");
	       break;
	 }
	 setText(df.format(time.getTime()));
      }
      else {
	 setText("");
      }

      firePropertyChange("time", oldValue, time);
   }

   /**
    * This method sets the value of the "Time" attribute in text format.
    *  
    * @param text The new Time.
    *                 
    */   
   public  void  setTime (
                          String  text
                         )
   {
      SimpleDateFormat df              = null;
      ParsePosition    myParsePosition = new ParsePosition(0);

      switch (getStyle()) {
	 case TimeTextField.STYLE_HHmmss:
	    df = new SimpleDateFormat("HHmmss");
	    break;
	    
	 case TimeTextField.STYLE_HHmm:
	    df = new SimpleDateFormat("HHmm");
	    break;
      }
      
      df.setLenient(false); 
      
      try {	 
	 Date myTime = df.parse(text, myParsePosition);
	 time = Calendar.getInstance();
	 time.setTime(myTime);
	 setTime(time);
      }
      catch(Throwable e) {
      }
   }

   /**
    * Override to handle focus changes. 
    *
    */
   protected void processFocusLost()
   {
      super.processFocusLost();
      if (hasValidData()) {
	 setTime(getText());
      }
   }
}



