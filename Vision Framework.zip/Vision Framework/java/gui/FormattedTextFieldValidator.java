package COM.novusnet.vision.java.gui;

import java.util.Enumeration;

/**
 * This validator checks whether the required fields of a formatted text field have been supplied.
 */
public class FormattedTextFieldValidator extends DefaultValidator
{
   /**
    * Checks the validity of a formatted text component. If the field is marked as optional
    * and no data has been entered, then the return value is true. This overrides any required
    * mask character in the field.
    *
    * @param value     The value to check.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component)
   {
      if ( component.getText().length() == 0) {
	 if (!component.isRequired()) {
	    return true;
	 }
      }

      Enumeration enum = ((FormattedTextField)component).getCharacterInfo();

      while(enum.hasMoreElements()) {
	 FormattedTextField.CharacterInfo charInfo = (FormattedTextField.CharacterInfo)enum.nextElement();
	 if (charInfo.isRequired() && !charInfo.isValueProvided()) {	    
	    return false;
	 }
      }
      return true;
   }
}
