package COM.novusnet.vision.java.gui;


/**
 * The Validator interface is invoked by an ExtendedTextField of subclasses, to determine if the contents
 * of the field are valid. Typically, a user creates a validator and adds it to the list of validators.
 */
public interface Validator
{
   /**
    * Checks the validity of a text component.
    * @param component The ExtendedTextField component to check against.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component);
}
