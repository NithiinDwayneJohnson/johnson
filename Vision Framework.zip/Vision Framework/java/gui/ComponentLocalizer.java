/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ComponentLocalizer.java                                 */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 0.5                          */
/* Emitter  :   JavaFileEmitter    Version 0.5                          */
/* Generated:   1997 October 30 at 11:07:47 GMT+00:00                   */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Component;
import java.awt.Container;
import java.util.ListResourceBundle;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ComponentLocalizer                                      */
/**
 * This class is used to localize GUI components. Its main task is to
 * ensure that a GUI component is displaying the proper text for a given
 * locale. The text is loaded from resource files and set on the
 * components. It is important to note that only static text is replaced.
 * Text that resides in controls such as combo boxes and tables is not
 * replaced by this class. It is the responsibility of the developer to
 * enusre that those components contain the proper data for a given locale.
 * This class provides default behavior for replacing static text without
 * forcing the component to be subclassed.
 * <p>
 * A component however, can implement an option Localizable interface in
 * which it can take over the localization process. There are some reasons
 * why a developer might wish to do this. If a given component's locale can
 * be hot switched during program execution, then a developer can use the
 * Localizable interface as an indication of the user wishes. The static
 * text replacement can still be delegated to the component localizer, but
 * dynamic data can be "refetched" from the database using the proper
 * locale.
 * <p>
 * A good example of hot switching will be a screen that displays text to
 * be read for a caller. If the caller happens to be spanish, the user can
 * click on the spanish button to obtain a spanish version of the text fro
 * a database.
 * <p>
 * Most applications however, will have the locale set at program
 * initialization and have no need for hot switching.
 * <p>
 * When replacing static text on GUI components, the Localizer needs to
 * figure out the proper "setText" method to call on the component. Since
 * not all components derive from the same heirarchy, special handling code
 * for some components must be hardcoded. Luckily, most JFC components
 * derive from abstract buttons so the need for hardcodes is minimal.
 * Another approach would be to create a component handler interface that
 * can handle a given component. This handler interface will be loaded
 * dynamically at runtime. Although more elegant, it has a potential
 * drawback when a handler does not exist for a component. This can impede
 * performance since the dynamic load will always force a trip to the web
 * server looking for a nonexistent class. Another approach will be to let
 * the ComponentLocalizer ahead of time be aware of existing handlers. The
 * list can be specified in a text file, or added dynamically via a static
 * method. This approach also suffers from performance problems since most
 * classes are usualy handled by one handler (AbstractButton and its
 * subclasses). The handler lookup code will be complex and slow. We chose
 * the MessageFormat approach, in which the known types are hardcoded into
 * the class. This approach does not suffer performance problems but have
 * the drawback of opening the code whenever a new handler is needed.
 * <p>
 * The Localizer also needs to look up a resource that matches the text to
 * be substituted. Every component that is Localizable, must have a name
 * associated with it. This can be done by calling the awt setName() method
 * on the component by a parent.
 */
/*======================================================================*/
public  class  ComponentLocalizer
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ComponentLocalizer:Attributes preserve=yes
   private Component          lastProcessedComponentParent = null;
   private ListResourceBundle lastResource                 = null;
   private Class              lastResourceClass            = null;
   private ResourceResolver   rr                           = null;
//##End   ComponentLocalizer:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private Locale locale = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getLocale                                        */
        /*                                                              */
        /**
         * This method returns the value of the "locale" attribute.
         *  
         * @return      :Locale -
         *                 The value of the "locale" attribute.
         */
        /*==============================================================*/
   public  Locale  getLocale (
                             )
   {
//##Begin ComponentLocalizer:getLocale() preserve=no

      return (locale);

//##End   ComponentLocalizer:getLocale()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setLocale                                        */
        /*                                                              */
        /**
         * This method sets the value of the "locale" attribute.
         *  
         * @param       aValue:Locale
         *                 The value of the "locale" attribute.
         */
        /*==============================================================*/
   private  void  setLocale (
                             Locale  aValue
                            )
   {
//##Begin ComponentLocalizer:setLocale(Locale) preserve=no
      locale = aValue;
//##End   ComponentLocalizer:setLocale(Locale)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ComponentLocalizer                               */
        /*                                                              */
        /**
         * Constructor.
         *  
         * @param       aLocale:Locale
         */
        /*==============================================================*/
   public    ComponentLocalizer (
                                 Locale  aLocale
                                )
   {
//##Begin ComponentLocalizer:ComponentLocalizer(Locale) preserve=yes
      if (aLocale == null) {
	 aLocale = Locale.getDefault();
      }

      setLocale(aLocale);

//##End   ComponentLocalizer:ComponentLocalizer(Locale)
   }

        /*==============================================================*/
        /* OPERATION:  ComponentLocalizer                               */
        /*                                                              */
        /**
         * Constructor.
         *  
         */
        /*==============================================================*/
   public    ComponentLocalizer (
                                )
   {
//##Begin ComponentLocalizer:ComponentLocalizer() preserve=yes
      this(null);
//##End   ComponentLocalizer:ComponentLocalizer()
   }

        /*==============================================================*/
        /* OPERATION:  localize                                         */
        /*                                                              */
        /**
         * This method is called so that a components localizable
         * attributes can be changed The attributes consists mainly of text
         * but can be an image.
         *  
         * @param       aComponent:Component
         */
        /*==============================================================*/
   public  void  localize (
                           Component  aComponent
                          )
   {
//##Begin ComponentLocalizer:localize(Component) preserve=yes

      //======================================================================
      // For each non-container component, the name of the component
      // is looked up in the resource file using the resource resolver.
      // If a hit is made, we change the text of the component using
      // one of the resource helpers that knows how to deal with the component
      // class.
      //======================================================================

      aComponent.invalidate();

      if (aComponent instanceof Container) {

	 Component[] myComponents = ((Container)aComponent).getComponents();

	 processComponent(aComponent);

	 //=========================================
	 // Go thru the children and localize them.
	 //=========================================

	 for (int i = 0 ; i < myComponents.length ; i++) {
	    Component myComponent = myComponents[i];
	    localize(myComponent);
	 }
      }
      else {
	 processComponent(aComponent);
	 return;
      }

      aComponent.validate();
      return;

//##End   ComponentLocalizer:localize(Component)
   }

        /*==============================================================*/
        /* OPERATION:  performDefaultLocalization                       */
        /*                                                              */
        /**
         * Performs default localization by invoking the appropriate
         * handler for a component.
         *  
         * @param       aComponent:Component
         */
        /*==============================================================*/
   public  void  performDefaultLocalization (
                                             Component  aComponent
                                            )
   {
//##Begin ComponentLocalizer:performDefaultLocalization(Component) preserve=yes

      String componentName = aComponent.getName();

      //==================================================================================
      // If the last processed component has the same immediate parent as this component,
      // then try to locate the resource string by using the last resource
      // object returned for the last processed component.
      //==================================================================================
      try {
	 if (lastProcessedComponentParent != null) {
	    if (lastProcessedComponentParent == aComponent.getParent()) {
	       String label = lastResource.getString(componentName);
	       changeComponentText(aComponent , label);	       
	       return;
	    }
	 }
      }
      catch(MissingResourceException ignore) {
      }

      //===============================================
      // Go thru all the parents as normal
      //===============================================

      Vector parents = getNonSystemParents(aComponent);

      //================================================================
      // Every component has a parent. We get the list of parents which 
      // we use as references to locate resources. 
      //================================================================

      for (int i = 0; i < parents.size() ; i++) {

	 Component parent = (Component) parents.elementAt(i);

	 rr = new ResourceResolver("javax.swing.JComponent", 
				   getLocale());

	 String label = rr.getStringResource(componentName , parent.getClass());

	 if (label != null) {	    
	    //=========================================
	    // Save the component for speed purposes.
	    //=========================================
	    lastProcessedComponentParent = aComponent.getParent();
	    lastResourceClass            = parent.getClass();
	    lastResource                 = rr.getLastMatchResourceClass();
	    changeComponentText(aComponent , label);
	    break;
	 }
      }

      return;

//##End   ComponentLocalizer:performDefaultLocalization(Component)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleAbstractButton                             */
        /*                                                              */
        /**
         * Localizes abstract buttons.
         *  
         * @param       aComponent:AbstractButton
         * @param       aText:String
         */
        /*==============================================================*/
   protected  void  handleAbstractButton (
                                          AbstractButton  aComponent,
                                          String          aText
                                         )
   {
//##Begin ComponentLocalizer:handleAbstractButton(AbstractButton,String) preserve=yes
      aComponent.setText(aText);
//##End   ComponentLocalizer:handleAbstractButton(AbstractButton,String)
   }

        /*==============================================================*/
        /* OPERATION:  handleJLabel                                     */
        /*                                                              */
        /**
         * Localizes labels.
         *  
         * @param       aComponent:JLabel
         * @param       aText:String
         */
        /*==============================================================*/
   protected  void  handleJLabel (
                                  JLabel  aComponent,
                                  String  aText
                                 )
   {
//##Begin ComponentLocalizer:handleJLabel(JLabel,String) preserve=yes
      aComponent.setText(aText);
//##End   ComponentLocalizer:handleJLabel(JLabel,String)
   }

        /*==============================================================*/
        /* OPERATION:  handleJTable                                     */
        /*                                                              */
        /**
         * Localizes tables.
         *  
         * @param       aComponent:JTable
         * @param       aText:String
         */
        /*==============================================================*/
   protected  void  handleJTable (
                                  JTable  aComponent,
                                  String  aText
                                 )
   {
//##Begin ComponentLocalizer:handleJTable(JTable,String) preserve=yes
      TableColumnModel columnModel = aComponent.getColumnModel();
      int              columnCount = columnModel.getColumnCount();
      TableColumn      column      = null;
      String           columnLabel = null;
      Object           columnID    = null;

      //===========================================================================
      // Go thru all columns using the column ID as a Key into the resource table.
      //===========================================================================      
      for (int i = 0; i < columnCount ; i++) {
	 column   = columnModel.getColumn(i);
	 columnID = column.getIdentifier();
	 if (columnID instanceof String) {
	    columnLabel  = rr.getStringResource( (String)columnID , lastResourceClass);
	    if (columnLabel != null) {
	       column.setHeaderValue(columnLabel);
	    }	    
	 }
      }

      return;

//##End   ComponentLocalizer:handleJTable(JTable,String)
   }

        /*==============================================================*/
        /* OPERATION:  handleTitledBorder                               */
        /*                                                              */
        /**
         * Localizes components that have titled borders.
         *  
         * @param       aComponent:JComponent
         * @param       aText:String
         */
        /*==============================================================*/
   protected  void  handleTitledBorder (
                                        JComponent  aComponent,
                                        String      aText
                                       )
   {
//##Begin ComponentLocalizer:handleTitledBorder(JComponent,String) preserve=yes
      String titleText  = rr.getStringResource(aComponent.getName() + "Title", 
					       lastResourceClass);
      if (titleText != null) {
	 ((TitledBorder)aComponent.getBorder()).setTitle(titleText);
      }
//##End   ComponentLocalizer:handleTitledBorder(JComponent,String)
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  processComponent                                 */
        /*                                                              */
        /**
         * @param       aComponent:Component
         */
        /*==============================================================*/
   private  void  processComponent (
                                    Component  aComponent
                                   )
   {
//##Begin ComponentLocalizer:processComponent(Component) preserve=yes
      String componentName = aComponent.getName();

      //=======================================
      // Must have a name
      //=======================================
      if (componentName == null) {
	 return;
      }

      //=================================================================
      // If the component implements the optional Localizable interface 
      // then call it.
      //=================================================================
      if (aComponent.getClass().isAssignableFrom(Localizable.class)) {
	 ((Localizable)aComponent).localize(this);
      }
      else {
	 performDefaultLocalization(aComponent);
      }
//##End   ComponentLocalizer:processComponent(Component)
   }

        /*==============================================================*/
        /* OPERATION:  changeComponentText                              */
        /*                                                              */
        /**
         * @param       aComponent:Component
         * @param       aText:String
         */
        /*==============================================================*/
   private  void  changeComponentText (
                                       Component  aComponent,
                                       String     aText
                                      )
   {
//##Begin ComponentLocalizer:changeComponentText(Component,String) preserve=yes

      if (aComponent instanceof JComponent) {
	 if (((JComponent)aComponent).getBorder() instanceof TitledBorder) {
	    handleTitledBorder((JComponent)aComponent, null);
	 }	 
      } 

      if (aComponent instanceof JLabel) {
	 handleJLabel((JLabel)aComponent, aText);
      } 
      else if (aComponent instanceof AbstractButton) {
	 handleAbstractButton((AbstractButton)aComponent , aText);
      }	  
      else if (aComponent instanceof JTable) {
	 handleJTable((JTable)aComponent , aText);
      }

//##End   ComponentLocalizer:changeComponentText(Component,String)
   }

        /*==============================================================*/
        /* OPERATION:  getNonSystemParents                              */
        /*                                                              */
        /**
         * Returns the parents of the component excluding system parents.
         *  
         * @param       aComponent:Component
         * @return      :Vector -
         */
        /*==============================================================*/
   private  Vector  getNonSystemParents (
                                         Component  aComponent
                                        )
   {
//##Begin ComponentLocalizer:getNonSystemParents(Component) preserve=yes

      Vector     myParents = new Vector();
      Component  aParent  = null;

      aParent = aComponent.getParent();

      while (aParent != null) {

	 String className = aParent.getClass().getName();

	 if ( (!className.startsWith("javax.swing")) &&
	      (!className.startsWith("java")) ) {
	    myParents.addElement(aParent);
	 }

	 aParent = aParent.getParent();
      }

      return (myParents);

//##End   ComponentLocalizer:getNonSystemParents(Component)
   }


}
