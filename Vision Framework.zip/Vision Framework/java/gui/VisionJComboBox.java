package COM.novusnet.vision.java.gui;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class VisionJComboBox extends JComboBox
{
   public VisionJComboBox()  {}
   public VisionJComboBox(ComboBoxModel aModel) { super(aModel); }
   public VisionJComboBox(Object[] items) { super(items); } 
   public VisionJComboBox(Vector items) { super (items); } 

   JTextField field = null;
   int displayIdx = -1;
   public void installPowerTyping()
   {
      field = (JTextField)getEditor().getEditorComponent();
      field.getDocument().addDocumentListener( new DocumentListener() {
         public void changedUpdate(DocumentEvent e) 
         {
            System.out.println(e);
         }
         public void insertUpdate(DocumentEvent e) 
         {
            System.out.println(e);
            String text = field.getText();
            ComboBoxModel mdl = getModel();
            for ( int i = 0; i < mdl.getSize(); i++ )
            {
                String stringItem = (String)mdl.getElementAt(i);
                System.out.println("Text  = " + text + " isp = " + stringItem );
                if ( stringItem.startsWith(text) )
                {
                   // POST a msg on the event handling thread to
                   // populate current index
                   displayIdx = i;
                   SwingUtilities.invokeLater( new Runnable() {
                      public void run ()
                      {
//                         System.out.println("Setting selected index " + displayIdx );
                         setSelectedIndex(displayIdx);
                      }
                   } );
                   return ;
                }
            } 
         }
         public void removeUpdate(DocumentEvent e) 
         {
            System.out.println(e);
         }
      });
   } 
}
class SampleUsage
{
   VisionJComboBox j = new VisionJComboBox();
   public SampleUsage()
   {
      j.setEditable(true);
      j.installPowerTyping();
  }
}
