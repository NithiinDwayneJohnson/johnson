package COM.novusnet.vision.java.gui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;

import javax.swing.Action;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.JTextComponent;
import javax.swing.text.Keymap;
import javax.swing.text.TextAction;


// BIG todo. Should have a State object for when the object has focus.

/**
 * <p>The NumberEditField handles numeric editing. The user can specify
 * a numeric format as defined the DecimalFormat class. There are 2 modes
 * associated with this class. An edit mode and a non-edit mode formally known
 * as edit and display mode. With each mode, a user can associate a format string. For
 * example, during currency edits, the user might not wish to show the currency 
 * character but wishes to show it when component loses focus. If no format
 * is specified, the default locale currency format is used as a format.
 *
 * <p>Many helper methods are available to alter the format without changing the format string itself. 
 * setMaxNumberOfIntegerDigits() is an example of such a method.
 *
 * <p>The alignment of this class is to the right by default. Users can change this
 * property by calling the setHorizontalAlignment() method of JTextField.
 *
 * <p>A user can specify a lower and upper limit for the value entered by a user. If a user
 * tries to set a value that is out of range, the component is marked invalid. The component
 * starts out in an invalid state. The user can always call hasValidData() to determine
 * if the component has valid data.
 *
 * <p>When specifying a format with fractional digits, it is important that you call
 * setMaximumIntegerDigits() as this class can not determine the number of
 * integer digits to allow. This is only necessary if the format has fractions
 * in it. For non fractional formats, this class automatically determines the number
 * of integer digits to allow.
 *
 * <p>Callers should never call setText() directly. Instead the setValue() and getValue()
 * methods should be used.
 *
 * <p>The minus button is used to toggled between a negative and a positive value. Remeber
 * that pressing the minus button does not necessarly cause a '-' to appear. Check the
 * negative prefix of the locale for the correct symbol(s).
 *
 */
public abstract class NumberEditField extends ExtendedTextField
{
   protected DecimalFormat   editFormatter;
   protected DecimalFormat   displayFormatter;
   private   static Number   zeroDouble        = new Double(0.0);
   private   Number          value             = null;
   protected double          lower             = Double.NEGATIVE_INFINITY;
   protected double          upper             = Double.MAX_VALUE;
   private   boolean         tempInsert        = false;
   private   boolean         wasInInsert       = false;
   private   boolean         negativeAllowed   = true;
   private   boolean         autoAlign         = false;
   private   static          OverrideActions overrideActions   = new OverrideActions();

   /**
    * Constructs a NumberEditField. The number of default columns is 10.
    */
   public NumberEditField()
   {      
      this(10);
   }
   
   /**
    * Constructor that takes the number of columns to display
    * @param columns Number of columns to display.
    */
   public NumberEditField(int columns)
   {
      super(columns);
      NumberEditField.OverrideActions.setup(this);
      setInsertMode(false);
      setHorizontalAlignment(SwingConstants.RIGHT); 
      editFormatter = createEditFormatter();
      displayFormatter = createDisplayFormatter();
      addValidator(new NumberEditFieldValidator());
      setDefaultValue(zeroDouble);
   }

   /**
    * If set, the autoAlign property causes the alignment to change
    * to left, if the component is editable or right if not.
    * @see #isAutoAlign
    */
   public void setAutoAlign(boolean autoAlign)
   {
      this.autoAlign = autoAlign;
      setEditable(isEditable());
   }

   /**
    * Returns the autoAlign property.
    */
   public boolean isAutoAlign()
   {
      return autoAlign;
   }

   /**
    * Override to fix the alignment if need be.
    * @see #setAutoAlign
    */
   public void setEditable(boolean editable)
   {
      super.setEditable(editable);

      if (autoAlign) {
	 if (editable) {
	    setHorizontalAlignment(SwingConstants.RIGHT); 
	 }
	 else {
	    setHorizontalAlignment(SwingConstants.LEFT); 
	 }
      }
   }

   /**
    * Sets the default value of the field. The default value is used in case of 
    * an error.
    * @param number The default value. This can be null.
    */
   public void setDefaultValue(Number number)
   {
      super.setDefaultValue(number);

      if (value == null) {
	 setValue(number);
      }
   }

   /**
    * Sets the valid  range of the field.
    * @param lower The lower range.
    * @param upper The upper range.
    * @exception IllegalArgumentException If the range is invalid.
    */
   public void setRange(double lower, double upper) throws IllegalArgumentException
   {
      if (lower > upper) {
	 throw new IllegalArgumentException("Invalid range set. lower is greater than upper");
      }

      this.lower = lower;
      this.upper = upper;
      return;
   }

   /**
    * Returns the lower range currently set.
    */
   public double getLowerRange()
   {
      return lower;
   }

   /**
    * Returns the upper range currently set.
    */
   public double getUpperRange()
   {
      return upper;
   }
			   
   public boolean isInsertMode()
   {
      return ((BlockCaret)getCaret()).isInsertMode();
   }

   public void setInsertMode(boolean insertMode)
   {
      if (!insertMode && tempInsert) {
	 return;
      }

      ((BlockCaret)getCaret()).setInsertMode(insertMode);
   }
      
   /**
    * Sets the maximum number of integer digits allowed during an edit. This is only necessary
    * when a format contains fractions.
    * @param number The number of integer digits to allow.
    */
   public void setMaxNumberOfIntegerDigits(int number)
   {
      editFormatter.setMaximumIntegerDigits(Math.min(number, 12));
      setDefaultText();
   }

   /**
    * Sets the maximum number of fraction digits allowed during an edit. This is only necessary
    * when a format contains fractions. Note that for formatting purposes, the minumum number
    * of fraction digits is set to the maximum number.
    * @param number The number of fraction digits to allow.
    */
   public void setMaxNumberOfFractionDigits(int number)
   {
      editFormatter.setMinimumFractionDigits(number);
      editFormatter.setMaximumFractionDigits(number);
      setDefaultText();
   }

   /**
    * Sets the maximum number of integer digits allowed during display mode. This is only necessary
    * when a format contains fractions.
    * @param number The number of integer digits to allow.
    */
   public void setMaxNumberOfDisplayIntegerDigits(int number)
   {
      displayFormatter.setMaximumIntegerDigits(number);
      setDefaultText();
   }

   /**
    * Sets the maximum number of fraction digits allowed during display mode. This is only necessary
    * when a format contains fractions. Note that for formatting purposes, the minumum number
    * of fraction digits is set to the maximum number.
    * @param number The number of fraction digits to allow.
    */
   public void setMaxNumberOfDisplayFractionDigits(int number)
   {
      displayFormatter.setMinimumFractionDigits(number);
      displayFormatter.setMaximumFractionDigits(number);
      setDefaultText();
   }

   /**
    * Sets the Positive prefix of an edit formatter.
    * @param string The positive prefix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setPositivePrefix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      editFormatter.setPositivePrefix(string);
      setDefaultText();
   }

   /**
    * Sets the Positive suffix of an edit formatter.
    * @param string The positive suffix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setPositiveSuffix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      editFormatter.setPositiveSuffix(string);
      setDefaultText();
   }

   /**
    * Sets the Negative prefix of an edit formatter.
    * @param string The negative prefix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setNegativePrefix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      editFormatter.setNegativePrefix(string);
      setDefaultText();
   }

   /**
    * Sets the Negative suffix of an edit formatter.
    * @param string The negative suffix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setNegativeSuffix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      editFormatter.setNegativeSuffix(string);
      setDefaultText();
   }

   /**
    * Sets the Positive prefix of the display formatter.
    * @param string The positive prefix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setDisplayPositivePrefix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      displayFormatter.setPositivePrefix(string);
      setDefaultText();
   }

   /**
    * Sets the Positive suffix of an display formatter.
    * @param string The positive suffix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setDisplayPositiveSuffix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      displayFormatter.setPositiveSuffix(string);
      setDefaultText();
   }

   /**
    * Sets the Negative prefix of an display formatter.
    * @param string The negative prefix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setDisplayNegativePrefix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      displayFormatter.setNegativePrefix(string);
      setDefaultText();
   }

   /**
    * Sets the Negative suffix of an display formatter.
    * @param string The negative suffix.
    * @exception IllegalArgumentException If the string is null.
    */
   public void setDisplayNegativeSuffix(String string) throws IllegalArgumentException
   {
      if (string == null) {
	 throw new IllegalArgumentException("Null value is not acceptable");
      }

      displayFormatter.setNegativeSuffix(string);
      setDefaultText();
   }

   /**
    * This method toggles the grouping separator visibility. i.e show the comma in the US.
    * @param flag If true, then show the grouping separator otherwise hide.
    */
   public void setGroupingSeparatorVisible(boolean flag)
   {
      displayFormatter.setGroupingSize(0);
      editFormatter.setGroupingSize(0);
   }

   /**
    * Sets the current value and updates the valid state. 
    *
    * @param number The new value. If number is null, the value is set to the default
    * value. If number is out of range, the component is marked as invalid. If the number
    * is less than zero and negatives are not allowed, the value is set to a default value and
    * the component is marked as invalid.
    *
    * @param number The new value.
    */
   public void setValue(Number number)
   {
      updateValue(number, hasFocus());
   }

   /**
    * Gets the current value. If the value is invalid or unavailable a null
    * is returned. The value returned if the field is being edited is whatever value
    * that was last set.
    *
    * @return The current value.
    */
   public Number getValue()
   {     
      return value;
   }

   /**
    * Override to switch between display and edit formats and update the new value.
    */
   protected void processFocusGained()
   {
      super.processFocusGained();

      Number number;
      String myText;

      number = getValue();

      if (number == null) {
	 number = zeroDouble;
      }

      myText = editFormatter.format(number.doubleValue());      
      setText(myText);
      updateCaretPosition(-1, true);
   }

   /**
    * Override to switch between display and edit formats and update the new value.
    */
   protected void processFocusLost()
   {
      commitFieldValue();
   }

   /**
    * Commits the current contents if valid, otherwise marks the component as invalid. This is usefull
    * for committing values without any focus processing.
    *
    */
   public void commitFieldValue()
   {
      Number number;

      // Parse the number using the editFormatter and set the new
      // value.
      try {
	 number = getNumberForText(getText());

	 // Commented out this section since we want the error state to be updated.
 	 if (number.equals(getValue())) {
 	    return;
 	 }

	 updateValue(number, hasFocus());
      }
      catch(Throwable exception) {
	 exception.printStackTrace();
      }   
   }

   /**
    * Sets the current edit pattern. Refer to class description for more information.
    *
    * @param mask The new pattern. If this is null, the default pattern is used.
    */
   public void setEditFormat(String format)
   {
      if (format == null) {
	 format = ((DecimalFormat)NumberFormat.getCurrencyInstance()).toPattern();
      }

      editFormatter.applyPattern(format);

      //==========================================//
      // Calculate the number of integer digits   //
      //==========================================//
      int  start         = 0;
      char decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      
      int maxIntegerDigits = 0;

      if (editFormatter.getMinimumFractionDigits() == 0) {
	 for (; start < format.length(); ++start) {
	    char ch = format.charAt(start);

	    if (ch ==';') {
	       break;
	    }

	    if (ch == '#') {
	       ++maxIntegerDigits;
	    }
	    if (ch == '0') {
	       ++maxIntegerDigits;
	    }
	    if (ch == decimalSymbol) break;
	 }
	 editFormatter.setMaximumIntegerDigits(maxIntegerDigits);
      }

      setValue(getValue());

      // For edit purposes and a consistent look, always set the minimum fraction digits to the
      // maximum number.
      editFormatter.setMinimumFractionDigits(editFormatter.getMaximumFractionDigits());
   }

   /**
    * Sets the current display pattern. Refer to class description for more information.
    *
    * @param format The new pattern. If this is null, the default pattern is used.
    */
   public void setDisplayFormat(String format)
   {
      displayFormatter.applyPattern(format);
   }

   /**
    * A quick way to enable/disable negative numbers during edit without altering the format
    * string manually. Even if negatives are allowed part of the edit format string, this 
    * flag overrides the format string.
    *
    * @param The new prefix
    */
   public void setNegativeAllowed(boolean allow)
   {
      negativeAllowed = allow;
   }

   /**
    * Returns the negativeAllowed attribute.
    *
    * @return 
    */
   public boolean isNegativeAllowed()
   {
      return negativeAllowed;
   }

   /**
    * This method creates a decimal edit formatter. Subclassers can override this method
    * to provide custom formatters (subclasses of DecimalFormat). The default edit
    * format has the currency symbol removed, with a negative prefix of "-" localized
    * and a negative suffix of nothing.
    */
   protected DecimalFormat createEditFormatter()
   {
      DecimalFormat myFormat =  (DecimalFormat)NumberFormat.getCurrencyInstance();
      myFormat.setMaximumIntegerDigits(12);
      return myFormat;
   }

   /**
    * This method creates a decimal display formatter. Subclassers can override this method
    * to provide custom formatters (subclasses of DecimalFormat).
    */
   protected DecimalFormat createDisplayFormatter()
   {
      DecimalFormat myFormat =  (DecimalFormat)NumberFormat.getCurrencyInstance();
      myFormat.setMaximumIntegerDigits(12);
      return myFormat;
   }
   
   /**
    * Process a key stroke
    */
   protected boolean processChar(char c)
   {	 	
      // Must adjust cursor if someone is feeding us key strokes. Like BasicTableUI.
      if (!hasFocus()) {
	 requestFocus();
      }

      char    decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      int     decimalIndex  = getText().indexOf("" + decimalSymbol);
      int     caret         = getCaretPosition();
      String  myText        = getText();
      String  originalText  = myText;

      //=====================================================================//
      // Ignore enter keys                                                   //
      //=====================================================================//
      if (c == KeyEvent.VK_ENTER) {
	 return true;
      }

      if (c == 0x0D) {
	 return true;
      }

      //==========================================================================//
      // If the entered character is a decimal separator and                      //
      // the edit format does contain a decimal separator and this is the         //
      // first decimal separator, then accept it.                                 //
      //==========================================================================//
      if ( c == decimalSymbol ) {
	 if ( (editFormatter.getMaximumFractionDigits() > 0) &&
	      (getText().indexOf("" + c) == -1) ) {
	    return true;
	 }

	 // If there is a decimal symbol, then just position the cursor
	 // after the decimal symbol.
	 else if (decimalIndex != -1) {
	    updateCaretPosition(decimalIndex + 1, true);
	    return false;
	 }
	 else {
	    signalError();
	    return false;
	 }
      }
      
      char    minus = editFormatter.getDecimalFormatSymbols().getMinusSign();
      Number  number;

      try {	      
	 if (c == minus && !isNegativeAllowed()) {
	    signalError();
	    return false;
	 }

	 if (c != minus) {
	    myText = updateText(c, originalText, caret);
	    if (myText == null) {
	       signalError();
	       return false;
	    }
	    number = getNumberForText(myText);
	 }
	 else {
	    number = getNumberForText(originalText);
	    number = new Double(number.doubleValue() * -1);	 
	 }

	 myText = editFormatter.format(number);
	
	 setText(myText);

	 if (c == minus) {
	    updateCaretPosition(-1, true);
	 }
	 // If it is the delete character, then we need to adjust the cursor
	 // by the number of characters that changed before and after. If as a result
	 // of a delete we end up with 0.0 then zap the whole thing.
	 else if (c == KeyEvent.VK_DELETE) {
	    if (number.doubleValue() == 0.0) {
	       setDefaultText();
	       updateCaretPosition(-1, true);	       
	    }
	    else {
	       updateCaretPosition(caret -  
				   calcDifference(originalText, myText), 
				   true);

	       // If the caret stayed in its position , the position
	       // is just before the decimal index , there is a minimum
	       // number of fraction digits specified then place the
	       // caret at decimalIndex + 1.
	       if ( (caret == decimalIndex - 1)) {
		  updateCaretPosition(caret + 2, true);
	       }
	    }
	 }
	 // If it is the backspace character, then we need to adjust the cursor
	 // by the number of characters that changed before and after. If as a result
	 // of a delete we end up with 0.0 then zap the whole thing.
	 else if (c == KeyEvent.VK_BACK_SPACE) {
	    if (number.doubleValue() == 0.0) {
	       setDefaultText();
	       updateCaretPosition(-1, false);
	    }
	    else {
	       if (caret - 1 == decimalIndex) {
		  caret--;
	       }
	       updateCaretPosition(Math.min(caret -1,
					    caret - calcDifference(originalText, myText)), false);
	    }
	 }
	 // If the old text had no decimal sign and the new
	 // text has a decimal sign, then position the cursor before 
	 // the decimal sign. We assume the user wants to continue entering 
	 // integer values.
	 else if ( (decimalIndex == -1) && (myText.indexOf("" + decimalSymbol) >= 0)) {
	    updateCaretPosition(myText.indexOf("" + decimalSymbol), true);
	 }
	 // If the current cursor position is at a decimal sign, then leave it there
	 else if (caret == decimalIndex) {
	    updateCaretPosition(myText.indexOf("" + decimalSymbol), true);
	 }
	 // If the caret position was after the decimal sign, then simply increment
	 // the caret position once.
	 else if (!isIntegerSection(caret)) {
	    updateCaretPosition(caret + 1, true);
	 }
	 // Just bump up the caret position
	 else {	
	    updateCaretPosition(caret + Math.max(1, calcDifference(originalText, myText)), 
				true);	    
	 }

	 return false;
      }
      catch(NumberFormatException e) {
	 e.printStackTrace();
	 signalError();
      }

      return false;			     
   }
      
   private int calcDifference(String oldText, String newText)
   {
      int diff  = Math.abs(oldText.length() - newText.length());
      return diff;
   }

   /**
    * Updates the text. This method takes into consideration
    * many variables including the position of the caret and 
    * the insert mode.
    * @param text  The text to update
    * @param caret The caret location where the user entered the character
    */
   protected String updateText(char c, String text, int caret)
   {
      StringBuffer myStringBuffer;
      char         decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();            
      int          decimalIndex  = text.indexOf("" + decimalSymbol);
      double       number        = 0;

      // Bail out if not a digit or valid keystroke.
      if ( (c != KeyEvent.VK_DELETE) && 
	   (c != KeyEvent.VK_BACK_SPACE) && 
	   !Character.isDigit(c)) {
	 return null;
      }

      try {
	 number = getNumberForText(text).doubleValue();
      }
      catch(Throwable e) {  // Should never happen
	 System.out.println("Pattern is:" + editFormatter.toPattern());
	 System.out.println("Negative Prefix is:" + editFormatter.getNegativePrefix());
	 System.out.println("Positive Prefix is:" + editFormatter.getPositivePrefix());
	 System.out.println("Negative suffix is:" + editFormatter.getNegativeSuffix());
	 System.out.println("Positive suffix is:" + editFormatter.getPositiveSuffix());
	 e.printStackTrace();
      }


      if (c == KeyEvent.VK_BACK_SPACE) {

	 if (!isAtStart(caret, number < 0)) {

	    if (caret - 1 == decimalIndex) {
	       caret--;
	       if (isAtStart(caret, number < 0)) {
		  return null;
	       }
	       setCaretPosition(caret);
	    }

	    text = text.substring(0, caret - 1) + text.substring(caret);	    
	    return text;
	 }
	 else {
	    return null;
	 }
      }      
      else if (c == KeyEvent.VK_DELETE) {	     
	 if (caret == decimalIndex) {
	    caret++;
	 }

	 if (isAtEnd(caret, number < 0)) {
	    return null;
	 }

	 if ( (caret < text.length()) && 
	      (text.length() > 0)) {
	    text = text.substring(0, caret) + text.substring(caret + 1);

	    // If the text is only made up of a positive suffix, then
	    // make the text empty before parsing.
	    if (text.equals(editFormatter.getPositiveSuffix())) {
	       text = editFormatter.format(getDefaultValue());
	    }

	    return text;
	 }
	 else {
	    return null;
	 }
      }
      else {	  
	 int  suffixLength  = 0;

	 if (number >= 0) {
	    suffixLength = editFormatter.getPositiveSuffix().length();
	 }
	 else {
	    suffixLength = editFormatter.getNegativeSuffix().length();
	 }

	 if (!isIntegerSection(caret) &&       
	     (getNumberOfFractionDigits() == editFormatter.getMaximumFractionDigits()) && 
	     isAtEnd(caret, number < 0))  {
	    return null;
	 }

	 myStringBuffer = new StringBuffer(text);

	 if(getSelectedText() != null) {
	    myStringBuffer.replace(getSelectionStart(), getSelectionEnd(), String.valueOf(c));
	 }
	 else if (isInsertMode()) {
	    myStringBuffer = myStringBuffer.insert(caret, c);
	 }
	 else {
	    if(isAtEnd(caret, number < 0)) myStringBuffer.setCharAt(((caret <= 1) ? 0 : (caret - 1)), c);
	    else myStringBuffer.setCharAt(caret, c);
	 }
	 
	 text = myStringBuffer.toString();
      }

      return text;
   }

   /**
    * Updates the caret position
    * @param index The new index to set the caret at.
    * @param forward If true, any adjustments that need to be made are 
    * forward bias.
    */
   protected void updateCaretPosition(int index, boolean forward)
   {
      String  text          = getText();
      char    decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      int     decimalIndex  = text.indexOf("" + decimalSymbol);
      boolean forcedASwitch = false;
      double  number        = 0.0;
      int     suffixLength  = 0;

      try {
	 number = getNumberForText(getText()).doubleValue();
      }
      catch(Throwable e) {  // Should never happen
	 e.printStackTrace();
      }

      if (number >= 0) {
	 suffixLength = editFormatter.getPositiveSuffix().length();
      }
      else {
	 suffixLength = editFormatter.getNegativeSuffix().length();
      }

      // If we have a negative index, then set the caret to the
      // first position where a number exists or where anumber can be 
      // accepted.
      if (index < 0 ) {
	 index = 0;
	 forward = true;
      }

      // If the new index will exceed the length of the text, then adjust
      if (index >= text.length()) {
	 index = text.length() - suffixLength;
      }


      // If the index is at the decimal point, then switch to temporary insert mode
      if (decimalIndex == index) {
	 switchToInsertTemp();
	 forcedASwitch = true;
      }

      if (isAtEnd(index, number < 0)) {
	 switchToInsertTemp();
	 forcedASwitch = true;
      }

      // If the caret is in the integer region at the end of the text, and there
      // is no decimal point and we have not exceeded the maximum number of
      // integer digits that can be entered, then switch to insert mode.
      else if ( (decimalIndex == -1)    &&
	   (index == text.length() - suffixLength) &&
	   (index < editFormatter.getMaximumIntegerDigits())) {
	 switchToInsertTemp();
	 forcedASwitch = true;	 
      }
	         
      // Update the state of the insert mode
      if (forcedASwitch == false) {
	 if (tempInsert) {
	    tempInsert = false;
	    setInsertMode(wasInInsert);       
	 }
      }
      
      // If the index is at a non digit, then adjust.
      if (!isAtEnd(index, number < 0) && 
	  !isAtStart(index, number < 0) &&
	  (index != decimalIndex) && 
	  !Character.isDigit(text.charAt(index))) {

	 if (forward) {
	    index++;
	 }
	 else {
	    index--;
	 }

	 //	 System.out.println("Recursing for:" + editFormatter.toPattern() + " new index is:" + index);
	 updateCaretPosition(index, forward);
	 return;
      }

      setCaretPosition(index);
   }

   public void restoreDefaultValue(Object value)
   {
      if (value != null) {
	 setValue((Number)value);
      }
   }

   /**
    * Override to do nothing.
    */
   public void cut()
   {
      signalError();
   }

   /**
    * Override to do nothing.
    */
   public void paste()
   {
      signalError();
   }

   /**
    * Sets the default text of the component.
    */ 
   protected void setDefaultText()
   {
      if (hasFocus()) {
	 setText(editFormatter.format(getDefaultValue()));    
      }
      else {
	 setText(displayFormatter.format(getDefaultValue()));    
      }
      updateCaretPosition(-1, true);
   }

   //===============================================================================//
   //                                    Privates                                   //
   //===============================================================================//
   private void updateValue(Number number, boolean focus)
   {
      String myText;
      Number oldValue = value;

      if (number == null) {
	 number = (Number)getDefaultValue();
      }

      if (focus) {
	 myText = editFormatter.format(number.doubleValue());
      }
      else {
	 myText = displayFormatter.format(number.doubleValue());
      }
      
      setText(myText);

      // Only update if we have focus
      if (focus) {
	 updateCaretPosition(-1, true);
      }

      value = number;

      updateValidState();
      checkValid();

      firePropertyChange("value", oldValue, value);
   }

	private Number getNumberForText(String text) {
		Number number = (Number) getDefaultValue();
		boolean noNumbers = true;
		// If the string is has no numbers in it, then assume a default value.
		for (int i = 0; i < text.length(); i++) {
			if (Character.isDigit(text.charAt(i))) {
				noNumbers = false;
				break;
			}
		}
		if (!noNumbers) {
			ParsePosition pp = new ParsePosition(0);
			if (hasFocus()) number = editFormatter.parse(text, pp);
			else number = displayFormatter.parse(text, pp);
		}
		if(number == null) return((Number)getDefaultValue());
		return number;
	}

   private boolean isAtStart(int index, boolean negative)
   {
      int length = 0;

      if (negative) {
	 length = editFormatter.getNegativePrefix().length();
	          
      } 
      else {
	 length = editFormatter.getPositivePrefix().length();
      }

      return (index == length);
   }

   private boolean isAtEnd(int index, boolean negative)
   {
      int length = getText().length();

      if (negative) {
	 length -= editFormatter.getNegativeSuffix().length();;	          
	          
      } 
      else {
	 length -= editFormatter.getPositiveSuffix().length();; 
      }

      return (index == length);
   }

   private boolean isIntegerSection(int index)
   {
      String  text          = getText();
      char    decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      int     decimalIndex  = text.indexOf("" + decimalSymbol);

      if (decimalIndex == -1) {
	 return true;
      }

      if (index <= decimalIndex) {
	 return true;
      }

      return false;
   }

   private void switchToInsertTemp()
   {
      //      System.out.println("Switching to temporary insert mode");

      if (tempInsert) {
	 return;
      }

      tempInsert = true;

      wasInInsert = isInsertMode();

      setInsertMode(true);
   }

   private int getNumberOfFractionDigits()
   {
      return getNumberOfFractionDigits(getText());
   }

   private int getNumberOfFractionDigits(String text)
   {
      char   decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      int    decimalIndex  = text.indexOf("" + decimalSymbol);
      int    number        = 0;
      double myValue       = 0.0;

      if (decimalIndex != -1) {

	 try {
	    myValue = getNumberForText(getText()).doubleValue();
	 }
	 catch(Throwable e) {  // Should never happen
	    e.printStackTrace();
	 }

	 if (myValue < 0) {
	    number = getText().substring(decimalIndex + 1).length() - editFormatter.getNegativeSuffix().length();
	 }
	 else {
	    number = getText().substring(decimalIndex + 1).length() - editFormatter.getPositiveSuffix().length();
	 }
      }

      return number;
   }

   private int getNumberOfIntegerDigits()
   {
      char   decimalSymbol = editFormatter.getDecimalFormatSymbols().getDecimalSeparator();
      String text          = getText();
      int    number        = 0;
      int    startIndex    = 0;
      double myValue       = 0.0;

      try {
	 myValue = getNumberForText(getText()).doubleValue();
      }
      catch(Throwable e) {  // Should never happen
	 e.printStackTrace();
      }

      if (myValue < 0) {
	 startIndex = editFormatter.getPositivePrefix().length();
      }
      else {
	 startIndex = editFormatter.getNegativePrefix().length();
      }

      for (int i = startIndex; (i < text.length() && text.charAt(i) != decimalSymbol) ; i++) {
	 if (Character.isDigit(text.charAt(i))) {
	    number++;
	 }
      }
	         	    
      return number;
   }

   static class OverrideActions 
   {
      private  static JTextComponent.KeyBinding[] defaultBindings = {
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0),
					     DefaultEditorKit.backwardAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0),
					     DefaultEditorKit.forwardAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0),
					     DefaultEditorKit.beginAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_END, 0),
					     DefaultEditorKit.endAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0),
					     DefaultEditorKit.deletePrevCharAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0),
					     DefaultEditorKit.deleteNextCharAction),
	new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(KeyEvent.VK_INSERT, 0),
					     "InsertAction")
      };

      static Action actions[] = { new LeftAction(),
				  new RightAction(),
				  new HomeAction(),
				  new EndAction(),
				  new BackSpaceAction(),
				  new DeleteAction(),
				  new InsertAction()
      };
      
      static Action oldLeftHandler     = null;
      static Action oldRightHandler    = null;
      static Action oldHomeHandler     = null;
      static Action oldEndHandler      = null;
      static Action oldKeyTypedHandler = null;
      static Action oldDeleteHandler   = null;

      static void setup(JTextComponent component) 
      {
	 init(component);
	 	 
	 component.addPropertyChangeListener(new PropertyChangeListener() {
	    public void propertyChange(PropertyChangeEvent e) {
	       if (e.getPropertyName().equals("UI")) {
		  JTextComponent myComponent = (JTextComponent)e.getSource();		 		  
		  // BUGID 4193026 Remove the if check.
		  if (myComponent.getUI() != null) {
		     init(myComponent);
		  }
	       }
	    }
	 });
      }

      private static void init(JTextComponent component)
      {
	 String mapName     = "NumberFieldActionMap" + UIManager.getLookAndFeel().getName();
	 Keymap map         = JTextComponent.getKeymap(mapName);
	 
	 oldLeftHandler     = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0));
	 oldRightHandler    = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0));
	 oldHomeHandler     = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_HOME, 0));
	 oldEndHandler      = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_END, 0));
	 oldKeyTypedHandler = component.getKeymap().getDefaultAction();
	 oldDeleteHandler   = component.getKeymap().getAction(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));

	 //=======================================================//
	 // A key map is global so create it since none has       //
	 //=======================================================//
	 if (map == null) {
	    map = JTextComponent.addKeymap(mapName , component.getKeymap());
	    JTextComponent.loadKeymap(map, 
				      defaultBindings, 
				      actions);	    
	    map.setDefaultAction(new UndefinedAction());
	 }

	 component.setKeymap(map);
	 component.setCaret(new BlockCaret());	 
      }

      public static class LeftAction extends TextAction
      {	 
	 public LeftAction()
	 {
	    super(DefaultEditorKit.backwardAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {	
	    NumberEditField ef = (NumberEditField)getTextComponent(e);
	    ef.updateCaretPosition(ef.getCaretPosition() - 1, false);	    
	 }
      } 

      public static class RightAction extends TextAction 
      {	 
	 public RightAction()
	 {
	    super(DefaultEditorKit.forwardAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	    NumberEditField ef = (NumberEditField)getTextComponent(e);
	    ef.updateCaretPosition(ef.getCaretPosition() + 1, true);
	 }
      }      

      public static class HomeAction extends TextAction 
      {	 
	 public HomeAction()
	 {
	    super(DefaultEditorKit.beginAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	    NumberEditField ef = (NumberEditField)getTextComponent(e);
	    ef.updateCaretPosition(-1, true);
	 }
      }      

      public static class EndAction extends TextAction 
      {	 
	 public EndAction()
	 {
	    super(DefaultEditorKit.endAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	    NumberEditField ef = (NumberEditField)getTextComponent(e);
	    ef.updateCaretPosition(ef.getText().length(), false);
	 }
      }      

      public static class UndefinedAction extends TextAction 
      {	 
	 public UndefinedAction()
	 {
	    super(DefaultEditorKit.defaultKeyTypedAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {	    	    
	    if ( (e.getActionCommand() != null) && 
		 (e.getActionCommand().charAt(0) == (char)KeyEvent.VK_DELETE)) {
	       return;
	    }

	    if (getTextComponent(e).isEditable()) {
	       if (((NumberEditField)getTextComponent(e)).processChar(e.getActionCommand().charAt(0))) {
		  oldKeyTypedHandler.actionPerformed(e);
	       }
	    }
	 }
      }      

      public static class BackSpaceAction extends TextAction 
      {	 
	 public BackSpaceAction()
	 {
	    super(DefaultEditorKit.deletePrevCharAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	 }
      }      

      public static class InsertAction extends TextAction 
      {	 
	 public InsertAction()
	 {
	    super("InsertAction");
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	    NumberEditField tf = ((NumberEditField)getTextComponent(e));
	    tf.setInsertMode(!tf.isInsertMode());
	 }
      }      

      public static class DeleteAction extends TextAction 
      {	 
	 public DeleteAction()
	 {
	    super(DefaultEditorKit.deleteNextCharAction);
	 }
	 
	 public void actionPerformed(ActionEvent e)
	 {
	    if (getTextComponent(e).isEditable()) {
	       ((NumberEditField)getTextComponent(e)).processChar((char)KeyEvent.VK_DELETE);
	    }
	    else {
	       oldDeleteHandler.actionPerformed(e);	    
	    }
	 }
      }
   }
}
