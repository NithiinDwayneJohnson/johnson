/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableFormBeanInfo.java                                  */
/*                                                                      */
/* Generator:   BeanInfoGenerator    Version 0.49                       */
/* Emitter  :   JavaFileEmitter      Version 1.0                        */
/* Generated:   1998 October 19 at 15:26:12 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableFormBeanInfo                                       */
/**
 * This class implements the BeanInfo interface for the TableFormBeanInfo
 * class.
 * <p>
 * A short description is provided for each of the properties (attributes)
 * of the class. This description is derived from the first paragraph of
 * thethe attribute description in your model, created within Rational
 * Rose.
 */
/*======================================================================*/
public  class  TableFormBeanInfo  extends  SimpleBeanInfo
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableFormBeanInfo:Attributes preserve=yes

//##End   TableFormBeanInfo:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getPropertyDescriptors                           */
        /*                                                              */
        /**
         * This method returns an array of PropertyDescriptor objects that
         * specify additional information about the properties supported by
         * the bean.
         * <p>
         * By explicitly specifying property descriptors, it is possible to
         * provide simple help strings for each property.
         *  
         * @see         java.beans.SimpleBeanInfo
         *  
         * @return      :PropertyDescriptor[] -
         *                 The descriptor objects for each of the
         *                 properties (or attributes) of the class to which
         *                 this BeanInfo class corresponds.
         */
        /*==============================================================*/
   public  PropertyDescriptor[]  getPropertyDescriptors (
                                                        )
   {
//##Begin TableFormBeanInfo:getPropertyDescriptors() preserve=no
      try {

         PropertyDescriptor []  myPropertyDescriptors = {
            property (
                      "autoResizeColumns",
                      "When set, the table columns are set to their data size.",
                      "isAutoResizeColumns",
                      "setAutoResizeColumns",
                      false
                     ),
            property (
                      "table",
                      "",
                      "getTable",
                      "setTable",
                      true
                     ) 
         };

         return (myPropertyDescriptors);
      }

      catch (IntrospectionException myIntrospectionException) {
         return (super.getPropertyDescriptors ());
      }

//##End   TableFormBeanInfo:getPropertyDescriptors()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  property                                         */
        /*                                                              */
        /**
         * This method returns an array of PropertyDescriptor objects that
         * specify additional information about the properties supported by
         * the bean.
         * <p>
         * By explicitly specifying property descriptors, it is possible to
         * provide simple help strings for each property.
         *  
         * @see         java.beans.SimpleBeanInfo
         *  
         * @param       aPropertyName:String
         *                 The name of this particular property (or
         *                 attribute).
         * @param       aDescription:String
         *                 A short description for the property.
         * @param       aGetMethodName:String
         *                 The name of the get method for this particular
         *                 property (or attribute).
         * @param       aSetMethodName:String
         *                 The name of the set method for this particular
         *                 property (or attribute).
         * @param       aBound:boolean
         *                 Whether or not the attribute is bound (i.e. it
         *                 has propertyChangeEventSpecified set to true).
         * @return      :PropertyDescriptor -
         *                 The descriptor object for this particular
         *                 property (or attribute).
         * @exception   IntrospectionException -
         *                 An error occurred attempting to introspect the
         *                 object.
         */
        /*==============================================================*/
   private static  PropertyDescriptor  property (
                                                 String   aPropertyName,
                                                 String   aDescription,
                                                 String   aGetMethodName,
                                                 String   aSetMethodName,
                                                 boolean  aBound
                                                )
                                          throws IntrospectionException
   {
//##Begin TableFormBeanInfo:property(String,String,String,String,boolean) preserve=no


                PropertyDescriptor  myPropertyDescriptor;

      myPropertyDescriptor = new PropertyDescriptor (
                                                     aPropertyName,
                                                     TableFormBeanInfo.class,
                                                     aGetMethodName,
                                                     aSetMethodName
                                                    );
      myPropertyDescriptor.setShortDescription (aDescription);
      myPropertyDescriptor.setBound            (aBound);
      return (myPropertyDescriptor);

//##End   TableFormBeanInfo:property(String,String,String,String,boolean)
   }


}
