/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      HTMLChildWindowAction.java                                  */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 February 15 at 10:36:45 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.AbstractAction;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       HTMLChildWindowAction                                       */
/**
 * Deals specifically with HTML actions. Here we are pretty much inheriting
 * the implementation which Java kinda frowns upon but that is the
 * quickest way for now.
 */
/*======================================================================*/
public  class  HTMLChildWindowAction extends ChildWindowAction
{
                /*======================================================*/
                /* ATTRIBUTE:  ACTION_HTML_POST                         */
                /*                                                      */
                /**
                 * The ID for the HTML POST Action
                /*======================================================*/
   public static final String        ACTION_HTML_POST               = "HTML_POST_ACTION";

                 /*======================================================*/
                /* ATTRIBUTE:  ACTION_HTML_GET                          */
                /*                                                      */
                /**
                 * The ID for the HTML GET
                /*======================================================*/
   public static final String        ACTION_HTML_GET                = "HTML_GET_ACTION";

   private static final String DEFAULT_POST_TEXT         ;
   private static final String DEFAULT_GET_TEXT          ;
   private static final char DEFAULT_POST_ACCEL_CHAR   ;
   private static final char DEFAULT_GET_ACCEL_CHAR    ;

        /*==============================================================*/
        /* OPERATION:  createHTMLPostAction                             */
        /*                                                              */
        /**
         * Creates the default OK action for standard dialogs.
         *  
         * @return      :AbstractAction -
         */
        /*==============================================================*/
   protected  AbstractAction  createHTMLPostAction (
                                                    )
   {
//##Begin HTMLChildWindowAction:createHTMLPostAction() preserve=yes
      AbstractAction myAction =  new AbstractAction() {
	 public void actionPerformed(ActionEvent event) {
          // call the prepareStore method to check for prepareFormExceptions
          // this gives the users a chance to validate forms and get out if necessary 
            try {
               getForm().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
               ((FormComponent)getForm()).prepareStore();
               doHTMLMethod(ACTION_HTML_POST);
            }
            catch(PrepareFormException e) {
               if (!e.isNoGUI()) {
                  new ExceptionPane(e);
               }
               throw e;
            }
            catch(RuntimeException e) {
               throw e;
            }
            finally {
               getForm().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
	 }
      };
      actions.put(ACTION_HTML_POST, myAction);

      return myAction;
//##End   HTMLChildWindowAction:createHTMLPostAction()
   }

        /*==============================================================*/
        /* OPERATION:  createHTMLGetAction                             */
        /*                                                              */
        /**
         * Creates the default OK action for standard dialogs.
         *  
         * @return      :AbstractAction -
         */
        /*==============================================================*/
   protected  AbstractAction  createHTMLGetAction (
                                                    )
   {
//##Begin HTMLChildWindowAction:createHTMLGetAction() preserve=yes
      AbstractAction myAction =  new AbstractAction() {
	 public void actionPerformed(ActionEvent event) {
          // call the prepareStore method to check for prepareFormExceptions
          // this gives the users a chance to validate forms and get out if necessary 
            try {
               getForm().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
               ((FormComponent)getForm()).prepareStore();
               doHTMLMethod(ACTION_HTML_GET);
            }
            catch(PrepareFormException e) {
               if (!e.isNoGUI()) {
                  new ExceptionPane(e);
               }
               throw e;
            }
            catch(RuntimeException e) {
               throw e;
            }
            finally {
               getForm().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
	 }
      };
      actions.put(ACTION_HTML_GET, myAction);

      return myAction;
//##End   HTMLChildWindowAction:createHTMLGetAction()
   }

   protected synchronized void doHTMLMethod(String method)
   {
       boolean useProxy    = ((FormComponent)getForm()).isUsingProxy();
       HttpURLConnection aConnection = null;
       try {

          
          // before we initiate the connect we instate the socksProxyHost
          // and the socksProxyPort
          System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");

          // create the said URL
          String urlToConnect = ((FormComponent)getForm()).getURLString();
          if ( useProxy )
          {
             System.setProperty("socksProxyHost", "fw00216.us1.ibm.net" );
             System.setProperty("socksProxyPort", "1080" );
          }

          URL aURL = new URL(urlToConnect);
          aConnection = (HttpURLConnection)aURL.openConnection();
                                
          aConnection.setDoOutput(true);

          // Add any cookies that the form thinks are necessary
          boolean manipulatedRequest = ((FormComponent)getForm()).manipulateRequest(aConnection);


System.out.println( "Connection = " + aConnection + " Request Manipulated ?= " + manipulatedRequest);
         
          // get the output writer only in case of a POST
          if ( ACTION_HTML_POST.equals(method) )
          {
             PrintWriter out = new PrintWriter(
                         aConnection.getOutputStream());
             String encodedStringToSend = ((FormComponent)getForm()).getEncodedPostString();
             if ( encodedStringToSend == null || encodedStringToSend.trim().length() < 1 ) {
                 throw new RuntimeException("Illegal Argument to Post" + encodedStringToSend);           
             }
             out.write(encodedStringToSend);
             out.close();
          }
       } catch (Throwable t) {
          t.printStackTrace();
       } finally {
           // remove the proxy info
           System.getProperties().remove("java.protocol.handler.pkgs");
           if ( useProxy )
           {
              System.getProperties().remove("socksProxyHost");
              System.getProperties().remove("socksProxyPort");
           }
       }

       // extract and save off cookies from the response.
       // Subclasses override this to look for the cookie they want
       // to save off
       // Add any cookies that the form thinks are necessary
       boolean handledResponse = ((FormComponent)getForm()).handleHTTPResponse(aConnection);
System.out.println( "Connection = " + aConnection + " Response Handled ?= " + handledResponse);
       // close the calling window
       if ( handledResponse ) 
       {
          windowClosing();
       }
   }

   /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin HTMLChildWindowAction:StaticInitializer preserve=yes
   static {
     ResourceResolver aResolver = new ResourceResolver ();      
     aResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
     DEFAULT_POST_TEXT          = aResolver.getStringResource("post", HTMLChildWindowAction.class);
     DEFAULT_GET_TEXT           = aResolver.getStringResource("get", HTMLChildWindowAction.class);
     DEFAULT_POST_ACCEL_CHAR    = aResolver.getStringResource("POSTAccel", HTMLChildWindowAction.class).charAt(0);    
     DEFAULT_GET_ACCEL_CHAR     = aResolver.getStringResource("GETAccel", HTMLChildWindowAction.class).charAt(0);    

     // this line forces the jsse.jar to be present. Since we are not doing this kind of stuff
     // now I am commenting it out
     //com.sun.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new NovusHostVerifier());
   }
//##End   HTMLChildWindowAction:StaticInitializer

}
