package COM.novusnet.vision.java.gui;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

public class JComponentTableCellRenderer implements TableCellRenderer {
  public Component getTableCellRendererComponent(JTable table, Object value,
      boolean isSelected, boolean hasFocus, int row, int column) {
      	if (table != null) {
                JTableHeader header = table.getTableHeader();
                if (header != null && value != null && value instanceof JLabel) {
                	JLabel label = (JLabel) value;
                    label.setForeground(header.getForeground());
                    label.setBackground(header.getBackground());
                    label.setFont(header.getFont());
                    label.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
            		label.setHorizontalAlignment(JLabel.CENTER);
                }
            }
    
            
            

   		 return (JComponent) value;
  }
} 
