package COM.novusnet.vision.java.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.UIManager;


/**
 * This class takes a label and wraps it into multiple lines. The default number 
 * of columns is 30.
 */
public class WrappedLabel extends JTextArea
{
   public WrappedLabel()
   {
      this("");
   }

   public WrappedLabel(String text, int columns)
   {
      setColumns(columns);
      setText(text);

      setBorder(null);
      setFont((Font)(UIManager.get("Label.font")));
      setEditable(false);
      setBackground((Color)(UIManager.get("Label.background")));
      setForeground((Color)(UIManager.get("Label.foreground")));      
      setLineWrap(true);
      setWrapStyleWord(true);   
   }

   public WrappedLabel(String text)
   {
      this(text, 30);
   }

   public boolean isFocusTraversable()
   {
      return false;
   }

   public Dimension getMinimumSize()
   {
      return getPreferredSize();
   }

   public static void main( String[]  aArgs)
   {
      JFrame    myFrame   = new JFrame();

      myFrame.getContentPane().setLayout(new GridBagLayout());
      myFrame.getContentPane().add(new WrappedLabel("This is a test of a wrapped label whose width is greater than 30 chars"));

      myFrame.setSize(500, 500);
      myFrame.setVisible(true);

      myFrame.addWindowListener( new WindowAdapter() {
	 public void windowClosing(WindowEvent e) {
	    System.exit(0);
	 }
      });
   }

}
	
      

