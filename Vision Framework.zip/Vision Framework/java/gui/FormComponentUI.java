/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      FormComponentUI.java                                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 December 20 at 09:28:26 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       FormComponentUI                                         */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  FormComponentUI  extends  ComponentUI
                             implements  PropertyChangeListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin FormComponentUI:Attributes preserve=yes

//##End   FormComponentUI:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private FormComponent formComponent;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  FormComponentUI                                  */
        /*                                                              */
        /**
         * The constructor for a FormComponentUI class.
         *  
         */
        /*==============================================================*/
   public    FormComponentUI (
                             )
   {
//##Begin FormComponentUI:FormComponentUI() preserve=yes

//##End   FormComponentUI:FormComponentUI()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getFormComponent                                 */
        /*                                                              */
        /**
         * This method returns the value of the "formComponent" attribute.
         *  
         * @return      :FormComponent -
         *                 The value of the "formComponent" attribute.
         */
        /*==============================================================*/
   public  FormComponent  getFormComponent (
                                           )
   {
//##Begin FormComponentUI:getFormComponent() preserve=no

      return (formComponent);

//##End   FormComponentUI:getFormComponent()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setFormComponent                                 */
        /*                                                              */
        /**
         * This method sets the value of the "formComponent" attribute.
         *  
         * @param       aValue:FormComponent
         *                 The value of the "formComponent" attribute.
         */
        /*==============================================================*/
   protected  void  setFormComponent (
                                      FormComponent  aValue
                                     )
   {
//##Begin FormComponentUI:setFormComponent(FormComponent) preserve=no

      formComponent = aValue;

//##End   FormComponentUI:setFormComponent(FormComponent)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  propertyChange                                   */
        /*                                                              */
        /**
         * Implemented as part of the PropertyChangeListener interface. If
         * a new model is set on the model view we need to know.
         * <p>
         * If you override this method, you must always call the super
         * method to handle default cases.
         *  
         * @param       event:PropertyChangeEvent
         */
        /*==============================================================*/
   public  void  propertyChange (
                                 PropertyChangeEvent  event
                                )
   {
//##Begin FormComponentUI:propertyChange(PropertyChangeEvent) preserve=yes
      if (event.getPropertyName().equals("model")) {
	 handleModelChange(event.getOldValue(), event.getNewValue());
      }
//##End   FormComponentUI:propertyChange(PropertyChangeEvent)
   }

        /*==============================================================*/
        /* OPERATION:  installUI                                        */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         */
        /*==============================================================*/
   public  void  installUI (
                            JComponent  aComponent
                           )
   {
//##Begin FormComponentUI:installUI(JComponent) preserve=yes
      setFormComponent((FormComponent) aComponent);
      aComponent.addPropertyChangeListener(this);
//##End   FormComponentUI:installUI(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  uninstallUI                                      */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         */
        /*==============================================================*/
   public  void  uninstallUI (
                              JComponent  aComponent
                             )
   {
//##Begin FormComponentUI:uninstallUI(JComponent) preserve=yes
      FormComponent myFormComponent = (FormComponent)aComponent;

      Object model = myFormComponent.getModel();

      if (model != null) {
	 if (model instanceof BusinessObject) {
	    ((BusinessObject)model).removePropertyChangeListener(this);
	 }
      }

      myFormComponent.removePropertyChangeListener(this);
      setFormComponent(null);
//##End   FormComponentUI:uninstallUI(JComponent)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleModelChange                                */
        /*                                                              */
        /**
         * This method is called whenever the model that is set on the view
         * is changed. When the model is changed and if the model
         * represents a BO, the following is performed:
         * <p>
         * - Remove propertyChangeListener on the old model.
         * <p>
         * - Add propertyChangeListener on the new model.
         * <p>
         * You should always call the super method before doing any further
         * processing.
         *  
         * @param       oldModel:Object
         * @param       newModel:Object
         */
        /*==============================================================*/
   protected  void  handleModelChange (
                                       Object  oldModel,
                                       Object  newModel
                                      )
   {
//##Begin FormComponentUI:handleModelChange(Object,Object) preserve=yes

      if (oldModel != null) {
	 if (oldModel instanceof BusinessObject) {
	    ((BusinessObject)oldModel).removePropertyChangeListener(this);
	 }
      }

      if (newModel != null) {
	 if (newModel instanceof BusinessObject) {
	    ((BusinessObject)newModel).addPropertyChangeListener(this);
	 }
      }

//##End   FormComponentUI:handleModelChange(Object,Object)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createUI                                         */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         * @return      :ComponentUI -
         */
        /*==============================================================*/
   public static  ComponentUI  createUI (
                                         JComponent  aComponent
                                        )
   {
//##Begin FormComponentUI:createUI(JComponent) preserve=yes
      return new FormComponentUI();
//##End   FormComponentUI:createUI(JComponent)
   }


}
