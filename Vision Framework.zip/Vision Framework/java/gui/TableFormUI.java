/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableFormUI.java                                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 19 at 15:28:19 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.*;
import java.beans.*;
import java.util.*;
import java.lang.*;
import java.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.*;
import javax.swing.table.*;


                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/


                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
import COM.novusnet.vision.java.businessobjects.*;
import COM.novusnet.vision.java.utility.*;
import COM.novusnet.vision.java.utility.resourcehelpers.*;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableFormUI                                             */
/**
 * This class provides keyboard navigation capabilities to a table view.
 * This class also allows subclasses to monitor when the user scrolls to
 * the top or bottom of a Table. The user will typically load more rows
 * from the database optionally discarding existing rows for space
 * effeciency.
 * <p>
 * The user can specify actions to be performed when a predefined keystroke
 * is pressed. These keystrokes are:
 * <p>
 * - insert
 * <p>
 * - delete
 * <p>
 * - enter
 * <p>
 * When the user sets one of the predefined actions via the setAddAction,
 * setRemoveAction or setChangeActions, they are automatically bound to
 * these predefined keys. These actions are typically set in the subclass
 * of the table view controller. In addition, this controller provides for
 * a popup menu hot key, Alt-F10.
 */
/*======================================================================*/
public  class  TableFormUI  extends  FormComponentUI
                         implements  PropertyChangeListener, AdjustmentListener, ListSelectionListener, TableModelListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableFormUI:Attributes preserve=yes
      int oldScrollBarValue = 0;
      String javaVersion = System.getProperty("java.version");
//##End   TableFormUI:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private JTable         table        = null;
   private MouseAdapter   mouseAdapter;
   private AbstractAction addAction;
   private AbstractAction changeAction;
   private AbstractAction removeAction;

   private static final ResourceResolver aResourceResolver = new ResourceResolver();
   static {
      aResourceResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
   }

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TableFormUI                                      */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public    TableFormUI (
                         )
   {
//##Begin TableFormUI:TableFormUI() preserve=yes
//##End   TableFormUI:TableFormUI()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getTable                                         */
        /*                                                              */
        /**
         * This method returns the value of this is the table that we are
         * currently monitoring.
         *  
         * @return      :JTable -
         *                 The value of this is the table that we are
         *                 currently monitoring.
         */
        /*==============================================================*/
   public  JTable  getTable (
                            )
   {
//##Begin TableFormUI:getTable() preserve=no

      return (table);

//##End   TableFormUI:getTable()
   }

        /*==============================================================*/
        /* OPERATION:  getMouseAdapter                                  */
        /*                                                              */
        /**
         * This method returns the value of the "mouseAdapter" attribute.
         *  
         * @return      :MouseAdapter -
         *                 The value of the "mouseAdapter" attribute.
         */
        /*==============================================================*/
   public  MouseAdapter  getMouseAdapter (
                                         )
   {
//##Begin TableFormUI:getMouseAdapter() preserve=no

      return (mouseAdapter);

//##End   TableFormUI:getMouseAdapter()
   }

        /*==============================================================*/
        /* OPERATION:  getAddAction                                     */
        /*                                                              */
        /**
         * This method returns the value of the "addAction" attribute.
         *  
         * @return      :AbstractAction -
         *                 The value of the "addAction" attribute.
         */
        /*==============================================================*/
   public  AbstractAction  getAddAction (
                                        )
   {
//##Begin TableFormUI:getAddAction() preserve=no

      return (addAction);

//##End   TableFormUI:getAddAction()
   }

        /*==============================================================*/
        /* OPERATION:  getChangeAction                                  */
        /*                                                              */
        /**
         * This method returns the value of the "changeAction" attribute.
         *  
         * @return      :AbstractAction -
         *                 The value of the "changeAction" attribute.
         */
        /*==============================================================*/
   public  AbstractAction  getChangeAction (
                                           )
   {
//##Begin TableFormUI:getChangeAction() preserve=no

      return (changeAction);

//##End   TableFormUI:getChangeAction()
   }

        /*==============================================================*/
        /* OPERATION:  getRemoveAction                                  */
        /*                                                              */
        /**
         * This method returns the value of the "removeAction" attribute.
         *  
         * @return      :AbstractAction -
         *                 The value of the "removeAction" attribute.
         */
        /*==============================================================*/
   public  AbstractAction  getRemoveAction (
                                           )
   {
//##Begin TableFormUI:getRemoveAction() preserve=no

      return (removeAction);

//##End   TableFormUI:getRemoveAction()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setTable                                         */
        /*                                                              */
        /**
         * This method sets the value of this is the table that we are
         * currently monitoring.
         *  
         * @param       aValue:JTable
         *                 The value of this is the table that we are
         *                 currently monitoring.
         */
        /*==============================================================*/
   private  void  setTable (
                            JTable  aValue
                           )
   {
//##Begin TableFormUI:setTable(JTable) preserve=yes
      undefineKeys();

      //=======================================================
      // If the old table has the standard actions bound
      // to the standard keys (insert ,delete ...), then 
      // bind the same actions in the new table.
      //=======================================================
      AbstractAction oldAddAction    = getAddAction();
      AbstractAction oldRemoveAction = getRemoveAction();
      AbstractAction oldChangeAction = getChangeAction();

      if (table != null) {
	 table.removeMouseListener(getMouseAdapter());	 
	 table.getSelectionModel().removeListSelectionListener(this);
      }

      //=======================================================
      // Install ourselves as a new listener
      //=======================================================
      ((TableForm)getFormComponent()).getScrollPane().
      getVerticalScrollBar().addAdjustmentListener(this);
      
      table = aValue;

      //=======================================================
      // Rebind the actions
      //=======================================================
      setAddAction(oldAddAction);
      setRemoveAction(oldRemoveAction);
      setChangeAction(oldChangeAction);
      
      setMouseAdapter( new MouseAdapter() {
	 public void mouseClicked(MouseEvent e) {	    

	    //================================================================
	    // For Macs, they must hold the meta key when pressing the only
	    // mouse button. FIX when isPopupTrigger() is fixed.
	    //================================================================
	    if ((e.getModifiers() & InputEvent.META_MASK) > 0 ) {
	       handleButton2Clicked(e.getPoint());	       
	    } 
	    else if (e.getClickCount() == 2 && 
		     ( (e.getModifiers() & InputEvent.BUTTON1_MASK) > 0) ) {	       
	       handleButton1DoubleClicked(e.getPoint());
	    }
	 }
      });

      ((TableForm)getFormComponent()).getScrollPane().addMouseListener(getMouseAdapter());
      table.addMouseListener(getMouseAdapter());
      table.getSelectionModel().addListSelectionListener(this);
      defineKeys();

//##End   TableFormUI:setTable(JTable)
   }

        /*==============================================================*/
        /* OPERATION:  setMouseAdapter                                  */
        /*                                                              */
        /**
         * This method sets the value of the "mouseAdapter" attribute.
         *  
         * @param       aValue:MouseAdapter
         *                 The value of the "mouseAdapter" attribute.
         */
        /*==============================================================*/
   private  void  setMouseAdapter (
                                   MouseAdapter  aValue
                                  )
   {
//##Begin TableFormUI:setMouseAdapter(MouseAdapter) preserve=no

      mouseAdapter = aValue;

//##End   TableFormUI:setMouseAdapter(MouseAdapter)
   }

        /*==============================================================*/
        /* OPERATION:  setAddAction                                     */
        /*                                                              */
        /**
         * This method sets the value of the "addAction" attribute.
         *  
         * @param       aValue:AbstractAction
         *                 The value of the "addAction" attribute.
         */
        /*==============================================================*/
   public  void  setAddAction (
                               AbstractAction  aValue
                              )
   {
//##Begin TableFormUI:setAddAction(AbstractAction) preserve=no

      addAction = aValue;

//##End   TableFormUI:setAddAction(AbstractAction)
   }

        /*==============================================================*/
        /* OPERATION:  setChangeAction                                  */
        /*                                                              */
        /**
         * This method sets the value of the "changeAction" attribute.
         *  
         * @param       aValue:AbstractAction
         *                 The value of the "changeAction" attribute.
         */
        /*==============================================================*/
   public  void  setChangeAction (
                                  AbstractAction  aValue
                                 )
   {
//##Begin TableFormUI:setChangeAction(AbstractAction) preserve=yes

      //========================================================
      // Remove any existing binding for the current action
      //========================================================

      if (changeAction != null) {
	 getTable().unregisterKeyboardAction(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0));
      }
      
      changeAction = aValue;

      //========================================================
      // Bind with new action
      //========================================================

      if (changeAction != null) {
	 getTable().registerKeyboardAction(changeAction,
					   KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
					   JComponent.WHEN_FOCUSED);
      }

//##End   TableFormUI:setChangeAction(AbstractAction)
   }

        /*==============================================================*/
        /* OPERATION:  setRemoveAction                                  */
        /*                                                              */
        /**
         * This method sets the value of the "removeAction" attribute.
         *  
         * @param       aValue:AbstractAction
         *                 The value of the "removeAction" attribute.
         */
        /*==============================================================*/
   public  void  setRemoveAction (
                                  AbstractAction  aValue
                                 )
   {
//##Begin TableFormUI:setRemoveAction(AbstractAction) preserve=yes

      //========================================================
      // Remove any existing binding for the current action
      //========================================================
      if (removeAction != null) {
	 getTable().unregisterKeyboardAction(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
      }
      
      removeAction = aValue;

      //========================================================
      // Bind with new action
      //========================================================

      if (removeAction != null) {
	 getTable().registerKeyboardAction(removeAction,
					   KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0),
					   JComponent.WHEN_FOCUSED);
      }


//##End   TableFormUI:setRemoveAction(AbstractAction)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  propertyChange                                   */
        /*                                                              */
        /**
         * Implemented as part of the PropertyChangeListener interface. If
         * a table changes in the table view we install the new keyboard
         * listeners on the new table and remove them from the old.
         *  
         * @param       event:PropertyChangeEvent
         */
        /*==============================================================*/
   public  void  propertyChange (
                                 PropertyChangeEvent  event
                                )
   {
//##Begin TableFormUI:propertyChange(PropertyChangeEvent) preserve=yes
      super.propertyChange(event);

      if (event.getPropertyName().equals("table")) {
	 //==============================================================
	 // If table of TableForm changes we need to install new
	 // keyboard listeners on new table.
	 //==============================================================
	 setTable((JTable)event.getNewValue());
      }

//##End   TableFormUI:propertyChange(PropertyChangeEvent)
   }

        /*==============================================================*/
        /* OPERATION:  adjustmentValueChanged                           */
        /*                                                              */
        /**
         * Handles adjustment notifications.
         *  
         * @param       e:AdjustmentEvent
         */
        /*==============================================================*/
   public  void  adjustmentValueChanged (
                                         AdjustmentEvent  e
                                        )
   {
//##Begin TableFormUI:adjustmentValueChanged(AdjustmentEvent) preserve=yes

      BoundedRangeModel brm = ((TableForm)getFormComponent()).getScrollPane().getVerticalScrollBar().getModel();
      boolean callingHandleBottomReached = false;

      //==============================
      // Did we reach the top ?
      //==============================
      if ( (e.getValue() == 0) && oldScrollBarValue != 0) {
	 oldScrollBarValue = 0;

	 // Clear should not cause a handle top reached method
	 // on the UI.
	 if (getTable().getModel().getRowCount() != 0) {
	    handleTopReached();
            // if we drop down to the last line of this method then
            // oldScrollBarValue will be 0 so the next time the user
            // pages up or tries to scroll up the handleTopReached
            // event will not trigger, so we set the oldScrollBarValue
            // to a non zero value here and get out
	    oldScrollBarValue = getTable().getModel().getRowCount();
	    return;
	 }
	 
      } 
      //==============================
      // How about the bottom ?
      //==============================
      else if ( (brm.getValue() == (brm.getMaximum() - brm.getExtent()))) {
	 if (oldScrollBarValue != (brm.getMaximum() - brm.getExtent())) {
            callingHandleBottomReached = true;
	    handleBottomReached();
	 }
      }
      oldScrollBarValue = e.getValue();
      if ( ((TableForm)getFormComponent()).getMsgtext() != null )
      {
         if (! callingHandleBottomReached )
         {
            ((TableForm)getFormComponent()).setMsgtext(null);
         }
      }
      getFormComponent().revalidate();
//##End   TableFormUI:adjustmentValueChanged(AdjustmentEvent)
   }

        /*==============================================================*/
        /* OPERATION:  valueChanged                                     */
        /*                                                              */
        /**
         * Public by implementation. Do not call.
         *  
         * @param       e:ListSelectionEvent
         */
        /*==============================================================*/
   public  void  valueChanged (
                               ListSelectionEvent  e
                              )
   {
//##Begin TableFormUI:valueChanged(ListSelectionEvent) preserve=yes
      handleSelectionChanged();
//##End   TableFormUI:valueChanged(ListSelectionEvent)
   }

        /*==============================================================*/
        /* OPERATION:  tableChanged                                     */
        /*                                                              */
        /**
         * Provided for subclasses.
         *  
         * @param       e:TableModelEvent
         */
        /*==============================================================*/
   public  void  tableChanged (
                               TableModelEvent  e
                              )
   {
//##Begin TableFormUI:tableChanged(TableModelEvent) preserve=yes
//##End   TableFormUI:tableChanged(TableModelEvent)
   }

        /*==============================================================*/
        /* OPERATION:  installUI                                        */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         */
        /*==============================================================*/
   public  void  installUI (
                            JComponent  aComponent
                           )
   {
//##Begin TableFormUI:installUI(JComponent) preserve=yes
      setFormComponent((FormComponent) aComponent);
      TableForm aTableForm = (TableForm)getFormComponent();
      setTable(aTableForm.getTable());

      //===========================================================
      // We need to monitor the TableForm for any changes in table
      //===========================================================
      aTableForm.addPropertyChangeListener(this);
//##End   TableFormUI:installUI(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  uninstallUI                                      */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         */
        /*==============================================================*/
   public  void  uninstallUI (
                              JComponent  aComponent
                             )
   {
//##Begin TableFormUI:uninstallUI(JComponent) preserve=yes
      TableForm aTableForm = (TableForm)getFormComponent();
      aTableForm.removePropertyChangeListener(this);
      undefineKeys();
//##End   TableFormUI:uninstallUI(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  resizeColumns                                    */
        /*                                                              */
        /**
         * Resizes columns to their data width.
         *  
         */
        /*==============================================================*/
   public  void  resizeColumns (
                               )
   {
//##Begin TableFormUI:resizeColumns() preserve=yes
      TableForm        tableForm   = (TableForm)getFormComponent();
      JTable           table       = tableForm.getTable();
      TableColumnModel columnModel = table.getColumnModel();
      int              count       = columnModel.getColumnCount();
      TableModel       model       = table.getModel();
      int              rows        = model.getRowCount();
      TableColumn      column      = null;
      Component        comp        = null;
      int              headerWidth = 0;
      int              cellWidth   = 0;
      
      if (!tableForm.isAutoResizeColumns()) {
	 return;
      }

      for (int i = 0; i < count; i++) {

	 cellWidth = 0;

	 column = columnModel.getColumn(i);

	 if (column != null) {
	    if (!javaVersion.startsWith("1.1")) {
	       // JDK 1.3 and upwards
	       // JDK 1.3 has Moved the header renderers from the columns themselves 
	       // to the table header.
	       comp = table.getTableHeader().getDefaultRenderer().getTableCellRendererComponent(
									 null, 
									 column.getHeaderValue(), 
									 false, 
									 false, 
									 0, 
									 0);
	    }else {
	       // jdk 1.1.x	 
	       comp = column.getHeaderRenderer().getTableCellRendererComponent(
								       null, 
								       column.getHeaderValue(), 
								       false, 
								       false, 
								       0, 
								       0);
	    }


	    headerWidth = comp.getPreferredSize().width;

	    for (int j = 0; j < rows ; j++) {
	       comp = table.getDefaultRenderer(model.getColumnClass(i)).getTableCellRendererComponent(
								      table, 
								      model.getValueAt(j, i),
								      false, 
								      false, 
								      j, 
								      i);
	       cellWidth = Math.max(cellWidth, comp.getPreferredSize().width);
	    }

	    column.setPreferredWidth(Math.max(headerWidth, cellWidth));
	 }

      }

//##End   TableFormUI:resizeColumns()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  defineKeys                                       */
        /*                                                              */
        /**
         * This method establishes the keyboard mappings.
         *  
         */
        /*==============================================================*/
   protected  void  defineKeys (
                               )
   {
//##Begin TableFormUI:defineKeys() preserve=yes

      //==================================================
      // Keydown action listener
      //==================================================
      ActionListener menuAction = new ActionListener() {
	 public void actionPerformed(ActionEvent e)
	 {
	    JPopupMenu myMenu = createPopupMenu();
	    positionPopupMenu(myMenu, null);
	    myMenu.setInvoker(getTable());
	    myMenu.setLightWeightPopupEnabled(false);
	    myMenu.setVisible(true);
	    myMenu.requestFocus();
	 }
      };

      getTable().registerKeyboardAction(menuAction,
					KeyStroke.getKeyStroke(KeyEvent.VK_F12, InputEvent.ALT_MASK),
					JComponent.WHEN_FOCUSED);

      if((ApplicationConfigHelper.instance().getProperty("accessiblemode") != null) &&
	 (ApplicationConfigHelper.instance().getProperty("accessiblemode").equalsIgnoreCase("on"))) {

         ActionListener tableRowDescriptionAction = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               createTableRowDescriptionPane();
            }
         };

         getTable().registerKeyboardAction(tableRowDescriptionAction,
               KeyStroke.getKeyStroke(KeyEvent.VK_F1, InputEvent.ALT_MASK),
               JComponent.WHEN_FOCUSED);

         ActionListener tableCellDescriptionAction = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               createTableCellDescriptionPane();
            }
         };

         getTable().registerKeyboardAction(tableCellDescriptionAction,
               KeyStroke.getKeyStroke(KeyEvent.VK_F2, InputEvent.ALT_MASK),
               JComponent.WHEN_FOCUSED);
      }


//##End   TableFormUI:defineKeys()
   }

        /*==============================================================*/
        /* OPERATION:  createTableCellDescriptionPane                   */
        /*                                                              */
        /**
         * This method will generate a VisionOptionPane to describe 
         * the cell that currently has focus when ALT+F2 is pressed.
         *  
         */
        /*==============================================================*/
    protected void createTableCellDescriptionPane() {
//##Begin TableFormUI:createTableCellDescriptionPane() preserve=yes
       int aRow    = getTable().getSelectedRow();
       int aColumn = getTable().getSelectedColumn();
       StringBuffer aStringBuffer = new StringBuffer();
       String aMessage = null;
       if(getTable().getRowCount() == 0) {
          aStringBuffer.append(aResourceResolver.getStringResource("tableFormUImsg9", 
             COM.novusnet.vision.java.gui.TableFormUI.class));
       }
       if(aRow > -1) {
          aStringBuffer.append(MessageFormat.format(
             aResourceResolver.getStringResource("tableFormUImsg2", 
             COM.novusnet.vision.java.gui.TableFormUI.class), new Object[] {new Integer(aRow + 1)}));
       } else {
          aStringBuffer.append(aResourceResolver.getStringResource("tableFormUImsg3", 
             COM.novusnet.vision.java.gui.TableFormUI.class));
       }
       if(aColumn > -1) {
          aStringBuffer.append(MessageFormat.format(
             aResourceResolver.getStringResource("tableFormUImsg6", 
             COM.novusnet.vision.java.gui.TableFormUI.class), 
             new Object[] {new Integer(aColumn + 1), getTable().getModel().getColumnName(aColumn)}));
       } else {
          aStringBuffer.append(aResourceResolver.getStringResource("tableFormUImsg7", 
             COM.novusnet.vision.java.gui.TableFormUI.class));
       }
       if(aRow > -1
         && aColumn > -1) {
          aStringBuffer.append(MessageFormat.format(
             aResourceResolver.getStringResource("tableFormUImsg8", 
             COM.novusnet.vision.java.gui.TableFormUI.class), 
             new Object[] {getCellContentValueAt(getTable(), aRow, aColumn)}));
       }
       aMessage = aStringBuffer.toString();
       aStringBuffer = new StringBuffer();
       aStringBuffer.append(MessageFormat.format(
          aResourceResolver.getStringResource("tableFormUItitle2", 
          COM.novusnet.vision.java.gui.TableFormUI.class), new Object[] {getTableName(getTable())}));
       VisionOptionPane.showMessageDialog(getFormComponent(), aMessage, 
          aStringBuffer.toString(), JOptionPane.PLAIN_MESSAGE);
//##End TableFormUI:createTableCellDescriptionPane()
    }

        /*==============================================================*/
        /* OPERATION:  createTableRowDescriptionPane                    */
        /*                                                              */
        /**
         * This method will generate a VisionOptionPane to describe 
			* the row that is currently selected when ALT+F1 is pressed.
         *  
         */
        /*==============================================================*/
    protected void createTableRowDescriptionPane() {
//##Begin TableFormUI:createTableRowDescriptionPane() preserve=yes
       int aRow = getTable().getSelectedRow();
       StringBuffer aStringBuffer = new StringBuffer();
       String aMessage = null;
       if(getTable().getRowCount() == 0) {
          aStringBuffer.append(aResourceResolver.getStringResource("tableFormUImsg9", 
             COM.novusnet.vision.java.gui.TableFormUI.class));
       }
       if(aRow > -1) {
          aStringBuffer.append(MessageFormat.format(
             aResourceResolver.getStringResource("tableFormUImsg2", 
             COM.novusnet.vision.java.gui.TableFormUI.class), new Object[] {new Integer(aRow + 1)}));
          for(int i = 0; i < getTable().getModel().getColumnCount(); i++) {
             aStringBuffer.append(MessageFormat.format(
                aResourceResolver.getStringResource("tableFormUImsg5", 
                COM.novusnet.vision.java.gui.TableFormUI.class), 
                new Object[] {getTable().getModel().getColumnName(i), 
                getCellContentValueAt(getTable(), aRow, i)}));
          }
       } else {
          aStringBuffer.append(aResourceResolver.getStringResource("tableFormUImsg3", 
             COM.novusnet.vision.java.gui.TableFormUI.class));
       }
       aMessage = aStringBuffer.toString();
       aStringBuffer = new StringBuffer();
       aStringBuffer.append(MessageFormat.format(
          aResourceResolver.getStringResource("tableFormUItitle1", 
          COM.novusnet.vision.java.gui.TableFormUI.class), new Object[] {getTableName(getTable())}));
       VisionOptionPane.showMessageDialog(getFormComponent(), aMessage, 
          aStringBuffer.toString(), JOptionPane.PLAIN_MESSAGE);
//##End TableFormUI:createTableRowDescriptionPane()
    }

        /*==============================================================*/
        /* OPERATION:  getCellContentValueAt                            */
        /*                                                              */
        /**
         * This method will generate a String to describe 
			* the contents of the cell at row aRow and column aColumn.
         *  
         */
        /*==============================================================*/
    private String getCellContentValueAt(JTable aJTable, int aRow, int aColumn) {
//##Begin TableFormUI:getCellContentValueAt() preserve=yes
       String aString = aResourceResolver.getStringResource("tableFormUImsg4", 
          COM.novusnet.vision.java.gui.TableFormUI.class);
		 Object anObject = aJTable.getValueAt(aRow, aColumn);
		 if(anObject != null) {
          if(anObject instanceof String) {
             if(!((String)anObject).trim().equals("")) {
                aString = ((String)anObject).trim();
             }
          } else {
             aString = anObject.toString();
          }
       }
       return aString;
//##End TableFormUI:getCellContentValueAt()
    }

        /*==============================================================*/
        /* OPERATION:  getTableName                                     */
        /*                                                              */
        /**
         * This method will generate a String to describe 
			* the name of a JTable.
         *  
         */
        /*==============================================================*/
    private String getTableName(JTable aJTable) {
//##Begin TableFormUI:getTableName() preserve=yes
       String aString = getTable().getName();
       if(aString == null || aString.trim().equalsIgnoreCase("null")) {
          aString = "";
       } else {
          aString = aString.trim();
       }
       return aString;
//##End TableFormUI:getTableName()
    }


        /*==============================================================*/
        /* OPERATION:  undefineKeys                                     */
        /*                                                              */
        /**
         * This method deregisters key bindings.
         *  
         */
        /*==============================================================*/
   protected  void  undefineKeys (
                                 )
   {
//##Begin TableFormUI:undefineKeys() preserve=yes
      JTable  myTable = getTable();

      if (myTable != null) {
	 myTable.unregisterKeyboardAction(KeyStroke.getKeyStroke(KeyEvent.VK_F10, InputEvent.ALT_MASK));
      }

//##End   TableFormUI:undefineKeys()
   }

        /*==============================================================*/
        /* OPERATION:  handleTopReached                                 */
        /*                                                              */
        /**
         * This method will be called when the user scrolls to vertical
         * scrollbar to the top.
         *  
         */
        /*==============================================================*/
   protected  void  handleTopReached (
                                     )
   {
//##Begin TableFormUI:handleTopReached() preserve=yes

//##End   TableFormUI:handleTopReached()
   }

        /*==============================================================*/
        /* OPERATION:  handleBottomReached                              */
        /*                                                              */
        /**
         * This method will be called when the user scrolls to vertical
         * scrollbar to the bottom.
         *  
         */
        /*==============================================================*/
   protected  void  handleBottomReached (
                                        )
   {
//##Begin TableFormUI:handleBottomReached() preserve=yes

//##End   TableFormUI:handleBottomReached()
   }

        /*==============================================================*/
        /* OPERATION:  handleButton2Clicked                             */
        /*                                                              */
        /**
         * This method is called whenever the user uses button2 to click on
         * the table. The default behavior for this method is to perform
         * the following:
         * <p>
         * - Create the standard table pop up menu.
         * <p>
         * - Call customizePopUpMenu()
         * <p>
         * - Then pop up the menu. 
         *  
         * @param       point:Point
         */
        /*==============================================================*/
   protected  void  handleButton2Clicked (
                                          Point  point
                                         )
   {
//##Begin TableFormUI:handleButton2Clicked(Point) preserve=yes
      JPopupMenu myMenu = createPopupMenu();

      if (myMenu != null) {
	 positionPopupMenu(myMenu, point);
	 myMenu.setInvoker(getTable());
	 myMenu.setLightWeightPopupEnabled(false);
	 myMenu.setVisible(true);
      }

//##End   TableFormUI:handleButton2Clicked(Point)
   }

        /*==============================================================*/
        /* OPERATION:  createPopupMenu                                  */
        /*                                                              */
        /**
         * This method is called whenever the user clicks on the second
         * button. This method must be overridden by subclasses to create a
         * custom popup menu. The default behavior of this method is to
         * return a null, in which case no popup menu is popped. 
         *  
         * @return      :JPopupMenu -
         */
        /*==============================================================*/
   protected  JPopupMenu  createPopupMenu (
                                          )
   {
//##Begin TableFormUI:createPopupMenu() preserve=yes
      return (null);
//##End   TableFormUI:createPopupMenu()
   }

        /*==============================================================*/
        /* OPERATION:  handleSelectionChanged                           */
        /*                                                              */
        /**
         * This method is called whenver the selection changes in the
         * table. Subclassers can override this method to update things
         * like action states.
         *  
         */
        /*==============================================================*/
   protected  void  handleSelectionChanged (
                                           )
   {
//##Begin TableFormUI:handleSelectionChanged() preserve=yes

//##End   TableFormUI:handleSelectionChanged()
   }

        /*==============================================================*/
        /* OPERATION:  positionPopupMenu                                */
        /*                                                              */
        /**
         * Called when its time to position and show the popup menu.
         *  
         * @param       aMenu:JPopupMenu
         * @param       aPoint:Point
         */
        /*==============================================================*/
   protected  void  positionPopupMenu (
                                       JPopupMenu  aMenu,
                                       Point       aPoint
                                      )
   {
//##Begin TableFormUI:positionPopupMenu(JPopupMenu,Point) preserve=yes
      //=====================================================
      // Position at center of table if no point is supplied.
      //=====================================================
      if (aPoint == null) {

	 aPoint = new Point();

	 Rectangle rect = getTable().getVisibleRect();
	    
	 aPoint.x   = ( (rect.width - rect.x) /  2);
	 aPoint.y   = rect.y + (rect.height /  2);
      }

      Point tableLocation = getTable().getLocationOnScreen();
      
      aPoint.x += tableLocation.x;
      aPoint.y += tableLocation.y;

      if (aMenu != null) {
	 aMenu.setBorderPainted(true);
//	 aMenu.setBackground(Color.lightGray);      
	 aMenu.setLocation(aPoint.x, aPoint.y - aMenu.getPreferredSize().height);
      }
//##End   TableFormUI:positionPopupMenu(JPopupMenu,Point)
   }

        /*==============================================================*/
        /* OPERATION:  handleModelChange                                */
        /*                                                              */
        /**
         * Overridden to remove/add a table model listener.
         *  
         * @param       oldModel:Object
         * @param       newModel:Object
         */
        /*==============================================================*/
   protected  void  handleModelChange (
                                       Object  oldModel,
                                       Object  newModel
                                      )
   {
//##Begin TableFormUI:handleModelChange(Object,Object) preserve=yes

      super.handleModelChange(oldModel, newModel);

      JTable                myTable  = getTable ();
      BOContainerTableModel myModel  = (BOContainerTableModel) myTable.getModel ();

      if (oldModel != null) {
	 myModel.removeTableModelListener(this);
      }

      if (newModel != null) {
	 myModel.addTableModelListener(this);

	 if (newModel instanceof BusinessObjectContainer) {
	    myModel.setModel ((BusinessObjectContainer) newModel);  
	 }
      }
      else {
	 myModel.setModel ((BusinessObjectContainer) null);  
      }

      resizeColumns();

//##End   TableFormUI:handleModelChange(Object,Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleButton1DoubleClicked                       */
        /*                                                              */
        /**
         * This method is called whenever the user doubleclicks on button
         * 1. The default behavior is to invoke the change action if one is
         * defined.
         *  
         * @param       point:Point
         */
        /*==============================================================*/
   protected  void  handleButton1DoubleClicked (
                                                Point  point
                                               )
   {
//##Begin TableFormUI:handleButton1DoubleClicked(Point) preserve=yes
      if (changeAction != null && changeAction.isEnabled()) {
	 getChangeAction().actionPerformed(new ActionEvent(getTable(),
							   ActionEvent.ACTION_PERFORMED,
							   "Double click"));
      }
//##End   TableFormUI:handleButton1DoubleClicked(Point)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createUI                                         */
        /*                                                              */
        /**
         * @param       aComponent:JComponent
         * @return      :ComponentUI -
         */
        /*==============================================================*/
   public static  ComponentUI  createUI (
                                         JComponent  aComponent
                                        )
   {
//##Begin TableFormUI:createUI(JComponent) preserve=yes
      return new TableFormUI();
//##End   TableFormUI:createUI(JComponent)
   }

    /*==============================================================*/
    /* The private variables listed below, plus the following two   */
    /* methods create an API within this class to quickly and       */
    /* simply enable and disable mouse clicks, effectively          */
    /* rendering tables as read-only.                               */
    /* This functionality was added to enforce restrictions on the  */
    /* ability to apply APRs based on mainframe security values.    */
    /*==============================================================*/

    private MouseAdapter saveMouseAdapter = null;
    private MouseAdapter emptyMouseAdapter = new MouseAdapter() {};

    /*==============================================================*/
    /* OPERATION: disableTableMouseListener                         */
    /*==============================================================*/
    /**
     * Save off the current MouseListener for the pane, and replace
     * it with a no-op listener, to temporarily disable it.
     */
    public void disableTableMouseListener() {
//##Begin TableFormUI:disableTableMouseListener() preserve=yes

	if(getMouseAdapter() == emptyMouseAdapter) return; // already disabled
	saveMouseAdapter = getMouseAdapter();
	if((table != null) && (saveMouseAdapter != null)) {
	    ((TableForm)getFormComponent()).getScrollPane().removeMouseListener(saveMouseAdapter);
	    table.removeMouseListener(saveMouseAdapter);

	    ((TableForm)getFormComponent()).getScrollPane().addMouseListener(emptyMouseAdapter);
	    table.addMouseListener(emptyMouseAdapter);

	    setMouseAdapter(emptyMouseAdapter);
	    undefineKeys();
	}

//##End   TableFormUI:disableTableMouseListener()
    }

    /*==============================================================*/
    /* OPERATION: enableTableMouseListener                          */
    /*==============================================================*/
    /**
     * Restore the previously saved MouseListener
     */
    public void enableTableMouseListener() {
//##Begin TableFormUI:enableTableMouseListener() preserve=yes

	if(getMouseAdapter() == saveMouseAdapter) return; // already restored
	if((table != null) && (saveMouseAdapter != null)) {
	    ((TableForm)getFormComponent()).getScrollPane().removeMouseListener(emptyMouseAdapter);
	    table.removeMouseListener(emptyMouseAdapter);

	    ((TableForm)getFormComponent()).getScrollPane().addMouseListener(saveMouseAdapter);
	    table.addMouseListener(saveMouseAdapter);

	    setMouseAdapter(saveMouseAdapter);
	    defineKeys();
	}

//##End   TableFormUI:enableTableMouseListener()
    }

}
