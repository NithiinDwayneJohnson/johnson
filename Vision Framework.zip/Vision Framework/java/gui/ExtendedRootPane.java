/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedRootPane.java                                   */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 0.5                          */
/* Emitter  :   JavaFileEmitter    Version 0.5                          */
/* Generated:   1997 November 20 at 08:17:31 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.LayoutManager2;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JLayeredPane;
import javax.swing.JRootPane;
import javax.swing.JToolBar;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedRootPane                                        */
/**
 * This class enhances the default JRootPane by adding an optional ToolBar
 * and Status bar components in addition to the existing JMenuBar. The
 * implementation avoided adding these new components to the south and
 * south sides of the content pane since these areas should be application
 * specific. Thus a new layout was implemented to ensure that the newly
 * added components are at the frame layer.
 * <p>
 * The extended root pane also creates a FormComponent for use as its content
 * pane. This allows for better integration with other serives provided by
 * the framework such as save.
 */
/*======================================================================*/
public  class  ExtendedRootPane  extends  JRootPane
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedRootPane:Attributes preserve=yes

//##End   ExtendedRootPane:Attributes

    /*==================================================================*/
    /* Public Attributes                                                */
    /*==================================================================*/
   public JToolBar   toolBar;
   public JComponent statusBar;
   public ScrollingMarqueeField     marqueeField;
   public JComponent statusBar2;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getToolBar                                       */
        /*                                                              */
        /**
         * This method returns the value of the "toolBar" attribute.
         *
         * @return      :JToolBar -
         *                 The value of the "toolBar" attribute.
         */
        /*==============================================================*/
   public  JToolBar  getToolBar (
                                )
   {
//##Begin ExtendedRootPane:getToolBar() preserve=no

      return (toolBar);

//##End   ExtendedRootPane:getToolBar()
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * This method returns the value of the "statusBar" attribute.
         *
         * @return      :JComponent -
         *                 The value of the "statusBar" attribute.
         */
        /*==============================================================*/
   public  JComponent  getStatusBar (
                                    )
   {
//##Begin ExtendedRootPane:getStatusBar() preserve=no

      return (statusBar);

 //##End   ExtendedRootPane:getStatusBar()
   }

   public  JComponent getStatusBar2 (
	                                      )
   {
	   return (statusBar2);
   }


        /*==============================================================*/
        /* OPERATION:  getMarqueeField                                  */
        /*                                                              */
        /**
         * This method returns the value of the "marqueeField" attribute.
         *
         * @return      :ScrollingMarqueeField -
         *                 The value of the "marqueeField" attribute.
         */
        /*==============================================================*/
   public ScrollingMarqueeField getMarqueeField (
                                                )
   {
//##Begin ExtendedRootPane:getMarqueeField() preserve=no

      return (marqueeField);

 //##End   ExtendedRootPane:getMarqueeField()
   }

    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setToolBar                                       */
        /*                                                              */
        /**
         * This method sets the value of the "toolBar" attribute.
         *
         * @param       aValue:JToolBar
         *                 The value of the "toolBar" attribute.
         */
        /*==============================================================*/
   public  void  setToolBar (
                             JToolBar  aValue
                            )
   {
//##Begin ExtendedRootPane:setToolBar(JToolBar) preserve=yes
      if(toolBar != null && toolBar.getParent() == getLayeredPane()) {
	getLayeredPane().remove(toolBar);
      }

      toolBar = aValue;

      if(aValue != null) {
	getLayeredPane().add(aValue, JLayeredPane.FRAME_CONTENT_LAYER);
      }

//##End   ExtendedRootPane:setToolBar(JToolBar)
   }

        /*==============================================================*/
        /* OPERATION:  setStatusBar                                     */
        /*                                                              */
        /**
         * This method sets the value of the "statusBar" attribute.
         *
         * @param       aValue:JComponent
         *                 The value of the "statusBar" attribute.
         */
        /*==============================================================*/
   public  void  setStatusBar (
                               JComponent  aValue
                              )
   {
//##Begin ExtendedRootPane:setStatusBar(JComponent) preserve=yes
      if(statusBar != null && statusBar.getParent() == getLayeredPane()) {
	getLayeredPane().remove(statusBar);
      }

      statusBar = aValue;

      if(aValue != null) {
	getLayeredPane().add(aValue, JLayeredPane.FRAME_CONTENT_LAYER);
      }

//##End   ExtendedRootPane:setStatusBar(JComponent)
   }

   public  void  setStatusBar2 (
	   							 JComponent aValue
								)
   {
	   if(statusBar2 != null && statusBar2.getParent() == getLayeredPane()) {
	   		getLayeredPane().remove(statusBar2);
	   }

	   statusBar2 = aValue;

	   if(aValue != null) {
	   		getLayeredPane().add(aValue, JLayeredPane.FRAME_CONTENT_LAYER);
       }
   }


   public void removeStatusBar2 (
	   							)
   {
	   	if (statusBar2 != null)
	   	{
	   		getLayeredPane().remove(statusBar2);
	   		statusBar2 = null;
		}
   }

        /*==============================================================*/
        /* OPERATION:  setMarqueeField                                  */
        /*                                                              */
        /**
         * This method sets the value of the "marqueeField" attribute.
         *
         * @param       aValue:ScrollingMarqueeField
         *                 The value of the "marqueeField" attribute.
         */
        /*==============================================================*/
   public void setMarqueeField(ScrollingMarqueeField aValue)
      {
//##Begin ExtendedRootPane:setMarqueeField(ScrollingMarqueeField) preserve=yes
	 if(marqueeField != null && marqueeField.getParent() == getLayeredPane()) {
	    getLayeredPane().remove(marqueeField);
	 }

	 marqueeField = aValue;

	 if(aValue != null) {
	    getLayeredPane().add(aValue, JLayeredPane.FRAME_CONTENT_LAYER);
	 }
//##End   ExtendedRootPane:setMarqueeField(ScrollingMarqueeField)
      }

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setContentPane                                   */
        /*                                                              */
        /**
         * This method is overridden in order to ensure that the only valid
         * content panes are those derived from FormComponent.
         *
         * @param       aContainer:Container
         */
        /*==============================================================*/
   public  void  setContentPane (
                                 Container  aContainer
                                )
   {
//##Begin ExtendedRootPane:setContentPane(Container) preserve=yes
      if (aContainer instanceof FormComponent == false) {
	throw new IllegalArgumentException("Content pane must be a subclass of FormComponent");
      }
      super.setContentPane(aContainer);
//##End   ExtendedRootPane:setContentPane(Container)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createRootLayout                                 */
        /*                                                              */
        /**
         * This method is overridden in order to handle the layout of the
         * newly added components.
         *
         * @return      :LayoutManager -
         */
        /*==============================================================*/
   protected  LayoutManager  createRootLayout (
                                              )
   {
//##Begin ExtendedRootPane:createRootLayout() preserve=yes
      return new ExtendedRootLayout();
//##End   ExtendedRootPane:createRootLayout()
   }

        /*==============================================================*/
        /* OPERATION:  createContentPane                                */
        /*                                                              */
        /**
         * Overriden to create a FormComponent instead of the generic container
         * class.
         *
         * @return      :Container -
         */
        /*==============================================================*/
   protected  Container  createContentPane (
                                           )
   {
//##Begin ExtendedRootPane:createContentPane() preserve=yes
      return new FormComponent();
//##End   ExtendedRootPane:createContentPane()
   }


    /*==================================================================*/
    /*=========================               ==========================*/
    /*========================= Inner Classes ==========================*/
    /*=========================               ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* CLASS:       ExtendedRootLayout                                  */
    /**
     * No documentation is currently available for this class.
     */
    /*==================================================================*/
    public  class  ExtendedRootLayout  implements  LayoutManager2
    {


        /*==============================================================*/
        /* Custom Attributes                                            */
        /*==============================================================*/
//##Begin ExtendedRootLayout:Attributes preserve=yes

//##End   ExtendedRootLayout:Attributes

        /*==============================================================*/
        /* Public Operations                                            */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  layoutContainer                              */
            /*                                                          */
            /**
             * @param       parent:Container
             */
            /*==========================================================*/
       public  void  layoutContainer (
                                      Container  parent
                                     )
       {
//##Begin ExtendedRootLayout:layoutContainer(Container) preserve=yes
	    Rectangle   b          = parent.getBounds();
	    Insets      i          = getInsets();
	    int         contentY   = 0;

	    int w = b.width - i.right - i.left;
	    int h = b.height - i.top - i.bottom;

	    if(getLayeredPane() != null) {
	       getLayeredPane().setBounds(i.left, i.top, w, h);
	    }

	    if(getGlassPane() != null) {
	       getGlassPane().setBounds(i.left, i.top, w, h);
	    }

	    //============================================================
	    // Note: This is laying out the children in the layeredPane,
	    // technically, these are not our chilren.
	    //============================================================

	    if(getJMenuBar() != null) {
	       Dimension mbd = getJMenuBar().getPreferredSize();
	       getJMenuBar().setBounds(0, 0, w, mbd.height);
	       contentY += mbd.height;
	    }

	    if(getToolBar() != null) {
	       Dimension tbd = getToolBar().getPreferredSize();
	       getToolBar().setBounds(0, contentY , w, tbd.height);
	       contentY += tbd.height;
	    }

	    Dimension sbd;

	    if(getStatusBar() != null) {
	       sbd = getStatusBar().getPreferredSize();
	    }
	    else {
	       sbd = new Dimension(0 , 0);

	    }

		Dimension sbd2;

	    if(getStatusBar2() != null) {
		   sbd2 = getStatusBar2().getPreferredSize();
	    }
	    else {
		   sbd2 = new Dimension(0 , 0);
	    }

	    if(getContentPane() != null) {
	       getContentPane().setBounds(0, contentY, w, h - contentY - sbd.height);
	       contentY = h - contentY - sbd.height;
	    }

	    if (getStatusBar() != null && getMarqueeField() != null && getStatusBar2() == null) {
	       getStatusBar().setBounds(0, h - sbd.height, (6 * w) / 10, sbd.height);
	       getMarqueeField().setBounds((6 * w) / 10, h - sbd.height, (4 * w) / 10, sbd.height);
	       getMarqueeField().setPreferredSize(new Dimension((4 * w) / 10, sbd.height));
	    }

	    if (getMarqueeField() != null && getStatusBar() == null && getStatusBar2() == null) {
	       getMarqueeField().setBounds(0, h - sbd.height, w, sbd.height);
	       getMarqueeField().setPreferredSize(new Dimension(w, sbd.height));
	    }

	    if (getStatusBar() != null && getMarqueeField() == null && getStatusBar2() != null) {
	       getStatusBar().setBounds(0, h - sbd.height,  w - sbd.height, sbd.height);
	       getStatusBar2().setBounds(w - sbd.height, h - sbd.height, sbd.height, sbd.height);
	       getStatusBar2().setPreferredSize(new Dimension(sbd.height, sbd.height));
	    }

	    if (getStatusBar() != null && getMarqueeField() == null && getStatusBar2() == null) {
			getStatusBar().setBounds(0, h - sbd.height, w, sbd.height);
	    }

//##End   ExtendedRootLayout:layoutContainer(Container)
       }

            /*=========================================================*/
            /* OPERATION:  invalidateLayout                            */
            /*                                                         */
            /**
             * @param       parent:Container
             */
            /*=========================================================*/
       public  void  invalidateLayout (
                                       Container  parent
                                      )
       {
//##Begin ExtendedRootLayout:invalidateLayout(Container) preserve=yes

//##End   ExtendedRootLayout:invalidateLayout(Container)
       }

            /*==========================================================*/
            /* OPERATION:  getLayoutAlignmentX                          */
            /*                                                          */
            /**
             * @param       parent:Container
             * @return      :float -
             */
            /*==========================================================*/
       public  float  getLayoutAlignmentX (
                                           Container  parent
                                          )
       {
//##Begin ExtendedRootLayout:getLayoutAlignmentX(Container) preserve=yes
	  return (0.0f);
//##End   ExtendedRootLayout:getLayoutAlignmentX(Container)
       }

            /*==========================================================*/
            /* OPERATION:  getLayoutAlignmentY                          */
            /*                                                          */
            /**
             * @param       parent:Container
             * @return      :float -
             */
            /*==========================================================*/
       public  float  getLayoutAlignmentY (
                                           Container  parent
                                          )
       {
//##Begin ExtendedRootLayout:getLayoutAlignmentY(Container) preserve=yes
	  return (0.0f);
//##End   ExtendedRootLayout:getLayoutAlignmentY(Container)
       }

            /*==========================================================*/
            /* OPERATION:  removeLayoutComponent                        */
            /*                                                          */
            /**
             * @param       comp:Component
             */
            /*==========================================================*/
       public  void  removeLayoutComponent (
                                            Component  comp
                                           )
       {
//##Begin ExtendedRootLayout:removeLayoutComponent(Component) preserve=yes

//##End   ExtendedRootLayout:removeLayoutComponent(Component)
       }

            /*==========================================================*/
            /* OPERATION:  addLayoutComponent                           */
            /*                                                          */
            /**
             * @param       comp:Component
             * @param       o:Object
             */
            /*==========================================================*/
       public  void  addLayoutComponent (
                                         Component  comp,
                                         Object     o
                                        )
       {
//##Begin ExtendedRootLayout:addLayoutComponent(Component,Object) preserve=yes

//##End   ExtendedRootLayout:addLayoutComponent(Component,Object)
       }

            /*==========================================================*/
            /* OPERATION:  addLayoutComponent                           */
            /*                                                          */
            /**
             * @param       name:String
             * @param       component:Component
             */
            /*==========================================================*/
       public  void  addLayoutComponent (
                                         String     name,
                                         Component  component
                                        )
       {
//##Begin ExtendedRootLayout:addLayoutComponent(String,Component) preserve=yes

//##End   ExtendedRootLayout:addLayoutComponent(String,Component)
       }

            /*==========================================================*/
            /* OPERATION:  minimumLayoutSize                            */
            /*                                                          */
            /**
             * @param       parent:Container
             * @return      :Dimension -
             */
            /*==========================================================*/
       public  Dimension  minimumLayoutSize (
                                             Container  parent
                                            )
       {
//##Begin ExtendedRootLayout:minimumLayoutSize(Container) preserve=yes
	    Dimension rd, mbd , tbd , sbd, sbd2;
	    int       maxWidth = 0;

	    Insets i = getInsets();

	    if(getContentPane() != null) {
	       rd = getContentPane().getMinimumSize();
	    }
	    else {
	       rd = parent.getSize();
	    }

	    maxWidth = Math.max(maxWidth , rd.width);

	    if(getJMenuBar() != null) {
	       mbd = getJMenuBar().getMinimumSize();
	    } else {
	       mbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , mbd.width);

	    if(getStatusBar() != null) {
	       sbd = getStatusBar().getMinimumSize();
	    } else {
	       sbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , sbd.width);

		if(getStatusBar2() != null) {
		   sbd2 = getStatusBar2().getMinimumSize();
		} else {
		   sbd2 = new Dimension(0, 0);
		}

	    maxWidth = Math.max(maxWidth , sbd2.width);

	    if(getToolBar() != null) {
	       tbd = getToolBar().getMinimumSize();
	    } else {
	       tbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , tbd.width);

	    return new Dimension(maxWidth + i.left + i.right,
				 rd.height + mbd.height + sbd.height + sbd2.height + tbd.height + i.top + i.bottom);

//##End   ExtendedRootLayout:minimumLayoutSize(Container)
       }

            /*==========================================================*/
            /* OPERATION:  maximumLayoutSize                            */
            /*                                                          */
            /**
             * @param       parent:Container
             * @return      :Dimension -
             */
            /*==========================================================*/
       public  Dimension  maximumLayoutSize (
                                             Container  parent
                                            )
       {
//##Begin ExtendedRootLayout:maximumLayoutSize(Container) preserve=yes
	    Dimension rd, mbd , tbd , sbd, sbd2;
	    int       minWidth = 0;

	    Insets i = getInsets();

	    if(getJMenuBar() != null) {
	       mbd = getJMenuBar().getMaximumSize();
	    } else {
	       mbd = new Dimension(0, 0);
	    }

	    minWidth = Math.min(mbd.width , minWidth);

	    if(getStatusBar() != null) {
	       sbd = getStatusBar().getMaximumSize();
	    } else {
	       sbd = new Dimension(0, 0);
	    }

	    minWidth = Math.min(sbd.width , minWidth);

	    if(getStatusBar2() != null) {
		   sbd2 = getStatusBar2().getMaximumSize();
		} else {
		   sbd2 = new Dimension(0, 0);
		}

	    minWidth = Math.min(sbd2.width , minWidth);

	    if(getToolBar() != null) {
	       tbd = getToolBar().getMaximumSize();
	    } else {
	       tbd = new Dimension(0, 0);
	    }

	    minWidth = Math.min(tbd.width , minWidth);

	    if(getContentPane() != null) {
	       rd = getContentPane().getMaximumSize();
	    }
	    else {
		rd = new Dimension(Integer.MAX_VALUE,
				   Integer.MAX_VALUE - i.top - i.bottom - mbd.height - tbd.height - sbd.height - sbd2.height - 1);
	    }

	    minWidth = Math.min(rd.width , minWidth);

	    return new Dimension(minWidth + i.left + i.right,
				 rd.height + mbd.height + sbd.height + sbd2.height + tbd.height + i.top + i.bottom);

//##End   ExtendedRootLayout:maximumLayoutSize(Container)
       }

            /*==========================================================*/
            /* OPERATION:  preferredLayoutSize                          */
            /*                                                          */
            /**
             * @param       parent:Container
             * @return      :Dimension -
             */
            /*==========================================================*/
       public  Dimension  preferredLayoutSize (
                                               Container  parent
                                              )
       {
//##Begin ExtendedRootLayout:preferredLayoutSize(Container) preserve=yes
	    Dimension rd, mbd , tbd , sbd, sbd2;
	    int       maxWidth = 0;

	    Insets i = getInsets();

	    if(getContentPane() != null) {
	       rd = getContentPane().getPreferredSize();
	    }
	    else {
	       rd = parent.getSize();
	    }

	    maxWidth = Math.max(maxWidth , rd.width);

	    if(getJMenuBar() != null) {
	       mbd = getJMenuBar().getPreferredSize();
	    } else {
	       mbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , mbd.width);

	    if(getStatusBar() != null) {
	       sbd = getStatusBar().getPreferredSize();
	    } else {
	       sbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , sbd.width);

	    if(getStatusBar2() != null) {
		   sbd2 = getStatusBar2().getPreferredSize();
		} else {
		   sbd2 = new Dimension(0, 0);
	    }

		maxWidth = Math.max(maxWidth , sbd2.width);

	    if(getToolBar() != null) {
	       tbd = getToolBar().getPreferredSize();
	    } else {
	       tbd = new Dimension(0, 0);
	    }

	    maxWidth = Math.max(maxWidth , tbd.width);

	    return new Dimension(maxWidth + i.left + i.right,
				 rd.height + mbd.height + sbd.height + sbd2.height + tbd.height + i.top + i.bottom);

//##End   ExtendedRootLayout:preferredLayoutSize(Container)
       }


    }

}
