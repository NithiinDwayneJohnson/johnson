package COM.novusnet.vision.java.gui;


/**
 * This is the default validator that is associated with the ExtendedTextField class. This class checks
 * for requirement.
 */
public class DefaultValidator implements Validator
{
   /**
    * Checks the validity of a text component. If the field has no data and it is marked
    * as required, then an error is returned.
    * @param component The ExtendedTextField component to check against.
    * @param value     The value to check.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component)
   {
      if ( component.getText().length() == 0) {
	 if (component.isRequired()) {
	    return false;
	 }
      }
      return true;
   }
}
