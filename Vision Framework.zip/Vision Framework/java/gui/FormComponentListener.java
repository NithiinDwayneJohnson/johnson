/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      FormComponentListener.java                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 April 03 at 13:51:36 CST                           */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.util.EventListener;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       FormComponentListener                                   */
/**
 * This listener can be used to monitor various events that a form
 * component fires. Mainly, these events are triggered when a save is
 * taking placing.
 */
/*======================================================================*/
public interface  FormComponentListener  extends  EventListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin FormComponentListener:Attributes preserve=yes

//##End   FormComponentListener:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  storeStarted                                     */
        /*                                                              */
        /**
         * This method is called when the store process starts. This does
         * not mean that a transaction is active.
         *  
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  storeStarted (
                               FormComponentEvent  e
                              );

        /*==============================================================*/
        /* OPERATION:  storeEnded                                       */
        /*                                                              */
        /**
         * This event is fired when the store process ends.
         *  
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  storeEnded (
                             FormComponentEvent  e
                            );

        /*==============================================================*/
        /* OPERATION:  storeCommit                                      */
        /*                                                              */
        /**
         * This event is fired when the commit method in which a
         * transaction is guaranteed to be active, is called. Listeners
         * should commit user entered data to the models.
         *  
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  storeCommit (
                              FormComponentEvent  e
                             );

        /*==============================================================*/
        /* OPERATION:  storePrepare                                     */
        /*                                                              */
        /**
         * This event is fired when the prepareForm method is called. It
         * gives listeners a chance to abort the store process.
         *  
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  storePrepare (
                               FormComponentEvent  e
                              );

        /*==============================================================*/
        /* OPERATION:  reset                                            */
        /*                                                              */
        /**
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  reset (
                        FormComponentEvent  e
                       );

        /*==============================================================*/
        /* OPERATION:  disengage                                        */
        /*                                                              */
        /**
         * Called when the form ui is set to null. All DCC's should
         * disengage.
         *  
         * @param       e:FormComponentEvent
         */
        /*==============================================================*/
   public  void  disengage (
                            FormComponentEvent  e
                           );


}
