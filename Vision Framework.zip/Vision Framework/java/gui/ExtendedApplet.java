/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedApplet.java                                     */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 04 at 16:12:19 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.BorderLayout;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.JApplet;
import javax.swing.JRootPane;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedApplet                                          */
/**
 * This class is the base class for all framework applets. Its main
 * responsibility is to load and run an application named as a parameter
 * value in the HTML file's applet tag. The parameter is ApplicationClass
 * and the value is your subclass of Application.
 * <p>
 * After initialization is complete, the Application's ini()method is
 * called. The browser invokes the start() stop() and destroy() methods on
 * this applet. These methods are always forwarded to the Application
 * class. The html file should look something like this:
<pre>
applet code="COM.novusnet.vision.java.gui.ExtendedApplet.class"
        width=800 height=800 Reuiqres Java enabled web browser>
<param name="ApplicationClass" value="temp.TesterApp">
/applet
</pre>
 */
/*======================================================================*/
public  class  ExtendedApplet  extends  JApplet
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedApplet:Attributes preserve=yes
   boolean  startedRun, appletStarted;
//##End   ExtendedApplet:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private        Application application;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   private static Hashtable   groupToApplet = new Hashtable(1);

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ExtendedApplet                                   */
        /*                                                              */
        /**
         * Constructor.
         *  
         */
        /*==============================================================*/
   public    ExtendedApplet (
                            )
   {
//##Begin ExtendedApplet:ExtendedApplet() preserve=yes
      getContentPane().setLayout(new BorderLayout());
//##End   ExtendedApplet:ExtendedApplet()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getGroupToApplet                                 */
        /*                                                              */
        /**
         * This method returns the value of thread group to applet mapping
         * table.
         *  
         * @return      :Hashtable -
         *                 The value of thread group to applet mapping
         *                 table.
         */
        /*==============================================================*/
   public static  Hashtable  getGroupToApplet (
                                              )
   {
//##Begin ExtendedApplet:getGroupToApplet() preserve=no

      return (groupToApplet);

//##End   ExtendedApplet:getGroupToApplet()
   }

        /*==============================================================*/
        /* OPERATION:  getApplication                                   */
        /*                                                              */
        /**
         * This method returns the value of the "application" attribute.
         *  
         * @return      :Application -
         *                 The value of the "application" attribute.
         */
        /*==============================================================*/
   public  Application  getApplication (
                                       )
   {
//##Begin ExtendedApplet:getApplication() preserve=no

      return (application);

//##End   ExtendedApplet:getApplication()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setGroupToApplet                                 */
        /*                                                              */
        /**
         * This method sets the value of thread group to applet mapping
         * table.
         *  
         * @param       aValue:Hashtable
         *                 The value of thread group to applet mapping
         *                 table.
         */
        /*==============================================================*/
   public static  void  setGroupToApplet (
                                          Hashtable  aValue
                                         )
   {
//##Begin ExtendedApplet:setGroupToApplet(Hashtable) preserve=no

      groupToApplet = aValue;

//##End   ExtendedApplet:setGroupToApplet(Hashtable)
   }

        /*==============================================================*/
        /* OPERATION:  setApplication                                   */
        /*                                                              */
        /**
         * This method sets the value of the "application" attribute.
         *  
         * @param       aValue:Application
         *                 The value of the "application" attribute.
         */
        /*==============================================================*/
   public  void  setApplication (
                                 Application  aValue
                                )
   {
//##Begin ExtendedApplet:setApplication(Application) preserve=no

      application = aValue;

//##End   ExtendedApplet:setApplication(Application)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  init                                             */
        /*                                                              */
        /**
         * This method is called by the browser. 
         *  
         */
        /*==============================================================*/
   public  void  init (
                      )
   {
//##Begin ExtendedApplet:init() preserve=yes
      super.init();

      setAppletForGroup(this);	       

      if (getApplication() == null) {

	 //=====================================================
	 // Hack for 0.7. )Otherwise JTable throws exceptions
	 //=====================================================
	 //	 setVisible(true);
	        
	 String param = getParameter("ApplicationClass");
      
	 if (param != null && !param.equals("")) {
	    Object newObject = instantiateObjectOfClass(param);
	 
	    if (newObject instanceof Application) {
	       setApplication((Application)newObject);
	    } 
	    else {
	       throw new IllegalArgumentException("ApplicationClass " + param +
						  " must be a subclass of COM.novusnet.vision.java.gui.Application");
	    }
	 } 
	 else {
	    throw new IllegalArgumentException("An ApplicationClass parameter must be specified in the <applet> tag.  For example:\n<applet code=\"netscape.application.ExtendedApplet\" width=320 height=200>\n    <param name=\"ApplicationClass\" value=\"MyApplication\">\n</applet>\n");
	 }  
      }     

      getApplication().init();
//##End   ExtendedApplet:init()
   }

        /*==============================================================*/
        /* OPERATION:  stop                                             */
        /*                                                              */
        /**
         * This method is called by the browser when the applet should stop
         * running. 
         *  
         */
        /*==============================================================*/
   public  void  stop (
                      )
   {
//##Begin ExtendedApplet:stop() preserve=yes
      getApplication().stop();
//##End   ExtendedApplet:stop()
   }

        /*==============================================================*/
        /* OPERATION:  start                                            */
        /*                                                              */
        /**
         * This method is called by the browser when the applet should
         * start running. 
         *  
         */
        /*==============================================================*/
   public  void  start (
                       )
   {
//##Begin ExtendedApplet:start() preserve=yes
      getApplication().start();
//##End   ExtendedApplet:start()
   }

        /*==============================================================*/
        /* OPERATION:  destroy                                          */
        /*                                                              */
        /**
         * This method is called by the browser. It notifies the
         * application of the fact then calls cleanup().
         *  
         */
        /*==============================================================*/
   public  void  destroy (
                         )
   {
//##Begin ExtendedApplet:destroy() preserve=yes
      cleanup();
//##End   ExtendedApplet:destroy()
   }

        /*==============================================================*/
        /* OPERATION:  run                                              */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public  void  run (
                     )
   {
//##Begin ExtendedApplet:run() preserve=yes

//##End   ExtendedApplet:run()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  instantiateObjectOfClass                         */
        /*                                                              */
        /**
         * This dynamically loads an Application class specified in the
         * applet HTML file.
         *  
         * @param       name:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  instantiateObjectOfClass (
                                                String  name
                                               )
   {
//##Begin ExtendedApplet:instantiateObjectOfClass(String) preserve=yes
      Class newClass;
      Object newObject;
      
      try {
	 newClass = Class.forName(name);
	 newObject = newClass.newInstance();
      } catch (ClassNotFoundException e) {
	 throw new IllegalArgumentException("Unable to find class \"" + name + "\"");
      } catch (InstantiationException e) {
	 throw new IllegalArgumentException("Unable to instantiate class \"" + name + "\" -- " + e.getMessage());
      } catch (IllegalAccessException e) {
	 throw new IllegalArgumentException("Unable to instantiate class \"" + name + "\" -- " + e.getMessage());
      }

      return newObject;

//##End   ExtendedApplet:instantiateObjectOfClass(String)
   }

        /*==============================================================*/
        /* OPERATION:  createRootPane                                   */
        /*                                                              */
        /**
         * Overridden to create an extenxed root pane.
         *  
         * @return      :JRootPane -
         */
        /*==============================================================*/
   protected  JRootPane  createRootPane (
                                        )
   {
//##Begin ExtendedApplet:createRootPane() preserve=yes
      return new ExtendedRootPane();
//##End   ExtendedApplet:createRootPane()
   }

        /*==============================================================*/
        /* OPERATION:  cleanup                                          */
        /*                                                              */
        /**
         * Cleanup resources associated with the Applet.
         *  
         */
        /*==============================================================*/
   protected  void  cleanup (
                            )
   {
//##Begin ExtendedApplet:cleanup() preserve=yes
      Enumeration       groups;
      ExtendedApplet    applet;
      ThreadGroup       group;

      groups = groupToApplet.keys();

      while (groups.hasMoreElements()) {
	 group = (ThreadGroup)groups.nextElement();
	 applet = (ExtendedApplet)groupToApplet.get(group);

	 if (applet == this) {
	    groupToApplet.remove(group);
	    break;
	 }
      }

      setApplication(null);

//##End   ExtendedApplet:cleanup()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getApplet                                        */
        /*                                                              */
        /**
         * Returns the singleton (Thread group) applet.
         *  
         * @return      :ExtendedApplet -
         */
        /*==============================================================*/
   public static  ExtendedApplet  getApplet (
                                            )
   {
//##Begin ExtendedApplet:getApplet() preserve=yes
      ThreadGroup group = Thread.currentThread().getThreadGroup();
      return (ExtendedApplet)groupToApplet.get(group);
//##End   ExtendedApplet:getApplet()
   }

        /*==============================================================*/
        /* OPERATION:  setAppletForGroup                                */
        /*                                                              */
        /**
         * Each applet belongs in its own thread group. This method simply
         * sets the applet for the current thread group.
         *  
         * @param       applet:ExtendedApplet
         */
        /*==============================================================*/
   protected static  void  setAppletForGroup (
                                              ExtendedApplet  applet
                                             )
   {
//##Begin ExtendedApplet:setAppletForGroup(ExtendedApplet) preserve=yes
      groupToApplet.put(Thread.currentThread().getThreadGroup(), applet);
//##End   ExtendedApplet:setAppletForGroup(ExtendedApplet)
   }


}
