package COM.novusnet.vision.java.gui;

import java.awt.Point;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.StringTokenizer;

import javax.swing.JTextArea;
import javax.swing.text.Caret;

/**
 *
 * The ExtendedTextArea provides missing functionality in the regular JTextArea.
 * For example, it allows developer to limit input number of characters per line and
 * number of lines(rows). All lines will be terminated with "\n\r" line fead, caret return
 * characters so the text is formatted without further processing
 *
 *
 *
 * <p> A developer should always set the limits befor calling limitInput() method.
 *     In case limits are equal to zero the limit input functionality will not be
 *     turned on.
 */

public class  ExtendedTextArea extends JTextArea
{

   private int maxRowCharacters = 0;
   private int maxRows          = 0;
   private int                 lineNumber = 0;
   StringTokenizer tokens     = new StringTokenizer("", "\n");

   /**
    * Handy constructor that takes the number of rows,columns, max number of characters in row  and
    * max number of rows.
    */
   public ExtendedTextArea(int rows, int columns, int maxRowCharacters, int maxRows)
   {
      super(rows, columns);
      setMaxRowCharacters(maxRowCharacters);
      setMaxRows(maxRows);
   }


   /**
    *  This method is used to get Max number of characters in one row
    */
    public int getMaxRowCharacters()
    {
         return maxRowCharacters;
    }

   /**
    *  This method is used to get Max number of characters in one row
    */
    public int getMaxRows()
    {
         return maxRows;
    }

   /**
    *  This method is used to set Max number of characters in one row
    */
    public void setMaxRowCharacters(int value)
    {
         maxRowCharacters = value;
    }

   /**
    *  This method is used to set Max number of rows allowed to
    *  be entered into JTextArea
    */
    public void setMaxRows(int value)
    {
         maxRows = value;
    }

   /**
    *  This method is used to limit input of:
    *  characters per row
    *  total rows
    *  into JTextArea
    *
    *
    */
    public void limitInput( )
    {
       setLineWrap(false);
       setWrapStyleWord(false);

       if(maxRows > 0 && maxRowCharacters > 0)
       {
         this.addKeyListener(new KeyAdapter()
         {
            public void keyPressed( KeyEvent e )
            {

               int lineCount = getLineCount();
               int c = e.getKeyCode();
               int Y_PositionOfCaret = 0;
               int X_PositionOfCaret = 0;
               int Y_PositionOfTextArea = 0;
               int fontSize = getFontMetrics(getFont()).getHeight();
               Caret caret = getCaret();

               if(caret.getMagicCaretPosition() != null)
               {
                  Y_PositionOfCaret = caret.getMagicCaretPosition().y;
                  X_PositionOfCaret = caret.getMagicCaretPosition().x;
                  Y_PositionOfTextArea = getY();
                  lineNumber = (int)((Y_PositionOfCaret - Y_PositionOfTextArea)/fontSize);
                }

                if(c == KeyEvent.VK_UP &&  lineNumber > 0)
                {
                   caret.setMagicCaretPosition(new Point(0, Y_PositionOfCaret - fontSize));
                }
                else if(c == KeyEvent.VK_DOWN &&  lineNumber < maxRows - 1)
                {
                   caret.setMagicCaretPosition(new Point(0, Y_PositionOfCaret + fontSize));
                }

                tokens = new StringTokenizer(getText(), "\n");
                int tokenNumber = 0;
                int caretPosition = getCaretPosition();

                while(tokens.hasMoreTokens())
                {
                    String line = tokens.nextToken();

//                    System.out.println("line.length() = " + line.length());
                    if((c == KeyEvent.VK_ENTER && lineCount < maxRows) || c == KeyEvent.VK_LEFT ||
                        c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ||
                        c == KeyEvent.VK_UP || c == KeyEvent.VK_DOWN )
                    {
                        setEditable(true);
                    }
                    else if( line.length()  >= maxRowCharacters &&
                             c != KeyEvent.VK_ENTER &&
                             c != KeyEvent.VK_RIGHT &&
                             c != KeyEvent.VK_CONTROL &&
                             c != KeyEvent.VK_END &&
                             lineCount < maxRows &&
                             tokenNumber == lineNumber)
                    {
                        if(caretPosition == getText().length())
                            append("\n\r");
                        else
                            insert("\n\r", (tokenNumber+1)*maxRowCharacters);
                    }
                    else if(lineCount >= maxRows && line.length() >= maxRowCharacters && tokenNumber == lineNumber)
                    {
                        setEditable(false);
                    }
                    else if(line.length()  < maxRowCharacters && tokenNumber == lineNumber)
                    {
                        setEditable(true);
                    }

                    ++tokenNumber;
                }

                if((c == KeyEvent.VK_ENTER && lineCount < maxRows) || c == KeyEvent.VK_LEFT ||
                   c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE ||
                   c == KeyEvent.VK_UP || c == KeyEvent.VK_DOWN )
                {
                    setEditable(true);
                }
                else if(c == KeyEvent.VK_ENTER && lineCount >= maxRows)
                {
                    setEditable(false);
                }
            }
         });

         this.addFocusListener(new FocusAdapter(){

             public void focusLost(FocusEvent fe)
             {
                 setEditable(true);
             }

         });

        }
    }
}











