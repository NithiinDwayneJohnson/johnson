/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TextDataComponentController.java                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 January 09 at 12:50:53 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.*;
import java.util.*;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/
import javax.swing.text.*;

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import COM.novusnet.vision.java.gui.*;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TextDataComponentController                             */
/**
 * An implementation of a data controller that handles simple text. 
 */
/*======================================================================*/
public  class  TextDataComponentController  extends  DataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TextDataComponentController:Attributes preserve=yes
//##End   TextDataComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TextDataComponentController                      */
        /*                                                              */
        /**
         * This constructor takes the name of the attribute in the model
         * and text component that needs to be managed.
         *  
         * @param       component:JTextComponent
         * @param       name:String
         */
        /*==============================================================*/
   public    TextDataComponentController (
                                          JTextComponent  component,
                                          String          name
                                         )
   {
//##Begin TextDataComponentController:TextDataComponentController(JTextComponent,String) preserve=yes
      this( component, name, null);     
//##End   TextDataComponentController:TextDataComponentController(JTextComponent,String)
   }

        /*==============================================================*/
        /* OPERATION:  TextDataComponentController                      */
        /*                                                              */
        /**
         * A constructor that takes a Variable , attribute name and a
         * component. 
         * <p>
         * The Variable is updated under the following conditions:
         * <p>
         *   - When the model (thus an attribute) is changed.
         * <p>
         *   - When an attribute in the model changes.
         * <p>
         *   - When the user interface component changes.
         * <p>
         * The Model attribute is updated under the following conditions:
         * <p>
         *   - During commit and if the Variable has changed. 
         * <p>
         *   - Optionally, whenver the Variable changes. 
         * <p>
         * The Component attribute is updated under the following
         * conditions:
         * <p>
         *       - Whenever the contents of the variable change.
         *  
         * @param       component:JComponent
         * @param       name:String
         * @param       variable:Variable
         */
        /*==============================================================*/
   public    TextDataComponentController (
                                          JComponent  component,
                                          String      name,
                                          Variable    variable
                                         )
   {
//##Begin TextDataComponentController:TextDataComponentController(JComponent,String,Variable) preserve=yes
      super( component, name, variable);     
//##End   TextDataComponentController:TextDataComponentController(JComponent,String,Variable)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Returns true or false based on the validity of the contents
         * entered by the user. This method is called whenever the
         * component loses focus. If the contents are valid, the model is
         * updated otherwise an error message is displayed to the user.
         * Subclassers can override this method to provide their own
         * validation routines.
         * <p>
         * The default implementation calls hasValidData() on
         * ExtendedTextFields.
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                            )
   {
//##Begin TextDataComponentController:isValid() preserve=yes
      if (component instanceof ExtendedTextField) {
	 return ((ExtendedTextField)component).hasValidData();
      }
     
      return true;
//##End   TextDataComponentController:isValid()
   }

        /*==============================================================*/
        /* OPERATION:  getComponentText                                 */
        /*                                                              */
        /**
         * Returns the text of the component.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getComponentText (
                                    )
   {
//##Begin TextDataComponentController:getComponentText() preserve=yes
      String  text   = ((JTextComponent)component).getText();
      return text;
//##End   TextDataComponentController:getComponentText()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleFocusLost                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleFocusLost (
                                    )
   {
//##Begin TextDataComponentController:handleFocusLost() preserve=yes
      
      if (getModel() == null) {
	 return;
      }

      if (!((JTextComponent)component).isEditable()) {
	 return;
      }
    
      updateModelValue();
//##End   TextDataComponentController:handleFocusLost()
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The new
         * attribute value is set on the text component. This happens only
         * if the two values are not equal.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin TextDataComponentController:handleValueChange(Object) preserve=yes
      //      System.out.println(this + "Model attribute " + attributeName + " has changed. New Value is:" + newValue);

      updateComponent(formatComponentContents(newValue));
      
      if (component instanceof JTextField) {
	 ((JTextField)component).setScrollOffset(0);
	 
	 if (((JTextField)component).getCaret() != null) {
	    ((JTextField)component).setCaretPosition(0);	 
	 }
      }
//##End   TextDataComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * This method is called just before the contents of the model are
         * updated. It gives subclassers a chance to create an appropriate
         * object for the attribute class.
         *  
         * @see getAttributeClass
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin TextDataComponentController:formatContents(String) preserve=yes
      return text;
//##End   TextDataComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  updateComponent                                  */
        /*                                                              */
        /**
         * Called whenever the contents of the component need updating (As
         * a result of attribute change).
         *  
         * @param       text:String
         */
        /*==============================================================*/
   protected  void  updateComponent (
                                     String  text
                                    )
   {
//##Begin TextDataComponentController:updateComponent(String) preserve=yes
      if (!text.equals(getComponentText())) {
	 ((JTextComponent)component).setText(text);
      }
//##End   TextDataComponentController:updateComponent(String)
   }

        /*==============================================================*/
        /* OPERATION:  formatComponentContents                          */
        /*                                                              */
        /**
         * This method is called just before the contents of the component
         * are updated. It gives subclassers a chance to create an
         * appropriate string from the attribute. The default method simply
         * calls toString() on the object.
         *  
         * @see formatContents
         *  
         * @param       object:Object
         * @return      :String -
         */
        /*==============================================================*/
   protected  String  formatComponentContents (
                                               Object  object
                                              )
   {
//##Begin TextDataComponentController:formatComponentContents(Object) preserve=yes
      if (object == null) {
	 object = "";
      }

      return object.toString();
//##End   TextDataComponentController:formatComponentContents(Object)
   }

        /*==============================================================*/
        /* OPERATION:  updateModelValue                                 */
        /*                                                              */
        /**
         * Called to update the model value with the current contents of
         * the field.
         *  
         */
        /*==============================================================*/
   protected  void  updateModelValue (
                                     )
   {
//##Begin TextDataComponentController:updateModelValue() preserve=yes

      if (!isValid()) {
	 displayError();
	 return;
      }

      String  text   = getComponentText();
      Object  value  = formatContents(text);

      getVariable().setValue(value);
//##End   TextDataComponentController:updateModelValue()
   }

        /*==============================================================*/
        /* OPERATION:  setToReadWrite                                   */
        /*                                                              */
        /**
         * @param       state:boolean
         */
        /*==============================================================*/
   protected  void  setToReadWrite (
                                    boolean  state
                                   )
   {
//##Begin TextDataComponentController:setToReadWrite(boolean) preserve=yes
      ((JTextComponent)component).setEditable(state);
//##End   TextDataComponentController:setToReadWrite(boolean)
   }


}
