/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PostalCodeComponentController.java                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 June 17 at 11:09:31 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.text.JTextComponent;

import COM.novusnet.vision.java.gui.dcc.TextDataComponentController;
import COM.novusnet.vision.java.commonbos.PostalCode;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PostalCodeComponentController                           */
/**
 * The component controller transfers user input to the model, only if the
 * contents of the postal code text field are valid.
 */
/*======================================================================*/
public  class  PostalCodeComponentController  extends  TextDataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PostalCodeComponentController:Attributes preserve=yes

//##End   PostalCodeComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  PostalCodeComponentController                    */
        /*                                                              */
        /**
         * This is the constructor for the postal code controller.
         *  
         * @param       component:JTextComponent
         * @param       name:String
         */
        /*==============================================================*/
   public    PostalCodeComponentController (
                                            JTextComponent  component,
                                            String          name
                                           )
   {
//##Begin PostalCodeComponentController:PostalCodeComponentController(JTextComponent,String) preserve=yes
      super(component, name);
//##End   PostalCodeComponentController:PostalCodeComponentController(JTextComponent,String)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * Overridden to construct a PostalCode object from a string.
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin PostalCodeComponentController:formatContents(String) preserve=yes
      return new PostalCode(text);
//##End   PostalCodeComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  formatComponentContents                          */
        /*                                                              */
        /**
         * This method is called just before the contents of the component
         * are updated.
         *  
         * @see formatContents
         *  
         * @param       object:Object
         * @return      :String -
         */
        /*==============================================================*/
   protected  String  formatComponentContents (
                                               Object  object
                                              )
   {
//##Begin PostalCodeComponentController:formatComponentContents(Object) preserve=yes
      
      if (object == null) {
	 object = new PostalCode();
      }

      return ((PostalCode)object).getUnformattedPostalCode();
//##End   PostalCodeComponentController:formatComponentContents(Object)
   }
}

