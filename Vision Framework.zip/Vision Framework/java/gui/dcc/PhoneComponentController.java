/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PhoneComponentController.java                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 June 17 at 11:14:27 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.text.JTextComponent;

import COM.novusnet.vision.java.gui.dcc.TextDataComponentController;
import COM.novusnet.vision.java.commonbos.PhoneNumber;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PhoneComponentController                                */
/**
 * The component controller transfers user input to the model, only if the
 * contents of the phone number text field are valid.
 */
/*======================================================================*/
public  class  PhoneComponentController  extends  TextDataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PhoneComponentController:Attributes preserve=yes

//##End   PhoneComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  PhoneComponentController                         */
        /*                                                              */
        /**
         * This is the constructor for the phone controller.
         *  
         * @param       component:JTextComponent
         * @param       name:String
         */
        /*==============================================================*/
   public    PhoneComponentController (
                                       JTextComponent  component,
                                       String          name
                                      )
   {
//##Begin PhoneComponentController:PhoneComponentController(JTextComponent,String) preserve=yes
      super(component, name);
//##End   PhoneComponentController:PhoneComponentController(JTextComponent,String)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * Overridden to construct a PhoneNumber object from a string.
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin PhoneComponentController:formatContents(String) preserve=yes
      return new PhoneNumber(text);
//##End   PhoneComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  formatComponentContents                          */
        /*                                                              */
        /**
         * This method is called just before the contents of the component
         * are updated. It gives subclassers a chance to create an
         * appropriate string from the attribute. 
         *  
         * @see formatContents
         *  
         * @param       object:Object
         * @return      :String -
         */
        /*==============================================================*/
   protected  String  formatComponentContents (
                                               Object  object
                                              )
   {
//##Begin PhoneComponentController:formatComponentContents(Object) preserve=yes
      
      PhoneNumber myPhoneNumber = (PhoneNumber)object;

      if (myPhoneNumber == null) {
	 myPhoneNumber = new PhoneNumber();
      }

      return myPhoneNumber.getUnformattedPhoneNumberShort();
//##End   PhoneComponentController:formatComponentContents(Object)
   }
}
