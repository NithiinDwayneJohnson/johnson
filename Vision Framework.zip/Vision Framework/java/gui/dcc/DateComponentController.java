/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      DateComponentController.java                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 July 02 at 13:43:47 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Calendar;

import COM.novusnet.vision.java.gui.DateTextField;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       DateComponentController                                 */
/**
 * This controller handles interaction between date attributes and date
 * components.
 */
/*======================================================================*/
public  class  DateComponentController  extends  TextDataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin DateComponentController:Attributes preserve=yes

//##End   DateComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  DateComponentController                          */
        /*                                                              */
        /**
         * @param       component:DateTextField
         * @param       name:String
         */
        /*==============================================================*/
   public    DateComponentController (
                                      DateTextField  component,
                                      String         name
                                     )
   {
//##Begin DateComponentController:DateComponentController(DateTextField,String) preserve=yes
      super(component, name);

      component.addPropertyChangeListener(new PropertyChangeListener() {
	 public  void  propertyChange (PropertyChangeEvent  e) {
	    if (e.getPropertyName().equals("date")) {
	       handleFocusLost(); // We probably need to create a new method. This is cheating.
	    }
	 }
      });

//##End   DateComponentController:DateComponentController(DateTextField,String)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Returns true or false based on the validity of the contents
         * entered by the user. 
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                            )
   {
//##Begin DateComponentController:isValid() preserve=yes
      return ((DateTextField)component).hasValidData();
//##End   DateComponentController:isValid()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * This method is called just before the contents of the model are
         * updated. It gives subclassers a chance to create an appropriate
         * object for the attribute class.
         *  
         * @see getAttributeClass
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin DateComponentController:formatContents(String) preserve=yes
      // return null if the text field sent is bogus.
      if (text != null && text.length() != 0) {
	 return ((DateTextField)component).getDate();
      } 
      else { return null;}
//##End   DateComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The new
         * attribute value is set on the text component. This happens only
         * if the two values are not equal.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin DateComponentController:handleValueChange(Object) preserve=yes
      ((DateTextField)component).setDate((Calendar)newValue);      
//##End   DateComponentController:handleValueChange(Object)
   }
}
