package COM.novusnet.vision.java.gui.dcc.locale.en_US;

import java.util.ListResourceBundle;

public class Resources extends ListResourceBundle
{
   public Object[][] getContents() 
   {
      return contents;
   }
   
   static final Object[][] contents = 
   {     
     {"error"               , " Field error" },
     {"defaultErrorMessage" , "The field \"{0}\" has an invalid value. Please correct."}
   };
}
