package COM.novusnet.vision.java.gui.dcc;


public class StringVariable extends Variable
{
   /**
    * Constructor that takes a string as a default value.
    *
    */
   public StringVariable(String defaultValue)
   {
      super(defaultValue);
   }   

   public String stringValue()
   {
      return (String)getValue();
   }
}





