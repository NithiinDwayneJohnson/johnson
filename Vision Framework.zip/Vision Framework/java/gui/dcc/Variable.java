package COM.novusnet.vision.java.gui.dcc;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import COM.novusnet.vision.java.businessobjects.ModelInterface;

public class Variable implements ModelInterface
{
   Object value;

   private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

   public Variable()
   {
      this(null);
   }

   public Variable(Object defaultValue)
   {
      value = defaultValue;
   }

   public int hashCode()
   {
      if (value != null) {
	 return value.hashCode();
      }
      return super.hashCode();
   }

   public synchronized  void  addPropertyChangeListener (
                                                         PropertyChangeListener  aListener
                                                        )
   {
      propertyChangeSupport.addPropertyChangeListener (aListener);
   }

   public synchronized  void  removePropertyChangeListener (
                                                            PropertyChangeListener  aListener
                                                           )
   {
      propertyChangeSupport.removePropertyChangeListener (aListener);
   }

   public  void  firePropertyChange (
                                     String  propertyName,
                                     Object  oldValue,
                                     Object  newValue
                                    )
   {
      propertyChangeSupport.firePropertyChange (propertyName, oldValue, newValue);    
   }


   /**
    * Sets the value of the variable.
    */
   public void setValue(Object newValue)
   {
      if (value == newValue) {
         return;
      }

      if (value != null) {
         if (value.equals(newValue)) {
            return;
         }
      }

      Object myOldValue = value;

      value = newValue;

      firePropertyChange ("value", myOldValue, value);
   }

   /**
    * Get the value of the variable.
    */
   public Object getValue()
   {
      return value;
   }
}




