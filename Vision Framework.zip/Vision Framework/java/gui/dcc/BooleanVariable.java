package COM.novusnet.vision.java.gui.dcc;


public class BooleanVariable extends Variable
{
   /**
    * Constructor that takes an boolean as a default value.
    */
   public BooleanVariable(boolean defaultValue)
   {
      super (new Boolean(defaultValue));
   }   

   /**
    * Constructor that takes an Boolean as a default value.
    */
   public BooleanVariable(Boolean defaultValue)
   {
      super (defaultValue);
   }   

   public boolean booleanValue()
   {
      return ((Boolean)getValue()).booleanValue();
   }
}
