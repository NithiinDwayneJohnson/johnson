package COM.novusnet.vision.java.gui.dcc;


public class IntegerVariable extends Variable
{
   /**
    * Constructor that takes an int as a default value.
    */
   public IntegerVariable(int defaultValue)
   {
      super (new Integer(defaultValue));
   }   

   /**
    * Constructor that takes an Integer as a default value.
    */
   public IntegerVariable(Integer defaultValue)
   {
      super (defaultValue);
   }   

   public int intValue()
   {
      return ((Integer)getValue()).intValue();
   }
}



