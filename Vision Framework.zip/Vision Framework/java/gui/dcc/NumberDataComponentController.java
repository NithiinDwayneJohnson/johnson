/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      NumberDataComponentController.java                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 27 at 11:22:17 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import COM.novusnet.vision.java.gui.NumberEditField;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       NumberDataComponentController                           */
/**
 * This controller is suitable for linking numeric fields to
 * NumberEditField and family.
 */
/*======================================================================*/
public  class  NumberDataComponentController  extends  TextDataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin NumberDataComponentController:Attributes preserve=yes

//##End   NumberDataComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  NumberDataComponentController                    */
        /*                                                              */
        /**
         * The default constructor.
         *  
         * @param       component:NumberEditField
         * @param       name:String
         */
        /*==============================================================*/
   public    NumberDataComponentController (
                                            NumberEditField  component,
                                            String           name
                                           )
   {
//##Begin NumberDataComponentController:NumberDataComponentController(NumberEditField,String) preserve=yes
      this( component, name, null);     

//##End   NumberDataComponentController:NumberDataComponentController(NumberEditField,String)
   }

        /*==============================================================*/
        /* OPERATION:  NumberDataComponentController                    */
        /*                                                              */
        /**
         * A constructor that takes a Variable , attribute name and a
         * component. 
         * <p>
         * The Variable is updated under the following conditions:
         * <p>
         *   - When the model (thus an attribute) is changed.
         * <p>
         *   - When an attribute in the model changes.
         * <p>
         *   - When the user interface component changes.
         * <p>
         * The Model attribute is updated under the following conditions:
         * <p>
         *   - During commit and if the Variable has changed. 
         * <p>
         *   - Optionally, whenver the Variable changes. 
         * <p>
         * The Component attribute is updated under the following
         * conditions:
         * <p>
         *       - Whenever the contents of the variable change.
         *  
         * @param       component:NumberEditField
         * @param       name:String
         * @param       variable:Variable
         */
        /*==============================================================*/
   public    NumberDataComponentController (
                                            NumberEditField  component,
                                            String           name,
                                            Variable         variable
                                           )
   {
//##Begin NumberDataComponentController:NumberDataComponentController(NumberEditField,String,Variable) preserve=yes
      super( component, name, variable);     

      component.addPropertyChangeListener(new PropertyChangeListener() {
	 public  void  propertyChange (PropertyChangeEvent  e) {

	    if (e.getPropertyName().equals("value")) {
       
	       if (getModel() == null) {
		  return;
	       }
	       
	       updateModelValue();
	    }
	 }
      }); 
//##End   NumberDataComponentController:NumberDataComponentController(NumberEditField,String,Variable)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleAttributeChange                            */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The new
         * attribute value is set on the numeric component. This happens
         * only if the two values are not equal.
         *  
         * @param       oldValue:Object
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleAttributeChange (
                                           Object  oldValue,
                                           Object  newValue
                                          )
   {
//##Begin NumberDataComponentController:handleAttributeChange(Object,Object) preserve=yes
      ((NumberEditField)component).setValue((Number)newValue);      
//##End   NumberDataComponentController:handleAttributeChange(Object,Object)
   }

        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * This method is called just before the contents of the model are
         * updated. We simply call getValue() on the NumberEditField and
         * convert it to the appropriate number subclass.
         *  
         * @see getAttributeClass
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin NumberDataComponentController:formatContents(String) preserve=yes
      Number myNumber = ((NumberEditField)component).getValue();

      if (myNumber != null) {
	 Class  classOfAttribute = getAttributeClass();

	 if (classOfAttribute.equals(Integer.TYPE)) {
	    return new Integer(myNumber.intValue());
	 } 
	 else if (classOfAttribute.equals(Double.TYPE)) {
	    return new Double(myNumber.doubleValue());
	 } 
	 else if (classOfAttribute.equals(Float.TYPE)) {
	    return new Float(myNumber.floatValue());
	 } 
	 else if (classOfAttribute.equals(Long.TYPE)) {
	    return new Long(myNumber.longValue());
	 } 
	 else if (classOfAttribute.equals(Short.TYPE)) {
	    return new Short(myNumber.shortValue());
	 } 
      }

      return null;
//##End   NumberDataComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The new
         * attribute value is set on the text component. This happens only
         * if the two values are not equal.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin NumberDataComponentController:handleValueChange(Object) preserve=yes
      ((NumberEditField)component).setValue((Number)newValue); 
//##End   NumberDataComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleFocusLost                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleFocusLost (
                                    )
   {
//##Begin NumberDataComponentController:handleFocusLost() preserve=yes

//##End   NumberDataComponentController:handleFocusLost()
   }


}
