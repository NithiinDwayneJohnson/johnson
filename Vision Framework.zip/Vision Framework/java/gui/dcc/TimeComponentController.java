/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TimeComponentController.java                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 July 02 at 13:43:47 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Calendar;

import COM.novusnet.vision.java.gui.TimeTextField;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TimeComponentController                                 */
/**
 * This controller handles interaction between Time attributes and time
 * components.
 */
/*======================================================================*/
public  class  TimeComponentController  extends  TextDataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TimeComponentController:Attributes preserve=yes

//##End   TimeComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TimeComponentController                          */
        /*                                                              */
        /**
         * @param       component:TimeTextField
         * @param       name:String
         */
        /*==============================================================*/
   public    TimeComponentController (
                                      TimeTextField  component,
                                      String         name
                                     )
   {
//##Begin TimeComponentController:TimeComponentController(TimeTextField,String) preserve=yes
      super(component, name);

      component.addPropertyChangeListener(new PropertyChangeListener() {
	 public  void  propertyChange (PropertyChangeEvent  e) {
	    if (e.getPropertyName().equals("time")) {
	       handleFocusLost(); // We probably need to create a new method. This is cheating.
	    }
	 }
      });

//##End   TimeComponentController:TimeComponentController(TimeTextField,String)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Returns true or false based on the validity of the contents
         * entered by the user. 
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                            )
   {
//##Begin TimeComponentController:isValid() preserve=yes
      return ((TimeTextField)component).hasValidData();
//##End   TimeComponentController:isValid()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  formatContents                                   */
        /*                                                              */
        /**
         * This method is called just before the contents of the model are
         * updated. It gives subclassers a chance to create an appropriate
         * object for the attribute class.
         *  
         * @see getAttributeClass
         *  
         * @param       text:String
         * @return      :Object -
         */
        /*==============================================================*/
   protected  Object  formatContents (
                                      String  text
                                     )
   {
//##Begin TimeComponentController:formatContents(String) preserve=yes
      return ((TimeTextField)component).getTime();
//##End   TimeComponentController:formatContents(String)
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The new
         * attribute value is set on the text component. This happens only
         * if the two values are not equal.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin TimeComponentController:handleValueChange(Object) preserve=yes
      ((TimeTextField)component).setTime((Calendar)newValue);      
//##End   TimeComponentController:handleValueChange(Object)
   }
}
