/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      CheckBoxComponentController.java                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 July 02 at 11:02:22 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.JCheckBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       CheckBoxComponentController                             */
/**
 * The controller manages a check box and a boolean attribute in the model.
 */
/*======================================================================*/
public  class  CheckBoxComponentController  extends  DataComponentController
                                         implements  ChangeListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin CheckBoxComponentController:Attributes preserve=yes

//##End   CheckBoxComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  CheckBoxComponentController                      */
        /*                                                              */
        /**
         * The constructor of this class.
         *  
         * @param       component:JCheckBox
         * @param       name:String
         */
        /*==============================================================*/
   public    CheckBoxComponentController (
                                          JCheckBox  component,
                                          String     name
                                         )
   {
//##Begin CheckBoxComponentController:CheckBoxComponentController(JCheckBox,String) preserve=yes
      super(component, name);
      component.addChangeListener(this);
//##End   CheckBoxComponentController:CheckBoxComponentController(JCheckBox,String)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  stateChanged                                     */
        /*                                                              */
        /**
         * Public for implementation reasons. Do not call.
         *  
         * @param       e:ChangeEvent
         */
        /*==============================================================*/
   public  void  stateChanged (
                               ChangeEvent  e
                              )
   {
//##Begin CheckBoxComponentController:stateChanged(ChangeEvent) preserve=yes
      JCheckBox myCheckBox = (JCheckBox)e.getSource();      
      getVariable().setValue(new Boolean(myCheckBox.isSelected()));
//##End   CheckBoxComponentController:stateChanged(ChangeEvent)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin CheckBoxComponentController:handleValueChange(Object) preserve=yes
      Boolean currentValue = new Boolean(((JCheckBox)component).isSelected());

      if (newValue == null ) {
	 newValue = new Boolean(false);
      }

      if (newValue.equals(currentValue)) {
	 return;
      }

      ((JCheckBox)component).setSelected( ((Boolean)newValue).booleanValue());
//##End   CheckBoxComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  getAttributeClass                                */
        /*                                                              */
        /**
         * Returns the class of the attribute in the model. This method
         * returns Boolean.class.
         *  
         * @return      :Class -
         */
        /*==============================================================*/
   protected  Class  getAttributeClass (
                                       )
   {
//##Begin CheckBoxComponentController:getAttributeClass() preserve=yes
      return Boolean.class;
//##End   CheckBoxComponentController:getAttributeClass()
   }
}
