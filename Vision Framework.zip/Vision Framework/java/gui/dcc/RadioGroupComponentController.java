/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      RadioGroupComponentController.java                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 January 09 at 12:50:53 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JRadioButton;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       RadioGroupComponentController                           */
/**
 * The controller manages a set of radio buttons in a group. Each radio
 * button sets an attribute in a BO to some value. Similarly, when the
 * attribute in the BO is changed, the selection is automatically changed
 * in the group.
 */
/*======================================================================*/
public  class  RadioGroupComponentController  extends  DataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin RadioGroupComponentController:Attributes preserve=yes
//##End   RadioGroupComponentController:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private ButtonGroup group;
   private Hashtable   values;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  RadioGroupComponentController                    */
        /*                                                              */
        /**
         * The constructor of this class.
         * <p>
         * @param group. The group object.
         * <p>
         * @param name. The model attribute to set as a result of a change.
         * <p>
         * @param values.  A hash table of radio buttons to value mappings.
         * The key is the radio button.
         *  
         * @param       group:ButtonGroup
         * @param       name:String
         * @param       values:Hashtable
         */
        /*==============================================================*/
   public    RadioGroupComponentController (
                                            ButtonGroup  group,
                                            String       name,
                                            Hashtable    values
                                           )
   {
//##Begin RadioGroupComponentController:RadioGroupComponentController(ButtonGroup,String,Hashtable) preserve=yes
      super ((JComponent)(values.keys().nextElement()), name);

      this.group  = group;
      this.values = values;

      ActionListener actionListener = new ActionListener() {
	 public  void  actionPerformed (ActionEvent  e) {
	    //=================================================================
	    // Match the source to one of the radio buttons in the collection
	    // and read the value. Set the value on the target model.
	    //=================================================================
	    Object value = RadioGroupComponentController.this.values.get(e.getSource());		    	    
	    getVariable().setValue(value);
	 }
      };
	 
      Enumeration myEnum = values.keys();
      
      while (myEnum.hasMoreElements ()) {
         JRadioButton myRadioButton = (JRadioButton) myEnum.nextElement ();
	 myRadioButton.addActionListener( actionListener);
      }
//##End   RadioGroupComponentController:RadioGroupComponentController(ButtonGroup,String,Hashtable)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin RadioGroupComponentController:handleValueChange(Object) preserve=yes
      Enumeration  elements = group.getElements();

      if (newValue == null) {
	 while(elements.hasMoreElements()) {
	    JRadioButton myRadioButton = (JRadioButton)elements.nextElement();	    
	    myRadioButton.setSelected(false);
	 }
      }

      elements = group.getElements();

      while(elements.hasMoreElements()) {
	 JRadioButton myRadioButton = (JRadioButton)elements.nextElement();	 
	 if (values.get(myRadioButton).equals(newValue) && !myRadioButton.isSelected()) {
	    myRadioButton.setSelected(true);	 
	    break;
	 } 
      }            
//##End   RadioGroupComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setToReadWrite                                   */
        /*                                                              */
        /**
         * @param       state:boolean
         */
        /*==============================================================*/
   protected  void  setToReadWrite (
                                    boolean  state
                                   )
   {
//##Begin RadioGroupComponentController:setToReadWrite(boolean) preserve=yes
      Enumeration  elements = group.getElements();

      while(elements.hasMoreElements()) {
	 JRadioButton myRadioButton = (JRadioButton)elements.nextElement();	 
	    myRadioButton.setEnabled(state);
      }
//##End   RadioGroupComponentController:setToReadWrite(boolean)
   }


}
