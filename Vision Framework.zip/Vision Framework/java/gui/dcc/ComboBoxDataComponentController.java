/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ComboBoxDataComponentController.java                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 January 09 at 12:50:52 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.*;
import java.util.*;
import java.awt.event.*;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.lang.reflect.*;
import java.awt.event.*;
import java.beans.*;
import COM.novusnet.vision.java.utility.helpers.*;
import COM.novusnet.vision.java.businessobjects.*;
import COM.novusnet.vision.java.utility.textformatting.*;
import COM.novusnet.vision.java.gui.*;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ComboBoxDataComponentController                         */
/**
 * The controller manages a combobox and an attribute in a BO. Whenever the
 * selection changes, the attribute is updated to the new value.
 */
/*======================================================================*/
public  class  ComboBoxDataComponentController  extends  DataComponentController
                                             implements  ItemListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ComboBoxDataComponentController:Attributes preserve=yes

//##End   ComboBoxDataComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ComboBoxDataComponentController                  */
        /*                                                              */
        /**
         * This constructor takes the name of the attribute in the
         * <p>
         * model, a combo and a combobox model. Any time the selection
         * changes in the combobox, the attribute in the model is set to
         * the new value of the combobox. Similarly, anytime the attribute
         * in the model changes, the combobox is updated to reflect the
         * change.
         *
         * @param       component:JComboBox
         * @param       name:String
         */
        /*==============================================================*/
   public    ComboBoxDataComponentController (
                                              JComboBox  component,
                                              String     name
                                             )
   {
//##Begin ComboBoxDataComponentController:ComboBoxDataComponentController(JComboBox,String) preserve=yes
      super(component, name);
      component.addItemListener(this);
//##End   ComboBoxDataComponentController:ComboBoxDataComponentController(JComboBox,String)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  itemStateChanged                                 */
        /*                                                              */
        /**
         * Overridden to detect list selection changes.
         *
         * @param       e:ItemEvent
         */
        /*==============================================================*/
   public  void  itemStateChanged (
                                   ItemEvent  e
                                  )
   {
//##Begin ComboBoxDataComponentController:itemStateChanged(ItemEvent) preserve=yes

      BOContainerComboBoxModel bocModel = null;
      BusinessObjectContainer  boc      = null;
      JComboBox                cb       = (JComboBox)component;

      if (getModel() == null) {
	 return;
      }

      if (e.getStateChange() == ItemEvent.SELECTED) {

	 Object myValue = e.getItem();

	 //
	 // Given the item, we need to find its position in the
	 // combobox list, and use that index to extract the real
	 // object associated. Then we set the object on the
	 // model. We only do this for BOContainerComboBoxModels.

	 ComboBoxModel cbModel = cb.getModel();

	 if (cbModel instanceof BOContainerComboBoxModel) {
	    int           index   = -1;
	    int           size    = cbModel.getSize();

	    for (int i = 0; i < size; i++) {
	       if (cbModel.getElementAt(i).equals(myValue)) {
		  index = i;
		  break;
	       }
	    }

	    if (index == -1) {
	       throw new RuntimeException("Failed to find a matching object for:" + myValue);
	    }

	    bocModel = (BOContainerComboBoxModel)cb.getModel();
	    boc      = bocModel.getModel();

	    getVariable().setValue(boc.getElementAt(index));
	 }
	 else {
	    getVariable().setValue(myValue);
	 }
      }
//##End   ComboBoxDataComponentController:itemStateChanged(ItemEvent)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/

           /*==============================================================*/
           /* OPERATION:  updateModelAttribute                             */
           /*                                                              */
           /**
            * Updates the model attribute using the name and model currently
            * set.
            * <p>
            * @param parameterClass. The class of the attribute.
            * <p>
            * @param value. The new value
            *
            * @param       parameterClass:java.lang.Class
            * @param       value:java.lang.Object
            */
           /*==============================================================*/
   protected  void  updateModelAttribute (
                                          java.lang.Class   parameterClass,
                                          java.lang.Object  value
                                         )
   {
   //##Begin DataComponentController:updateModelAttribute(Class,Object) preserve=yes
   		java.lang.Object myModel = null;
   		myModel = getModel();

   		if (myModel == null) {
   	 		return;
        }

        Object attributeValue = getModelAttributeValue();

        if (value == attributeValue) {
   	 		return;
        }

         if (value != null && attributeValue != null) {
   	 		if (value.equals(attributeValue)) {
   	    		return;
   	 		}
         }

         System.out.println("Updating the model attribute:" +
   			 attributeName +
   			 " with new value:" +
   			 value +
   			 " The current attribute value in the model is:" +
   			 attributeValue +
   			 " .The attribute class is:" +
   			 parameterClass +
   			 ". The model is:" +
   			 myModel +
   			 " . Parameter class is:" + parameterClass + "\n\n");

         Class           myClass       = myModel.getClass();
         Method          myMethod      = null;
         Class []        myParams      = { parameterClass };

         myMethod = ClassHelper.getClosestMatchingMethod("set" + Case.capitalize(attributeName),
   													      myClass,
   													      myParams);

         if (myMethod != null ) {
   	 		Object  args[] = { value };
   	 		try {
   	    		myMethod.invoke(myModel , args);
   	 		}
   	 		catch(InvocationTargetException exception) {
   			// start josh code
   				setModel(myModel);
   			// end josh code
   			    if (!exception.getTargetException().getMessage().equals("LostStolenUserAborted"))
   	    			new ExceptionPane(exception.getTargetException());
   	 		}
   	 		catch(Throwable exception) {
   	    		new ExceptionPane(exception);
   	 		}
         }
         else {
   	 		System.out.println("The attribute " + attributeName + " is readonly. No Setter is found in the model");
         }

   //##End   DataComponentController:updateModelAttribute(Class,Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The
         * object is looked up in the combobox model and made the selected
         * item.
         *
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin ComboBoxDataComponentController:handleValueChange(Object) preserve=yes
      JComboBox cb              = (JComboBox)component;
      int       index           = -1;

      BOContainerComboBoxModel bocModel = null;
      BusinessObjectContainer  boc      = null;

      if (cb.getModel() == null) {
	 return;
      }

      if (cb.getModel() instanceof BOContainerComboBoxModel) {
	 bocModel = (BOContainerComboBoxModel)cb.getModel();
	 boc      = bocModel.getModel();

	 if (boc == null) {
	    return;
	 }

	 index  = boc.getIndexOfValue(newValue);

	 if (index == cb.getSelectedIndex()) {
	    return;
	 }

	 if (index == -1) {
	    cb.setSelectedItem(null);
	 }
	 else {
	    cb.setSelectedIndex(index);
	 }
      }
      else {
	 if (cb.getSelectedItem() != newValue) {
	    cb.setSelectedItem(newValue);
	 }
      }

      // Hack. Remove when fixed in swing.
      cb.repaint();

//##End   ComboBoxDataComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setToReadWrite                                   */
        /*                                                              */
        /**
         * @param       state:boolean
         */
        /*==============================================================*/
   protected  void  setToReadWrite (
                                    boolean  state
                                   )
   {
//##Begin ComboBoxDataComponentController:setToReadWrite(boolean) preserve=yes
      component.setEnabled(state);
//##End   ComboBoxDataComponentController:setToReadWrite(boolean)
   }


}
