package COM.novusnet.vision.java.gui.dcc;


public class LongVariable extends Variable
{
   /**
    * Constructor that takes a long as a default value.
    *
    */
   public LongVariable(long defaultValue)
   {
      super (new Long(defaultValue));
   }   

   public LongVariable(Long defaultValue)
   {
      super (defaultValue);
   }   

   public long longValue()
   {
      return ((Long)getValue()).longValue();
   }
}
