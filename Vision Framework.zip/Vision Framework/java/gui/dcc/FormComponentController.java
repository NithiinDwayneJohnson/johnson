/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      FormComponentController.java                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 December 20 at 19:36:43 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import COM.novusnet.vision.java.gui.FormComponent;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       FormComponentController                                 */
/**
 * A form component controller is used to sync up a model that has an
 * attribute that is being edited by a form.
 */
/*======================================================================*/
public  class  FormComponentController  extends  DataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin FormComponentController:Attributes preserve=yes

//##End   FormComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  FormComponentController                          */
        /*                                                              */
        /**
         * This constructor takes the name of the attribute in the 
         * <p>
         * modell and a FormComponent.
         *  
         * @param       component:FormComponent
         * @param       name:String
         */
        /*==============================================================*/
   public    FormComponentController (
                                      FormComponent  component,
                                      String         name
                                     )
   {
//##Begin FormComponentController:FormComponentController(FormComponent,String) preserve=yes
      super(component, name);
      component.addPropertyChangeListener(new PropertyChangeListener() {
	 public void propertyChange(PropertyChangeEvent e) {
	    if (e.getPropertyName().equals("model")) {
	       FormComponent    myForm    = (FormComponent)FormComponentController.this.component;
	       getVariable().setValue(e.getNewValue());
	    }
	 }
      });
//##End   FormComponentController:FormComponentController(FormComponent,String)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. 
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin FormComponentController:handleValueChange(Object) preserve=yes
      FormComponent     myForm  = (FormComponent)component;
      myForm.setModel(newValue);
//##End   FormComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleDisengage                                  */
        /*                                                              */
        /**
         * This method has been overriden to remove property change
         * listener from the formComponent.  This is done to assist the GC.
         *  
         */
        /*==============================================================*/
   protected  void  handleDisengage (
                                    )
   {
//##Begin FormComponentController:handleDisengage() preserve=yes

//##End   FormComponentController:handleDisengage()
   }


}
