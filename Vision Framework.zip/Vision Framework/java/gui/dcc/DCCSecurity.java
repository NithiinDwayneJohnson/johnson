/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      DCCSecurity.java                                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 January 09 at 13:37:48 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       DCCSecurity                                             */
/**
 * This interface is used to give a client the chance to disallow changes
 * to an attribute that is being managed by a DCC. If the client returns a
 * false, the component is disabled, otherwise the component is enabled.
 */
/*======================================================================*/
public interface  DCCSecurity
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin DCCSecurity:Attributes preserve=yes

//##End   DCCSecurity:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  checkAttributeSecurity                           */
        /*                                                              */
        /**
         * A client should return true/false based on some security
         * mechanism. The DCC passes itself as an argument to this method.
         * Please note that the DCC can operate on embedded models. For
         * example a DCC with a model of Account with a property of
         * address.street, will make the realModel of the dcc to be address
         * and root model  to be Account. In this case, the property name
         * is street and the real property name is address.street. This
         * method should return one of the DCC constants like
         * SECURITY_UNMANAGED_ATTRIBUTE
         *  
         * @param       dcc:DataComponentController
         * @return      :int -
         */
        /*==============================================================*/
   public  int  checkAttributeSecurity (
                                        DataComponentController  dcc
                                       );


}
