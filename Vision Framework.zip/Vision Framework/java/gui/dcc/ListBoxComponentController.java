/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ListBoxComponentController.java                         */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 April 24 at 15:11:31 CDT                           */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.ListModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ListBoxComponentController                              */
/**
 * A list controller maps a selected list row to an attribute in the model.
 * whenever the selection changes, the model is updated. It is important
 * that the equals  of a leaf BO be implemented.
 */
/*======================================================================*/
public  class  ListBoxComponentController  extends  DataComponentController
                                        implements  ListSelectionListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ListBoxComponentController:Attributes preserve=yes

//##End   ListBoxComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ListBoxComponentController                       */
        /*                                                              */
        /**
         * This constructor takes the name of the attribute in the 
         * <p>
         * modell and a list.
         *  
         * @param       component:JList
         * @param       name:String
         */
        /*==============================================================*/
   public    ListBoxComponentController (
                                         JList   component,
                                         String  name
                                        )
   {
//##Begin ListBoxComponentController:ListBoxComponentController(JList,String) preserve=yes
      this(component, name, null);
//##End   ListBoxComponentController:ListBoxComponentController(JList,String)
   }

        /*==============================================================*/
        /* OPERATION:  ListBoxComponentController                       */
        /*                                                              */
        /**
         * A constructor that takes a Variable , attribute name and a
         * component. The variable is used as the model for the controller.
         *  
         * @param       component:JList
         * @param       name:String
         * @param       variable:Variable
         */
        /*==============================================================*/
   public    ListBoxComponentController (
                                         JList     component,
                                         String    name,
                                         Variable  variable
                                        )
   {
//##Begin ListBoxComponentController:ListBoxComponentController(JList,String,Variable) preserve=yes
      super( component, name, variable);     
      component.addListSelectionListener(this);
//##End   ListBoxComponentController:ListBoxComponentController(JList,String,Variable)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  valueChanged                                     */
        /*                                                              */
        /**
         * @param       e:ListSelectionEvent
         */
        /*==============================================================*/
   public  void  valueChanged (
                               ListSelectionEvent  e
                              )
   {
//##Begin ListBoxComponentController:valueChanged(ListSelectionEvent) preserve=yes
      JList     myList      = (JList)ListBoxComponentController.this.component;
      ListModel myListModel = myList.getModel();
      
      if (getModel() == null) {
	 return;
      }	   
      getVariable().setValue(myList.getSelectedValue());
//##End   ListBoxComponentController:valueChanged(ListSelectionEvent)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The
         * object is looked up in the combobox model and made the selected
         * item.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin ListBoxComponentController:handleValueChange(Object) preserve=yes
      JList     myList  = (JList)component;
      ListModel myModel = myList.getModel();

      if (myModel == null) {
	 return;
      }

      int count  = myModel.getSize();

      for (int i = 0; i < count; i++) {
	 if (myModel.getElementAt(i).equals(newValue)) {
	    myList.setSelectedIndex(i);
	    return;
	 }
      }
//##End   ListBoxComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleDisengage                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleDisengage (
                                    )
   {
//##Begin ListBoxComponentController:handleDisengage() preserve=yes
      super.handleDisengage();
      JList     myList      = (JList)ListBoxComponentController.this.component;      
      myList.removeListSelectionListener(this);
      // Avoid leakage of cached objects
      myList.setModel(new DefaultListModel());
//##End   ListBoxComponentController:handleDisengage()
   }
}
