package COM.novusnet.vision.java.gui.dcc;

import java.util.Calendar;

public class CalendarVariable extends Variable
{
   /**
    * Constructor that takes an Calendar as a default value.
    */
   public CalendarVariable(Calendar defaultValue)
   {
      super (defaultValue);
   }   

   public Calendar calendarValue()
   {
      return ((Calendar)getValue());
   }
}





