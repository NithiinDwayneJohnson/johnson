/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      DataComponentController.java                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2001 November 06 at 09:38:08 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeSupport;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.businessobjects.ModelInterface;
import COM.novusnet.vision.java.gui.ExceptionPane;
import COM.novusnet.vision.java.gui.FormComponent;
import COM.novusnet.vision.java.gui.FormComponentEvent;
import COM.novusnet.vision.java.gui.FormComponentListener;
import COM.novusnet.vision.java.gui.PrepareFormException;
import COM.novusnet.vision.java.utility.ApplicationConfigHelper;
import COM.novusnet.vision.java.utility.helpers.ClassHelper;
import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
import COM.novusnet.vision.java.utility.textformatting.Case;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       DataComponentController                                 */
/**
 * <h3>The&nbsp;<a
 * name="DataComponentController"></a>DataComponentController</h3>
 * <p>DataComponentControllers allow for proper model and view
 * synchronization. Whenever the model changes, the GUI component is
 * updated and vice-versa. These glue components are simple controllers
 * that can be extended by developers. These controllers typically install
 * listeners on both the model and the GUI component and manage
 * interactions amongst them. They take full advantage of the BO model in
 * the Vision-2000 framework. The interface of these objects is named
 * DataComponentController. 
 * <p>The following is a basic set of services provided by a DCC: </p>
 * <p>
 * <ol>
 * <p>
 *     <li>Undo capability</li>
 * <p>
 *     <li>Formatting of the contents of components</li>
 * <p>
 *     <li>Constraints and validation rule checking beyond keystroke
 * validation provided by masked components</li>
 * <p>
 *     <li>Automatic synchronization of model and view.</li>
 * <p>
 * </ol>
 * <p>A DCC binds the view component to its data source (or target
 * depending on how you look at it). All DCC's monitor changes to the model
 * of the closest FormComponent class that contains them. In order to be
 * notified of model changes, they add themselves as property listeners on
 * the form component. Thus a DCC can only be created after the component
 * is added to the FormComponent. This might be a minor irritant to a
 * developer. The other approach would have been an explicit registration
 * mechanism with the FormComponent which is more work for the developer.
 * All interaction between the FormComponent and its DCC's is through event
 * notifications. For example, an undo on the form component fires an undo
 * event which is intercepted by the DCC's for proper action. The
 * FormComponent knows nothing about these DCC's. The architecture of DCC's
 * relies on getter and setter methods on the model attribute be available.
 * Otherwise an exception is thrown. <br>
 * <p>
 * &nbsp; </p>
 * <p>The DCC framework relies on these important pre-requisites:</p>
 * <p>
 * <ol>
 * <p>
 *     <li>An attribute of a model must have a properly defined equals()
 * method. This is specifically important with DCC's that deal with
 * lists.</li>
 * <p>
 *     <li>The setXXX where xxx is the attribute in the model must test for
 * equality and not set the value if the old and new values are the same.
 * The Vision-2000 object generator emits code that handle this case.</li>
 * <p>
 *     <li>Attributes must fire events whenever they change. Again, the
 * Vision-2000 object generator can generate such a code when an attribute
 * is marked as bound which is the default.</li>
 * <p>
 * </ol>
 * <p>
 * As an added benefit, rather than binding a model attribute to a
 * controller, a user can bind a Variable (or any of its subclasses) to a
 * DCC. This allows for temporay variables that can be later set on the
 * model at store time.
 */
/*======================================================================*/
public abstract  class  DataComponentController  implements  java.beans.PropertyChangeListener, java.awt.event.FocusListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin DataComponentController:Attributes preserve=yes
   Object  resetValue   = null;
   boolean userVariable = false;
   private final static String  DEFAULT_ERROR_STRING;
   private final static String  LOCALIZED_ERROR_STRING;
   private Vector embeddedModels = new Vector();
   boolean displayingError = false;
   FormComponentListener formComponentListener;
//##End   DataComponentController:Attributes

    /*==================================================================*/
    /* Protected Attributes                                             */
    /*==================================================================*/
   protected           COM.novusnet.vision.java.gui.FormComponent formComponent;
   protected           java.lang.String                           attributeName;
   protected           javax.swing.JComponent                     component;

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private             java.lang.Object                           model                        = null;
   private             Variable                                   variable                     = null;
   private             java.lang.Class                            attributeClass               = null;
   private transient   java.beans.PropertyChangeSupport           propertyChangeSupport        = null;
   private             java.lang.String                           errorMessage;
   private             java.lang.String                           localizedErrorMessageID;
   private             boolean                                    autoDisplayErrors            = true;
   private             java.lang.String                           errorFieldName;

   // We do not want to read from the model to populate this component. However, 
   // when we enter something into the edit field we do want it to write to the 
   // model hence the flag writeOnly.
   private             boolean                                    writeOnly                    = false;

   private             boolean                                    required                     = false;
   private             java.lang.Object                           rootModel                    = null;
   private             java.lang.String                           realAttributeName            = null;
   private             boolean                                    readOnly                     = false;
   private             boolean                                    resetAllowedIfRequired       = false;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   public static final int                                        SECURITY_UNMANAGED_ATTRIBUTE = 0;
   public static final int                                        SECURITY_WRITABLE_ATTRIBUTE  = 1;
   public static final int                                        SECURITY_READONLY_ATTRIBUTE  = 2;
   private static      java.util.Vector                           securityList                 = new Vector();
   private static final String READONLY = "readonly";

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  DataComponentController                          */
        /*                                                              */
        /**
         * A constructor that takes the model attribute name and a
         * component. The model attribute and the component are always kept
         * in sync.
         *  
         * @param       component:javax.swing.JComponent
         * @param       name:java.lang.String
         * 
         */
        /*==============================================================*/
   public   DataComponentController (
                                      javax.swing.JComponent  component,
                                      java.lang.String        name
                                    )
   {
//##Begin DataComponentController:DataComponentController(JComponent,String) preserve=yes
      this(component, name, null);
//##End   DataComponentController:DataComponentController(JComponent,String)
   }

        /*==============================================================*/
        /* OPERATION:  DataComponentController                          */
        /*                                                              */
        /**
         * A constructor that takes a Variable , attribute name and a
         * component. 
         * <p>
         * The Variable is updated under the following conditions:
         * <p>
         *   - When the model (thus an attribute) is changed.
         * <p>
         *   - When an attribute in the model changes.
         * <p>
         *   - When the user interface component changes.
         * <p>
         * The Model attribute is updated under the following conditions:
         * <p>
         *   - During commit and if the Variable has changed. 
         * <p>
         *   - Optionally, whenver the Variable changes. 
         * <p>
         * The Component attribute is updated under the following
         * conditions:
         * <p>
         *       - Whenever the contents of the variable change.
         *  
         * @param       component:javax.swing.JComponent
         * @param       name:java.lang.String
         * @param       variable:Variable
         * 
         */
        /*==============================================================*/
   public  DataComponentController (
                                    javax.swing.JComponent  component,
                                    java.lang.String        name,
                                    Variable                variable
                                   )
   {
//##Begin DataComponentController:DataComponentController(JComponent,String,Variable) preserve=yes
      this.attributeName     = name;
      this.realAttributeName = name;
      this.component         = component;
      formComponent          = (FormComponent)SwingUtilities.getAncestorOfClass(FormComponent.class, component);

      if (formComponent == null) {
	 throw new RuntimeException("Failed to locate the form component for " + component + 
				    " Make sure that the component is added to the form component before creating this class.");
      }

      //=====================================================
      // Install listeners on the appropriate components.
      //=====================================================
      formComponent.addPropertyChangeListener(this);
      component.addPropertyChangeListener(this);
      component.addFocusListener(this);

      formComponentListener = new FormComponentListener() {
	 
	 public  void  storeStarted (FormComponentEvent  e) 
	 {
	 }

	 public  void  storeEnded (FormComponentEvent  e)
	 {	 
	 }

	 public  void  storeCommit (FormComponentEvent  e)
	 {
	    handleCommit();
	 }

	 public  void  storePrepare (FormComponentEvent  e)
	 {
	    handlePrepare();
	 }

	 public  void  reset(FormComponentEvent  e)
	 {
	    handleReset();
	 }

	 public  void  disengage(FormComponentEvent  e)
	 {
	    handleDisengage();
	 }
      };


      // Add the form component listener
      formComponent.addFormComponentListener(formComponentListener);

      propertyChangeSupport = new PropertyChangeSupport(this);

      this.variable = new Variable("");

      if (variable != null) {
	 userVariable = true;
	 setModel(variable);
      }

      this.variable.addPropertyChangeListener(this);
//##End   DataComponentController:DataComponentController(JComponent,String,Variable)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getFormComponent                                 */
        /*                                                              */
        /**
         * This method returns the value of the form component being
         * listened on.
         *  
         * @return      :COM.novusnet.vision.java.gui.FormComponent -
         *                 The value of the form component being listened
         *                 on.
         */
        /*==============================================================*/
   public  COM.novusnet.vision.java.gui.FormComponent  getFormComponent (
                                                                        )
   {
//##Begin DataComponentController:getFormComponent() preserve=no

      return (formComponent);

//##End   DataComponentController:getFormComponent()
   }

        /*==============================================================*/
        /* OPERATION:  getAttributeName                                 */
        /*                                                              */
        /**
         * This method returns the value of the "attributeName" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "attributeName" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getAttributeName (
                                              )
   {
//##Begin DataComponentController:getAttributeName() preserve=no

      return (attributeName);

//##End   DataComponentController:getAttributeName()
   }

        /*==============================================================*/
        /* OPERATION:  getComponent                                     */
        /*                                                              */
        /**
         * This method returns the value of the "component" attribute.
         *  
         * @return      :javax.swing.JComponent -
         *                 The value of the "component" attribute.
         */
        /*==============================================================*/
   public  javax.swing.JComponent  getComponent (
                                                )
   {
//##Begin DataComponentController:getComponent() preserve=no

      return (component);

//##End   DataComponentController:getComponent()
   }

        /*==============================================================*/
        /* OPERATION:  getModel                                         */
        /*                                                              */
        /**
         * This method returns the value of the attibute model. This is the
         * same model in the form component.
         *  
         * @return      :java.lang.Object -
         *                 The value of the attibute model. This is the
         *                 same model in the form component.
         */
        /*==============================================================*/
   public  java.lang.Object  getModel (
                                      )
   {
//##Begin DataComponentController:getModel() preserve=yes
      return model;
//##End   DataComponentController:getModel()
   }

        /*==============================================================*/
        /* OPERATION:  getVariable                                      */
        /*                                                              */
        /**
         * This method returns the value of the current value. This is
         * initialized from the model. At commit time, the attribute in the
         * model updated with this value. The "value" is typically updated
         * at focus loss or at selection changed based on the component
         * controller's role.
         *  
         * @return      :Variable -
         *                 The value of the current value. This is
         *                 initialized from the model. At commit time, the
         *                 attribute in the model updated with this value.
         *                 The "value" is typically updated at focus loss
         *                 or at selection changed based on the component
         *                 controller's role.
         */
        /*==============================================================*/
   public  Variable  getVariable (
                                 )
   {
//##Begin DataComponentController:getVariable() preserve=no

      return (variable);

//##End   DataComponentController:getVariable()
   }

        /*==============================================================*/
        /* OPERATION:  getAttributeClass                                */
        /*                                                              */
        /**
         * This method returns the value of this is set the first time we
         * get a non-null model.
         *  
         * @return      :java.lang.Class -
         *                 The value of this is set the first time we get a
         *                 non-null model.
         */
        /*==============================================================*/
   protected  java.lang.Class  getAttributeClass (
                                                 )
   {
//##Begin DataComponentController:getAttributeClass() preserve=yes

      // If we have already figured out what the attribute class is, then
      // return it.

      if (attributeClass != null) {
	 return attributeClass;
      }

      if (model == null) {
	 attributeClass = null;
	 return attributeClass;
      }

      Method myMethod = ClassHelper.getClosestMatchingMethod("get" + Case.capitalize(attributeName),
							     model.getClass(),
							     null);

      if (myMethod == null) {
	 // maybe its a boolean.
	 myMethod = ClassHelper.getClosestMatchingMethod("is" + Case.capitalize(attributeName),
							     model.getClass(),
							     null);
      }

      if (myMethod == null) {
	 throw new RuntimeException("Failed to locate proper getMethod on model:" + model + " whose class is:" + 
				    model.getClass() + " for attribute:" + attributeName);
      }

      attributeClass = myMethod.getReturnType();

      return(attributeClass);
//##End   DataComponentController:getAttributeClass()
   }

        /*==============================================================*/
        /* OPERATION:  getPropertyChangeSupport                         */
        /*                                                              */
        /**
         * This method returns the value of the "propertyChangeSupport"
         * attribute.
         *  
         * @return      :java.beans.PropertyChangeSupport -
         *                 The value of the "propertyChangeSupport"
         *                 attribute.
         */
        /*==============================================================*/
   private  java.beans.PropertyChangeSupport  getPropertyChangeSupport (
                                                                       )
   {
//##Begin DataComponentController:getPropertyChangeSupport() preserve=no

      return (propertyChangeSupport);

//##End   DataComponentController:getPropertyChangeSupport()
   }

        /*==============================================================*/
        /* OPERATION:  getErrorMessage                                  */
        /*                                                              */
        /**
         * This method returns the value of this errorMessage attribute is
         * used during error reporting. An error is reported if the
         * autoReportErrors attribute is set. An errorMessage is always
         * overridden is a localizedErrorMessageID is specified. Developers
         * are encouraged to use setLocalizedErrorMessageID rather than set
         * error message.
         *  
         * @return      :java.lang.String -
         *                 The value of this errorMessage attribute is used
         *                 during error reporting. An error is reported if
         *                 the autoReportErrors attribute is set. An
         *                 errorMessage is always overridden is a
         *                 localizedErrorMessageID is specified. Developers
         *                 are encouraged to use setLocalizedErrorMessageID
         *                 rather than set error message.
         */
        /*==============================================================*/
   public  java.lang.String  getErrorMessage (
                                             )
   {
//##Begin DataComponentController:getErrorMessage() preserve=no

      return (errorMessage);

//##End   DataComponentController:getErrorMessage()
   }

        /*==============================================================*/
        /* OPERATION:  getLocalizedErrorMessageID                       */
        /*                                                              */
        /**
         * This method returns the value of this message is used to extract
         * a message string to display to a user in case of an error. The
         * resources is resolved relative to the FormComponent that this
         * DCC is managing. A developer is given a chance to substitute
         * parameters by overriding the substitueParameters method. The
         * system provides a default error message with simple
         * substituions.
         *  
         * @return      :java.lang.String -
         *                 The value of this message is used to extract a
         *                 message string to display to a user in case of
         *                 an error. The resources is resolved relative to
         *                 the FormComponent that this DCC is managing. A
         *                 developer is given a chance to substitute
         *                 parameters by overriding the substitueParameters
         *                 method. The system provides a default error
         *                 message with simple substituions.
         */
        /*==============================================================*/
   public  java.lang.String  getLocalizedErrorMessageID (
                                                        )
   {
//##Begin DataComponentController:getLocalizedErrorMessageID() preserve=no

      return (localizedErrorMessageID);

//##End   DataComponentController:getLocalizedErrorMessageID()
   }

        /*==============================================================*/
        /* OPERATION:  isAutoDisplayErrors                              */
        /*                                                              */
        /**
         * This method returns the value of this attribute determines
         * whether the controller displays an error message when an error
         * situation is detected. Typical situations will be invalid data
         * entered by a user.
         *  
         * @return      :boolean -
         *                 The value of this attribute determines whether
         *                 the controller displays an error message when an
         *                 error situation is detected. Typical situations
         *                 will be invalid data entered by a user.
         */
        /*==============================================================*/
   public  boolean  isAutoDisplayErrors (
                                        )
   {
//##Begin DataComponentController:isAutoDisplayErrors() preserve=no

      return (autoDisplayErrors);

//##End   DataComponentController:isAutoDisplayErrors()
   }

        /*==============================================================*/
        /* OPERATION:  getErrorFieldName                                */
        /*                                                              */
        /**
         * This method returns the value of when substituion of error
         * messages take place, if this field is set, it is used inplace of
         * the attribute name. This makes for a more friendly error
         * message.
         *  
         * @return      :java.lang.String -
         *                 The value of when substituion of error messages
         *                 take place, if this field is set, it is used
         *                 inplace of the attribute name. This makes for a
         *                 more friendly error message.
         */
        /*==============================================================*/
   public  java.lang.String  getErrorFieldName (
                                               )
   {
//##Begin DataComponentController:getErrorFieldName() preserve=no

      return (errorFieldName);

//##End   DataComponentController:getErrorFieldName()
   }

        /*==============================================================*/
        /* OPERATION:  isWriteOnly                                      */
        /*                                                              */
        /**
         * This method returns the value of if set, then attribute changes
         * in the model will never update the GUI component.
         *  
         * @return      :boolean -
         *                 The value of if set, then attribute changes in
         *                 the model will never update the GUI component.
         */
        /*==============================================================*/
   public  boolean  isWriteOnly (
                                )
   {
//##Begin DataComponentController:isWriteOnly() preserve=no

      return (writeOnly);

//##End   DataComponentController:isWriteOnly()
   }

        /*==============================================================*/
        /* OPERATION:  isRequired                                       */
        /*                                                              */
        /**
         * This method returns the value of this attribute designates a
         * given value as required. The model will simply not accept a null
         * value. By default this is set to false (not required). The
         * "required" interpretation is handled by the subclasses.
         * <p>
         * For most formatted text field controls , a developer should set
         * the constraints on the text component.
         *  
         * @return      :boolean -
         *                 The value of this attribute designates a given
         *                 value as required. The model will simply not
         *                 accept a null value. By default this is set to
         *                 false (not required). The "required"
         *                 interpretation is handled by the subclasses.
         * <p>
         *                 For most formatted text field controls , a
         *                 developer should set the constraints on the text
         *                 component.
         */
        /*==============================================================*/
   public  boolean  isRequired (
                               )
   {
//##Begin DataComponentController:isRequired() preserve=no

      return (required);

//##End   DataComponentController:isRequired()
   }

        /*==============================================================*/
        /* OPERATION:  getRootModel                                     */
        /*                                                              */
        /**
         * This method returns the value of if the attribute name
         * represents an embedded model, this attribute will hold the whole
         * the rootModel as supplied to the form. The model attribute will
         * then have the embedded model from the attribute name.
         *  
         * @return      :java.lang.Object -
         *                 The value of if the attribute name represents an
         *                 embedded model, this attribute will hold the
         *                 whole the rootModel as supplied to the form. The
         *                 model attribute will then have the embedded
         *                 model from the attribute name.
         */
        /*==============================================================*/
   public  java.lang.Object  getRootModel (
                                          )
   {
//##Begin DataComponentController:getRootModel() preserve=no

      return (rootModel);

//##End   DataComponentController:getRootModel()
   }

        /*==============================================================*/
        /* OPERATION:  getRealAttributeName                             */
        /*                                                              */
        /**
         * This method returns the value of if the attribute represents an
         * embedded model, then this attribute holds the real name as
         * supplied during object construction. Otherwise this attribute is
         * the same as the attributeName.
         *  
         * @return      :java.lang.String -
         *                 The value of if the attribute represents an
         *                 embedded model, then this attribute holds the
         *                 real name as supplied during object
         *                 construction. Otherwise this attribute is the
         *                 same as the attributeName.
         */
        /*==============================================================*/
   public  java.lang.String  getRealAttributeName (
                                                  )
   {
//##Begin DataComponentController:getRealAttributeName() preserve=no

      return (realAttributeName);

//##End   DataComponentController:getRealAttributeName()
   }

        /*==============================================================*/
        /* OPERATION:  isReadOnly                                       */
        /*                                                              */
        /**
         * This method returns the value of if set to true, then override
         * security enabling.
         *  
         * @return      :boolean -
         *                 The value of if set to true, then override
         *                 security enabling.
         */
        /*==============================================================*/
   public  boolean  isReadOnly (
                               )
   {
//##Begin DataComponentController:isReadOnly() preserve=no

      return (readOnly);

//##End   DataComponentController:isReadOnly()
   }

        /*==============================================================*/
        /* OPERATION:  isResetAllowedIfRequired                         */
        /*                                                              */
        /**
         * This method returns the value of the "resetAllowedIfRequired"
         * attribute.
         *  
         * @return      :boolean -
         *                 The value of the "resetAllowedIfRequired"
         *                 attribute.
         */
        /*==============================================================*/
   public  boolean  isResetAllowedIfRequired (
                                             )
   {
//##Begin DataComponentController:isResetAllowedIfRequired() preserve=no

      return (resetAllowedIfRequired);

//##End   DataComponentController:isResetAllowedIfRequired()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * This method sets the value of the attibute model. This is the
         * same model in the form component.
         *  
         * @param       aValue:java.lang.Object
         *                 The value of the attibute model. This is the
         *                 same model in the form component.
         */
        /*==============================================================*/
   protected  void  setModel (
                              java.lang.Object  aValue
                             )
   {
//##Begin DataComponentController:setModel(Object) preserve=yes
      boolean compound = (realAttributeName.indexOf('.') != -1);

      if ((aValue != null) && !(aValue instanceof ModelInterface) ) {
	 throw new RuntimeException("Model must be a business object or a Variable.");
      }
      
      if ( rootModel != null ) {
	 ((ModelInterface)rootModel).removePropertyChangeListener(this);   
      }
      
      rootModel = aValue;

      // Add a property change listener on the main model.
      if ( rootModel != null ) {
	 ((ModelInterface)rootModel).addPropertyChangeListener(this);
      }

      // If we had any embedded models, then remove the property change listener
      // and clear the list.
      int embeddedCount = embeddedModels.size();

      for (int i = 0; i < embeddedCount; i++) {
	 ModelInterface embeddedModel = (ModelInterface)embeddedModels.elementAt(i);
	 embeddedModel.removePropertyChangeListener(this);	 
      }

      embeddedModels.removeAllElements();

      Object myModel = rootModel;

      // Handle compound names
      try {
	 //===================================================================
	 // If the attributeName is a compound name, then find the real model
	 // by parsing the attribute name and then fixing up the model.
	 // The format is: [model.]?*attributeName
	 //===================================================================
	 if (aValue != null && compound) {
	    
	    StringTokenizer st      = new StringTokenizer(realAttributeName, ".");
	    int             count   = st.countTokens();
	    
	    for (int i = 0; i < count && myModel != null; i++) {
	       String token = st.nextToken();
	       
	       // Are we at the field yet ?
	       if (i == count - 1) {
		  attributeName = token;
	       }
	       // Nope still reading embedded models.
	       // Read the model value using introspection.
	       else {
		  Method myMethod = ClassHelper.getClosestMatchingMethod("get" + Case.capitalize(token),
									 myModel.getClass(), 
									 null);      
		  if ( myMethod == null ) {
		     myMethod = ClassHelper.getClosestMatchingMethod("is" + Case.capitalize(token),
								     myModel.getClass(), 
								     null);	 
		  }
		  
		  if ( myMethod != null ) {

		     try {
			myModel = myMethod.invoke(myModel , null);  
			if (myModel != null && !(myModel instanceof ModelInterface) ) {
			   throw new RuntimeException("Model must be a business object or a Variable." + myModel.getClass().getName());
			}
			// We add a property change listener on embedded models and add it to the list of
			// embedded models.
			if ( myModel != null ) {
			   ((ModelInterface)myModel).addPropertyChangeListener(this);
			   embeddedModels.addElement(myModel);	
			} else {
			   System.out.println("Method " + myMethod.getName() + " returned " + myModel );
                        }
		     }

		     catch(InvocationTargetException e) {
			throw new RuntimeException(e.getTargetException().getMessage());
		     }     

		     catch(Throwable ignore) {
			throw new RuntimeException("Failed to read  embedded model for " + aValue + " name is " + token + " - " + ignore + " : " + ignore.getMessage() + " : " + ignore.toString());
		     }     
		  } 
	       }
	    }
	 }
	 
	 model = myModel;
	 handleModelChange();
      }
      catch(RuntimeException e) {
	 new ExceptionPane(e);
      }      
//##End   DataComponentController:setModel(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setVariable                                      */
        /*                                                              */
        /**
         * This method sets the value of the current value. This is
         * initialized from the model. At commit time, the attribute in the
         * model updated with this value. The "value" is typically updated
         * at focus loss or at selection changed based on the component
         * controller's role.
         *  
         * @param       aValue:Variable
         *                 The value of the current value. This is
         *                 initialized from the model. At commit time, the
         *                 attribute in the model updated with this value.
         *                 The "value" is typically updated at focus loss
         *                 or at selection changed based on the component
         *                 controller's role.
         */
        /*==============================================================*/
   protected  void  setVariable (
                                 Variable  aValue
                                )
   {
//##Begin DataComponentController:setVariable(Variable) preserve=no

      variable = aValue;

//##End   DataComponentController:setVariable(Variable)
   }

        /*==============================================================*/
        /* OPERATION:  setErrorMessage                                  */
        /*                                                              */
        /**
         * This method sets the value of this errorMessage attribute is
         * used during error reporting. An error is reported if the
         * autoReportErrors attribute is set. An errorMessage is always
         * overridden is a localizedErrorMessageID is specified. Developers
         * are encouraged to use setLocalizedErrorMessageID rather than set
         * error message.
         *  
         * @param       aValue:java.lang.String
         *                 The value of this errorMessage attribute is used
         *                 during error reporting. An error is reported if
         *                 the autoReportErrors attribute is set. An
         *                 errorMessage is always overridden is a
         *                 localizedErrorMessageID is specified. Developers
         *                 are encouraged to use setLocalizedErrorMessageID
         *                 rather than set error message.
         */
        /*==============================================================*/
   public  void  setErrorMessage (
                                  java.lang.String  aValue
                                 )
   {
//##Begin DataComponentController:setErrorMessage(String) preserve=no

      errorMessage = aValue;

//##End   DataComponentController:setErrorMessage(String)
   }

        /*==============================================================*/
        /* OPERATION:  setLocalizedErrorMessageID                       */
        /*                                                              */
        /**
         * This method sets the value of this message is used to extract a
         * message string to display to a user in case of an error. The
         * resources is resolved relative to the FormComponent that this
         * DCC is managing. A developer is given a chance to substitute
         * parameters by overriding the substitueParameters method. The
         * system provides a default error message with simple
         * substituions.
         *  
         * @param       aValue:java.lang.String
         *                 The value of this message is used to extract a
         *                 message string to display to a user in case of
         *                 an error. The resources is resolved relative to
         *                 the FormComponent that this DCC is managing. A
         *                 developer is given a chance to substitute
         *                 parameters by overriding the substitueParameters
         *                 method. The system provides a default error
         *                 message with simple substituions.
         */
        /*==============================================================*/
   public  void  setLocalizedErrorMessageID (
                                             java.lang.String  aValue
                                            )
   {
//##Begin DataComponentController:setLocalizedErrorMessageID(String) preserve=no

      localizedErrorMessageID = aValue;

//##End   DataComponentController:setLocalizedErrorMessageID(String)
   }

        /*==============================================================*/
        /* OPERATION:  setAutoDisplayErrors                             */
        /*                                                              */
        /**
         * This method sets the value of this attribute determines whether
         * the controller displays an error message when an error situation
         * is detected. Typical situations will be invalid data entered by
         * a user.
         *  
         * @param       aValue:boolean
         *                 The value of this attribute determines whether
         *                 the controller displays an error message when an
         *                 error situation is detected. Typical situations
         *                 will be invalid data entered by a user.
         */
        /*==============================================================*/
   public  void  setAutoDisplayErrors (
                                       boolean  aValue
                                      )
   {
//##Begin DataComponentController:setAutoDisplayErrors(boolean) preserve=no

      autoDisplayErrors = aValue;

//##End   DataComponentController:setAutoDisplayErrors(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setErrorFieldName                                */
        /*                                                              */
        /**
         * This method sets the value of when substituion of error messages
         * take place, if this field is set, it is used inplace of the
         * attribute name. This makes for a more friendly error message.
         *  
         * @param       aValue:java.lang.String
         *                 The value of when substituion of error messages
         *                 take place, if this field is set, it is used
         *                 inplace of the attribute name. This makes for a
         *                 more friendly error message.
         */
        /*==============================================================*/
   public  void  setErrorFieldName (
                                    java.lang.String  aValue
                                   )
   {
//##Begin DataComponentController:setErrorFieldName(String) preserve=no

      errorFieldName = aValue;

//##End   DataComponentController:setErrorFieldName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setWriteOnly                                     */
        /*                                                              */
        /**
         * This method sets the value of if set, then attribute changes in
         * the model will never update the GUI component.
         *  
         * @param       aValue:boolean
         *                 The value of if set, then attribute changes in
         *                 the model will never update the GUI component.
         */
        /*==============================================================*/
   public  void  setWriteOnly (
                               boolean  aValue
                              )
   {
//##Begin DataComponentController:setWriteOnly(boolean) preserve=no

      writeOnly = aValue;

//##End   DataComponentController:setWriteOnly(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setRequired                                      */
        /*                                                              */
        /**
         * This method sets the value of this attribute designates a given
         * value as required. The model will simply not accept a null
         * value. By default this is set to false (not required). The
         * "required" interpretation is handled by the subclasses.
         * <p>
         * For most formatted text field controls , a developer should set
         * the constraints on the text component.
         *  
         * @param       aValue:boolean
         *                 The value of this attribute designates a given
         *                 value as required. The model will simply not
         *                 accept a null value. By default this is set to
         *                 false (not required). The "required"
         *                 interpretation is handled by the subclasses.
         * <p>
         *                 For most formatted text field controls , a
         *                 developer should set the constraints on the text
         *                 component.
         */
        /*==============================================================*/
   public  void  setRequired (
                              boolean  aValue
                             )
   {
//##Begin DataComponentController:setRequired(boolean) preserve=no

      required = aValue;

//##End   DataComponentController:setRequired(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setRootModel                                     */
        /*                                                              */
        /**
         * This method sets the value of if the attribute name represents
         * an embedded model, this attribute will hold the whole the
         * rootModel as supplied to the form. The model attribute will then
         * have the embedded model from the attribute name.
         *  
         * @param       aValue:java.lang.Object
         *                 The value of if the attribute name represents an
         *                 embedded model, this attribute will hold the
         *                 whole the rootModel as supplied to the form. The
         *                 model attribute will then have the embedded
         *                 model from the attribute name.
         */
        /*==============================================================*/
   protected  void  setRootModel (
                                  java.lang.Object  aValue
                                 )
   {
//##Begin DataComponentController:setRootModel(Object) preserve=no

      rootModel = aValue;

//##End   DataComponentController:setRootModel(Object)
   }

        /*==============================================================*/
        /* OPERATION:  setRealAttributeName                             */
        /*                                                              */
        /**
         * This method sets the value of if the attribute represents an
         * embedded model, then this attribute holds the real name as
         * supplied during object construction. Otherwise this attribute is
         * the same as the attributeName.
         *  
         * @param       aValue:java.lang.String
         *                 The value of if the attribute represents an
         *                 embedded model, then this attribute holds the
         *                 real name as supplied during object
         *                 construction. Otherwise this attribute is the
         *                 same as the attributeName.
         */
        /*==============================================================*/
   protected  void  setRealAttributeName (
                                          java.lang.String  aValue
                                         )
   {
//##Begin DataComponentController:setRealAttributeName(String) preserve=no

      realAttributeName = aValue;

//##End   DataComponentController:setRealAttributeName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setReadOnly                                      */
        /*                                                              */
        /**
         * This method sets the value of if set to true, then override
         * security enabling.
         *  
         * @param       aValue:boolean
         *                 The value of if set to true, then override
         *                 security enabling.
         */
        /*==============================================================*/
   public  void  setReadOnly (
                              boolean  aValue
                             )
   {
//##Begin DataComponentController:setReadOnly(boolean) preserve=no

      readOnly = aValue;

//##End   DataComponentController:setReadOnly(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setResetAllowedIfRequired                        */
        /*                                                              */
        /**
         * This method sets the value of the "resetAllowedIfRequired"
         * attribute.
         *  
         * @param       aValue:boolean
         *                 The value of the "resetAllowedIfRequired"
         *                 attribute.
         */
        /*==============================================================*/
   public  void  setResetAllowedIfRequired (
                                            boolean  aValue
                                           )
   {
//##Begin DataComponentController:setResetAllowedIfRequired(boolean) preserve=no

      resetAllowedIfRequired = aValue;

//##End   DataComponentController:setResetAllowedIfRequired(boolean)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  focusGained                                      */
        /*                                                              */
        /**
         * @param       e:java.awt.event.FocusEvent
         */
        /*==============================================================*/
   public  void  focusGained (
                              java.awt.event.FocusEvent  e
                             )
   {
//##Begin DataComponentController:focusGained(FocusEvent) preserve=yes
      handleFocusGained();
//##End   DataComponentController:focusGained(FocusEvent)
   }

        /*==============================================================*/
        /* OPERATION:  focusLost                                        */
        /*                                                              */
        /**
         * @param       e:java.awt.event.FocusEvent
         */
        /*==============================================================*/
   public  void  focusLost (
                            java.awt.event.FocusEvent  e
                           )
   {
//##Begin DataComponentController:focusLost(FocusEvent) preserve=yes
      handleFocusLost();
//##End   DataComponentController:focusLost(FocusEvent)
   }

        /*==============================================================*/
        /* OPERATION:  propertyChange                                   */
        /*                                                              */
        /**
         * @param       e:java.beans.PropertyChangeEvent
         */
        /*==============================================================*/
   public  void  propertyChange (
                                 java.beans.PropertyChangeEvent  e
				 )
      {
	 //##Begin DataComponentController:propertyChange(PropertyChangeEvent) preserve=yes

	 //=============================================================================
	 // If the source is the formComponent, we need to look for the model change
	 //=============================================================================
	 if (e.getSource() == formComponent) {
	    if (!userVariable && e.getPropertyName().equals("model")) {
	       setModel(formComponent.getModel());
	    }
	    // Readonly
	    String readonly = ApplicationConfigHelper.instance().getProperty(READONLY);
	    if (!isReadOnly()) {
	       // Readonly
	       // This readonly flag is taken from property file, instead of being
	       // specified by caller of this routine;
	       if ((readonly != null) && (readonly.equalsIgnoreCase("true"))) {
	       } else {
		  checkSecurity();
	       }
	    }
	    else {
	       // Readonly
	       // This readonly flag is taken from property file, instead of being
	       // specified by caller of this routine;
	       if ((readonly != null) && (readonly.equalsIgnoreCase("true"))) {
	       } else {
		  setToReadWrite(false);
	       }
	    }

	 }
	 //=============================================================================
	 // If the source is the formComponent, we need to look for the value change
	 //=============================================================================
	 else if (e.getSource() == variable) {
	    if (e.getPropertyName().equals("value")) {
	       if (!isWriteOnly()) {
		  handleValueChange(e.getNewValue());
	       }
	       updateModelAttribute(getAttributeClass(), variable.getValue());	 
	    }	 
	 }
	 //=============================================================================
	 // If the source is the model itself, we need to look for the value change
	 //=============================================================================
	 else if (e.getSource() == model) {
	    if (e.getPropertyName().equals(attributeName)) {
	       variable.setValue(e.getNewValue());
	    }
	 }
	 // If the property that has changed in the main model, represents an embedded model
	 // then we should treat the event as a model change and install listeners in the children
	 // attributes. For example, if we are monitoring property "description" of "reason" in account,
	 // i.e the user specified "reason.description", our main model is , say , account (which we monitor)
	 // but the real model is reason resolved in setModel. Anytime the root of an embedded property changes,
	 // we need to remove all listeners from the old root and children, and install them in the new
	 // root. Here is the algorithm:
	 // - If the property change is the root object from the compound name, then our root model has changed.
	 //   - For root and all children , remove property change listeners (if any) and add new listeners on the
	 //     new root and children.
	 else if (realAttributeName != null && realAttributeName.startsWith(e.getPropertyName() + ".")) {
	    setModel(rootModel); // Update the root model to trigger installation of new listeners in embedded models.
	 }
	 //##End   DataComponentController:propertyChange(PropertyChangeEvent)
      }

        /*==============================================================*/
        /* OPERATION:  addPropertyChangeListener                        */
        /*                                                              */
        /**
         * Adds a property change listener to the list of listeners. Used
         * by objects that are interested in events fiered by this object.
         *  
         * @param       aListener:java.beans.PropertyChangeListener
         */
        /*==============================================================*/
   public synchronized  void  addPropertyChangeListener (
                                                         java.beans.PropertyChangeListener  aListener
                                                        )
   {
//##Begin DataComponentController:addPropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().addPropertyChangeListener (aListener);
//##End   DataComponentController:addPropertyChangeListener(PropertyChangeListener)
   }

        /*==============================================================*/
        /* OPERATION:  removePropertyChangeListener                     */
        /*                                                              */
        /**
         * Removes the listener from the listener list.
         *  
         * @param       aListener:java.beans.PropertyChangeListener
         */
        /*==============================================================*/
   public synchronized  void  removePropertyChangeListener (
                                                            java.beans.PropertyChangeListener  aListener
                                                           )
   {
//##Begin DataComponentController:removePropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().removePropertyChangeListener (aListener);
//##End   DataComponentController:removePropertyChangeListener(PropertyChangeListener)
   }

        /*==============================================================*/
        /* OPERATION:  firePropertyChange                               */
        /*                                                              */
        /**
         * Called by subclasses to fire property change notifications to
         * event listeners.
         *  
         * @param       propertyName:java.lang.String
         * @param       oldValue:java.lang.Object
         * @param       newValue:java.lang.Object
         */
        /*==============================================================*/
   public  void  firePropertyChange (
                                     java.lang.String  propertyName,
                                     java.lang.Object  oldValue,
                                     java.lang.Object  newValue
                                    )
   {
//##Begin DataComponentController:firePropertyChange(String,Object,Object) preserve=yes
      propertyChangeSupport.firePropertyChange (propertyName, oldValue, newValue);    
//##End   DataComponentController:firePropertyChange(String,Object,Object)
   }

        /*==============================================================*/
        /* OPERATION:  substituteParameters                             */
        /*                                                              */
        /**
         * This method is called just before an error message is displayed.
         * It allows a user to customize the parameters set in the error
         * message. The attribute name is inserted in the text.
         *  
         * @param       message:java.lang.String
         * @return      :java.lang.String -
         */
        /*==============================================================*/
   public  java.lang.String  substituteParameters (
                                                   java.lang.String  message
                                                  )
   {
//##Begin DataComponentController:substituteParameters(String) preserve=yes
      if (message == DEFAULT_ERROR_STRING ) {	 
	 Object[] arguments = { errorFieldName == null ? attributeName : errorFieldName};
	 message = MessageFormat.format(message, arguments);
      }
      return message;
//##End   DataComponentController:substituteParameters(String)
   }

        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * If the model has a null value, and the DCC is marked as required
         * then false is returned.
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                            )
   {
//##Begin DataComponentController:isValid() preserve=yes
      if (!isRequired()) {	 
	 return true;
      }

      Object value = getModelAttributeValue();

      return value != null;
//##End   DataComponentController:isValid()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleModelChange                                */
        /*                                                              */
        /**
         * Called whenever the model on the form is changed. If the
         * variable was supplied by the user, this method has no effect.
         *  
         */
        /*==============================================================*/
   protected  void  handleModelChange (
                                      )
   {
//##Begin DataComponentController:handleModelChange() preserve=yes

      // Whenever the model changes, the reset flag is set to false since
      // every attribute is considered clean.      
      resetValue = getModelAttributeValue();
      variable.setValue(resetValue);      
//##End   DataComponentController:handleModelChange()
   }

        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed.
         *  
         * @param       newValue:java.lang.Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       java.lang.Object  newValue
                                      )
   {
//##Begin DataComponentController:handleValueChange(Object) preserve=yes

//##End   DataComponentController:handleValueChange(Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleFocusLost                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleFocusLost (
                                    )
   {
//##Begin DataComponentController:handleFocusLost() preserve=yes

//##End   DataComponentController:handleFocusLost()
   }

        /*==============================================================*/
        /* OPERATION:  handleFocusGained                                */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleFocusGained (
                                      )
   {
//##Begin DataComponentController:handleFocusGained() preserve=yes

//##End   DataComponentController:handleFocusGained()
   }

        /*==============================================================*/
        /* OPERATION:  updateModelAttribute                             */
        /*                                                              */
        /**
         * Updates the model attribute using the name and model currently
         * set.
         * <p>
         * @param parameterClass. The class of the attribute.
         * <p>
         * @param value. The new value
         *  
         * @param       parameterClass:java.lang.Class
         * @param       value:java.lang.Object
         */
        /*==============================================================*/
   protected  void  updateModelAttribute (
                                          java.lang.Class   parameterClass,
                                          java.lang.Object  value
                                         )
   {
//##Begin DataComponentController:updateModelAttribute(Class,Object) preserve=yes
      if (model == null) {
	 return;
      }

      Object attributeValue = getModelAttributeValue();

      if (value == attributeValue) {
	 return;
      }

      if (value != null && attributeValue != null) {
	 if (value.equals(attributeValue)) {
	    return;
	 }
      }

      System.out.println("Updating the model attribute:" + 
			 attributeName + 
			 " with new value:" + 
			 value + 
			 " The current attribute value in the model is:" + 
			 attributeValue + 
			 " .The attribute class is:" + 
			 parameterClass + 
			 ". The model is:" + 
			 model + 
			 " . Parameter class is:" + parameterClass + "\n\n");

      Class           myClass       = model.getClass();
      Method          myMethod      = null;
      Class []        myParams      = { parameterClass };
       
      myMethod = ClassHelper.getClosestMatchingMethod("set" + Case.capitalize(attributeName),
						      myClass, 
						      myParams);

      if (myMethod != null ) {
	 Object  args[] = { value };
	 try {
	    myMethod.invoke(model , args);  	
	 }
	 catch(InvocationTargetException exception) {
	    System.out.println("We caught an exception invoking the set method. Lets reset the value in the gui control."); 
	    new ExceptionPane(exception.getTargetException());
	    variable.setValue(attributeValue);      
	 }
	 catch(Throwable exception) {
	    System.out.println("We caught an exception invoking the set method. Lets reset the value in the gui control."); 
	    new ExceptionPane(exception);
	    variable.setValue(attributeValue);      
	 }     
      }
      else {
	 System.out.println("The attribute " + attributeName + " is readonly. No Setter is found in the model");
      }

//##End   DataComponentController:updateModelAttribute(Class,Object)
   }

        /*==============================================================*/
        /* OPERATION:  getModelAttributeValue                           */
        /*                                                              */
        /**
         * Returns the attribute value as currently set in the model.
         *  
         * @return      :java.lang.Object -
         */
        /*==============================================================*/
   protected  java.lang.Object  getModelAttributeValue (
                                                       )
   {
//##Begin DataComponentController:getModelAttributeValue() preserve=yes
      Class           myClass       = null;
      Method          myMethod      = null;
      Object          myValue       = null;

      if (model == null) {
	 return myValue;
      }

      myClass  = model.getClass();

      myMethod = ClassHelper.getClosestMatchingMethod("get" + Case.capitalize(attributeName),
						      myClass, 
						      null);
      
      if ( myMethod == null ) {
	 myMethod = ClassHelper.getClosestMatchingMethod("is" + Case.capitalize(attributeName),
							 myClass, 
							 null);	 
      }

      if ( myMethod != null ) {
	 try {
	    myValue = myMethod.invoke(model , null);  
	 }
	 catch(Throwable ignore) {
	    throw new RuntimeException("Failed to read  model for " + component + " attribute is " + attributeName);
	 }     
      } 
      
      return myValue;
//##End   DataComponentController:getModelAttributeValue()
   }

        /*==============================================================*/
        /* OPERATION:  handlePrepare                                    */
        /*                                                              */
        /**
         * Called as a result of the form firing a prepare event. The
         * prepare event is fired by a form component in its
         * prepareStore(). If that method is overridden by your form, you
         * must call super.prepareStore() in order for a DCC to get a
         * notification.
         *  
         * @exception   COM.novusnet.vision.java.gui.PrepareFormException -
         */
        /*==============================================================*/
   protected  void  handlePrepare (
                                  )
                            throws COM.novusnet.vision.java.gui.PrepareFormException
   {
//##Begin DataComponentController:handlePrepare() preserve=yes
      if (!isValid() && isAutoDisplayErrors()) {
	 displayError();
	 PrepareFormException myException = new PrepareFormException();
	 myException.setNoGUI(true);
	 throw myException;
      }      
//##End   DataComponentController:handlePrepare()
   }

        /*==============================================================*/
        /* OPERATION:  handleCommit                                     */
        /*                                                              */
        /**
         * Called in response to the form firing a commit event. The
         * default implementation automatically involves the model in the
         * transaction.
         *  
         */
        /*==============================================================*/
   protected  void  handleCommit (
                                 )
   {
//##Begin DataComponentController:handleCommit() preserve=yes
//       if (attributeChangedByUser && 
// 	  model != null && 
// 	  model instanceof BusinessObject) {
// 	 BusinessObjectTxnResource txnResource = ((BusinessObject)model).getBusinessObjectTxnResource();

// 	 if (txnResource == null) {
// 	    ((BusinessObject)model).handleTransactionInvolvement();
// 	    txnResource = ((BusinessObject)model).getBusinessObjectTxnResource();
// 	 }

	 //	 ((BusinessObject)model).setDirty(attributeName, resetValue, getVariable().getValue());
// 	 System.out.println("Added: " + 
// 			    attributeName + 
// 			    " with a reset value of:" + 
// 			    resetValue + 
// 			    " and new value of " + 
// 			    getVariable().getValue() + 
// 			    " to model:" + 
// 			    model);
      //      }
//##End   DataComponentController:handleCommit()
   }

        /*==============================================================*/
        /* OPERATION:  displayError                                     */
        /*                                                              */
        /**
         * This method is called to display an error message. This method
         * loads the message, calls susbstitueParameters and then creates
         * an option pane to display the error.
         *  
         */
        /*==============================================================*/
   protected  void  displayError (
                                 )
   {
//##Begin DataComponentController:displayError() preserve=yes
      String           errorString = getLocalizedErrorMessageID() ;
      ResourceResolver aResolver   = new ResourceResolver ();      

      if (displayingError) {
	 return;
      }

      if (isAutoDisplayErrors())  {
	 displayingError = true;
      }

      try {
	 if (errorString != null) {
	    errorString = aResolver.getStringResource(errorString, 
						      getFormComponent().getClass()); 
	 }
	 
	 if (errorString == null) {
	    errorString = getErrorMessage();
	 }
	 
	 if (errorString == null) {
	    errorString = DEFAULT_ERROR_STRING;
	 }
	 
	 errorString = substituteParameters(errorString);
	 
	 JOptionPane.showMessageDialog(getFormComponent().getFrame(), 
				       errorString,
				       LOCALIZED_ERROR_STRING,
				       JOptionPane.ERROR_MESSAGE); 
         if(isResetAllowedIfRequired()) {
             handleReset();
         }     					       
      }
      finally {
	 displayingError = false;
      }

//##End   DataComponentController:displayError()
   }

        /*==============================================================*/
        /* OPERATION:  handleReset                                      */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleReset (
                                )
   {
//##Begin DataComponentController:handleReset() preserve=yes
      if (model != null) {
	 if (model instanceof BusinessObject) {
	    if (((BusinessObject)model).isDirty(attributeName)) {
	       updateModelAttribute(getAttributeClass() , resetValue);
	       ((BusinessObject)model).setDirty(attributeName, false);
	    }
	 }
	 else {
	    updateModelAttribute(getAttributeClass() , resetValue);	    
	 }
      }
//##End   DataComponentController:handleReset()
   }

        /*==============================================================*/
        /* OPERATION:  setToReadWrite                                   */
        /*                                                              */
        /**
         * @param       state:boolean
         */
        /*==============================================================*/
   protected  void  setToReadWrite (
                                    boolean  state
                                   )
   {
//##Begin DataComponentController:setToReadWrite(boolean) preserve=yes
      System.out.println("setting toreadwrite: " + state);
      component.setEnabled(state);
//##End   DataComponentController:setToReadWrite(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  handleDisengage                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected  void  handleDisengage (
                                    )
   {
//##Begin DataComponentController:handleDisengage() preserve=yes
      setModel(null);
      if (formComponent != null) {
	 formComponent.removePropertyChangeListener(this);
	 formComponent.removeFormComponentListener(formComponentListener);
      }
      component.removePropertyChangeListener(this);
      component.removeFocusListener(this);
      variable.removePropertyChangeListener(this);
      variable.setValue(null);
      formComponent = null;
//##End   DataComponentController:handleDisengage()
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  checkSecurity                                    */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   private  void  checkSecurity (
                                )
   {
//##Begin DataComponentController:checkSecurity() preserve=yes

      // Loop thru all secuirty objects enabling or disabling the component
      // based on the return value.
      int count = securityList.size();
      for (int i = 0; i < count; i++) {
	 DCCSecurity security = (DCCSecurity) securityList.elementAt(i);
	 if (security.checkAttributeSecurity(this) == SECURITY_WRITABLE_ATTRIBUTE) {
	    setToReadWrite(true);
	 }else if (security.checkAttributeSecurity(this) == SECURITY_READONLY_ATTRIBUTE) {
	    setToReadWrite(false);
	 }
      }      
//##End   DataComponentController:checkSecurity()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  addDCCSecurity                                   */
        /*                                                              */
        /**
         * Adds a new security record to the globalDCC table. The record
         * (checkAttributeSecurity) is called whenever the model changes on
         * the form.
         *  
         * @param      
         * security:COM.novusnet.vision.java.gui.dcc.DCCSecurity
         */
        /*==============================================================*/
   public static  void  addDCCSecurity (
                                        COM.novusnet.vision.java.gui.dcc.DCCSecurity  security
                                       )
   {
//##Begin DataComponentController:addDCCSecurity(DCCSecurity) preserve=yes
      securityList.addElement(security);
//##End   DataComponentController:addDCCSecurity(DCCSecurity)
   }

        /*==============================================================*/
        /* OPERATION:  removeDCCSecurity                                */
        /*                                                              */
        /**
         * Removes a security instance from the list.
         *  
         * @param      
         * security:COM.novusnet.vision.java.gui.dcc.DCCSecurity
         */
        /*==============================================================*/
   public static  void  removeDCCSecurity (
                                           COM.novusnet.vision.java.gui.dcc.DCCSecurity  security
                                          )
   {
//##Begin DataComponentController:removeDCCSecurity(DCCSecurity) preserve=yes
      securityList.removeElement(security);
//##End   DataComponentController:removeDCCSecurity(DCCSecurity)
   }


    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin DataComponentController:StaticInitializer preserve=yes
   static {
      ResourceResolver aResolver   = new ResourceResolver ();      
      aResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
      DEFAULT_ERROR_STRING = aResolver.getStringResource("defaultErrorMessage",
							 DataComponentController.class);
      LOCALIZED_ERROR_STRING = aResolver.getStringResource("error",
							   DataComponentController.class);
   }
//##End   DataComponentController:StaticInitializer

}
