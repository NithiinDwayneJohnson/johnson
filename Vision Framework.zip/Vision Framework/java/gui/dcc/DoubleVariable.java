package COM.novusnet.vision.java.gui.dcc;


public class DoubleVariable extends Variable
{
   /**
    * Constructor that takes an double as a default value.
    */
   public DoubleVariable(double defaultValue)
   {
      super (new Double(defaultValue));
   }   

   /**
    * Constructor that takes an Double as a default value.
    */
   public DoubleVariable(Double defaultValue)
   {
      super (defaultValue);
   }   

   public double doubleValue()
   {
      return ((Double)getValue()).doubleValue();
   }
}




