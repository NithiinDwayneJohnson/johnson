/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableComponentController.java                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 15 at 13:27:32 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui.dcc;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import COM.novusnet.vision.java.businessobjects.BusinessObjectContainer;
import COM.novusnet.vision.java.gui.TableForm;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableComponentController                                */
/**
 * A table controller maps a selected row to an attribute in the model.
 * whenever the selection changes, the model is updated. It is important
 * that the equals  of a leaf BO be implemented.
 */
/*======================================================================*/
public  class  TableComponentController  extends  DataComponentController
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableComponentController:Attributes preserve=yes

//##End   TableComponentController:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TableComponentController                         */
        /*                                                              */
        /**
         * This constructor takes the name of the attribute in the 
         * <p>
         * modell and a table.
         *  
         * @param       component:TableForm
         * @param       name:String
         */
        /*==============================================================*/
   public    TableComponentController (
                                       TableForm  component,
                                       String     name
                                      )
   {
//##Begin TableComponentController:TableComponentController(TableForm,String) preserve=yes
     this(component, name, null);
//##End   TableComponentController:TableComponentController(TableForm,String)
   }

        /*==============================================================*/
        /* OPERATION:  TableComponentController                         */
        /*                                                              */
        /**
         * A constructor that takes a Variable , attribute name and a
         * component. The variable is used as the model for the controller.
         *  
         * @param       component:TableForm
         * @param       name:String
         * @param       variable:Variable
         */
        /*==============================================================*/
   public    TableComponentController (
                                       TableForm  component,
                                       String     name,
                                       Variable   variable
                                      )
   {
//##Begin TableComponentController:TableComponentController(TableForm,String,Variable) preserve=yes
     super(component, name, variable);

     component.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
	 public  void  valueChanged ( ListSelectionEvent  e ) {
	   TableForm                   myTableForm   = (TableForm)TableComponentController.this.component;
	   BusinessObjectContainer     myBOC         = (BusinessObjectContainer)myTableForm.getModel();
	   JTable                      myTable       = myTableForm.getTable();
	   
	   Object   selected = null;
	   
	   if (myTable.getSelectedRow() != -1) {	       
	      selected = myBOC.getElementAt(myTable.getSelectedRow());
	   }
	   if (selected != null) {
	      getVariable().setValue(selected);
	   }
	 }
     });

     component.addPropertyChangeListener(new PropertyChangeListener() {
	public void propertyChange(PropertyChangeEvent e) {
	   if (e.getPropertyName().equals("model") ) {
	      TableForm  myTableForm   = (TableForm)TableComponentController.this.component;
	      JTable     myTable       = myTableForm.getTable();	   
	      myTable.getSelectionModel().clearSelection();
	   }
	}
     });
//##End   TableComponentController:TableComponentController(TableForm,String,Variable)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleValueChange                                */
        /*                                                              */
        /**
         * Called whenever the attribute in the model is changed. The
         * object is looked up in the combobox model and made the selected
         * item.
         *  
         * @param       newValue:Object
         */
        /*==============================================================*/
   protected  void  handleValueChange (
                                       Object  newValue
                                      )
   {
//##Begin TableComponentController:handleValueChange(Object) preserve=yes
      TableForm                   myTableForm   = (TableForm)component;
      BusinessObjectContainer     myBOC         = (BusinessObjectContainer)myTableForm.getModel();
      JTable                      myTable       = myTableForm.getTable();

      if (myBOC == null) {
	 return;
      }
      
//       myTable.setRowSelectionInterval(-1 , -1);

      int count  = myBOC.getSize();

      for (int i = 0; i < count; i++) {
	 if (myBOC.getElementAt(i).equals(newValue)) {
	    myTable.setRowSelectionInterval(i, i);
	    return;
	 }
      }

//       myTable.setRowSelectionInterval(-1 , -1);

//##End   TableComponentController:handleValueChange(Object)
   }
}









