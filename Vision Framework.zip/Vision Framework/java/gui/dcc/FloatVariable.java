package COM.novusnet.vision.java.gui.dcc;


public class FloatVariable extends Variable
{
   /**
    * Constructor that takes an float as a default value.
    */
   public FloatVariable(float defaultValue)
   {
      super (new Float(defaultValue));
   }   

   /**
    * Constructor that takes an Float as a default value.
    */
   public FloatVariable(Float defaultValue)
   {
      super (defaultValue);
   }   

   public float floatValue()
   {
      return ((Float)getValue()).floatValue();
   }
}




