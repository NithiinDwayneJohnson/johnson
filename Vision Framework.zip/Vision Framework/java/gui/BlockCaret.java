package COM.novusnet.vision.java.gui;

import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.plaf.TextUI;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.Document;

/**
 * This class provides a block caret missing from swing. To user simply call
 * setCaret on a JTextComponent.
 */
public class BlockCaret extends DefaultCaret
{
   boolean insertMode = false;

   public void paint(Graphics g) 
   {
      if (insertMode) {
	 super.paint(g);
	 return;
      }

      if(isVisible()) {
	 try {
	    Graphics  myGraphics = g;

	    TextUI    mapper = getComponent().getUI();
	    Rectangle r      = mapper.modelToView(getComponent(), getDot());
	    char      ch;
	    	    
	    ch = getCharAt(getDot());
	    
	    FontMetrics fm = getComponent().getFontMetrics(getComponent().getFont());
	    int         w  = fm.stringWidth("" + ch);
	    
	    myGraphics.setColor(getComponent().getCaretColor());
	    myGraphics.setXORMode(getComponent().getBackground());
	    myGraphics.fillRect(r.x, r.y, w , r.height - 1);
	    myGraphics.setPaintMode();
	 } catch (BadLocationException e) {
	    System.out.println("Can't render cursor");
	 }
      }
   }

   /**
    * Damages the area surrounding the caret to cause
    * it to be repainted.  If paint() is reimplemented,
    * this method should also be reimplemented.
    *
    * @param r  the current location of the caret
    * @see #paint
    */
   protected void damage(Rectangle r) 
   {
      getComponent().repaint();
   }

   private char getCharAt(int index)
   {
      String   text = null;
      Document doc  = getComponent().getDocument();
      char     ch   = '9';

      try {
	 text = doc.getText(0, doc.getLength());
	 if (index < doc.getLength()) {
	    ch   = text.charAt(index);
	 }
      }
      catch(BadLocationException e) {
      }

      return ch;
   }

   public void setInsertMode(boolean insertMode)
   {   
      this.insertMode = insertMode;
      setDot(getDot());
      getComponent().repaint();      
   }

   public boolean isInsertMode()
   {   
      return (insertMode);
   }
}






