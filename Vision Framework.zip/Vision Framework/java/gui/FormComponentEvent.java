/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      FormComponentEvent.java                                 */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 November 09 at 18:26:14 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.util.EventObject;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       FormComponentEvent                                      */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  FormComponentEvent  extends  EventObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin FormComponentEvent:Attributes preserve=yes

//##End   FormComponentEvent:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private             boolean success       = false;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   public static final int     STORE_STARTED = 0;
   public static final int     STORE_ENDED   = 1;
   public static final int     STORE_COMMIT  = 2;
   public static final int     STORE_PREPARE = 3;
   public static final int     RESET         = 4;
   public static final int     DISENGAGE     = 5;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  FormComponentEvent                               */
        /*                                                              */
        /**
         * @param       source:Object
         */
        /*==============================================================*/
   public    FormComponentEvent (
                                 Object  source
                                )
   {
//##Begin FormComponentEvent:FormComponentEvent(Object) preserve=yes
      super(source);
//##End   FormComponentEvent:FormComponentEvent(Object)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isSuccess                                        */
        /*                                                              */
        /**
         * This method returns the value of success indicator in case of
         * stores.
         *  
         * @return      :boolean -
         *                 The value of success indicator in case of
         *                 stores.
         */
        /*==============================================================*/
   public  boolean  isSuccess (
                              )
   {
//##Begin FormComponentEvent:isSuccess() preserve=no

      return (success);

//##End   FormComponentEvent:isSuccess()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setSuccess                                       */
        /*                                                              */
        /**
         * This method sets the value of success indicator in case of
         * stores.
         *  
         * @param       aValue:boolean
         *                 The value of success indicator in case of
         *                 stores.
         */
        /*==============================================================*/
   public  void  setSuccess (
                             boolean  aValue
                            )
   {
//##Begin FormComponentEvent:setSuccess(boolean) preserve=no

      success = aValue;

//##End   FormComponentEvent:setSuccess(boolean)
   }


}
