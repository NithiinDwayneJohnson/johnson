/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      BOContainerTableModel.java                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 July 14 at 09:09:21 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JLabel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

import COM.novusnet.vision.java.businessobjects.BusinessObjectContainer;
import COM.novusnet.vision.java.businessobjects.BusinessObjectIndexedContainer;
import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       BOContainerTableModel                                   */
/**
 * This model acts as a glue between business object icontainers and JFC
 * tables. Its main task is to install listeners and forward notifications
 * between the model and the table. All tables that are views on BO
 * containers should use this class as their model. Assuming you have a BO
 * named Foo. In order to show Foo in a table, simply extend your new
 * FooTableModel from BOContainerTableModel and set that model on the
 * table.
 */
/*======================================================================*/
public abstract  class  BOContainerTableModel  extends  AbstractTableModel
                                            implements  ListDataListener
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin BOContainerTableModel:Attributes preserve=yes

//##End   BOContainerTableModel:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/

                /*======================================================*/
                /* ATTRIBUTE:  label                                    */
                /*                                                      */
                /**
                 * This label is used internally to calculated the column
                 * witdth.
                /*======================================================*/
   private        JLabel                  label            = new JLabel();
   private        DateFormat              dateFormat;
   private        DecimalFormat           decimalFormat;
   private        BusinessObjectContainer model            = new BusinessObjectIndexedContainer();
   private        ResourceResolver        resourceResolver;

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   private static String                  yesString;
   private static String                  noString;
   private static String                  newString;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  BOContainerTableModel                            */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public    BOContainerTableModel (
                                   )
   {
//##Begin BOContainerTableModel:BOContainerTableModel() preserve=yes
      this(null);
//##End   BOContainerTableModel:BOContainerTableModel()
   }

        /*==============================================================*/
        /* OPERATION:  BOContainerTableModel                            */
        /*                                                              */
        /**
         * @param       aBOContainer:BusinessObjectContainer
         */
        /*==============================================================*/
   public    BOContainerTableModel (
                                    BusinessObjectContainer  aBOContainer
                                   )
   {
//##Begin BOContainerTableModel:BOContainerTableModel(BusinessObjectContainer) preserve=yes
      setModel(aBOContainer);
//##End   BOContainerTableModel:BOContainerTableModel(BusinessObjectContainer)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getLabel                                         */
        /*                                                              */
        /**
         * This method returns the value of this label is used internally
         * to calculated the column witdth.
         *  
         * @return      :JLabel -
         *                 The value of this label is used internally to
         *                 calculated the column witdth.
         */
        /*==============================================================*/
   private  JLabel  getLabel (
                             )
   {
//##Begin BOContainerTableModel:getLabel() preserve=no

      return (label);

//##End   BOContainerTableModel:getLabel()
   }

        /*==============================================================*/
        /* OPERATION:  getYesString                                     */
        /*                                                              */
        /**
         * This method returns the value of the "yesString" attribute.
         *  
         * @return      :String -
         *                 The value of the "yesString" attribute.
         */
        /*==============================================================*/
   public static  String  getYesString (
                                       )
   {
//##Begin BOContainerTableModel:getYesString() preserve=no

      return (yesString);

//##End   BOContainerTableModel:getYesString()
   }

        /*==============================================================*/
        /* OPERATION:  getNoString                                      */
        /*                                                              */
        /**
         * This method returns the value of the "noString" attribute.
         *  
         * @return      :String -
         *                 The value of the "noString" attribute.
         */
        /*==============================================================*/
   public static  String  getNoString (
                                      )
   {
//##Begin BOContainerTableModel:getNoString() preserve=no

      return (noString);

//##End   BOContainerTableModel:getNoString()
   }

        /*==============================================================*/
        /* OPERATION:  getDateFormat                                    */
        /*                                                              */
        /**
         * This method returns the value of a format object used for
         * formatting dates.
         *  
         * @return      :DateFormat -
         *                 The value of a format object used for formatting
         *                 dates.
         */
        /*==============================================================*/
   public  DateFormat  getDateFormat (
                                     )
   {
//##Begin BOContainerTableModel:getDateFormat() preserve=yes
      if (dateFormat == null) {
	 dateFormat = DateFormat.getDateInstance(); 
      }

      return dateFormat;
//##End   BOContainerTableModel:getDateFormat()
   }

        /*==============================================================*/
        /* OPERATION:  getDecimalFormat                                 */
        /*                                                              */
        /**
         * This method returns the value of a format object used for
         * formatting numbers.
         *  
         * @return      :DecimalFormat -
         *                 The value of a format object used for formatting
         *                 numbers.
         */
        /*==============================================================*/
   public  DecimalFormat  getDecimalFormat (
                                           )
   {
//##Begin BOContainerTableModel:getDecimalFormat() preserve=yes
      if (decimalFormat == null) {
	 decimalFormat = (DecimalFormat)NumberFormat.getCurrencyInstance();
      }

      return decimalFormat;
//##End   BOContainerTableModel:getDecimalFormat()
   }

        /*==============================================================*/
        /* OPERATION:  getNewString                                     */
        /*                                                              */
        /**
         * This method returns the value of the "newString" attribute.
         *  
         * @return      :String -
         *                 The value of the "newString" attribute.
         */
        /*==============================================================*/
   public static  String  getNewString (
                                       )
   {
//##Begin BOContainerTableModel:getNewString() preserve=no

      return (newString);

//##End   BOContainerTableModel:getNewString()
   }

        /*==============================================================*/
        /* OPERATION:  getModel                                         */
        /*                                                              */
        /**
         * This method returns the value of the "model" attribute.
         *  
         * @return      :BusinessObjectContainer -
         *                 The value of the "model" attribute.
         */
        /*==============================================================*/
   public  BusinessObjectContainer  getModel (
                                             )
   {
//##Begin BOContainerTableModel:getModel() preserve=no

      return (model);

//##End   BOContainerTableModel:getModel()
   }

        /*==============================================================*/
        /* OPERATION:  getResourceResolver                              */
        /*                                                              */
        /**
         * This method returns the value of the "resourceResolver"
         * attribute.
         *  
         * @return      :ResourceResolver -
         *                 The value of the "resourceResolver" attribute.
         */
        /*==============================================================*/
   public  ResourceResolver  getResourceResolver (
                                                 )
   {
//##Begin BOContainerTableModel:getResourceResolver() preserve=yes

      if (resourceResolver == null) {
	 resourceResolver = new ResourceResolver();
	 resourceResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
      }

      return (resourceResolver);

//##End   BOContainerTableModel:getResourceResolver()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setLabel                                         */
        /*                                                              */
        /**
         * This method sets the value of this label is used internally to
         * calculated the column witdth.
         *  
         * @param       aValue:JLabel
         *                 The value of this label is used internally to
         *                 calculated the column witdth.
         */
        /*==============================================================*/
   private  void  setLabel (
                            JLabel  aValue
                           )
   {
//##Begin BOContainerTableModel:setLabel(JLabel) preserve=no

      label = aValue;

//##End   BOContainerTableModel:setLabel(JLabel)
   }

        /*==============================================================*/
        /* OPERATION:  setResourceResolver                              */
        /*                                                              */
        /**
         * This method sets the value of the "resourceResolver" attribute.
         *  
         * @param       aValue:ResourceResolver
         *                 The value of the "resourceResolver" attribute.
         */
        /*==============================================================*/
   public  void  setResourceResolver (
                                      ResourceResolver  aValue
                                     )
   {
//##Begin BOContainerTableModel:setResourceResolver(ResourceResolver) preserve=no

      resourceResolver = aValue;

//##End   BOContainerTableModel:setResourceResolver(ResourceResolver)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getRowCount                                      */
        /*                                                              */
        /**
         * Returns the number of rows currently in the model.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getRowCount (
                            )
   {
//##Begin BOContainerTableModel:getRowCount() preserve=yes

      if (getModel() != null) {
	 return getModel().getSize(); 
      }

      return (0);

//##End   BOContainerTableModel:getRowCount()
   }

        /*==============================================================*/
        /* OPERATION:  intervalAdded                                    */
        /*                                                              */
        /**
         * This method gets called by the BOContainer when a new interval
         * is added. In turn, this methods forwards an event to the table
         * to cause it to insert the new rows.
         *  
         * @param       e:ListDataEvent
         */
        /*==============================================================*/
   public  void  intervalAdded (
                                ListDataEvent  e
                               )
   {
//##Begin BOContainerTableModel:intervalAdded(ListDataEvent) preserve=yes
      mapAndFireTableModelEvent(e);
//##End   BOContainerTableModel:intervalAdded(ListDataEvent)
   }

        /*==============================================================*/
        /* OPERATION:  contentsChanged                                  */
        /*                                                              */
        /**
         * This method gets called by the BOContainer when an interval is
         * changed. In turn, this methods forwards an event to the table to
         * cause it to handle the new changes.
         *  
         * @param       e:ListDataEvent
         */
        /*==============================================================*/
   public  void  contentsChanged (
                                  ListDataEvent  e
                                 )
   {
//##Begin BOContainerTableModel:contentsChanged(ListDataEvent) preserve=yes
      mapAndFireTableModelEvent(e);
//##End   BOContainerTableModel:contentsChanged(ListDataEvent)
   }

        /*==============================================================*/
        /* OPERATION:  intervalRemoved                                  */
        /*                                                              */
        /**
         * This method gets called by the BOContainer when an interval is
         * removed. In turn, this methods forwards an event to the table to
         * cause it to remove the rows from the table.
         *  
         * @param       e:ListDataEvent
         */
        /*==============================================================*/
   public  void  intervalRemoved (
                                  ListDataEvent  e
                                 )
   {
//##Begin BOContainerTableModel:intervalRemoved(ListDataEvent) preserve=yes
      mapAndFireTableModelEvent(e);
//##End   BOContainerTableModel:intervalRemoved(ListDataEvent)
   }

        /*==============================================================*/
        /* OPERATION:  setModel                                         */
        /*                                                              */
        /**
         * Users call this method to set the BO to link.
         *  
         * @param       aModel:BusinessObjectContainer
         */
        /*==============================================================*/
   public  void  setModel (
                           BusinessObjectContainer  aModel
                          )
   {
//##Begin BOContainerTableModel:setModel(BusinessObjectContainer) preserve=yes

    //==========================================
    // Remove listeners on the old container
    //==========================================
    if (model != null) {
       model.removeListDataListener(this);
    }

    model = aModel;

    //==========================================
    // Intall new listener
    //==========================================
    if (model != null) {
       model.addListDataListener(this);
    }

    //==========================================
    // Tell the table that we have changed
    //==========================================
    fireTableDataChanged(); 
//##End   BOContainerTableModel:setModel(BusinessObjectContainer)
   }

        /*==============================================================*/
        /* OPERATION:  getStringResource                                */
        /*                                                              */
        /**
         * This method returns the resource string associated with a key.
         * If the resource is not found, a "Not found" is returned to
         * caller.
         *  
         * @param       aKey:String
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getStringResource (
                                      String  aKey
                                     )
   {
//##Begin BOContainerTableModel:getStringResource(String) preserve=yes
      String resource = "Not found";

      resource = getResourceResolver().getStringResource(aKey, this.getClass());
      
      return(resource);
//##End   BOContainerTableModel:getStringResource(String)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  mapAndFireTableModelEvent                        */
        /*                                                              */
        /**
         * Internal method that translates between ListData and table
         * events.
         *  
         * @param       e:ListDataEvent
         */
        /*==============================================================*/
   protected  void  mapAndFireTableModelEvent (
                                               ListDataEvent  e
                                              )
   {
//##Begin BOContainerTableModel:mapAndFireTableModelEvent(ListDataEvent) preserve=yes

    TableModelEvent tableEvent = null;
        
    switch(e.getType()) {
       case ListDataEvent.INTERVAL_ADDED:	  
	  fireTableRowsInserted(e.getIndex0() ,e.getIndex1());
	  break;
	  
       case ListDataEvent.INTERVAL_REMOVED:
	  tableEvent = new TableModelEvent(this , e.getIndex0() ,e.getIndex1());
	  fireTableRowsDeleted(e.getIndex0() ,e.getIndex1());
	  break;
	  
       case ListDataEvent.CONTENTS_CHANGED:
	  int index0 = e.getIndex0();
	  int index1 = e.getIndex1();

	  if (index0 == -1) {
	     index0 = 0;
	     index1 = Integer.MAX_VALUE;
	  }
	  
	  fireTableRowsUpdated(index0 ,index1);
	  break;
    } 

//##End   BOContainerTableModel:mapAndFireTableModelEvent(ListDataEvent)
   }

        /*==============================================================*/
        /* OPERATION:  adjustTextColumnMinWidth                         */
        /*                                                              */
        /**
         * This method sets the minimum width of the column to be based on
         * the minimum width in the text columns. It is hard to predict the
         * width of the column without the data thus this function should
         * be called when the data contents is known.
         * <p>
         * Please note that this function works with text columns. Its
         * results are unpredictable otherwise.
         *  
         * @param       columnID:Object
         * @param       text:String
         * @return      :String -
         */
        /*==============================================================*/
   protected  String  adjustTextColumnMinWidth (
                                                Object  columnID,
                                                String  text
                                               )
   {
//##Begin BOContainerTableModel:adjustTextColumnMinWidth(Object,String) preserve=yes
//       TableColumn          myColumn     = getTable().getColumn(columnID);
//       DefaultCellRenderer  cellRenderer = (DefaultCellRenderer)myColumn.getCellRenderer();
           
//       getLabel().setText(text);
//       java.awt.Dimension dim = getLabel().getPreferredSize();

//       if (myColumn.getMinWidth() < dim.width) {
// 	 myColumn.setMinWidth(dim.width);
// 	 getTable().repaint();
//       }

//       return (text);

      return("Crap");
//##End   BOContainerTableModel:adjustTextColumnMinWidth(Object,String)
   }


    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin BOContainerTableModel:StaticInitializer preserve=yes
   static {
      ResourceResolver.registerApplicationFallback("COM.novusnet.vision" , "COM.novusnet.vision.java.Resources");
      ResourceResolver aResolver = new ResourceResolver ();            
      aResolver.setPolicy(ResourceResolver.POLICY_PACKAGE);
      yesString = aResolver.getStringResource("yes",BOContainerTableModel.class);
      noString  = aResolver.getStringResource("no",BOContainerTableModel.class);
      newString = aResolver.getStringResource("new",BOContainerTableModel.class);
   }
//##End   BOContainerTableModel:StaticInitializer

}
