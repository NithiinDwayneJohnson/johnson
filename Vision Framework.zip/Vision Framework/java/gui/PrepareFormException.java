/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PrepareFormException.java                               */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 June 08 at 14:22:08 GMT+00:00                      */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PrepareFormException                                    */
/**
 * This exception can be thrown by the prepareStore methods. It can
 * optionally have a display panel that the controller will display upon
 * failure.
 */
/*======================================================================*/
public  class  PrepareFormException  extends  RuntimeException
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PrepareFormException:Attributes preserve=yes

//##End   PrepareFormException:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private boolean noGUI = false;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  PrepareFormException                             */
        /*                                                              */
        /**
         * A constructor that takes text. It creates an error JOption pane.
         *  
         * @param       text:String
         */
        /*==============================================================*/
   public    PrepareFormException (
                                   String  text
                                  )
   {
//##Begin PrepareFormException:PrepareFormException(String) preserve=yes
      super(text);
//##End   PrepareFormException:PrepareFormException(String)
   }

        /*==============================================================*/
        /* OPERATION:  PrepareFormException                             */
        /*                                                              */
        /**
         * A constructor that takes text. It creates an error JOption pane.
         *  
         */
        /*==============================================================*/
   public    PrepareFormException (
                                  )
   {
//##Begin PrepareFormException:PrepareFormException() preserve=yes

//##End   PrepareFormException:PrepareFormException()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isNoGUI                                          */
        /*                                                              */
        /**
         * This method returns the value of if set, this flag causes an
         * catcher not to display a GUI pane indicating an error. This is
         * usually the case when the raiser of the exception has already
         * displayed an error to the user.
         *  
         * @return      :boolean -
         *                 The value of if set, this flag causes an catcher
         *                 not to display a GUI pane indicating an error.
         *                 This is usually the case when the raiser of the
         *                 exception has already displayed an error to the
         *                 user.
         */
        /*==============================================================*/
   public  boolean  isNoGUI (
                            )
   {
//##Begin PrepareFormException:isNoGUI() preserve=no

      return (noGUI);

//##End   PrepareFormException:isNoGUI()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setNoGUI                                         */
        /*                                                              */
        /**
         * This method sets the value of if set, this flag causes an
         * catcher not to display a GUI pane indicating an error. This is
         * usually the case when the raiser of the exception has already
         * displayed an error to the user.
         *  
         * @param       aValue:boolean
         *                 The value of if set, this flag causes an catcher
         *                 not to display a GUI pane indicating an error.
         *                 This is usually the case when the raiser of the
         *                 exception has already displayed an error to the
         *                 user.
         */
        /*==============================================================*/
   public  void  setNoGUI (
                           boolean  aValue
                          )
   {
//##Begin PrepareFormException:setNoGUI(boolean) preserve=no

      noGUI = aValue;

//##End   PrepareFormException:setNoGUI(boolean)
   }


}
