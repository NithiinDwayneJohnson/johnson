package COM.novusnet.vision.java.gui;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * The PercentEditField is a number field suitable for manipulating percent numbers.
 * The default format does not allow for fraction digits. It allows for negative 
 * percentages.
 */
public class PercentEditField extends NumberEditField
{
   /**
    * Constructor that takes the number of columns to display
    * @param columns Number of columns to display.
    */
   public PercentEditField(int columns)
   {
      super(columns);
   }

   /**
    * Default constructor.
    */
   public PercentEditField()
   {      
      super();
   }

   /**
    * This method creates a percent edit formatter.
    */
   protected DecimalFormat createEditFormatter()
   {
      DecimalFormat myFormat =  (DecimalFormat)NumberFormat.getPercentInstance();
      if (Locale.getDefault().equals(Locale.US)) {
	 myFormat.applyPattern("#0.00%");
      }
      return myFormat;
   }

   /**
    * This method creates a percent display formatter.
    */
   protected DecimalFormat createDisplayFormatter()
   {
      DecimalFormat myFormat =  (DecimalFormat)NumberFormat.getPercentInstance();
      if (Locale.getDefault().equals(Locale.US)) {
	 myFormat.applyPattern("#0.00%");
      }
      return myFormat;

//       return (DecimalFormat)NumberFormat.getPercentInstance();
   }
}
