package COM.novusnet.vision.java.gui;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This validator checks whether the contents of a field represent a valid date.
 */
public class DateTextFieldValidator extends DefaultValidator
{
   /**
    * Checks the validity of a date field.
    * @param component The ExtendedTextField component to check against.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component)
   {
      DateTextField    dateTextField = (DateTextField)component;
      SimpleDateFormat df              = null;
      ParsePosition    myParsePosition = new ParsePosition(0);

      switch (dateTextField.getStyle()) {
	 case DateTextField.STYLE_MMDDYYYY:
	    df = new SimpleDateFormat("MMddyyyy");
	    break;
	    
	 case DateTextField.STYLE_MMYYYY:
	    df = new SimpleDateFormat("MMyyyy");
	    break;

	 case DateTextField.STYLE_YYYY:
	    df = new SimpleDateFormat("yyyy");
	    break;

	 case DateTextField.STYLE_MMYY:
	    df = new SimpleDateFormat("MMyy");
	    break;

      }
      
      df.setLenient(false); 
      
      try {	
     //@@@J.S  	fix error caused by SimpleDateFormat version change.
     String sdate =  component.getText().trim();
     //treat "" as valid date base on was4 isValid definition
	 if (sdate.equalsIgnoreCase("")) return true;
	 Date myDate = df.parse(sdate, myParsePosition);	
	  if ( myDate == null )return false;
      }
      catch(Throwable e) {
	 return false;
      }

      return true;        

   }
}
