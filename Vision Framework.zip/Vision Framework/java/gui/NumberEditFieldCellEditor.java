package COM.novusnet.vision.java.gui;

import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.EventObject;

import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;
import javax.swing.table.TableCellEditor;


/**
 * A table cell editor that uses the NumberEditField rather than the
 * normal JTextField.
 */

public class NumberEditFieldCellEditor implements TableCellEditor
{
   NumberEditField                 field;
   protected EventListenerList     listenerList = new EventListenerList();
   protected ChangeEvent           changeEvent  = null;
   Number                          value        = null;
   JTable                          table        = null;

   public NumberEditFieldCellEditor(NumberEditField field)
   {
      this.field = field;
      field.addFocusListener(new FocusAdapter() {
	 public void focusLost(FocusEvent e) {
	    stopCellEditing();
	 }
      });
   }

   public boolean isCellEditable(EventObject anEvent) 
   {
      return true;
   }
    
   public boolean shouldSelectCell(EventObject anEvent) 
   {
      table.requestFocus();
      field.requestFocus();
      return true;
   }

   public boolean stopCellEditing() 
   {      
      field.commitFieldValue();

      if (!field.hasValidData()) {
	 return false;
      }

      fireEditingStopped();            
      return true;
   }

   public void cancelCellEditing() 
   {
      field.setValue(value);
      fireEditingCanceled();  
   }

   public Object getCellEditorValue() 
   {
      return field.getValue();
   }
   
   public  Component getTableCellEditorComponent(JTable  table,
						 Object  value,
						 boolean isSelected,
						 int     row,
						 int     column) 
   {
      this.table = table;
      this.value = (Number)value;
      field.setValue(this.value);
      return field;
   }

    public void addCellEditorListener(CellEditorListener l) {
	listenerList.add(CellEditorListener.class, l);
    }

    public void removeCellEditorListener(CellEditorListener l) {
	listenerList.remove(CellEditorListener.class, l);
    }

    /*
     * Notify all listeners that have registered interest for
     * notification on this event type.  The event instance 
     * is lazily created using the parameters passed into 
     * the fire method.
     * @see EventListenerList
     */
    protected void fireEditingStopped() {
	// Guaranteed to return a non-null array
	Object[] listeners = listenerList.getListenerList();
	// Process the listeners last to first, notifying
	// those that are interested in this event
	for (int i = listeners.length-2; i>=0; i-=2) {
	    if (listeners[i]==CellEditorListener.class) {
		// Lazily create the event:
		if (changeEvent == null)
		    changeEvent = new ChangeEvent(this);
		((CellEditorListener)listeners[i+1]).editingStopped(changeEvent);
	    }	       
	}
    }

    /*
     * Notify all listeners that have registered interest for
     * notification on this event type.  The event instance 
     * is lazily created using the parameters passed into 
     * the fire method.
     * @see EventListenerList
     */
    protected void fireEditingCanceled() {
	// Guaranteed to return a non-null array
	Object[] listeners = listenerList.getListenerList();
	// Process the listeners last to first, notifying
	// those that are interested in this event
	for (int i = listeners.length-2; i>=0; i-=2) {
	    if (listeners[i]==CellEditorListener.class) {
		// Lazily create the event:
		if (changeEvent == null)
		    changeEvent = new ChangeEvent(this);
		((CellEditorListener)listeners[i+1]).editingCanceled(changeEvent);
	    }	       
	}
    }
}
