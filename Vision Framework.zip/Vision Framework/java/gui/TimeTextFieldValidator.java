package COM.novusnet.vision.java.gui;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This validator checks whether the contents of a field represent a valid date.
 */
public class TimeTextFieldValidator extends DefaultValidator
{
   /**
    * Checks the validity of a date field.
    * @param component The ExtendedTextField component to check against.
    * @return true If the value is valid and false otherwise.
    */
   public boolean isValid(ExtendedTextField component)
   {
      TimeTextField    timeTextField = (TimeTextField)component;
      SimpleDateFormat df              = null;
      ParsePosition    myParsePosition = new ParsePosition(0);

      switch (timeTextField.getStyle()) {
	 case TimeTextField.STYLE_HHmmss:
	    df = new SimpleDateFormat("HHmmss");
	    break;
	    
	 case TimeTextField.STYLE_HHmm:
	    df = new SimpleDateFormat("HHmm");
	    break;
      }
      
      df.setLenient(false); 
      
      try {	 
	 Date myDate = df.parse(component.getText(), myParsePosition);
      }
      catch(Throwable e) {
	 return false;
      }

      return true;        

   }
}
