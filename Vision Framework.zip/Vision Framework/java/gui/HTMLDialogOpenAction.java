/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      HTMLDialogOpenAction.java                                   */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 May 07 at 10:48:38 GMT+00:00                       */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Component;
import java.awt.Container;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       HTMLDialogOpenAction                                        */
/**
 * This is an implementation of ChildWindowAction that handles dialog
 * windows.
 */
/*======================================================================*/
public  class  HTMLDialogOpenAction  extends  HTMLChildWindowAction
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin HTMLDialogOpenAction:Attributes preserve=yes

//##End   HTMLDialogOpenAction:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  HTMLDialogOpenAction                                 */
        /*                                                              */
        /**
         * Constructor that takes the Frame of the dialog, view class name,
         * model, title of the dialog, modal flag, and the button panel
         * that goes in the dialog.
         * <p>
         * A user can specify the action panel style. If a predefined style
         * is used (ACTIONPANEL_STYLE_OKCANCEL), a user can rename the text
         * on the buttons and hook the onOk or onCancel  actions.
         *  
         * @param       relativeComponent:Component
         * @param       title:String
         * @param       modal:boolean
         * @param       formClassName:String
         * @param       actionContainer:Container
         * @param       style:String
         */
        /*==============================================================*/
   public    HTMLDialogOpenAction (
                               Component  relativeComponent,
                               String     title,
                               boolean    modal,
                               String     formClassName,
                               Container  actionContainer,
                               String     style
                              )
   {
//##Begin HTMLDialogOpenAction:HTMLDialogOpenAction(Component,String,boolean,String,Container,String) preserve=yes
      setChildType(CHILD_TYPE_DIALOG);
      setRelativeComponent(relativeComponent);
      setTitle(title);
      setModal(modal);
      setFormClassName(formClassName);      
      setStyle(style);      
      setActionContainer(actionContainer);      
      setDefaultOKAction(HTMLDialogOpenAction.OK_ACTION_STORE | HTMLDialogOpenAction.OK_ACTION_DESTROY);
//##End   HTMLDialogOpenAction:HTMLDialogOpenAction(Component,String,boolean,String,Container,String)
   }

        /*==============================================================*/
        /* OPERATION:  HTMLDialogOpenAction                                 */
        /*                                                              */
        /**
         * No arg constructor. This sets up the action with the modal flag
         * set to true.
         *  
         */
        /*==============================================================*/
   public    HTMLDialogOpenAction (
                              )
   {
//##Begin HTMLDialogOpenAction:HTMLDialogOpenAction() preserve=yes
      this(null, null, true, null, null,null);
//##End   HTMLDialogOpenAction:HTMLDialogOpenAction()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the HTMLDialogOpenAction class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin HTMLDialogOpenAction:main(String[]) preserve=yes
      HTMLDialogOpenAction myAction = new HTMLDialogOpenAction();
//##End   HTMLDialogOpenAction:main(String[])
   }


}
