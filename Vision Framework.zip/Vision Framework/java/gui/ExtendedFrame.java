/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedFrame.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 January 25 at 15:42:19 CST                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Frame;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.JToolBar;

import COM.novusnet.vision.java.utility.ApplicationConfigHelper;
import COM.novusnet.vision.java.utility.typeconversion.Convert;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedFrame                                           */
/**
 * A regular JFrame creates a RootPane. This class creates an extened root
 * pane for toolbar and status bar support.
 */
/*======================================================================*/
public  class  ExtendedFrame  extends  JFrame
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedFrame:Attributes preserve=yes
Thread minimizeThread = null;
//##End   ExtendedFrame:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ExtendedFrame                                    */
        /*                                                              */
        /**
         * Constructs a new Frame that is initially invisible.
         *
         */
        /*==============================================================*/
   public    ExtendedFrame (
                           )
   {
//##Begin ExtendedFrame:ExtendedFrame() preserve=yes
      this(null);
//##End   ExtendedFrame:ExtendedFrame()
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedFrame                                    */
        /*                                                              */
        /**
         * Constructs a new, initially invisible Frame with the specified
         * title.
         *
         * @param       title:String
         */
        /*==============================================================*/
   public    ExtendedFrame (
                            String  title
                           )
   {
//##Begin ExtendedFrame:ExtendedFrame(String) preserve=yes
      super(title);
//##End   ExtendedFrame:ExtendedFrame(String)
   }

        /*==============================================================*/
        /* OPERATION:  setToolBar                                       */
        /*                                                              */
        /**
         * Sets the mainRootpane's tool bar.
         *
         * @param       aToolbar:JToolBar
         */
        /*==============================================================*/
   public  void  setToolBar (
                             JToolBar  aToolbar
                            )
   {
//##Begin ExtendedFrame:setToolBar(JToolBar) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setToolBar(aToolbar);
//##End   ExtendedFrame:setToolBar(JToolBar)
   }

        /*==============================================================*/
        /* OPERATION:  getToolBar                                       */
        /*                                                              */
        /**
         * Returns the tool bar associated with the root pane.
         *
         * @return      :JToolBar -
         */
        /*==============================================================*/
   public  JToolBar  getToolBar (
                                )
   {
//##Begin ExtendedFrame:getToolBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getToolBar();
//##End   ExtendedFrame:getToolBar()
   }

        /*==============================================================*/
        /* OPERATION:  setStatusBar                                     */
        /*                                                              */
        /**
         * Sets the mainRootpane's status bar.
         *
         * @param       aStatusBar:JComponent
         */
        /*==============================================================*/
   public  void  setStatusBar (
                               JComponent  aStatusBar
                              )
   {
//##Begin ExtendedFrame:setStatusBar(JComponent) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setStatusBar(aStatusBar);
//##End   ExtendedFrame:setStatusBar(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * Returns the statusl bar associated with the root pane.
         *
         * @return      :JComponent -
         */
        /*==============================================================*/
   public  JComponent  getStatusBar (
                                    )
   {
//##Begin ExtendedFrame:getStatusBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getStatusBar();
//##End   ExtendedFrame:getStatusBar()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createRootPane                                   */
        /*                                                              */
        /**
         * Create the ExtendedRootPane class.
         *
         * @return      :JRootPane -
         */
        /*==============================================================*/
   protected  JRootPane  createRootPane (
                                        )
   {
//##Begin ExtendedFrame:createRootPane() preserve=yes
      return new ExtendedRootPane();
//##End   ExtendedFrame:createRootPane()
   }

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setVisible                                       */
        /*                                                              */
        /**
         *
         * @param     state:boolean -
         */
        /*==============================================================*/
   public  void  setVisible (
                                  boolean state
                            )
   {
//##Begin ExtendedFrame:setVisible() preserve=yes
      super.setVisible(state);
      /// This is temp fix for memory leak
      //  which persists till parent JFrame window is minimized.
      //  this bug is confirmed in JDK 1.3.1, hopefully will be fixed in JDK 1.4
      //  To turn this feature on supply the following  -DminimizeDelay=<<number of minutes befor next minimize>>
      //  in the command line, or pass minimizeDelay=<<number of minutes befor next minimize>>
      //  to the properies file which is loaded by ApplicationConfigHelper.java
      //  For example for Orion cms:
      //  ORIONcms.properties

      if(minimizeThread != null)
         return;

       minimizeThread = new Thread( new Runnable(){
	  public void run(){

              String minimizeDelay = ApplicationConfigHelper.instance().getProperty("minimizeDelay");
              System.out.println("Minimize Delay = " + minimizeDelay);
              long minimizeSleepTime = 0;
              if(minimizeDelay == null)
                  return;
              try{
                  minimizeSleepTime = Convert.intoInt(minimizeDelay) * 60000;
                  System.out.println("!!!Minimize Delay = " + minimizeSleepTime);
              } catch (Throwable t) {
                  t.printStackTrace();
                  return;
              }

              while(true)
              {
                 try{
                     Thread.sleep(minimizeSleepTime);

                 } catch (InterruptedException ie) {
                     // No logging
                 }
                 if(ExtendedFrame.this.getState() == Frame.NORMAL && ExtendedFrame.this.isVisible())
                 {
                    ExtendedFrame.this.setState(Frame.ICONIFIED);
 /*                   try{
                        Thread.currentThread().sleep(1);

                    } catch (InterruptedException ie) {
                     // No logging
                    }*/
                    ExtendedFrame.this.setState(Frame.NORMAL);
                 }

              }
       	  }
      });
      minimizeThread.start();


//##End   ExtendedFrame:setVisible()
   }

}
