package COM.novusnet.vision.java.gui;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.FocusEvent;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 *
 * The ExtendedTextField provides missing functionality in the regular JTextField.
 * For example, when the editable property is false, the regular JTextField allows
 * tabbing to itself while this class does not. In addition, the nice colors
 * from the metal look and feel when a text field is non editable are provided for
 * all look and feels.
 *
 * <p>Indicators can be triggered if the contents of the field are invalid. The following
 * options are provided if the component becomes invalid:
 *
 * <p>- Beep
 * <p>- Change color
 * <p>- Reset default value.
 *
 * <p>These flags can be Or'ed together to achieve all effects. The default to 
 * beep and change colors.
 *
 * <h3> Validation </h3>
 *
 * <p>Whenever a value is set of focus is lost, the installed validators are called.
 * The default validator checks if the field is marked as required and sets the
 * state to valid/invalid if the field has data. By default all fields are marked
 * as optional. Please note that if a field is marked as autoTrim, then the
 * text is trimmed before is length is checked. Please check the documentation
 * of subclasses and their associated validator classes.
 *
 * <p>Validators are called whenever the updateValidState method is invoked. This method
 * is typically invoked when the focus is lost. The updateValidState iterates over the
 * installed validaters and calls isValid() on them. If any of the validators return 
 * a false, the component is marked as invalied. The focusLost method typically
 * checks the result of updateValidState and beep or changes colors in the case of
 * invalidity. 
 *
 * <p> This class checks validity on focus lost or whenever the setText method is called. In the
 * case of the setText method, the contents are only validated if the text does not equal the default
 * value (empty string by default). This allows a developer to initialze the field to some known value
 * even if the value is invalid. For example, a required field can be initialized
 * to the empty string (Or whatever string set as default) without the user getting any beeps of errors. When
 * the user tabs off the field indicating the end of data entry, validation takes place. Please note that
 * calling isValid() will return the proper valid state in any case.
 * 
 * <p> A developer should always check the validity of the fields before saving a form. A user 
 * can press the save button without event going to the text field.
 */

public class  ExtendedTextField extends JTextField
{
   private   Color           invalidBackground = Color.red;
   private   Color           invalidForeground = Color.white;
   private   Color           defaultBackground = getBackground();
   private   Color           defaultForeground = getForeground();
   protected Object          defaultValue;
   private   int             invalidAction     = 0;
   protected boolean         valid             = true;
   private   boolean         required;
   private   boolean         autoTrim;
   private   Vector          validators        = new Vector();
   private   boolean         beepOnError       = true;
   
   /**
    * If invalid, a beep is emitted.
    */
   public final static int INVALID_BEEP = 1;

   /**
    * If invalid, the colors are changed
    */
   public final static int INVALID_CHANGE_COLOR = 2;

   /**
    * If invalid, the default value is reset. The default value by default
    * is 0
    */
   public final static int INVALID_RESET_DEFAULT = 4;

   /**
    * Handy constructor that takes the number of columns.
    */
   public ExtendedTextField(int columns)
   {
      super(columns);
      setInvalidAction(ExtendedTextField.INVALID_BEEP | 
		       ExtendedTextField.INVALID_CHANGE_COLOR);
      enableEvents(AWTEvent.FOCUS_EVENT_MASK);
      addValidator(new DefaultValidator());
      setRequired(false);
      setDefaultValue("");

      // Uncomment for JDK 1.2
      //enableInputMethods(false);
   }

   /**
    * Default constructor
    */
   public ExtendedTextField()
   {
      this(0);
   }

   /**
    * Add a validator to the list of current validators.
    */
   public void addValidator(Validator validator)
   {
      validators.addElement(validator);
   }

   /**
    * Remove a validator from the list of current validators.
    */
   public void removeValidator(Validator validator)
   {
      validators.removeElement(validator);
   }

  /**
    * Clears the list of validators.
    */
   public void clearValidators()
   {
      validators.removeAllElements();
   }

   /**
    * Override to include the editable property
    */
   public boolean isFocusTraversable()
   {
//       return (isEditable() && isEnabled());
      // changed May 2 2000.  Even if a field is not editable users (for Accessibility) 
      // may need to be able to tab into enabled fields.
      return (isEnabled());
   }

   /**
    * Override to provide better color schemes when editing is off
    */
   public void setEditable(boolean editable)
   {
      super.setEditable(editable);

      Color foreground;
      Color background;

      foreground = (Color)UIManager.get("TextField.foreground");

      if (!editable) {
	 background = (Color)UIManager.get("ComboBox.disabledBackground");
      }
      else {
	 background = (Color)UIManager.get("TextField.background");
      }

      // The only look and feel that changes the colors
      // properly, is the metal look and feel. However, MLF is
      // broken in 1.0.1 as far as color changes. So we change it anyway.

      super.setForeground(foreground);
      super.setBackground(background);
   }   

   /**
    * Override to maintain proper default colors.
    */
   public void setBackground(Color c)
   {
      super.setBackground(c);
      defaultBackground = c;
   }

   /**
    * Override to maintain proper default colors.
    */
   public void setForeground(Color c)
   {
      super.setForeground(c);
      defaultForeground = c;
   }

   /**
    * Sets the color of the background when the component becomes invalid
    * @param color The new background color.
    * @see #setInvalidAction
    * @see #setInvalidBackground
    */
   public void setInvalidBackground(Color background)
   {
      invalidBackground = background;
   }

   /**
    * Returns the color of the background when the component becomes invalid
    * @return  The background color.
    * @see #setInvalidAction
    */
   public Color getInvalidBackground()
   {
      return invalidBackground;
   }

   /**
    * Sets the color of the foreground when the component becomes invalid
    * @param color The new foreground color.
    * @see #setInvalidAction
    */
   public void setInvalidForeground(Color foreground)
   {
      invalidForeground = foreground;
   }

   /**
    * Returns the color of the foreground when the component becomes invalid
    * @return  The foreground color.
    * @see #setInvalidAction
    */
   public Color getInvalidForeground()
   {
      return invalidForeground;
   }

   /**
    * Sets the action to take if the component is invalid.
    */
   public void setInvalidAction(int action)
   {
      invalidAction = action;
   }

   /**
    * Returns the invalid action property
    */
   public int getInvalidAction()
   {
      return invalidAction;
   }

   /**
    * Sets the default value
    * @param Object  The default value
    * @see #getDefaultValue
    */
   public void setDefaultValue(Object defaultValue)
   {
      this.defaultValue = defaultValue;
   }

   /**
    * Returns the default value currently set.
    * @return  The default value.
    * @see #setDefaultValue
    */
   public Object getDefaultValue()
   {
      return defaultValue;
   }

   /**
    * Sets the required property
    * @param required  true if required, false otherwise
    * @see #isRequired
    */
   public void setRequired(boolean required)
   {
      this.required = required;

      if (required) {
      }
   }

   /**
    * Returns the required property.
    * @return  The required property
    * @see #setRequired
    */
   public boolean isRequired()
   {
      return required;
   }

   /**
    * Sets the autoTrim property
    * @param autoTrim  true if autoTrim, false otherwise
    * @see #isAutoTrim
    */
   public void setAutoTrim(boolean autoTrim)
   {
      this.autoTrim = autoTrim;
   }

   /**
    * Returns the autoTrim property.
    * @return  The autoTrim property
    * @see #setAutoTrim
    */
   public boolean isAutoTrim()
   {
      return autoTrim;
   }

   /**
    * Returns the state of this component as far as validity is concerned.
    * @return true if valid , false otherwise.
    */
   public boolean hasValidData()
   {
      return valid;
   }

   /**
    * This method is used by subclassers whenever a new value is set on a component.
    * It checks the actions to take if the component has invalid data. If invalid,
    * a beep can be emitted, color changed or the default value restored.
    */
   protected void checkValid()
   {
      if (hasValidData()) {
	 if ( (invalidAction & INVALID_CHANGE_COLOR) > 0) {
	    super.setForeground(defaultForeground);
	    // non-editable fields should have a "disabled background" rather than the default
	    super.setBackground(isEditable() ? defaultBackground : ((Color)UIManager.get("ComboBox.disabledBackground")));
	 }
      } 
      else {
	 if ( (invalidAction & INVALID_CHANGE_COLOR) > 0) {
	    super.setForeground(invalidForeground);
	    super.setBackground(invalidBackground);
	 }

	 if ( (invalidAction & INVALID_BEEP) > 0) {
	    Toolkit.getDefaultToolkit().beep();
	 }

	 if ( (invalidAction & INVALID_RESET_DEFAULT) > 0) {
	    restoreDefaultValue(getDefaultValue());
	 }
      }
      repaint();
   }

   /**
    * This method is intended for use by subclassers. It is called whenever checkValid
    * is called and the component has no valid data and RESET option is set.
    */
   public void restoreDefaultValue(Object value)
   {
      if (value != null) {
	 setText(value.toString());
      }
   }

   /**
    * Override to allow subclasses to commit values.
    * @param e FocusEvent
    */
   protected void processFocusEvent(FocusEvent e)
   {
      // BUGID 4193026
      if (getUI() == null) {
	 return;
      }

      if (e.getID() == FocusEvent.FOCUS_GAINED) {	
	 super.processFocusEvent(e);
	 processFocusGained();
      }
      else {
	 processFocusLost();  // Force a data commit and then call listeners.
	 super.processFocusEvent(e);
      }
   }

   /**
    * Provided for subclassers to properly restore default colors.
    */
   protected void restoreDefaultColors()
   {
      super.setForeground(defaultForeground);
      // non-editable fields should have a "disabled background" rather than the default
      super.setBackground(isEditable() ? defaultBackground : ((Color)UIManager.get("ComboBox.disabledBackground")));
      repaint();
   }

   /**
    * Override to handle focus changes. The default behavior simply restores
    * default colors.
    */
   protected void processFocusGained()
   {
      restoreDefaultColors();
   }

   /**
    * Override to handle focus changes. If the component has invalid data, a beep, color
    * or a reset of value occurs depending on the action set.
    *
    * @see #setInvalidAction
    *
    */
   protected void processFocusLost()
   {
      updateValidState();
      checkValid();
   }

   /**
    * This method is called whenever focus is lost. Subclassers should update the valid state
    * of the component. This method checks the required attribute.
    *
    * @see #processFocusLost
    *
    */
   protected void updateValidState()
   {
      Enumeration enum = validators.elements();

      while(enum.hasMoreElements()) {
	 Validator myValidator = (Validator)enum.nextElement();
	 if (!myValidator.isValid(this)) {
	    valid = false;
	    return;
	 }
      }

      valid = true;
   }

   public void signalError()
   {
      if (isBeepOnError()) {
	 Toolkit.getDefaultToolkit().beep();
      }
   }

   /**
    * The beepOnError property. The default is true.
    *
    * @return true if a beep sounds if the user pressed an invalid key.
    */
   public boolean isBeepOnError()
   {
      return beepOnError;
   }

   /**
    * Sets the beepOnError property. 
    *
    * @param beepOnError . If true, a beep will sound on errorneous input. 
    *
    * @see #setBeepOnError
    */
   public void setBeepOnError(boolean beepOnError)
   {
      this.beepOnError = beepOnError;
   }

   /**
    * Override getText() to trim the text before returning. This is done if autoTrim is set.
    *
    * @see #autoTrim
    *
    */
   public String getText()
   {
      String text;

      if (isAutoTrim()) {
	 text = super.getText().trim();
      }
      else {
	 text = super.getText();
      }

      return text;
   }

   /**
    * Override setText() to trim the text before setting. This is done if autoTrim is set.
    * If the new text is not the same as the default value, then validation takes place. This
    * method applies this check only if the class is ExtendedTextField. This is because subclasses
    * use this setText method and may depend on the default value being of different class that String.
    * 
    * @see #autoTrim
    *
    */
   public void setText(String text)
   {
      if (isAutoTrim()) {
	 text = text.trim();
      }

      super.setText(text);
      
      if ( (getClass() == ExtendedTextField.class) && 
	   (defaultValue != null) && 
	   (defaultValue instanceof String) && 
	   (!text.equals((String)getDefaultValue()))) {
	      updateValidState();
	      checkValid();
      }
   }
}
