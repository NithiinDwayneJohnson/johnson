/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedDialog.java                                     */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 April 17 at 15:10:39 CDT                           */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
import javax.swing.*;
import java.awt.event.*;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedDialog                                          */
/**
 * An enhanced version of JDialog that provides for default controller
 * behavior.
 */
/*======================================================================*/
public  class  ExtendedDialog  extends  JDialog
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedDialog:Attributes preserve=yes
   /**
    * An m to m Hastable keyed on Frame. Each value is a vector of
    * dialogs. This is used to keep track of owned dialogs per frame
    * for focus checks. Remove when Swing has a true getFocusComponent().
    */
   public static Hashtable framesToDialogsHashtable = new Hashtable();
//##End   ExtendedDialog:Attributes

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   private static Frame rootFrame;
   private boolean closeAllowed = true;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ExtendedDialog                                   */
        /*                                                              */
        /**
         * Creates a dialog whose parent is frame.
         *  
         * @param       parent:Frame
         */
        /*==============================================================*/
   public    ExtendedDialog (
                             Frame  parent
                            )
   {
//##Begin ExtendedDialog:ExtendedDialog(Frame) preserve=yes
      this(parent, false);
//##End   ExtendedDialog:ExtendedDialog(Frame)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedDialog                                   */
        /*                                                              */
        /**
         * Creates a dialog whose parent is frame and modal as set in the
         * modal parameter.
         *  
         * @param       parent:Frame
         * @param       modal:boolean
         */
        /*==============================================================*/
   public    ExtendedDialog (
                             Frame    parent,
                             boolean  modal
                            )
   {
//##Begin ExtendedDialog:ExtendedDialog(Frame,boolean) preserve=yes
      this(parent , null, modal);
//##End   ExtendedDialog:ExtendedDialog(Frame,boolean)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedDialog                                   */
        /*                                                              */
        /**
         * Creates a dialog whose parent is frame and with a title as set
         * in the title parameter.
         *  
         * @param       parent:Frame
         * @param       title:String
         */
        /*==============================================================*/
   public    ExtendedDialog (
                             Frame   parent,
                             String  title
                            )
   {
//##Begin ExtendedDialog:ExtendedDialog(Frame,String) preserve=yes
      this(parent , title , false);
//##End   ExtendedDialog:ExtendedDialog(Frame,String)
   }

        /*==============================================================*/
        /* OPERATION:  ExtendedDialog                                   */
        /*                                                              */
        /**
         * Creates a dialog whose parent is frame and with a title as set
         * in the title parameter. A user also specifies modality.
         *  
         * @param       parent:Frame
         * @param       title:String
         * @param       modal:boolean
         */
        /*==============================================================*/
   public    ExtendedDialog (
                             Frame    parent,
                             String   title,
                             boolean  modal
                            )
   {
//##Begin ExtendedDialog:ExtendedDialog(Frame,String,boolean) preserve=yes
      this (parent, title, modal, true);
//##End   ExtendedDialog:ExtendedDialog(Frame,String,boolean)
   }
        /*==============================================================*/
        /* OPERATION:  ExtendedDialog                                   */
        /*                                                              */
        /**
         * Creates a dialog whose parent is frame and with a title as set
         * in the title parameter. A user also specifies modality and if
	 * the default behavior to handle closing of the window is allowed.
         *  
         * @param       parent:Frame
         * @param       title:String
         * @param       modal:boolean
	 * @param       allow:boolean
         */
        /*==============================================================*/

   public    ExtendedDialog (
                             Frame    parent,
                             String   title,
                             boolean  modal,
			     boolean  allow
                            )
   {
//##Begin ExtendedDialog:ExtendedDialog(Frame,String,boolean) preserve=yes
      super(parent , title , modal);
      closeAllowed = allow;
      Vector dialogsForFrameTable = (Vector)framesToDialogsHashtable.get(parent);
      if (dialogsForFrameTable == null) {
	 dialogsForFrameTable = new Vector();
	 framesToDialogsHashtable.put(parent, dialogsForFrameTable);
      }
      dialogsForFrameTable.addElement(this);
//##End   ExtendedDialog:ExtendedDialog(Frame,String,boolean)
   }

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getRootFrame                                     */
        /*                                                              */
        /**
         * This method returns the value of the root frame for all dialogs.
         * This is used in case the user does not supply a frame.
         *  
         * @return      :Frame -
         *                 The value of the root frame for all dialogs.
         *                 This is used in case the user does not supply a
         *                 frame.
         */
        /*==============================================================*/
   public static  Frame  getRootFrame (
                                      )
   {
//##Begin ExtendedDialog:getRootFrame() preserve=no

      return (rootFrame);

//##End   ExtendedDialog:getRootFrame()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setRootFrame                                     */
        /*                                                              */
        /**
         * This method sets the value of the root frame for all dialogs.
         * This is used in case the user does not supply a frame.
         *  
         * @param       aValue:Frame
         *                 The value of the root frame for all dialogs.
         *                 This is used in case the user does not supply a
         *                 frame.
         */
        /*==============================================================*/
   public static  void  setRootFrame (
                                      Frame  aValue
                                     )
   {
//##Begin ExtendedDialog:setRootFrame(Frame) preserve=no

      rootFrame = aValue;

//##End   ExtendedDialog:setRootFrame(Frame)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setMenuBar                                       */
        /*                                                              */
        /**
         * Sets the mainRootpane's menu bar.
         *  
         * @param       aMenu:JMenuBar
         */
        /*==============================================================*/
   public  void  setMenuBar (
                             JMenuBar  aMenu
                            )
   {
//##Begin ExtendedDialog:setMenuBar(JMenuBar) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setJMenuBar(aMenu);
//##End   ExtendedDialog:setMenuBar(JMenuBar)
   }

        /*==============================================================*/
        /* OPERATION:  getMenuBar                                       */
        /*                                                              */
        /**
         * Returns the menu bar associated with the root pane.
         *  
         * @return      :JMenuBar -
         */
        /*==============================================================*/
   public  JMenuBar  getMenuBar (
                                )
   {
//##Begin ExtendedDialog:getMenuBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getJMenuBar();
//##End   ExtendedDialog:getMenuBar()
   }

        /*==============================================================*/
        /* OPERATION:  setToolBar                                       */
        /*                                                              */
        /**
         * Sets the mainRootpane's tool bar.
         *  
         * @param       aToolbar:JToolBar
         */
        /*==============================================================*/
   public  void  setToolBar (
                             JToolBar  aToolbar
                            )
   {
//##Begin ExtendedDialog:setToolBar(JToolBar) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setToolBar(aToolbar);
//##End   ExtendedDialog:setToolBar(JToolBar)
   }

        /*==============================================================*/
        /* OPERATION:  getToolBar                                       */
        /*                                                              */
        /**
         * Returns the tool bar associated with the root pane.
         *  
         * @return      :JToolBar -
         */
        /*==============================================================*/
   public  JToolBar  getToolBar (
                                )
   {
//##Begin ExtendedDialog:getToolBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getToolBar();
//##End   ExtendedDialog:getToolBar()
   }

        /*==============================================================*/
        /* OPERATION:  setStatusBar                                     */
        /*                                                              */
        /**
         * Sets the mainRootpane's status bar.
         *  
         * @param       aStatusBar:JComponent
         */
        /*==============================================================*/
   public  void  setStatusBar (
                               JComponent  aStatusBar
                              )
   {
//##Begin ExtendedDialog:setStatusBar(JComponent) preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      rootPane.setStatusBar(aStatusBar);
//##End   ExtendedDialog:setStatusBar(JComponent)
   }

        /*==============================================================*/
        /* OPERATION:  getStatusBar                                     */
        /*                                                              */
        /**
         * Returns the statusl bar associated with the root pane.
         *  
         * @return      :JComponent -
         */
        /*==============================================================*/
   public  JComponent  getStatusBar (
                                    )
   {
//##Begin ExtendedDialog:getStatusBar() preserve=yes
      ExtendedRootPane rootPane = (ExtendedRootPane)getRootPane();
      return rootPane.getStatusBar();
//##End   ExtendedDialog:getStatusBar()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  createRootPane                                   */
        /*                                                              */
        /**
         * Create the ExtendedRootPane class.
         *  
         * @return      :JRootPane -
         */
        /*==============================================================*/
   protected  JRootPane  createRootPane (
                                        )
   {
//##Begin ExtendedDialog:createRootPane() preserve=yes
      return new ExtendedRootPane();
//##End   ExtendedDialog:createRootPane()
   }

        /*==============================================================*/
        /* OPERATION:  processWindowEvent                               */
        /*                                                              */
        /**
         * @param       e:WindowEvent
         */
        /*==============================================================*/
   protected  void  processWindowEvent (
                                        WindowEvent  e
                                       )
   {
//##Begin ExtendedDialog:processWindowEvent(WindowEvent) preserve=yes
      if (closeAllowed)
	  super.processWindowEvent(e);
      if (e.getID() == WindowEvent.WINDOW_CLOSED) {
	 Vector dialogsForFrameTable = (Vector)framesToDialogsHashtable.get(getParent());
	 dialogsForFrameTable.removeElement(this);
	 disengageWorker(this);
	 getContentPane().removeAll();
      }   
//##End   ExtendedDialog:processWindowEvent(WindowEvent)
   }

        /*==============================================================*/
        /* OPERATION:  disengageWorker                                  */
        /*                                                              */
        /**
         * This method recurses into the chidren represented by a
         * controller and calls setUI(null) on them.
         *  
         * @param       aContainer:Container
         */
        /*==============================================================*/
   protected  void  disengageWorker (
                                     Container  aContainer
                                    )
   {
//##Begin ExtendedDialog:disengageWorker(Container) preserve=yes
      Component[]    myComponents = aContainer.getComponents();

      for (int i = 0 ; i < myComponents.length ; i++) {

	 if (myComponents[i] instanceof FormComponent) {
	    ((FormComponent)myComponents[i]).disengage();
 	    disengageWorker((Container)myComponents[i]);
	 }
 	 else if (myComponents[i] instanceof Container) {
 	    disengageWorker((Container)myComponents[i]);
 	 }
      }

      return;      
//##End   ExtendedDialog:disengageWorker(Container)
   }


}






