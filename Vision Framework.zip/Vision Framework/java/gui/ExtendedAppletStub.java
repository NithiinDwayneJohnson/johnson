/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ExtendedAppletStub.java                                 */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 0.5                          */
/* Emitter  :   JavaFileEmitter    Version 0.5                          */
/* Generated:   1997 November 16 at 07:48:34 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.applet.AudioClip;
import java.awt.Image;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ExtendedAppletStub                                      */
/**
 * This stub is associated with the ExtendedApplet class. Please refer to
 * AppletStub for more information.
 */
/*======================================================================*/
  class  ExtendedAppletStub  implements  AppletStub, AppletContext
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ExtendedAppletStub:Attributes preserve=yes

//##End   ExtendedAppletStub:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private URL documentBase;
   private URL codeBase;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setDocumentBase                                  */
        /*                                                              */
        /**
         * This method sets the value of the "documentBase" attribute.
         *  
         * @param       aValue:URL
         *                 The value of the "documentBase" attribute.
         */
        /*==============================================================*/
   public  void  setDocumentBase (
                                  URL  aValue
                                 )
   {
//##Begin ExtendedAppletStub:setDocumentBase(URL) preserve=no
      documentBase = aValue;
//##End   ExtendedAppletStub:setDocumentBase(URL)
   }

        /*==============================================================*/
        /* OPERATION:  setCodeBase                                      */
        /*                                                              */
        /**
         * This method sets the value of the "codeBase" attribute.
         *  
         * @param       aValue:URL
         *                 The value of the "codeBase" attribute.
         */
        /*==============================================================*/
   public  void  setCodeBase (
                              URL  aValue
                             )
   {
//##Begin ExtendedAppletStub:setCodeBase(URL) preserve=no
      codeBase = aValue;
//##End   ExtendedAppletStub:setCodeBase(URL)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin ExtendedAppletStub:printOut() preserve=no

      try {
         System.out.println ("ExtendedAppletStub:");
         System.out.println ("   documentBase: " + getDocumentBase ());
         System.out.println ("   codeBase: " + getCodeBase ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   ExtendedAppletStub:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isActive                                         */
        /*                                                              */
        /**
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isActive (
                             )
   {
//##Begin ExtendedAppletStub:isActive() preserve=yes
      return true;
//##End   ExtendedAppletStub:isActive()
   }

        /*==============================================================*/
        /* OPERATION:  appletResize                                     */
        /*                                                              */
        /**
         * @param       width:int
         * @param       height:int
         */
        /*==============================================================*/
   public  void  appletResize (
                               int  width,
                               int  height
                              )
   {
//##Begin ExtendedAppletStub:appletResize(int,int) preserve=yes

//##End   ExtendedAppletStub:appletResize(int,int)
   }

        /*==============================================================*/
        /* OPERATION:  getCodeBase                                      */
        /*                                                              */
        /**
         * @return      :URL -
         */
        /*==============================================================*/
   public  URL  getCodeBase (
                            )
   {
//##Begin ExtendedAppletStub:getCodeBase() preserve=yes
      if (codeBase == null) {
	 try {
	    codeBase = new URL("file:" +
			       System.getProperty("user.dir").replace(File.separatorChar, '/') + "/");
	 } 
	 catch (Exception e) {
	 }
      }
      return codeBase;

//##End   ExtendedAppletStub:getCodeBase()
   }

        /*==============================================================*/
        /* OPERATION:  showDocument                                     */
        /*                                                              */
        /**
         * @param       url:URL
         */
        /*==============================================================*/
   public  void  showDocument (
                               URL  url
                              )
   {
//##Begin ExtendedAppletStub:showDocument(URL) preserve=yes

//##End   ExtendedAppletStub:showDocument(URL)
   }

        /*==============================================================*/
        /* OPERATION:  getDocumentBase                                  */
        /*                                                              */
        /**
         * @return      :URL -
         */
        /*==============================================================*/
   public  URL  getDocumentBase (
                                )
   {
//##Begin ExtendedAppletStub:getDocumentBase() preserve=yes
      if (documentBase == null) {
	 try {
	    documentBase = new URL("file:" +
				   System.getProperty("user.dir").replace(File.separatorChar, '/') + "/");
	 }
	 catch (Exception e) {
	 }
      }
      return documentBase;

//##End   ExtendedAppletStub:getDocumentBase()
   }

        /*==============================================================*/
        /* OPERATION:  showStatus                                       */
        /*                                                              */
        /**
         * @param       status:String
         */
        /*==============================================================*/
   public  void  showStatus (
                             String  status
                            )
   {
//##Begin ExtendedAppletStub:showStatus(String) preserve=yes

//##End   ExtendedAppletStub:showStatus(String)
   }

        /*==============================================================*/
        /* OPERATION:  getApplets                                       */
        /*                                                              */
        /**
         * @return      :Enumeration -
         */
        /*==============================================================*/
   public  Enumeration  getApplets (
                                   )
   {
//##Begin ExtendedAppletStub:getApplets() preserve=yes
      java.util.Vector applets = new java.util.Vector();
      applets.addElement(awtApplet());
      return applets.elements();
//##End   ExtendedAppletStub:getApplets()
   }

        /*==============================================================*/
        /* OPERATION:  getImage                                         */
        /*                                                              */
        /**
         * @param       url:URL
         * @return      :Image -
         */
        /*==============================================================*/
   public  Image  getImage (
                            URL  url
                           )
   {
//##Begin ExtendedAppletStub:getImage(URL) preserve=yes
      return java.awt.Toolkit.getDefaultToolkit().getImage(url);
//##End   ExtendedAppletStub:getImage(URL)
   }

        /*==============================================================*/
        /* OPERATION:  showDocument                                     */
        /*                                                              */
        /**
         * @param       url:URL
         * @param       target:String
         */
        /*==============================================================*/
   public  void  showDocument (
                               URL     url,
                               String  target
                              )
   {
//##Begin ExtendedAppletStub:showDocument(URL,String) preserve=yes

//##End   ExtendedAppletStub:showDocument(URL,String)
   }

        /*==============================================================*/
        /* OPERATION:  getAppletContext                                 */
        /*                                                              */
        /**
         * @return      :AppletContext -
         */
        /*==============================================================*/
   public  AppletContext  getAppletContext (
                                           )
   {
//##Begin ExtendedAppletStub:getAppletContext() preserve=yes
      return this;
//##End   ExtendedAppletStub:getAppletContext()
   }

        /*==============================================================*/
        /* OPERATION:  getApplet                                        */
        /*                                                              */
        /**
         * @param       name:String
         * @return      :Applet -
         */
        /*==============================================================*/
   public  Applet  getApplet (
                              String  name
                             )
   {
//##Begin ExtendedAppletStub:getApplet(String) preserve=yes
      return null;
//##End   ExtendedAppletStub:getApplet(String)
   }

        /*==============================================================*/
        /* OPERATION:  getAudioClip                                     */
        /*                                                              */
        /**
         * @param       url:URL
         * @return      :AudioClip -
         */
        /*==============================================================*/
   public  AudioClip  getAudioClip (
                                    URL  url
                                   )
   {
//##Begin ExtendedAppletStub:getAudioClip(URL) preserve=yes
      return null;
//##End   ExtendedAppletStub:getAudioClip(URL)
   }

        /*==============================================================*/
        /* OPERATION:  getParameter                                     */
        /*                                                              */
        /**
         * @param       name:String
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getParameter (
                                 String  name
                                )
   {
//##Begin ExtendedAppletStub:getParameter(String) preserve=yes
      return null;
//##End   ExtendedAppletStub:getParameter(String)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  awtApplet                                        */
        /*                                                              */
        /**
         * @return      :Applet -
         */
        /*==============================================================*/
   private static  Applet  awtApplet (
                                     )
   {
//##Begin ExtendedAppletStub:awtApplet() preserve=yes
      Application app;

      // FIX this
      return null;
//       app = Application.getApplication();
      
//       return (app == null) ? null : app.getApplet();

//##End   ExtendedAppletStub:awtApplet()
   }
   /**
	* Required by J2SE1.4.2, added by HL for 2005.09 release	
	*/
   public InputStream getStream(String aString) {
		   return null;
   }
   /**
	* Required by J2SE1.4.2, added by HL for 2005.09 release	
	*/
   public Iterator getStreamKeys() {
		   return null;
   }   
   /**
	* Required by J2SE1.4.2, added by HL for 2005.09 release	
	*/
   public void setStream(String aString, InputStream anInputStream) {
   }
}
