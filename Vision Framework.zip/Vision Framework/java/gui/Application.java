/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Application.java                                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 October 14 at 08:16:22 CDT                         */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Frame;
import java.awt.Window;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;

import COM.novusnet.vision.java.utility.ApplicationConfigHelper;
import COM.novusnet.vision.java.utility.PropertyHelper;
import COM.novusnet.vision.java.utility.runtime.VisionRuntime;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Application                                             */
/**
 * The main application class encapsulates the initialization, running, and
 * termination of an application. An application built on the framework
 * must have one (and only one) object of a class derived from Application.
 * An Application instance maintains application-wide state and manages
 * access to
 * <p>
 * resources or objects that provide resources or services, such as
 * RootPanes.
 * <p>
 * A developer rarely creates an instance of this class directly. The only
 * exception is when the application is run from main in which case the
 * developers does instantiate an instance of this class.
 * <p>
 * As mentioned, every application has a root pane instance associated with
 * it. The root pane is the overall container for the application. A user
 * can attach a menubar, statusbar and  a toolbar to the root pane. In
 * addition, the root pane holds all the application child windows.
 * <p>
 * This class facilitates running an application as an applet or from main.
 * Developers do not need to handle those differences. If run as an
 * application, the Application instance creates a frame for the developer
 * in which he/she can set or add to the main root pane. If run as an
 * applet, the Extended applet class creates the application instance and
 * associates it with the applet. In either case, the developer need not
 * worry.
 */
/*======================================================================*/
public  class  Application
{
	
	
	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Attributes ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/
	
	/*==================================================================*/
	/* Custom Attributes                                                */
	/*==================================================================*/
	//##Begin Application:Attributes preserve=yes
	
	public static final String PROPERTY_FILE_EXTENTION = ".properties";
	public static final String PROPERTY_FILE_PREFIX    = "\\properties\\";
	public static final String XML_FILE_EXTENTION      = ".xml";
	
	private PropertyHelper propertyHelper       = null;
	protected String applicationRevisionName    = "";
	protected String propertiesFileNameSuffix   = "";
	
	boolean   createdApplet  = false;
	static Hashtable appletsToApp   = new Hashtable();
	Component currentFocusComponent = null;
	
	//##End   Application:Attributes
	
	/*==================================================================*/
	/* Private Attributes                                               */
	/*==================================================================*/
	private        ExtendedApplet applet;
	
	/*==================================================================*/
	/* Class Attributes                                                 */
	/*==================================================================*/
	private static Hashtable      groupToApplication = new Hashtable();
	
	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Operations ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/
	
	/*==================================================================*/
	/* Constructor Operations                                           */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  Application                                      */
	/*                                                              */
	/**
	 * Default constructor for an application class. This method does
	 * the following:
	 * <p>
	 * - If an applet has been started (Web browser), then this method
	 * simply does nothing.
	 * <p>
	 * - If an applet has not been started (run from main), an applet
	 * Frame and class are created and this instance is associated with
	 * them.
	 *
	 */
	/*==============================================================*/
	public    Application (
	)
	{
		//##Begin Application:Application() preserve=yes
		super();
		
		//==================================================================
		// We need to find out if an applet has been created for this
		// application.
		// Find the applet in the current thread group. This is safe
		// to do here since we know we are not in the AWT dispatch thread.
		//==================================================================
		setApplet(ExtendedApplet.getApplet());
		groupToApplication.put(Thread.currentThread().getThreadGroup(), this);
		
		if (getApplet() == null) {
			setApplet(createApplet());
			((ExtendedApplet)getApplet()).setApplication(this);
		} else {
			VisionRuntime.setApplet(getApplet());
		}
		
		//===============================================
		// Set the root frames for the option pane and
		// the extended dialogs.
		//===============================================
		ExtendedDialog.setRootFrame(getFrame());
		JOptionPane.setRootFrame(getFrame());
		
		if (createdApplet) {
			applet.init();
			applet.start();
		}
		
		appletsToApp.put(applet, this);
		//##End   Application:Application()
	}
	
	
	/*==================================================================*/
	/* Attribute Set Operations                                         */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  setApplet                                        */
	/*                                                              */
	/**
	 * This method sets the value of the "applet" attribute.
	 *
	 * @param       aValue:ExtendedApplet
	 *                 The value of the "applet" attribute.
	 */
	/*==============================================================*/
	public  void  setApplet (
			ExtendedApplet  aValue
	)
	{
		//##Begin Application:setApplet(ExtendedApplet) preserve=no
		
		applet = aValue;
		
		//##End   Application:setApplet(ExtendedApplet)
	}
	
	
	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  init                                             */
	/*                                                              */
	/**
	 * The is a place holder which subclasses can override to
	 * initialize their Application instance.
	 *
	 */
	/*==============================================================*/
	public  void  init (
	)
	{
		//##Begin Application:init() preserve=yes
		
		//==============================================================================
		//
		//
		//
		//==============================================================================
		
		String propertyFileRelativePath = "\\" + applicationRevisionName + propertiesFileNameSuffix + PROPERTY_FILE_EXTENTION;
		ApplicationConfigHelper.instance().load(propertyFileRelativePath);
		
		//##End   Application:init()
	}
	
	/*==============================================================*/
	/* OPERATION:  stop                                             */
	/*                                                              */
	/**
	 * This method is called by the browser when the applet should stop
	 * running.
	 *
	 */
	/*==============================================================*/
	public  void  stop (
	)
	{
		//##Begin Application:stop() preserve=yes
		
		//##End   Application:stop()
	}
	
	/*==============================================================*/
	/* OPERATION:  start                                            */
	/*                                                              */
	/**
	 * This method is called by the browser when the applet should
	 * start running.
	 *
	 */
	/*==============================================================*/
	public  void  start (
	)
	{
		//##Begin Application:start() preserve=yes
		getRootPane().invalidate();
		getApplet().invalidate();
		getApplet().validate();
		//##End   Application:start()
	}
	
	/*==============================================================*/
	/* OPERATION:  getFrame                                         */
	/*                                                              */
	/**
	 * Gets the frame associated with this application instance. This
	 * might actually return the browser window intself.
	 *
	 * @return      :Frame -
	 */
	/*==============================================================*/
	public  Frame  getFrame (
	)
	{
		//##Begin Application:getFrame() preserve=yes
		java.awt.Component comp;
		for (comp = applet;
		comp != null && !(comp instanceof java.awt.Frame);
		comp = comp.getParent());
		
		if (comp != null) {
			return (java.awt.Frame) comp;
		}
		else {
			return null;
		}
		
		//##End   Application:getFrame()
	}
	
	/*==============================================================*/
	/* OPERATION:  getApplet                                        */
	/*                                                              */
	/**
	 * Returns the applet associated with the application.
	 *
	 * @return      :Applet -
	 */
	/*==============================================================*/
	public  Applet  getApplet (
	)
	{
		//##Begin Application:getApplet() preserve=yes
		
		return (applet);
		
		//##End   Application:getApplet()
	}
	
	/*==============================================================*/
	/* OPERATION:  getAppletContext                                 */
	/*                                                              */
	/**
	 * Returns the application applet context.
	 *
	 * @return      :AppletContext -
	 */
	/*==============================================================*/
	public  AppletContext  getAppletContext (
	)
	{
		//##Begin Application:getAppletContext() preserve=yes
		return applet == null ? null : applet.getAppletContext();
		//##End   Application:getAppletContext()
	}
	
	/*==============================================================*/
	/* OPERATION:  getParameterNamed                                */
	/*                                                              */
	/**
	 * Returns the values for the parameter <b>name</b>.
	 *
	 * @param       name:String
	 * @return      :String -
	 */
	/*==============================================================*/
	public  String  getParameterNamed (
			String  name
	)
	{
		//##Begin Application:getParameterNamed(String) preserve=yes
		
		//========================================================================
		//  With adding PropertyHelper to Application we are allowing
		//  developers to utilize command line "-Dxyz" properties
		//  as well as "abc.properties" file which will contain application
		//  revision specific parameters(properties) in format "xyzproperty=abc".
		//  In order for properties file to be located its name should be stored in
		//  variable <b>applicationRevisionName</b> and <b>propertiesFileNameSuffix</b> .
		//  applicationRevisionName=="ORION" and propertiesFileNameSuffix="security" then
		//  the properties file should be located in the following path=C:\WINNT\Profiles\<RACF ID>\ORION\properties\
		//  The absolute path of properties file will be for example:
		//  C:\WINNT\Profiles\MPYATET\ORION\properties\orionsecurity.properties
		//========================================================================
		
		if (createdApplet) {
			
			return ApplicationConfigHelper.instance().getProperty(name);
		}
		else {
			return getApplet().getParameter(name);
		}
		
		//##End   Application:getParameterNamed(String)
	}
	
	/*==============================================================*/
	/* OPERATION:  getCodeBase                                      */
	/*                                                              */
	/**
	 * Returns the application codebase where the applet was launched
	 * from.
	 *
	 * @return      :URL -
	 */
	/*==============================================================*/
	public  URL  getCodeBase (
	)
	{
		//##Begin Application:getCodeBase() preserve=yes
		return getApplet().getCodeBase();
		//##End   Application:getCodeBase()
	}
	
	/*==============================================================*/
	/* OPERATION:  isApplet                                         */
	/*                                                              */
	/**
	 * This method returns true if the Application is running as an
	 * applet or running from main.
	 *
	 * @return      :boolean -
	 */
	/*==============================================================*/
	public  boolean  isApplet (
	)
	{
		//##Begin Application:isApplet() preserve=yes
		return (!createdApplet);
		//##End   Application:isApplet()
	}
	
	/*==============================================================*/
	/* OPERATION:  getContentPane                                   */
	/*                                                              */
	/**
	 * Returns the content pane. The developer usually adds his/her
	 * main application window in this slot.
	 *
	 * @return      :Container -
	 */
	/*==============================================================*/
	public  Container  getContentPane (
	)
	{
		//##Begin Application:getContentPane() preserve=yes
		return (((ExtendedApplet)getApplet()).getRootPane().getContentPane());
		//##End   Application:getContentPane()
	}
	
	/*==============================================================*/
	/* OPERATION:  getRootPane                                      */
	/*                                                              */
	/**
	 * Returns the applications root pane. A user can add a menu bar,
	 * toolbar or a status bar to the extended root pane.
	 *
	 * @return      :ExtendedRootPane -
	 */
	/*==============================================================*/
	public  ExtendedRootPane  getRootPane (
	)
	{
		//##Begin Application:getRootPane() preserve=yes
		return ((ExtendedRootPane)((ExtendedApplet)getApplet()).getRootPane());
		//##End   Application:getRootPane()
	}
	
	/*==============================================================*/
	/* OPERATION:  setBusyCursor                                    */
	/*                                                              */
	/**
	 * This method toggles the cursor between busy and non-busy states.
	 * The method looks for the first heavy wieght parent for the
	 * curent focus component and sets the cursor on that component.
	 *
	 * @param       state:boolean
	 */
	/*==============================================================*/
	public  void  setBusyCursor (
			boolean  state
	)
	{
		//##Begin Application:setBusyCursor(boolean) preserve=yes
		Frame     myFrame          = getFrame();
		Component myFocusComponent = SwingUtilities.findFocusOwner(myFrame);
		
		if (myFocusComponent == null) {
			Vector      childList = (Vector)ExtendedDialog.framesToDialogsHashtable.get(myFrame);
			if (childList != null) {
				Enumeration enum = childList.elements();
				while(enum.hasMoreElements()) {
					Window myWindow = (Window)enum.nextElement();
					myFocusComponent = SwingUtilities.findFocusOwner(myWindow);
					if (myFocusComponent != null) {
						break;
					}
				}
			}
		}
		
		Component myAncestor = null;
		
		//===================================================
		// The component with focus may have changed since
		// the cursor was last put into the "busy" state. If
		// this is the case, the cursor for the component
		// that previously had focus is set to the "default"
		// state before changing the cursor for the currently
		// focussed component into the specified state.
		//===================================================
		if (currentFocusComponent != null &&
				currentFocusComponent != myFocusComponent) {
			myAncestor = SwingUtilities.getAncestorOfClass(RootPaneContainer.class, currentFocusComponent);
			
			if (myAncestor != null) {
				myAncestor.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
		
		if (myFocusComponent == null) {
			myAncestor = getApplet();
		}
		else {
			currentFocusComponent = myFocusComponent;
			myAncestor = SwingUtilities.getAncestorOfClass(RootPaneContainer.class, myFocusComponent);
		}
		
		if (myAncestor != null) {
			if (state) {
				myAncestor.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			}
			else {
				myAncestor.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		}
		//##End   Application:setBusyCursor(boolean)
	}
	
	
	/*==================================================================*/
	/* Protected Operations                                             */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  createApplet                                     */
	/*                                                              */
	/**
	 * Creates and returns the Application's Applet. This method will
	 * only be called in a stand-alone application. Application
	 * subclasses can override this method to provide a custom subclass
	 * of ExtendedApplet. This Applet must have been
	 * <p>
	 * added to a java.awt.Frame and have an AppletStub.
	 *
	 * @return      :ExtendedApplet -
	 */
	/*==============================================================*/
	protected  ExtendedApplet  createApplet (
	)
	{
		//##Begin Application:createApplet() preserve=yes
		ExtendedFrame    aFrame   = new ExtendedFrame();
				
		//==================================================
		// Force the frame to be realized by toggling the
		// visible state. This way, the add notify of the
		// applet gets called the moment we add the applet
		// to the frame and before calling init.
		//==================================================
		//       aFrame.setVisible(true);
		//       aFrame.setVisible(false);
		
		ExtendedApplet   applet   = new ExtendedApplet();
		
		aFrame.getContentPane().add(applet);
		
		applet.setStub(new ExtendedAppletStub());
		createdApplet = true;
		//      aFrame.setBackground(Color.lightGray);
		return applet;
		//##End   Application:createApplet()
	}
	
	
	/*==================================================================*/
	/* Class Operations                                                 */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  getApplication                                   */
	/*                                                              */
	/**
	 * Gets the only application instance.
	 *
	 * @param       aComponent:Component
	 * @return      :Application -
	 */
	/*==============================================================*/
	public static  Application  getApplication (
			Component  aComponent
	)
	{
		//##Begin Application:getApplication(Component) preserve=yes
		
		Application app       = null;
		Object      myObject  = null;
		ThreadGroup group     = null;
		
		try {
			group = Thread.currentThread().getThreadGroup() ;
			app      = (Application)groupToApplication.get(group);
			if (app != null) {
				return app;
			}
		}
		catch(Throwable e) {
		}
		
		//======================================================================
		// If we are being called in the context of the AWT thread dispatcher,
		// then the above mapping does not work. Try frame to application mapping.
		//======================================================================
		if (app == null) {
			Frame myFrame;
			if (aComponent instanceof Frame) {
				myFrame = (Frame)aComponent;
			}
			else {
				myFrame = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, aComponent);
			}
			
			Component focusComponent = SwingUtilities.findFocusOwner(myFrame);
			Applet    myApplet       = (Applet)SwingUtilities.getAncestorOfClass(Applet.class, focusComponent);
			
			if (myApplet != null) {
				app = (Application)appletsToApp.get(myApplet);
			}
		}
		
		return app;
		//##End   Application:getApplication(Component)
	}
	
	static {
		// By default we close stdout
		if ( ! "true".equalsIgnoreCase(ApplicationConfigHelper.instance().getProperty("KEEPOPEN_STDOUT")) )
		{
		    System.out.println("Closing STDOUT");
		    System.out.close();
		}
		// By default we keep open stderr
		if ( "false".equalsIgnoreCase(ApplicationConfigHelper.instance().getProperty("KEEPOPEN_STDERR")) )
		{
			System.err.println("Closing STDUT");
			System.err.close();
		}
	}
	
}
