/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      InternalFrameOpenAction.java                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 May 07 at 10:48:37 GMT+00:00                       */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import javax.swing.Action;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       InternalFrameOpenAction                                 */
/**
 * This implementation handles internal frames.
 */
/*======================================================================*/
public  class  InternalFrameOpenAction  extends  ChildWindowAction
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin InternalFrameOpenAction:Attributes preserve=yes

//##End   InternalFrameOpenAction:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  InternalFrameOpenAction                          */
        /*                                                              */
        /**
         * Constructor that takes:
         * <p>
         * - Desktop pane.
         * <p>
         * - Form class name
         * <p>
         * - Title.
         *  
         * @param       desktopPane:JDesktopPane
         * @param       formClassName:String
         * @param       title:String
         * @param       resizable:boolean
         * @param       closable:boolean
         * @param       maximizable:boolean
         * @param       iconifiable:boolean
         */
        /*==============================================================*/
   public    InternalFrameOpenAction (
                                      JDesktopPane  desktopPane,
                                      String        formClassName,
                                      String        title,
                                      boolean       resizable,
                                      boolean       closable,
                                      boolean       maximizable,
                                      boolean       iconifiable
                                     )
   {
//##Begin InternalFrameOpenAction:InternalFrameOpenAction(JDesktopPane,String,String,boolean,boolean,boolean,boolean) preserve=yes
      setChildType(CHILD_TYPE_INTERNAL_FRAME);
      setFormClassName(formClassName);
      setRelativeComponent(desktopPane);
      setTitle(title);
      setIconifiable(iconifiable);
      setMaximizable(maximizable);
      setClosable(closable);    
      setModel(null);  
//##End   InternalFrameOpenAction:InternalFrameOpenAction(JDesktopPane,String,String,boolean,boolean,boolean,boolean)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the InternalFrameOpenAction class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin InternalFrameOpenAction:main(String[]) preserve=yes
      JFrame myFrame = new JFrame("Internal frames actions.");
      myFrame.setSize(800,600);

      JMenuBar  menuBar  = new JMenuBar();
      myFrame.getRootPane().setJMenuBar(menuBar);

      JMenu menu = new JMenu("Internal frames");
      menuBar.add(menu);

      JDesktopPane desktopPane = new JDesktopPane();
      myFrame.getContentPane().add(desktopPane);

      InternalFrameOpenAction myAction = new InternalFrameOpenAction(desktopPane, 
								     "javax.swing.JButton",
								     "Customer address",
								     true, true, true, true);

      InternalFrameOpenAction myAction2 = new InternalFrameOpenAction(desktopPane, 
								      "javax.swing.JButton",
								      "Customer address",
								      true, true, true, true);

      myAction.setInitialPosition(InternalFrameOpenAction.POSITION_SOUTHEAST);
      myAction2.setInitialPosition(InternalFrameOpenAction.POSITION_NORTHEAST);

      menu.add( myAction);
      menu.add( myAction2);
      myAction.putValue(Action.NAME, "Create");
      myAction2.putValue(Action.NAME, "Create-2");
      myFrame.setVisible(true);
//##End   InternalFrameOpenAction:main(String[])
   }


}
