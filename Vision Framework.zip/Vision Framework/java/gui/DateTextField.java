package COM.novusnet.vision.java.gui;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * This class represents a date entry field. Rather than have the user set
 * a mask for the date, this class allows the user to choose for a
 * predefined set. This set will be locale independent. Please use, the
 * getDate(), setDate() methods rather than setText() and getText().
 */
public  class  DateTextField  extends  FormattedTextField
{
   /**
    * This is the default style, in which the full date is
    * displayed. Please note that for a given locale, the
    * elements may shift around so the client should never
    * make an assumption about the order of the fields in this
    * component.
    */

   public static final int      STYLE_MMDDYYYY = 0;

   /**
    * This show only the month and the year portion of a date.
    */
   public static final int      STYLE_MMYYYY   = 1;

   /**
    * This shows only the year portion of a date.
    */
   public static final int      STYLE_YYYY     = 2;

   /**
    * This shows only the month and the year in two digits. This
    * may seem like a Y2K issue but it is because the exp date on
    * the cards is such.
    */
   public static final int      STYLE_MMYY     = 3;

   private             int      style          = STYLE_MMDDYYYY;
   private             Calendar date;

   /**
    * The default constructor.
    *  
    */   
   public DateTextField ()
   {
      setStyle(STYLE_MMDDYYYY);
      addValidator(new DateTextFieldValidator());
   }

   /**
    * This method returns the value of the style of the field.
    *  
    * @return      :int -
    *                 The value of the style of the field.
    */    
   public int getStyle ()
   {
      return (style);
   }

   /**
    * This method returns the value of the "date" attribute.
    *  
    * @return      :Calendar -
    *                 The value of the "date" attribute.
    */
   public  Calendar  getDate (
                             )
   {
      return date;
   }

   /**
    * This method sets the value of the style of the field.
    *  
    * @param  aValue The value of the style of the field.
    */   
   public  void  setStyle (int  aValue)
   {
      // Based on the style, create a mask text and set it as out mask   
      // The mask should be retrieved from the resource file. FIX        

      switch (aValue) {
	 case STYLE_MMDDYYYY:
	    setMask("00-00-0000");
	    break;

	 case STYLE_MMYYYY:
	    setMask("00-0000");
	    break;

	 case STYLE_YYYY:
	    setMask("0000");
	    break;

	 case STYLE_MMYY:
	    setMask("00-00");
	    break;
      }      

      style = aValue;
   }

   /**
    * This method sets the value of the "date" attribute.
    *  
    * @param       aValue:Calendar
    *                 The value of the "date" attribute.
    */   
   public  void  setDate (
                          Calendar  aValue
                         )
   {
      SimpleDateFormat df       = null;
      Calendar         oldValue = date;

      if (date == aValue) {
	 return;
      }

      if (date != null) {
	 if (date.equals(aValue)) {
	    return;
	 }
      }

      date = aValue;

      if (date != null) {
	 switch (style) {
	    case STYLE_MMDDYYYY:
	       df = new SimpleDateFormat("MMddyyyy");
	       break;
	       
	    case STYLE_MMYYYY:
	       df = new SimpleDateFormat("MMyyyy");
	       break;

	    case STYLE_YYYY:
	       df = new SimpleDateFormat("yyyy");
	       break;

	    case STYLE_MMYY:
	       df = new SimpleDateFormat("MMyy");
	       break;
	 }
	 setText(df.format(date.getTime()));
      }
      else {
	 setText("");
      }

      firePropertyChange("date", oldValue, date);
   }

   /**
    * This method sets the value of the "date" attribute in text format.
    *  
    * @param text The new date.
    *                 
    */   
   public  void  setDate (
                          String  text
                         )
   {
      SimpleDateFormat df              = null;
      ParsePosition    myParsePosition = new ParsePosition(0);

      switch (getStyle()) {
	 case DateTextField.STYLE_MMDDYYYY:
	    df = new SimpleDateFormat("MMddyyyy");
	    break;
	    
	 case DateTextField.STYLE_MMYYYY:
	    df = new SimpleDateFormat("MMyyyy");
	    break;

	 case DateTextField.STYLE_YYYY:
	    df = new SimpleDateFormat("yyyy");
	    break;

	 case DateTextField.STYLE_MMYY:
	    df = new SimpleDateFormat("MMyy");
	    break;
      }
      
      df.setLenient(false); 
      
      try {	 
	 Date myDate = df.parse(text, myParsePosition);
	 date = Calendar.getInstance();
	 date.setTime(myDate);
	 setDate(date);
      }
      catch(Throwable e) {
      }
   }

   /**
    * Override to handle focus changes. 
    *
    */
   protected void processFocusLost()
   {
      super.processFocusLost();
      if (hasValidData()) {
	 setDate(getText());
      }
   }
}



