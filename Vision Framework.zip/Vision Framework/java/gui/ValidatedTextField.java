package COM.novusnet.vision.java.gui;


public class ValidatedTextField  extends FormattedTextField
{
    /**
     * Constructs a new ValidatedTextField. It can have 256 columns.
     */
	public ValidatedTextField() {
	   super();
	}
}
