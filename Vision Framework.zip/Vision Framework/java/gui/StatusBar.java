/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      StatusBar.java                                          */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 March 30 at 09:56:39 GMT+00:00                     */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       StatusBar                                               */
/**
 * This class combines the funcionality of a progress bar and a text status
 * area. The Status bar class can be used in the status area of the the
 * ExtendedRootPane.
 */
/*======================================================================*/
public  class  StatusBar  extends  JPanel
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin StatusBar:Attributes preserve=yes

//##End   StatusBar:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private JLabel                          label;
   private JProgressBar                    progressBar;
   private static       java.util.Vector   listeners     = new Vector();
    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  StatusBar                                        */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   public    StatusBar (
                       )
   {
//##Begin StatusBar:StatusBar() preserve=yes
      GridBagConstraints constraints;

      progressBar = new JProgressBar();

      setLayout( new GridBagLayout());
      label = new JLabel();      

      constraints = new GridBagConstraints();
      constraints.gridx = 0; constraints.gridy = 0;
      constraints.gridwidth = 1; constraints.gridheight = 1;
      constraints.anchor = java.awt.GridBagConstraints.WEST;
      constraints.weightx = 0.0;
      constraints.weighty = 0.0;
      ((GridBagLayout)this.getLayout()).setConstraints(progressBar, constraints);
      add(progressBar);

      constraints = new GridBagConstraints();
      constraints.gridx = 1; constraints.gridy = 0;
      constraints.gridwidth = 1; constraints.gridheight = 1;
      constraints.anchor  = java.awt.GridBagConstraints.WEST;
      constraints.weightx = 1.0;
      constraints.weighty = 0.0;
      constraints.insets  = new java.awt.Insets(0, 10, 0, 0);
      constraints.fill    = java.awt.GridBagConstraints.HORIZONTAL;
      ((GridBagLayout)this.getLayout()).setConstraints(label, constraints);

      add(label);

      Font myFont = label.getFont();
      myFont = new Font(myFont.getFamily(), myFont.getStyle(), 10);
      label.setFont(myFont);
//      label.setForeground(Color.black);
      label.setForeground((Color)(UIManager.get("Label.foreground")));

      setBorder( new SoftBevelBorder(BevelBorder.RAISED) );
      label.setBorder( new SoftBevelBorder(BevelBorder.LOWERED) );
      progressBar.setBorder( new SoftBevelBorder(BevelBorder.LOWERED) );

      label.setText("W");
      setMinimumSize(getPreferredSize());
      label.setText("");
//##End   StatusBar:StatusBar()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getLabel                                         */
        /*                                                              */
        /**
         * This method returns the value of the "label" attribute.
         *  
         * @return      :JLabel -
         *                 The value of the "label" attribute.
         */
        /*==============================================================*/
   private  JLabel  getLabel (
                             )
   {
//##Begin StatusBar:getLabel() preserve=no

      return (label);

//##End   StatusBar:getLabel()
   }

        /*==============================================================*/
        /* OPERATION:  getProgressBar                                   */
        /*                                                              */
        /**
         * This method returns the value of the "progressBar" attribute.
         *  
         * @return      :JProgressBar -
         *                 The value of the "progressBar" attribute.
         */
        /*==============================================================*/
   private  JProgressBar  getProgressBar (
                                         )
   {
//##Begin StatusBar:getProgressBar() preserve=no

      return (progressBar);

//##End   StatusBar:getProgressBar()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setLabel                                         */
        /*                                                              */
        /**
         * This method sets the value of the "label" attribute.
         *  
         * @param       aValue:JLabel
         *                 The value of the "label" attribute.
         */
        /*==============================================================*/
   private  void  setLabel (
                            JLabel  aValue
                           )
   {
//##Begin StatusBar:setLabel(JLabel) preserve=no

      label = aValue;

//##End   StatusBar:setLabel(JLabel)
   }

        /*==============================================================*/
        /* OPERATION:  setProgressBar                                   */
        /*                                                              */
        /**
         * This method sets the value of the "progressBar" attribute.
         *  
         * @param       aValue:JProgressBar
         *                 The value of the "progressBar" attribute.
         */
        /*==============================================================*/
   private  void  setProgressBar (
                                  JProgressBar  aValue
                                 )
   {
//##Begin StatusBar:setProgressBar(JProgressBar) preserve=no

      progressBar = aValue;

//##End   StatusBar:setProgressBar(JProgressBar)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setText                                          */
        /*                                                              */
        /**
         * Sets the status bar text.
         *  
         * @param       text:String
         */
        /*==============================================================*/
   public  void  setText (
                          String  text
                         )
   {
//##Begin StatusBar:setText(String) preserve=yes
      label.setText(text);
      Dimension dim = label.getSize();
      label.paintImmediately(0, 0,dim.width , dim.height);
      
      ActionEvent ae = new ActionEvent(this, 1, text);
      fireEvent(ae);

//##End   StatusBar:setText(String)
   }

        /*==============================================================*/
        /* OPERATION:  setMinimum                                       */
        /*                                                              */
        /**
         * Sets the minimum of the progress bar.
         *  
         * @param       value:int
         */
        /*==============================================================*/
   public  void  setMinimum (
                             int  value
                            )
   {
//##Begin StatusBar:setMinimum(int) preserve=yes
      getProgressBar().setMinimum(value);
//##End   StatusBar:setMinimum(int)
   }

        /*==============================================================*/
        /* OPERATION:  setMaximum                                       */
        /*                                                              */
        /**
         * Sets the maximum of the progress bar.
         *  
         * @param       value:int
         */
        /*==============================================================*/
   public  void  setMaximum (
                             int  value
                            )
   {
//##Begin StatusBar:setMaximum(int) preserve=yes
      getProgressBar().setMaximum(value);
//##End   StatusBar:setMaximum(int)
   }

        /*==============================================================*/
        /* OPERATION:  setValue                                         */
        /*                                                              */
        /**
         * Sets the current progress value.
         *  
         * @param       value:int
         */
        /*==============================================================*/
   public  void  setValue (
                           int  value
                          )
   {
//##Begin StatusBar:setValue(int) preserve=yes
      getProgressBar().setValue(value);
      Dimension dim = getProgressBar().getSize();
      getProgressBar().paintImmediately(0, 0,dim.width , dim.height);
//##End   StatusBar:setValue(int)
   }

        /*==============================================================*/
        /* OPERATION:  getValue                                         */
        /*                                                              */
        /**
         * Returns the current value.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getValue (
                         )
   {
//##Begin StatusBar:getValue() preserve=yes
      return getProgressBar().getValue();
//##End   StatusBar:getValue()
   }

        /*==============================================================*/
        /* OPERATION:  addListener                                      */
        /*                                                              */
        /**
         * This method will add a action listener to the status bar object.
         *  
         * @param       l:java.awt.event.ActionListener
         */
        /*==============================================================*/
   public static  void  addListener (
                                     java.awt.event.ActionListener  l
                                    )
   {
//##Begin StatusBar:addListener(ActionListener) preserve=yes
      listeners.addElement(l);
//##End   StatusBar:addListener(ActionListener)
   }

        /*==============================================================*/
        /* OPERATION:  removeListener                                   */
        /*                                                              */
        /**
         * This method will remove an action listener from the status bar
         * object.
         *  
         * @param       l:java.awt.event.ActionListener
         */
        /*==============================================================*/
   public static  void  removeListener (
                                        java.awt.event.ActionListener  l
                                       )
   {
//##Begin StatusBar:removeListener(ActionListener) preserve=yes
      listeners.removeElement(l);
//##End   StatusBar:removeListener(ActionListener)
   }

        /*==============================================================*/
        /* OPERATION:  fireEvent                                        */
        /*                                                              */
        /**
         * This method will send an event object to all the action
         * listeners attached to the StatusBar object.
         *  
         * @param       ae:java.awt.event.ActionEvent
         */
        /*==============================================================*/
   protected static  void  fireEvent (
                                      java.awt.event.ActionEvent  ae
                                     )
   {
//##Begin StatusBar:fireEvent(ActionEvent) preserve=yes
      Vector listers = (Vector) listeners.clone();
      
      for (int i = 0; i < listers.size() ; i++) {    
	 ActionListener aListener = (ActionListener)listeners.elementAt(i);  
	 aListener.actionPerformed(ae);
      }
//##End   StatusBar:fireEvent(ActionEvent)
   }

}
