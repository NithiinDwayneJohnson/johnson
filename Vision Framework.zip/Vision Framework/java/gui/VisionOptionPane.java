package COM.novusnet.vision.java.gui;

import java.awt.Component;
import java.awt.Dimension;

import javax.accessibility.Accessible;
import javax.accessibility.AccessibleContext;
import javax.accessibility.AccessibleRole;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/*======================================================================*/
/* CLASS:       VisionOptionPane                                        */
/**
 *  A VisionOptionPane is nothing more than a JOptionPane but with 
 *  accessibility features added for our own use. A normal
 *  JOptionPane does not provide the accessible functionality so that 
 *  the text can be read. This is provided here. 
 */
/*======================================================================*/
public class VisionOptionPane extends JOptionPane implements Accessible
{

    /**
     * Brings up a modal information-message dialog titled "Message".
     *
     * @param parentComponent determines the <code>Frame</code> in
     *		which the dialog is displayed; if <code>null</code>,
     *		or if the <code>parentComponent</code> has no
     *		<code>Frame</code>, a default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     */
    public static void showMessageDialog(Component parentComponent, Object message) {
        showMessageDialog(parentComponent, message, "Message", INFORMATION_MESSAGE);
    }

    /**
     * Brings up a dialog that displays a message using a default
     * icon determined by the <code>messageType</code> parameter.
     *
     * @param parentComponent determines the <code>Frame</code>
     *		in which the dialog is displayed; if <code>null</code>,
     *		or if the <code>parentComponent</code> has no
     *		<code>Frame</code>, a default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     * @param title     the title string for the dialog
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     */
    public static void showMessageDialog(Component parentComponent, Object message,
                                         String title, int messageType) {
        showMessageDialog(parentComponent, message, title, messageType, null);
    }

    /**
     * Brings up a dialog displaying a message, specifying all parameters.
     *
     * @param parentComponent determines the <code>Frame</code> in which the
     *			dialog is displayed; if <code>null</code>,
     *			or if the <code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *                  default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     * @param title     the title string for the dialog
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param icon      an icon to display in the dialog that helps the user
     *                  identify the kind of message that is being displayed
     */
    public static void showMessageDialog(Component parentComponent, Object message,
                                         String title, int messageType,
                                         Icon icon){
        showOptionDialog(parentComponent, message, title, DEFAULT_OPTION, 
                         messageType, icon, null, null);
    }

    /**
     * Brings up a modal dialog with the options Yes, No and Cancel; with the
     * title, "Select an Option".
     *
     * @param parentComponent determines the <code>Frame</code> in which the
     *			dialog is displayed; if <code>null</code>,
     *			or if the <code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *                  default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     * @return an integer indicating the option selected by the user
     */
    public static int showConfirmDialog(Component parentComponent, Object message) {
        return showConfirmDialog(parentComponent, message, "Select an Option",
                                 YES_NO_CANCEL_OPTION);
    }

    /**
     * Brings up a modal dialog where the number of choices is determined
     * by the <code>optionType</code> parameter.
     * 
     * @param parentComponent determines the <code>Frame</code> in which the
     *			dialog is displayed; if <code>null</code>,
     *			or if the <code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *                  default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     * @param title     the title string for the dialog
     * @param optionType an int designating the options available on the dialog:
     *                   YES_NO_OPTION, or YES_NO_CANCEL_OPTION
     * @return an int indicating the option selected by the user
     */
    public static int showConfirmDialog(Component parentComponent, Object message,
                                        String title, int optionType) {
        return showConfirmDialog(parentComponent, message, title, optionType,
                                 QUESTION_MESSAGE);
    }

    /**
     * Brings up a modal dialog where the number of choices is determined
     * by the <code>optionType</code> parameter, where the
     * <code>messageType</code>
     * parameter determines the icon to display.
     * The <code>messageType</code> parameter is primarily used to supply
     * a default icon from the Look and Feel.
     *
     * @param parentComponent determines the <code>Frame</code> in
     *			which the dialog is displayed; if <code>null</code>,
     *			or if the <code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *                  default <code>Frame</code> is used.
     * @param message   the <code>Object</code> to display
     * @param title     the title string for the dialog
     * @param optionType an integer designating the options available
     *			on the dialog:
     *                  YES_NO_OPTION, or YES_NO_CANCEL_OPTION
     * @param messageType an integer designating the kind of message this is, 
     *                  primarily used to determine the icon from the
     *			pluggable
     *                  Look and Feel: ERROR_MESSAGE, INFORMATION_MESSAGE, 
     *                  WARNING_MESSAGE, QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @return an integer indicating the option selected by the user
     */
    public static int showConfirmDialog(Component parentComponent, Object message,
                                        String title, int optionType,
                                        int messageType) {
        return showConfirmDialog(parentComponent, message, title, optionType,
                                messageType, null);
    }

    /**
     * Brings up a modal dialog with a specified icon, where the number of 
     * choices is determined by the <code>optionType</code> parameter.
     * The <code>messageType</code> parameter is primarily used to supply
     * a default icon from the Look and Feel.
     *
     * @param parentComponent determines the <code>Frame</code> in which the
     *			dialog is displayed; if <code>null</code>,
     *			or if the <code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *			default <code>Frame</code> is used
     * @param message   The Object to display
     * @param title     the title string for the dialog
     * @param optionType an int designating the options available on the dialog:
     *                   YES_NO_OPTION, or YES_NO_CANCEL_OPTION
     * @param messageType an int designating the kind of message this is, 
     *                    primarily used to determine the icon from the pluggable
     *                    Look and Feel: ERROR_MESSAGE, INFORMATION_MESSAGE, 
     *                    WARNING_MESSAGE, QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param icon      the icon to display in the dialog
     * @return an int indicating the option selected by the user
     */
    public static int showConfirmDialog(Component parentComponent, Object message,
                                        String title, int optionType,
                                        int messageType, Icon icon) {
        return showOptionDialog(parentComponent, message, title, optionType,
                                messageType, icon, null, null);
    }

    /**
     * Brings up a modal dialog with a specified icon, where the initial
     * choice is dermined by the <code>initialValue</code> parameter and
     * the number of choices is determined by the <code>optionType</code> 
     * parameter.
     * <p>
     * If <code>optionType</code> is YES_NO_OPTION, or YES_NO_CANCEL_OPTION
     * and the <code>options</code> parameter is <code>null</code>,
     * then the options are
     * supplied by the Look and Feel. 
     * <p>
     * The <code>messageType</code> parameter is primarily used to supply
     * a default icon from the Look and Feel.
     *
     * @param parentComponent determines the <code>Frame</code>
     *			in which the dialog is displayed;  if 
     *                  <code>null</code>, or if the
     *			<code>parentComponent</code> has no
     *			<code>Frame</code>, a 
     *                  default <code>Frame</code> is used
     * @param message   the <code>Object</code> to display
     * @param title     the title string for the dialog
     * @param optionType an integer designating the options available on the
     *			dialog: YES_NO_OPTION, or YES_NO_CANCEL_OPTION
     * @param messageType an integer designating the kind of message this is, 
     *                  primarily used to determine the icon from the
     *			pluggable
     *                  Look and Feel: ERROR_MESSAGE, INFORMATION_MESSAGE, 
     *                  WARNING_MESSAGE, QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param icon      the icon to display in the dialog
     * @param options   an array of objects indicating the possible choices
     *                  the user can make; if the objects are components, they
     *                  are rendered properly; non-<code>String</code>
     *			objects are
     *                  rendered using their <code>toString</code> methods;
     *                  if this parameter is <code>null</code>,
     *			the options are determined by the Look and Feel.
     * @param initialValue the object that represents the default selection
     *                     for the dialog
     * @return an integer indicating the option chosen by the user, 
     *         or CLOSED_OPTION if the user closed the Dialog
     */
   public static int showOptionDialog(Component parentComponent, Object message,
				      String title, int optionType,
				      int messageType, Icon icon,
				      Object[] options, Object initialValue) {

      VisionOptionPane pane = new VisionOptionPane(message, messageType,
						 optionType, icon,
						 options, initialValue);
       pane.setInitialValue(initialValue);

       JDialog         dialog = pane.createDialog(parentComponent, title);

       pane.selectInitialValue();

       dialog.show();
	
       Object        selectedValue = pane.getValue();

       if(selectedValue == null)
            return CLOSED_OPTION;
       if(options == null) {
	  if(selectedValue instanceof Integer)
	      return ((Integer)selectedValue).intValue();
	  return CLOSED_OPTION;
       }
       for(int counter = 0, maxCounter = options.length;
	   counter < maxCounter; counter++) {
	  if(options[counter].equals(selectedValue))
	      return counter;
       }
       return CLOSED_OPTION;
   }

    /**
     * Shows a question-message dialog requesting input from the user. The 
     * dialog uses the default frame, which usually means it is centered on 
     * the screen. 
     *
     * @param message the Object to display
     */
    public static String showInputDialog(Object message) {
        return showInputDialog(null, message);
    }

    /**
     * Shows a question-message dialog requesting input from the user parented to
     * <code>parentComponent</code>. The dialog is displayed in the Component's
     * frame, and is usually positioned below the Component. 
     *
     * @param parentComponent  the parent Component for the dialog
     * @param message  the Object to display
     */
    public static String showInputDialog(Component parentComponent, Object message){
        return showInputDialog(parentComponent, message, "Input", QUESTION_MESSAGE);
    }
    /**
     * Shows a dialog requesting input from the user parented to
     * <code>parentComponent</code> with the dialog having the title
     * <code>title</code> and message type <code>messageType</code>.
     *
     * @param parentComponent  the parent Component for the dialog
     * @param message  the Object to display
     * @param title    the String to display in the dialog title bar
     * @param messageType the type of message that is to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE.
     */
    public static String showInputDialog(Component parentComponent, Object message,
                                         String title, int messageType) {
        return (String)showInputDialog(parentComponent, message, title,
                                       messageType, null, null, null);
    }

    /**
     * Prompts the user for input in a blocking dialog where the
     * initial selection, possible selections, and all other options can
     * be specified. The user will able to choose from
     * <code>selectionValues</code>, where null implies the user can input
     * whatever they wish, usually by means of a JTextField. 
     * <code>initialSelectionValue</code> is the initial value to prompt
     * the user with. It is up to the UI to decide how best to represent
     * the <code>selectionValues</code>, but usually a JComboBox, JList, or
     * JTextField will be used.
     *
     * @param parentComponent  the parent Component for the dialog
     * @param message  the Object to display
     * @param title    the String to display in the dialog title bar
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE.
     * @param icon     the Icon image to display
     * @param selectionValues an array of Objects that gives the possible
     *                        selections
     * @param initialSelectionValue the value used to initialize the input
     *                              field
     * @return users input, or null meaning the user canceled the input
     */
    public static Object showInputDialog(Component parentComponent, Object message,
                      String title, int messageType, Icon icon,
                      Object[] selectionValues, Object initialSelectionValue) {
        VisionOptionPane    pane = new VisionOptionPane(message, messageType,
							OK_CANCEL_OPTION, icon,
							null, null);
        // Workaround for bug#4135218
        pane.adjustPreferredSize();

        pane.setWantsInput(true);
        pane.setSelectionValues(selectionValues);
        pane.setInitialSelectionValue(initialSelectionValue);

        JDialog        dialog = pane.createDialog(parentComponent, title);

        pane.selectInitialValue();
        dialog.show();

        Object value = pane.getInputValue();

        if(value == UNINITIALIZED_VALUE)
            return null;
        return value;
    }

    // Workaround for bug#4135218: make the optionpane's
    // preferred size be a little bigger than we need, hence
    // when AWT creates it a little too small, we're still ok.
    private void adjustPreferredSize() {
        Dimension prefSize = getPreferredSize();
        prefSize.width+=5;
        prefSize.height+=2;
        setPreferredSize(prefSize);
    }

    /**
     * Creates a <code>VisionOptionPane</code> with a test message.
     */
    public VisionOptionPane() {
        this("VisionOptionPane message");
    }

    /**
     * Creates a instance of <code>VisionOptionPane</code> to display a
     * message using the 
     * plain-message message type and the default options delivered by
     * the UI.
     *
     * @param message the <code>Object</code> to display
     */
    public VisionOptionPane(Object message) {
        this(message, PLAIN_MESSAGE);
    }

    /**
     * Creates an instance of <code>VisionOptionPane</code> to display a message
     * with the specified message type and the default options,
     *
     * @param message the <code>Object</code> to display
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     */
    public VisionOptionPane(Object message, int messageType) {
        this(message, messageType, DEFAULT_OPTION);
    }

    /**
     * Creates an instance of <code>VisionOptionPane</code> to display a message
     * with the specified message type and options.
     *
     * @param message the <code>Object</code> to display
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param optionType the options to display in the pane:
     *                   DEFAULT_OPTION, YES_NO_OPTION, YES_NO_CANCEL_OPTION
     *                   OK_CANCEL_OPTION
     */
    public VisionOptionPane(Object message, int messageType, int optionType) {
        this(message, messageType, optionType, null);
    }

    /**
     * Creates an instance of <code>VisionOptionPane</code> to display a message
     * with the specified message type, options, and icon.
     *
     * @param message the <code>Object</code> to display
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param optionType the options to display in the pane:
     *                   DEFAULT_OPTION, YES_NO_OPTION, YES_NO_CANCEL_OPTION
     *                   OK_CANCEL_OPTION
     * @param icon the <code>Icon</code> image to display
     */
    public VisionOptionPane(Object message, int messageType, int optionType,
                       Icon icon) {
        this(message, messageType, optionType, icon, null);
    }

    /**
     * Creates an instance of VisionOptionPane to display a message
     * with the specified message type, icon, and options.
     * None of the options is initially selected.
     * <p>
     * The options objects should contain either instances of
     * <code>Component</code>s, (which are added directly) or
     * <code>Strings</code> (which are wrapped in a <code>JButton</code>).
     * If you provide <code>Component</code>s, you must ensure that when the
     * <code>Component</code> is clicked it messages <code>setValue</code>
     * in the created <code>VisionOptionPane</code>.
     *
     * @param message the <code>Object</code> to display
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param optionType the options to display in the pane:
     *                   DEFAULT_OPTION, YES_NO_OPTION, YES_NO_CANCEL_OPTION
     *                   OK_CANCEL_OPTION; only meaningful if the 
     *                   <code>options</code> parameter is <code>null</code>
     * @param icon the <code>Icon</code> image to display
     * @param options  the choices the user can select
     */
    public VisionOptionPane(Object message, int messageType, int optionType,
                       Icon icon, Object[] options) {
        this(message, messageType, optionType, icon, options, null);
    }

    /**
     * Creates an instance of <code>VisionOptionPane</code> to display a message
     * with the specified message type, icon, and options, with the 
     * initially-selected option specified.
     *
     * @param message the <code>Object</code> to display
     * @param messageType the type of message to be displayed:
     *                    ERROR_MESSAGE, INFORMATION_MESSAGE, WARNING_MESSAGE,
     *                    QUESTION_MESSAGE, or PLAIN_MESSAGE
     * @param optionType the options to display in the pane:
     *                   DEFAULT_OPTION, YES_NO_OPTION, YES_NO_CANCEL_OPTION
     *                   OK_CANCEL_OPTION; only meaningful if the
     *                   <code>options</code> parameter is <code>null</code>
     * @param icon the Icon image to display
     * @param options  the choices the user can select
     * @param initialValue the choice that is initially selected
     */
    public VisionOptionPane(Object message, int messageType, int optionType,
			   Icon icon, Object[] options, Object initialValue) {
       this.message = message;
       this.options = options;
       this.initialValue = initialValue;
       this.icon = icon;
       setMessageType(messageType);
       setOptionType(optionType);
       value = UNINITIALIZED_VALUE;
       inputValue = UNINITIALIZED_VALUE;
       updateUI();
    }

///////////////////
// Accessibility support
///////////////////

    /**
     * Get the AccessibleContext associated with this JComponent
     *
     * @return the AccessibleContext of this JComponent
     * @beaninfo
     *       expert: true
     *  description: The AccessibleContext associated with this option pane
     */
    public AccessibleContext getAccessibleContext() {
        if (accessibleContext == null) {
            accessibleContext = new AccessibleVisionOptionPane();
        }
        return accessibleContext;
    }

    /**
     * Accessiblity support.
     * <p>
     * Define accessibility methods for this JComponent
     */
    protected class AccessibleVisionOptionPane extends AccessibleJComponent {

        /**
         * Get the role of this object.
         *
         * @return an instance of AccessibleRole describing the role of the object
         * @see AccessibleRole
         */
       public AccessibleRole getAccessibleRole() {
	  return AccessibleRole.OPTION_PANE;
       }

       public String getAccessibleName() {
	  if (getMessage() instanceof String) {
	     return ( (String)getMessage() );
	  }
	  else if (getMessage() instanceof JTextArea) {
	     return ( ((JTextArea)getMessage()).getText() );
	  }
						    
	  else if (getMessage() instanceof Object[])
	  {
	     Object [] args = (Object [])getMessage();
	     StringBuffer sb = new StringBuffer("");
	     for (int i=0; i < ((Object[])getMessage()).length; i++) {
		if (args[i] instanceof String)
		    sb.append((String)args[i]);
		else if (args[i] instanceof JTextArea) {
		   sb.append(((JTextArea)args[i]).getText());
		}
		else {
		   sb.append(((Object)args[i]).toString());
		}
	     }
	     return ( sb.toString() );
	  }
	  else {
	     return ("");
	  }
       }
    } // inner class AccessibleVisionOptionPane


}



