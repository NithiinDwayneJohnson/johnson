/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      WizardComponent.java                                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 November 06 at 13:41:11 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.TextField;
import java.util.Hashtable;

import javax.swing.DefaultSingleSelectionModel;
import javax.swing.JButton;
import javax.swing.SingleSelectionModel;
import javax.swing.border.EtchedBorder;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       WizardComponent                                         */
/**
 * A wizard, which consists of a sequence of panels that guide the user
 * through the steps of an operation, such as changing an address. A wizard
 * has a Back button, a Next or Finish button, and a Cancel button. These
 * buttons can be enables, disabled or hidden on an individual base.
 * <p>
 * This class's layout manager is the border layout. It positions the
 * WizardButtonPanel in the south, and the WizardPagePanel in the center.
 * <p>
 * A client can detect page changes (flipping) by installing a
 * ChangeListener or by overriding the default wizard controller. 
 * <p>
 * The text and accelerator keys for the buttons are always retrieved from
 * the current locale resource file.
 */
/*======================================================================*/
public  class  WizardComponent  extends  FormComponent
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin WizardComponent:Attributes preserve=yes
   private int        pageCounter    = 0;
   private Hashtable  pageToKeyTable = new Hashtable();
//##End   WizardComponent:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private int[]                storeOrder;

                /*======================================================*/
                /* ATTRIBUTE:  titles                                   */
                /*                                                      */
                /**
                 * The titles hash table.
                /*======================================================*/
   private Hashtable            titles            = new Hashtable();
   private WizardButtonPanel    wizardButtonPanel = new WizardButtonPanel();
   private WizardPagePanel      wizardPagePanel   = new WizardPagePanel();
   private SingleSelectionModel selectionModel    = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  WizardComponent                                  */
        /*                                                              */
        /**
         * Cosntructor.
         *  
         */
        /*==============================================================*/
   public    WizardComponent (
                             )
   {
//##Begin WizardComponent:WizardComponent() preserve=yes
      setLayout(new BorderLayout());
      super.add(getWizardPagePanel(), BorderLayout.CENTER);
      super.add(getWizardButtonPanel(), BorderLayout.SOUTH);
      setSelectionModel(new DefaultSingleSelectionModel());
      setUI(WizardComponentUI.createUI(this));
      setResourceOwnerClass(WizardComponent.class);      
//##End   WizardComponent:WizardComponent()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getStoreOrder                                    */
        /*                                                              */
        /**
         * This method returns the value of a user can specify an array of
         * indices to save. This has the affect of only saving those
         * indices and in the order specified in the array.
         *  
         * @return      :int[] -
         *                 The value of a user can specify an array of
         *                 indices to save. This has the affect of only
         *                 saving those indices and in the order specified
         *                 in the array.
         */
        /*==============================================================*/
   public  int[]  getStoreOrder (
                                )
   {
//##Begin WizardComponent:getStoreOrder() preserve=no

      return (storeOrder);

//##End   WizardComponent:getStoreOrder()
   }

        /*==============================================================*/
        /* OPERATION:  getTitles                                        */
        /*                                                              */
        /**
         * This method returns the value of the titles hash table.
         *  
         * @return      :Hashtable -
         *                 The value of the titles hash table.
         */
        /*==============================================================*/
   private  Hashtable  getTitles (
                                 )
   {
//##Begin WizardComponent:getTitles() preserve=no

      return (titles);

//##End   WizardComponent:getTitles()
   }

        /*==============================================================*/
        /* OPERATION:  getWizardButtonPanel                             */
        /*                                                              */
        /**
         * This method returns the value of the "wizardButtonPanel"
         * attribute.
         *  
         * @return      :WizardButtonPanel -
         *                 The value of the "wizardButtonPanel" attribute.
         */
        /*==============================================================*/
   public  WizardButtonPanel  getWizardButtonPanel (
                                                    )
   {
//##Begin WizardComponent:getWizardButtonPanel() preserve=no

      return (wizardButtonPanel);

//##End   WizardComponent:getWizardButtonPanel()
   }

        /*==============================================================*/
        /* OPERATION:  getWizardPagePanel                               */
        /*                                                              */
        /**
         * This method returns the value of the "wizardPagePanel"
         * attribute.
         *  
         * @return      :WizardPagePanel -
         *                 The value of the "wizardPagePanel" attribute.
         */
        /*==============================================================*/
   public  WizardPagePanel  getWizardPagePanel (
                                               )
   {
//##Begin WizardComponent:getWizardPagePanel() preserve=no

      return (wizardPagePanel);

//##End   WizardComponent:getWizardPagePanel()
   }

        /*==============================================================*/
        /* OPERATION:  getSelectionModel                                */
        /*                                                              */
        /**
         * This method returns the value of the "selectionModel" attribute.
         *  
         * @return      :SingleSelectionModel -
         *                 The value of the "selectionModel" attribute.
         */
        /*==============================================================*/
   public  SingleSelectionModel  getSelectionModel (
                                                   )
   {
//##Begin WizardComponent:getSelectionModel() preserve=no

      return (selectionModel);

//##End   WizardComponent:getSelectionModel()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setStoreOrder                                    */
        /*                                                              */
        /**
         * This method sets the value of a user can specify an array of
         * indices to save. This has the affect of only saving those
         * indices and in the order specified in the array.
         *  
         * @param       aValue:int[]
         *                 The value of a user can specify an array of
         *                 indices to save. This has the affect of only
         *                 saving those indices and in the order specified
         *                 in the array.
         */
        /*==============================================================*/
   public  void  setStoreOrder (
                                int[]  aValue
                               )
   {
//##Begin WizardComponent:setStoreOrder(int[]) preserve=no

      storeOrder = aValue;

//##End   WizardComponent:setStoreOrder(int[])
   }

        /*==============================================================*/
        /* OPERATION:  setTitles                                        */
        /*                                                              */
        /**
         * This method sets the value of the titles hash table.
         *  
         * @param       aValue:Hashtable
         *                 The value of the titles hash table.
         */
        /*==============================================================*/
   private  void  setTitles (
                             Hashtable  aValue
                            )
   {
//##Begin WizardComponent:setTitles(Hashtable) preserve=no

      titles = aValue;

//##End   WizardComponent:setTitles(Hashtable)
   }

        /*==============================================================*/
        /* OPERATION:  setWizardPagePanel                               */
        /*                                                              */
        /**
         * This method sets the value of the "wizardPagePanel" attribute.
         *  
         * @param       aValue:WizardPagePanel
         *                 The value of the "wizardPagePanel" attribute.
         */
        /*==============================================================*/
   private  void  setWizardPagePanel (
                                      WizardPagePanel  aValue
                                     )
   {
//##Begin WizardComponent:setWizardPagePanel(WizardPagePanel) preserve=no

      wizardPagePanel = aValue;

//##End   WizardComponent:setWizardPagePanel(WizardPagePanel)
   }

        /*==============================================================*/
        /* OPERATION:  setSelectionModel                                */
        /*                                                              */
        /**
         * This method sets the value of the "selectionModel" attribute.
         *  
         * @param       aValue:SingleSelectionModel
         *                 The value of the "selectionModel" attribute.
         */
        /*==============================================================*/
   private  void  setSelectionModel (
                                     SingleSelectionModel  aValue
                                    )
   {
//##Begin WizardComponent:setSelectionModel(SingleSelectionModel) preserve=no

      selectionModel = aValue;

//##End   WizardComponent:setSelectionModel(SingleSelectionModel)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getNextButton                                    */
        /*                                                              */
        /**
         * @return      :JButton -
         */
        /*==============================================================*/
   public  JButton  getNextButton (
                                  )
   {
//##Begin WizardComponent:getNextButton() preserve=yes
      return (getWizardButtonPanel().getNextButton());
//##End   WizardComponent:getNextButton()
   }

        /*==============================================================*/
        /* OPERATION:  getBackButton                                    */
        /*                                                              */
        /**
         * @return      :JButton -
         */
        /*==============================================================*/
   public  JButton  getBackButton (
                                  )
   {
//##Begin WizardComponent:getBackButton() preserve=yes
      return (getWizardButtonPanel().getBackButton());
//##End   WizardComponent:getBackButton()
   }

        /*==============================================================*/
        /* OPERATION:  getFinishButton                                  */
        /*                                                              */
        /**
         * @return      :JButton -
         */
        /*==============================================================*/
   public  JButton  getFinishButton (
                                    )
   {
//##Begin WizardComponent:getFinishButton() preserve=yes
      return (getWizardButtonPanel().getFinishButton());
//##End   WizardComponent:getFinishButton()
   }

        /*==============================================================*/
        /* OPERATION:  getCancelButton                                  */
        /*                                                              */
        /**
         * @return      :JButton -
         */
        /*==============================================================*/
   public  JButton  getCancelButton (
                                    )
   {
//##Begin WizardComponent:getCancelButton() preserve=yes
      return (getWizardButtonPanel().getCancelButton());
//##End   WizardComponent:getCancelButton()
   }

        /*==============================================================*/
        /* OPERATION:  addPage                                          */
        /*                                                              */
        /**
         * Adds the specified component to the wizard.
         *  
         * @param       aComponent:Component
         */
        /*==============================================================*/
   public  void  addPage (
                          Component  aComponent
                         )
   {
//##Begin WizardComponent:addPage(Component) preserve=yes
      addPage(aComponent , -1);
//##End   WizardComponent:addPage(Component)
   }

        /*==============================================================*/
        /* OPERATION:  addPage                                          */
        /*                                                              */
        /**
         * Adds the specified component to the wizard at a specific index.
         *  
         * @param       aComponent:Component
         * @param       index:int
         */
        /*==============================================================*/
   public  void  addPage (
                          Component  aComponent,
                          int        index
                         )
   {
//##Begin WizardComponent:addPage(Component,int) preserve=yes
      String     pageName     = "Page" + pageCounter;
      Component  selectedPage = getSelectedPage();
      
      pageCounter++;
      pageToKeyTable.put(aComponent, pageName);
      getWizardPagePanel().add(aComponent,pageName, index);
//##End   WizardComponent:addPage(Component,int)
   }

        /*==============================================================*/
        /* OPERATION:  removePage                                       */
        /*                                                              */
        /**
         * Removes a page from a specific index.
         *  
         * @param       index:int
         */
        /*==============================================================*/
   public  void  removePage (
                             int  index
                            )
   {
//##Begin WizardComponent:removePage(int) preserve=yes
      Component  currentComponent = getSelectedPage();

      if ( (index == getSelectedIndex()) && (getWizardPagePanel().getComponentCount() - 1 > 0) ) {
	 throw new IllegalArgumentException("Can only remove current page if it is last page.");
      }

      Component  aComponent = getWizardPagePanel().getComponent(index);

      getWizardPagePanel().remove(index);
      pageToKeyTable.remove(aComponent);

      // Reset the selected index to the currently selected page.
      // We need to calculate the new index of the currently selected
      // page.

      if (getWizardPagePanel().getComponentCount() > 0) {
	 setSelectedPage(currentComponent);
      }
      else {
	 setSelectedIndex(-1);
      }

//##End   WizardComponent:removePage(int)
   }

        /*==============================================================*/
        /* OPERATION:  removePage                                       */
        /*                                                              */
        /**
         * Removes a specific page.
         *  
         * @param       aComponent:Component
         */
        /*==============================================================*/
   public  void  removePage (
                             Component  aComponent
                            )
   {
//##Begin WizardComponent:removePage(Component) preserve=yes
      removePage(getPageIndex(aComponent));
//##End   WizardComponent:removePage(Component)
   }

        /*==============================================================*/
        /* OPERATION:  removeAll                                        */
        /*                                                              */
        /**
         * Removes all pages.
         *  
         */
        /*==============================================================*/
   public  void  removeAll (
                           )
   {
//##Begin WizardComponent:removeAll() preserve=yes
      getWizardPagePanel().removeAll();
      pageToKeyTable.clear();
      setSelectedIndex(-1);
//##End   WizardComponent:removeAll()
   }

        /*==============================================================*/
        /* OPERATION:  setSelectedIndex                                 */
        /*                                                              */
        /**
         * passthru to model. 
         *  
         * @param       index:int
         */
        /*==============================================================*/
   public  void  setSelectedIndex (
                                   int  index
                                  )
   {
//##Begin WizardComponent:setSelectedIndex(int) preserve=yes
      getSelectionModel().setSelectedIndex(index);
//##End   WizardComponent:setSelectedIndex(int)
   }

        /*==============================================================*/
        /* OPERATION:  getSelectedIndex                                 */
        /*                                                              */
        /**
         * passthru to model.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getSelectedIndex (
                                 )
   {
//##Begin WizardComponent:getSelectedIndex() preserve=yes
      return (getSelectionModel().getSelectedIndex());
//##End   WizardComponent:getSelectedIndex()
   }

        /*==============================================================*/
        /* OPERATION:  getPageIndex                                     */
        /*                                                              */
        /**
         * Returns the index of a given page.
         *  
         * @param       aComponent:Component
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getPageIndex (
                              Component  aComponent
                             )
   {
//##Begin WizardComponent:getPageIndex(Component) preserve=yes
      Component[] components = getWizardPagePanel().getComponents();

      for (int i = 0; i < components.length; i++) {
	 if (components[i] == aComponent) {
	    return i;
	 }
      }

      return -1;
      //      throw new IllegalArgumentException("Invalid component" + aComponent);

//##End   WizardComponent:getPageIndex(Component)
   }

        /*==============================================================*/
        /* OPERATION:  getSelectedPage                                  */
        /*                                                              */
        /**
         * Returns the currently selected page.
         *  
         * @return      :Component -
         */
        /*==============================================================*/
   public  Component  getSelectedPage (
                                      )
   {
//##Begin WizardComponent:getSelectedPage() preserve=yes
      if (getSelectedIndex() == -1) {
	 return (null);
      }

      return ( getWizardPagePanel().getComponent(getSelectedIndex()) );
//##End   WizardComponent:getSelectedPage()
   }

        /*==============================================================*/
        /* OPERATION:  setSelectedPage                                  */
        /*                                                              */
        /**
         * Selects a given page.
         *  
         * @param       aComponent:Component
         */
        /*==============================================================*/
   public  void  setSelectedPage (
                                  Component  aComponent
                                 )
   {
//##Begin WizardComponent:setSelectedPage(Component) preserve=yes
      setSelectedIndex(getPageIndex(aComponent));
//##End   WizardComponent:setSelectedPage(Component)
   }

        /*==============================================================*/
        /* OPERATION:  getPageName                                      */
        /*                                                              */
        /**
         * Returns the page name associated with the page. This is an
         * internal name used by the card layout manager when a page flip
         * is needed.
         *  
         * @param       aComponent:Component
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getPageName (
                                Component  aComponent
                               )
   {
//##Begin WizardComponent:getPageName(Component) preserve=yes
	 return((String)pageToKeyTable.get(aComponent)); 
//##End   WizardComponent:getPageName(Component)
   }

        /*==============================================================*/
        /* OPERATION:  getPageCount                                     */
        /*                                                              */
        /**
         * Returns the number of pages in the wizard.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getPageCount (
                             )
   {
//##Begin WizardComponent:getPageCount() preserve=yes
      return (getWizardPagePanel().getComponentCount());
//##End   WizardComponent:getPageCount()
   }

        /*==============================================================*/
        /* OPERATION:  getPageAt                                        */
        /*                                                              */
        /**
         * Returns the page at the given index.
         *  
         * @param       index:int
         * @return      :Component -
         */
        /*==============================================================*/
   public  Component  getPageAt (
                                 int  index
                                )
   {
//##Begin WizardComponent:getPageAt(int) preserve=yes
      return (getWizardPagePanel().getComponent(index));
//##End   WizardComponent:getPageAt(int)
   }

        /*==============================================================*/
        /* OPERATION:  setUI                                            */
        /*                                                              */
        /**
         * The JComponet setUI.
         *  
         * @param       aComponentUI:FormComponentUI
         */
        /*==============================================================*/
   public  void  setUI (
                        FormComponentUI  aComponentUI
                       )
   {
//##Begin WizardComponent:setUI(FormComponentUI) preserve=yes
      super.setUI(aComponentUI);
//##End   WizardComponent:setUI(FormComponentUI)
   }

        /*==============================================================*/
        /* OPERATION:  setPageTitle                                     */
        /*                                                              */
        /**
         * Sets a given page title. If the title is null, the page title is
         * empty.
         *  
         * @param       page:Component
         * @param       title:String
         */
        /*==============================================================*/
   public  void  setPageTitle (
                               Component  page,
                               String     title
                              )
   {
//##Begin WizardComponent:setPageTitle(Component,String) preserve=yes
      titles.remove(page);

      if (title != null) {
	 titles.put(page, title);
      }

//##End   WizardComponent:setPageTitle(Component,String)
   }

        /*==============================================================*/
        /* OPERATION:  getPageTitle                                     */
        /*                                                              */
        /**
         * Returns a page title.
         *  
         * @param       page:Component
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getPageTitle (
                                 Component  page
                                )
   {
//##Begin WizardComponent:getPageTitle(Component) preserve=yes
      return (String)titles.get(page);
//##End   WizardComponent:getPageTitle(Component)
   }

        /*==============================================================*/
        /* OPERATION:  getReservedAccelarators                          */
        /*                                                              */
        /**
         * In some situations, a form might want to reserve accelkeys. For
         * example, a Wizard should not allow embedded forms to to override
         * any accel keys that the Wizard is using.
         *  
         * @return      :char[] -
         */
        /*==============================================================*/
   public  char[]  getReservedAccelarators (
                                           )
   {
//##Begin WizardComponent:getReservedAccelarators() preserve=yes
      char reservedChars[] = new char[4]; 
      reservedChars[0] = getAccelCharacter("backButtonAccel");
      reservedChars[1] = getAccelCharacter("nextButtonAccel");
      reservedChars[2] = getAccelCharacter("cancelButtonAccel");
      reservedChars[3] = getAccelCharacter("finishButtonAccel");
      return reservedChars;
//##End   WizardComponent:getReservedAccelarators()
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  prepareStore                                     */
        /*                                                              */
        /**
         * This method is overridden so that we can flip to the page before
         * calling preparestore. The order of which the prepareStore method
         * is called can be changed by altering the store order array.
         *  
         * @exception   PrepareFormException -
         */
        /*==============================================================*/
   protected  void  prepareStore (
                                 )
                           throws PrepareFormException
   {
//##Begin WizardComponent:prepareStore() preserve=yes
      int        count        = getPageCount();
      int        currentIndex = getSelectedIndex();	    
      int[]      myStoreOrder = getStoreOrder();

      if (myStoreOrder == null) {
	 myStoreOrder = new int[count];
	 for (int i = 0; i < count ; i++) {
	    myStoreOrder[i] = i;
	 }
      }

      for (int i = 0; i < myStoreOrder.length ; i++) {
	 setSelectedIndex(myStoreOrder[i]);
	 Component aComponent = getPageAt(myStoreOrder[i]);
	 if (aComponent instanceof FormComponent) {
	    ((FormComponent)aComponent).prepareStore();
	 }
      }
      
      setSelectedIndex(currentIndex);
     	 	
//##End   WizardComponent:prepareStore()
   }

        /*==============================================================*/
        /* OPERATION:  commit                                           */
        /*                                                              */
        /**
         * This method is overridden to store pages of a wizard. Pages are
         * stored in increasing order as they are specified in the Wizard.
         * The order can be changed by specifying a different store order
         * by calling (or overriding) getStoreOrder.
         *  
         */
        /*==============================================================*/
   protected  void  commit (
                           )
   {
//##Begin WizardComponent:commit() preserve=yes
      int             count                   = getPageCount();
      int[]           myStoreOrder            = getStoreOrder();

      if (myStoreOrder == null) {
	 myStoreOrder = new int[count];
	 for (int i = 0; i < count ; i++) {
	    myStoreOrder[i] = i;
	 }
      }

      for (int i = 0; i < myStoreOrder.length ; i++) {
	 Component aComponent = getPageAt(myStoreOrder[i]);
	 if (aComponent instanceof FormComponent) {
	    ((FormComponent)aComponent).commit();
	 }
      } 

//##End   WizardComponent:commit()
   }


    /*==================================================================*/
    /*=========================               ==========================*/
    /*========================= Inner Classes ==========================*/
    /*=========================               ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* CLASS:       WizardButtonPanel                                   */
    /**
     * A WizardButtonPanel consists of the buttons that drive a wizard.
     * These buttons are the Next, Back, Finish and Cancel. The look of
     * each button can be altered using the appropriate setXXX method.
     */
    /*==================================================================*/
      class  WizardButtonPanel  extends  FormComponent
    {


        /*==============================================================*/
        /* Custom Attributes                                            */
        /*==============================================================*/
//##Begin WizardButtonPanel:Attributes preserve=yes

//##End   WizardButtonPanel:Attributes

        /*==============================================================*/
        /* Private Attributes                                           */
        /*==============================================================*/
       private JButton nextButton   = null;
       private JButton backButton   = null;
       private JButton finishButton = null;
       private JButton cancelButton = null;
       public TextField  msgText    = null;
        /*==============================================================*/
        /* Constructor Operations                                       */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  WizardButtonPanel                            */
            /*                                                          */
            /**
             */
            /*==========================================================*/
       public    WizardButtonPanel (
                                   )
       {
//##Begin WizardButtonPanel:WizardButtonPanel() preserve=yes
	  setResourceOwnerClass(WizardComponent.class);
          msgText = new TextField(38);
          msgText.setEditable(false);
          msgText.setVisible(false);
	  setBackButton(new JButton(getStringResource("backButton")));
	  setNextButton(new JButton(getStringResource("nextButton")));
	  setCancelButton(new JButton(getStringResource("cancelButton")));
	  setFinishButton(new JButton(getStringResource("finishButton")));
	  
	  getBackButton().setMnemonic(getAccelCharacter("backButtonAccel"));
	  getNextButton().setMnemonic(getAccelCharacter("nextButtonAccel"));
	  getCancelButton().setMnemonic(getAccelCharacter("cancelButtonAccel"));
	  getFinishButton().setMnemonic(getAccelCharacter("finishButtonAccel"));

	  Font aFont = getFinishButton().getFont();	  
	  aFont = new Font(aFont.getName(), Font.BOLD , aFont.getSize());
	  getFinishButton().setFont(aFont);

	  setLayout(new GridBagLayout());
	  positionButtons();

	  setBorder ( new EtchedBorder() );

	  getNextButton().setEnabled(false);
	  getBackButton().setEnabled(false);
//##End   WizardButtonPanel:WizardButtonPanel()
       }

       public  TextField  getMsgText (
                                      )
       {
            return (msgText);
       }
        /*==============================================================*/
        /* Attribute Get Operations                                     */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  getNextButton                                */
            /*                                                          */
            /**
             * This method returns the value of the "nextButton" attribute.
             *  
             * @return      :JButton -
             *                 The value of the "nextButton" attribute.
             */
            /*==========================================================*/
       public  JButton  getNextButton (
                                      )
       {
//##Begin WizardButtonPanel:getNextButton() preserve=no
    
          return (nextButton);
    
//##End   WizardButtonPanel:getNextButton()
       }

            /*==========================================================*/
            /* OPERATION:  getBackButton                                */
            /*                                                          */
            /**
             * This method returns the value of the "backButton" attribute.
             *  
             * @return      :JButton -
             *                 The value of the "backButton" attribute.
             */
            /*==========================================================*/
       public  JButton  getBackButton (
                                      )
       {
//##Begin WizardButtonPanel:getBackButton() preserve=no
    
          return (backButton);
    
//##End   WizardButtonPanel:getBackButton()
       }

            /*==========================================================*/
            /* OPERATION:  getFinishButton                              */
            /*                                                          */
            /**
             * This method returns the value of the "finishButton"
             * attribute.
             *  
             * @return      :JButton -
             *                 The value of the "finishButton" attribute.
             */
            /*==========================================================*/
       public  JButton  getFinishButton (
                                        )
       {
//##Begin WizardButtonPanel:getFinishButton() preserve=no
    
          return (finishButton);
    
//##End   WizardButtonPanel:getFinishButton()
       }

            /*==========================================================*/
            /* OPERATION:  getCancelButton                              */
            /*                                                          */
            /**
             * This method returns the value of the "cancelButton"
             * attribute.
             *  
             * @return      :JButton -
             *                 The value of the "cancelButton" attribute.
             */
            /*==========================================================*/
       public  JButton  getCancelButton (
                                        )
       {
//##Begin WizardButtonPanel:getCancelButton() preserve=no
    
          return (cancelButton);
    
//##End   WizardButtonPanel:getCancelButton()
       }


        /*==============================================================*/
        /* Attribute Set Operations                                     */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  setNextButton                                */
            /*                                                          */
            /**
             * This method sets the value of the "nextButton" attribute.
             *  
             * @param       aValue:JButton
             *                 The value of the "nextButton" attribute.
             */
            /*==========================================================*/
       public  void  setNextButton (
                                    JButton  aValue
                                   )
       {
//##Begin WizardButtonPanel:setNextButton(JButton) preserve=no
    
          nextButton = aValue;
    
//##End   WizardButtonPanel:setNextButton(JButton)
       }

            /*==========================================================*/
            /* OPERATION:  setBackButton                                */
            /*                                                          */
            /**
             * This method sets the value of the "backButton" attribute.
             *  
             * @param       aValue:JButton
             *                 The value of the "backButton" attribute.
             */
            /*==========================================================*/
       public  void  setBackButton (
                                    JButton  aValue
                                   )
       {
//##Begin WizardButtonPanel:setBackButton(JButton) preserve=no
    
          backButton = aValue;
    
//##End   WizardButtonPanel:setBackButton(JButton)
       }

            /*==========================================================*/
            /* OPERATION:  setFinishButton                              */
            /*                                                          */
            /**
             * This method sets the value of the "finishButton" attribute.
             *  
             * @param       aValue:JButton
             *                 The value of the "finishButton" attribute.
             */
            /*==========================================================*/
       public  void  setFinishButton (
                                      JButton  aValue
                                     )
       {
//##Begin WizardButtonPanel:setFinishButton(JButton) preserve=no
    
          finishButton = aValue;
    
//##End   WizardButtonPanel:setFinishButton(JButton)
       }

            /*==========================================================*/
            /* OPERATION:  setCancelButton                              */
            /*                                                          */
            /**
             * This method sets the value of the "cancelButton" attribute.
             *  
             * @param       aValue:JButton
             *                 The value of the "cancelButton" attribute.
             */
            /*==========================================================*/
       public  void  setCancelButton (
                                      JButton  aValue
                                     )
       {
//##Begin WizardButtonPanel:setCancelButton(JButton) preserve=no
    
          cancelButton = aValue;
    
//##End   WizardButtonPanel:setCancelButton(JButton)
       }


        /*==============================================================*/
        /* Private Operations                                           */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  positionButtons                              */
            /*                                                          */
            /**
             * Positions the buttons after a change.
             *  
             */
            /*==========================================================*/
       private  void  positionButtons (
                                      )
       {
//##Begin WizardButtonPanel:positionButtons() preserve=yes

	  GridBagConstraints c        = new GridBagConstraints();
	  GridBagLayout      gridbag  = (GridBagLayout)getLayout();

	  this.add(getMsgText());
	  c.fill = GridBagConstraints.NONE;
	  c.weightx = 0.8;
	  c.anchor  = GridBagConstraints.EAST;
	  gridbag.setConstraints(getCancelButton(), c);
	  this.add(getCancelButton());

	  c.weightx = 0.1;
	  gridbag.setConstraints(getBackButton(), c);
	  this.add(getBackButton());

	  this.add(getNextButton());

	  c.weightx = 0.1;
	  c.anchor  = GridBagConstraints.CENTER;
	  gridbag.setConstraints(getFinishButton(), c);
	  this.add(getFinishButton());
//##End   WizardButtonPanel:positionButtons()
       }


    }

    /*==================================================================*/
    /*=========================               ==========================*/
    /*========================= Inner Classes ==========================*/
    /*=========================               ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* CLASS:       WizardPagePanel                                     */
    /**
     * The panel occupies the center an north portions of the Wizard panel.
     * Its layout manager is the card layout. This layout will "flip"
     * amongst pages.
     */
    /*==================================================================*/
      class  WizardPagePanel  extends  FormComponent
    {


        /*==============================================================*/
        /* Custom Attributes                                            */
        /*==============================================================*/
//##Begin WizardPagePanel:Attributes preserve=yes

//##End   WizardPagePanel:Attributes

        /*==============================================================*/
        /* Constructor Operations                                       */
        /*==============================================================*/
            /*==========================================================*/
            /* OPERATION:  WizardPagePanel                              */
            /*                                                          */
            /**
             */
            /*==========================================================*/
       public    WizardPagePanel (
                                 )
       {
//##Begin WizardPagePanel:WizardPagePanel() preserve=yes
	  setBorder ( new EtchedBorder() );
	  setLayout( new CardLayout());
//##End   WizardPagePanel:WizardPagePanel()
       }


    }

    public void setMessageText(String s) 
    {
       getWizardButtonPanel().getMsgText().setText(s);
    }

    public  TextField  getMessageTextField (
                                      )
       {    
       	    return (getWizardButtonPanel().getMsgText());
       } 

}







