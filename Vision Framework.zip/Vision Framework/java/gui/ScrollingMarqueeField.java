/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      ScrollingMarqueeField.java                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2001 September 27 at 09:32:31 EST                       */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       ScrollingMarqueeField                                   */
/**
 * The ScrollingMarqueeField class is a text field where the text scrolls
 * across (also called TickerTape). The text is static but the font and
 * size can be changed. Also, the speed at which the text scrolls can be
 * changed by increasing the step of the text or by changing making the
 * speed that the timer uses faster. 
 * <p>
 * The class provides some default settings to the font ("Time Roman",
 * plain, size 18), to the scrolling speed (100 (ms))  and the step (3).
 */
/*======================================================================*/
public  class  ScrollingMarqueeField  extends  javax.swing.JPanel
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin ScrollingMarqueeField:Attributes preserve=yes

//##End   ScrollingMarqueeField:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private Container                     parent;
   private java.awt.Font                 marqueeFont;
   private int                           step;
   private java.lang.String              text;
   private int                           time;
   private int                           offset = 0;
   private javax.swing.Timer             timer;
   private java.awt.event.ActionListener listener = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  ScrollingMarqueeField                            */
        /*                                                              */
        /**
         * Constructor that takes a container as its parent.
         *  
         * @param       parentObj:Container
         * @param       dim:java.awt.Dimension
         */
        /*==============================================================*/
   public    ScrollingMarqueeField (
                                    Container           parentObj,
                                    java.awt.Dimension  dim
                                   )
   {
//##Begin ScrollingMarqueeField:ScrollingMarqueeField(Container,Dimension) preserve=yes

      parent = parentObj;
      setPreferredSize(dim);
      marqueeFont = new Font("TimesRoman", Font.PLAIN, 18);
      step = 3;
      text = "";
      time = 50;

      run();

//##End   ScrollingMarqueeField:ScrollingMarqueeField(Container,Dimension)
   }

        /*==============================================================*/
        /* OPERATION:  ScrollingMarqueeField                            */
        /*                                                              */
        /**
         * Constructor that takes a container as its parent object.
         * <p>
         * Defaults are then:
         * <p>
         * Font: Times Roman, plain, 18
         * <p>
         * Dimensions: 300 x 100
         * <p>
         * Offset: 0
         * <p>
         * Step: 3
         * <p>
         * String: ""
         * <p>
         * Timing: 100
         *  
         * @param       parentObj:Container
         */
        /*==============================================================*/
   public    ScrollingMarqueeField (
                                    Container  parentObj
                                   )
   {
//##Begin ScrollingMarqueeField:ScrollingMarqueeField(Container) preserve=yes

      this(parentObj, new Dimension(315, 25));

//##End   ScrollingMarqueeField:ScrollingMarqueeField(Container)
   }

        /*==============================================================*/
        /* OPERATION:  ScrollingMarqueeField                            */
        /*                                                              */
        /**
         * Constructor that takes a container, dimensions, font, offset,
         * step, text, time)
         * <p>
         * Defaults are NONE.
         *  
         * @param       parentObj:Container
         * @param       dim:java.awt.Dimension
         * @param       aFont:java.awt.Font
         * @param       aStep:int
         * @param       theText:java.lang.String
         * @param       aTime:int
         */
        /*==============================================================*/
   public    ScrollingMarqueeField (
                                    Container           parentObj,
                                    java.awt.Dimension  dim,
                                    java.awt.Font       aFont,
                                    int                 aStep,
                                    java.lang.String    theText,
                                    int                 aTime
                                   )
   {
//##Begin ScrollingMarqueeField:ScrollingMarqueeField(Container,Dimension,Font,int,String,int) preserve=yes

      parent = parentObj;
      setPreferredSize(dim);
      marqueeFont = aFont;
      step = aStep;
      text = theText;
      time = aTime;
      run();

//##End   ScrollingMarqueeField:ScrollingMarqueeField(Container,Dimension,Font,int,String,int)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getTimer                                         */
        /*                                                              */
        /**
         * This method returns the value of the "timer" attribute.
         *  
         * @return      :javax.swing.Timer -
         *                 The value of the "timer" attribute.
         */
        /*==============================================================*/
   public  javax.swing.Timer  getTimer (
                                       )
   {
//##Begin ScrollingMarqueeField:getTimer() preserve=no

      return (timer);

//##End   ScrollingMarqueeField:getTimer()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setMarqueeFont                                   */
        /*                                                              */
        /**
         * This method sets the value of the "marqueeFont" attribute.
         *  
         * @param       aValue:java.awt.Font
         *                 The value of the "marqueeFont" attribute.
         */
        /*==============================================================*/
   public  void  setMarqueeFont (
                                 java.awt.Font  aValue
                                )
   {
//##Begin ScrollingMarqueeField:setMarqueeFont(Font) preserve=yes

      synchronized(this) {
	marqueeFont = aValue;
      }
      run();

//##End   ScrollingMarqueeField:setMarqueeFont(Font)
   }

        /*==============================================================*/
        /* OPERATION:  setStep                                          */
        /*                                                              */
        /**
         * This method sets the value of the "step" attribute.
         *  
         * @param       aValue:int
         *                 The value of the "step" attribute.
         */
        /*==============================================================*/
   public  void  setStep (
                          int  aValue
                         )
   {
//##Begin ScrollingMarqueeField:setStep(int) preserve=yes

      synchronized(this) {
	step = aValue;
      }
      run();

//##End   ScrollingMarqueeField:setStep(int)
   }

        /*==============================================================*/
        /* OPERATION:  setTime                                          */
        /*                                                              */
        /**
         * This method sets the value of the "time" attribute.
         *  
         * @param       aValue:int
         *                 The value of the "time" attribute.
         */
        /*==============================================================*/
   public  void  setTime (
                          int  aValue
                         )
   {
//##Begin ScrollingMarqueeField:setTime(int) preserve=yes

      synchronized(this) {
	time = aValue;
      }
      run();

//##End   ScrollingMarqueeField:setTime(int)
   }

        /*==============================================================*/
        /* OPERATION:  setText                                          */
        /*                                                              */
        /**
         * This method sets the value of the "text" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "text" attribute.
         */
        /*==============================================================*/
   public  void  setText (
                          java.lang.String  aValue
                         )
   {
//##Begin ScrollingMarqueeField:setText(String) preserve=yes

      synchronized(this) {
	text = null;
	text = aValue;
      }
      run();

//##End   ScrollingMarqueeField:setText(String)
   }


   public void setTextAndStart (
				java.lang.String aValue
				)
   {
	 setText(aValue);
	 start();
   }

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  start                                            */
        /*                                                              */
        /**
         * This method will start the timer.
         *  
         */
        /*==============================================================*/
   public  void  start (
                       )
   {
//##Begin ScrollingMarqueeField:start() preserve=yes

      if (timer != null) {
	 if (timer.isRunning())
	     timer.restart();
	 else {
	    timer.start();
	 }
      }
      else {
	 System.out.println("THE TIMER IS NULL");
      }

//##End   ScrollingMarqueeField:start()
   }


        /*==============================================================*/
        /* OPERATION:  stop                                             */
        /*                                                              */
        /**
         * This method will stop the timer.
         *  
         */
        /*==============================================================*/
   public  void  stop (
                      )
   {
//##Begin ScrollingMarqueeField:stop() preserve=yes

      timer.stop();

//##End   ScrollingMarqueeField:stop()
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  run                                              */
        /*                                                              */
        /**
         * This method handles the creation of the images and the calling
         * of the timer. It is not available to be called directly but
         * instead is called when any of the attributes, such as the text,
         * are changed.
         *
         */
        /*==============================================================*/
    private void  run (
		       )
    {
//##Begin ScrollingMarqueeField:run() preserve=yes
	final int width  = (int)getPreferredSize().getWidth();
	final int height = (int)getPreferredSize().getHeight();
	final java.awt.Image image = parent.createImage(width, height);
	final Graphics gfx = image.getGraphics();
	final FontMetrics fm  = gfx.getFontMetrics(marqueeFont);

	if (timer != null) {
	    timer.stop();
	    timer = null;
	}

	if (listener == null) {
	    listener = new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
		    int baseline = fm.getHeight() - fm.getDescent();
		    int twidth = fm.stringWidth(text);

		    gfx.setFont(marqueeFont);
		    gfx.setColor(getBackground());
		    gfx.fillRect(0, 0, width, height);
		    gfx.setColor(getForeground());
		    gfx.drawString(text, width - offset, baseline);
		    getGraphics().drawImage(image, 0, 0, null);

		    // move
		    offset += step;
		    if(offset >= twidth + width) offset = 0;

		    gfx.dispose();
		    gfx.finalize();
		    getGraphics().dispose();
		    getGraphics().finalize();
		    image.flush();
		}
	    };
	}

	timer = new javax.swing.Timer(time, listener);
//    timer.start();
//##End   ScrollingMarqueeField:run()
    }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the ScrollingMarqueeField class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin ScrollingMarqueeField:main(String[]) preserve=yes

      JFrame    myFrame   = new JFrame("Ticker Tape Testing");

      ScrollingMarqueeField  comp;

      try {
	 myFrame.pack();
//  	 comp = new ScrollingMarqueeField(myFrame, new Dimension(300,100));
	 comp = new ScrollingMarqueeField(myFrame, new Dimension(300, 100), new Font("TimesRoman", Font.PLAIN, 24),3, new String("DEFAULT TEXT"), 50);
	 myFrame.getContentPane().add("Center", comp);

	 myFrame.setVisible(true);

	 try {
	    Thread.sleep(7000);
	 }
	 catch( InterruptedException ie ) {
	    ie.printStackTrace();
	 }

	 comp.setText("This is new text");
	 myFrame.addWindowListener( new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		   System.exit(0);
		}
	     });
      }
      catch (Throwable e) {
	 e.printStackTrace();
	 System.exit(0);
      }

//##End   ScrollingMarqueeField:main(String[])
   }


}
