/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      TableRowRemoveAction.java                               */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 February 15 at 09:26:29 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.gui;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.awt.Frame;
import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.businessobjects.BusinessObjectContainer;
import COM.novusnet.vision.java.persistence.ReadonlyException;
import COM.novusnet.vision.java.transactions.Current;
import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       TableRowRemoveAction                                    */
/**
 * This class handles row deletion from a table view. Its main duties
 * include:
 * <p>
 * - Setting the action name and shortcut.
 * <p>
 * When actionPerformed is called, this action calls the handleConfirmation
 * method. The default handle confirmation method puts up an confirmation
 * option pane with a confirmation string as specified by the user. 
 * <p>
 * If the user gives positive confirmation, the handleDeleteRow() method is
 * called. This method simply invokes Delete() on the business object as
 * selected by the current row. The PID is obtained from the default pid
 * factory associated with the BO.
 */
/*======================================================================*/
public  class  TableRowRemoveAction  extends  TableFormAction
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin TableRowRemoveAction:Attributes preserve=yes

//##End   TableRowRemoveAction:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String confirmationString;
   private String confirmationTitle;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  TableRowRemoveAction                             */
        /*                                                              */
        /**
         * This constructor sets the title of the action and its system
         * standard shortcut.
         *  
         * @param       target:TableForm
         * @param       confirmString:String
         */
        /*==============================================================*/
   public    TableRowRemoveAction (
                                   TableForm  target,
                                   String     confirmString
                                  )
   {
//##Begin TableRowRemoveAction:TableRowRemoveAction(TableForm,String) preserve=yes
      super(target);
      putValue(Action.NAME,"Remove");
      setConfirmationString(confirmString);
//##End   TableRowRemoveAction:TableRowRemoveAction(TableForm,String)
   }

        /*==============================================================*/
        /* OPERATION:  TableRowRemoveAction                             */
        /*                                                              */
        /**
         * This constructor sets the title of the action and its system
         * standard shortcut.
         *  
         * @param       target:TableForm
         */
        /*==============================================================*/
   public    TableRowRemoveAction (
                                   TableForm  target
                                  )
   {
//##Begin TableRowRemoveAction:TableRowRemoveAction(TableForm) preserve=yes
      this(target , null);
//##End   TableRowRemoveAction:TableRowRemoveAction(TableForm)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getConfirmationString                            */
        /*                                                              */
        /**
         * This method returns the value of the confirmation string to use
         * before deleting a row.
         *  
         * @return      :String -
         *                 The value of the confirmation string to use
         *                 before deleting a row.
         */
        /*==============================================================*/
   public  String  getConfirmationString (
                                         )
   {
//##Begin TableRowRemoveAction:getConfirmationString() preserve=yes

      if (confirmationString == null) {
	 ResourceResolver rr = getTableForm().getResourceResolver();
	 confirmationString  = rr.getStringResource("deleteConfirmation", TableForm.class);
      }

      return (confirmationString);

//##End   TableRowRemoveAction:getConfirmationString()
   }

        /*==============================================================*/
        /* OPERATION:  getConfirmationTitle                             */
        /*                                                              */
        /**
         * This method returns the value of the title used for the deletion
         * confirmation window.
         *  
         * @return      :String -
         *                 The value of the title used for the deletion
         *                 confirmation window.
         */
        /*==============================================================*/
   public  String  getConfirmationTitle (
                                        )
   {
//##Begin TableRowRemoveAction:getConfirmationTitle() preserve=yes
      if (confirmationTitle == null) {
	 ResourceResolver rr = getTableForm().getResourceResolver();
	 confirmationTitle  = rr.getStringResource("confirmation", TableForm.class);
      }

      return (confirmationTitle);

//##End   TableRowRemoveAction:getConfirmationTitle()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setConfirmationString                            */
        /*                                                              */
        /**
         * This method sets the value of the confirmation string to use
         * before deleting a row.
         *  
         * @param       aValue:String
         *                 The value of the confirmation string to use
         *                 before deleting a row.
         */
        /*==============================================================*/
   public  void  setConfirmationString (
                                        String  aValue
                                       )
   {
//##Begin TableRowRemoveAction:setConfirmationString(String) preserve=no

      confirmationString = aValue;

//##End   TableRowRemoveAction:setConfirmationString(String)
   }

        /*==============================================================*/
        /* OPERATION:  setConfirmationTitle                             */
        /*                                                              */
        /**
         * This method sets the value of the title used for the deletion
         * confirmation window.
         *  
         * @param       aValue:String
         *                 The value of the title used for the deletion
         *                 confirmation window.
         */
        /*==============================================================*/
   public  void  setConfirmationTitle (
                                       String  aValue
                                      )
   {
//##Begin TableRowRemoveAction:setConfirmationTitle(String) preserve=no

      confirmationTitle = aValue;

//##End   TableRowRemoveAction:setConfirmationTitle(String)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  actionPerformed                                  */
        /*                                                              */
        /**
         * When this method is called, the default behavior is to create
         * put up a confirmation dialog and then execute a delete against
         * the selected object. The model passed to handleDeleteRow method
         * depends on the class of the model associated with the table. If
         * the class represents business objects, then the currently
         * selected BO is passed to the handleDeleteRow. Otherwise, the
         * table model is passed.
         *  
         * @param       e:ActionEvent
         */
        /*==============================================================*/
   public  void  actionPerformed (
                                  ActionEvent  e
                                 )
   {
//##Begin TableRowRemoveAction:actionPerformed(ActionEvent) preserve=yes
      if (handleConfirmation()) {

	 JTable  table  = getTableForm().getTable();
	 Object  model  = table.getModel();

	 if (model instanceof BOContainerTableModel) {
	    BusinessObjectContainer BOContainer = ((BOContainerTableModel)model).getModel();
	    model = BOContainer.getElementAt(table.getSelectedRow());
	 }

	 handleDeleteRow(model);
      }
//##End   TableRowRemoveAction:actionPerformed(ActionEvent)
   }


    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  handleConfirmation                               */
        /*                                                              */
        /**
         * This method is called when the action performed method of this
         * action is called. The defaul behavior is to display a
         * confirmation option pane to the user. If the user selected yes,
         * the handleDeleteRow method is called. Otherwise the action is
         * terminated.
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   protected  boolean  handleConfirmation (
                                          )
   {
//##Begin TableRowRemoveAction:handleConfirmation() preserve=yes
      int choice = VisionOptionPane.showConfirmDialog(null,
						      getConfirmationString(),
						      getConfirmationTitle(),
						      JOptionPane.YES_NO_OPTION, 
						      JOptionPane.QUESTION_MESSAGE);
      /* IKUMAR	07.31.2002
      * The possibiliy of pressing the Esc key was not considered here.
      * A value of -1 is returned on Esc. and the table row is being removed on 'Esc'.
      * It is taken care now.
      */
      return(((choice == JOptionPane.YES_OPTION) || (choice == JOptionPane.OK_OPTION)) ? true : false);
//##End   TableRowRemoveAction:handleConfirmation()
   }

        /*==============================================================*/
        /* OPERATION:  handleDeleteRow                                  */
        /*                                                              */
        /**
         * This method deletes the currently selected row as specified by
         * the user. It is biased towards BusinessObjects. It assumes that
         * the model supplied is a BO in which case it deletes it.
         *  
         * @param       model:Object
         */
        /*==============================================================*/
   protected  void  handleDeleteRow (
                                     Object  model
                                    )
   {
//##Begin TableRowRemoveAction:handleDeleteRow(Object) preserve=yes

      Frame  frame  = getTableForm().getFrame();

      try {
	 if (model instanceof BusinessObject) {
	    Current myCurrent = new Current();
	    JTable  table  = getTableForm().getTable();
	    
	    if (table.getModel() instanceof BOContainerTableModel) {
	       BusinessObjectContainer BOContainer = ((BOContainerTableModel)table.getModel()).getModel();
	       myCurrent.begin();
	       try {
		  ((BusinessObject)model).Delete(null);
		  myCurrent.commit();
	       }
           // Readonly 
           catch ( ReadonlyException e ) {
               new ExceptionPane( e );
           }
	       catch(RuntimeException e) {
		  try {
		     myCurrent.rollback();	    
		  }
		  // Ignore if it came from rollback
		  catch(RuntimeException ignore) {
		  }

		  ResourceResolver rr = getTableForm().getResourceResolver();
		  String errorString = rr.getStringResource("deleteError", TableForm.class);	 
		  ExceptionPane pane = new ExceptionPane(errorString, e);
	       }	       
	    }	 
	 }
      }
      finally {
      }
//##End   TableRowRemoveAction:handleDeleteRow(Object)
   }

        /*==============================================================*/
        /* OPERATION:  handleException                                  */
        /*                                                              */
        /**
         * This method is provided for subclasses to override the default
         * message that is displayed in case of an exception during the
         * delete.
         *  
         * @param       e:Throwable
         */
        /*==============================================================*/
   protected  void  handleException (
                                     Throwable  e
                                    )
   {
//##Begin TableRowRemoveAction:handleException(Throwable) preserve=yes
      new ExceptionPane(null, e);
//##End   TableRowRemoveAction:handleException(Throwable)
   }


}
