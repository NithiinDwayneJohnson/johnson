package COM.novusnet.vision.java.commonbos;

import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.persistence.EOFPersistenceException;
import COM.novusnet.vision.java.persistence.DapErrorPersistenceException;
import COM.novusnet.vision.java.persistence.NotFoundPersistenceException;

/**
 */
public class ExceptionMapper {

   public static final PersistenceException mapToPersistenceException(Throwable anException) {
      if      (anException instanceof DapErrorException) {
         DapErrorException dapErrorException = (DapErrorException) anException;
         
         return new DapErrorPersistenceException (anException.getMessage         (),
                                                  dapErrorException.getMajorCode (),
                                                  dapErrorException.getMinorCode (),
                                                  dapErrorException.getErrorText ());
      } else if (anException instanceof NotFoundException) {
         return new NotFoundPersistenceException (anException.getMessage         ());
      } else if (anException instanceof java.io.EOFException) { /* PM634912 ticket -VGRUNST */
	 return new EOFPersistenceException (anException.getMessage         ());
      } else {
         return new PersistenceException (anException.getMessage         ());
      }
   }

}




