package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class YearInSchoolsResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String description
                                          )
   {
      YearInSchool year = new YearInSchool();

      year.setCode(code);
      year.setDescription(description);

      return year;

   }
}
