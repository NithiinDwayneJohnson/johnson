package COM.novusnet.vision.java.commonbos;

import java.sql.SQLException;
/**
 */

public class DapErrorException extends SQLException {
    private int m_majorCode = 0;
    private int m_minorCode = 0;
    private String m_errorText = "";

    public DapErrorException(int aMajorCode, int aMinorCode, String aErrorText) {
      m_majorCode = aMajorCode;
      m_minorCode = aMinorCode;
      m_errorText = aErrorText;
    }

    public int getMajorCode() {
      return m_majorCode;    
    }

    public int getMinorCode() {
      return m_minorCode;
    }

    public String getErrorText() {
      return m_errorText;
    }

}

