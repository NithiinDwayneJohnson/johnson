package COM.novusnet.vision.java.commonbos;

/**
 * Its job is to locate the EJB references
 * This will provide a central repository 
 * from where all routing can be done
 * 
 * An intersting question is whether we should cache the 
 * actual object reference or the home reference. Most documentation
 * says cache the Home....but then most documentation is oriented not towards
 * fat clients but thin clients. I have verified (on the web and with colleagues)
 * some of whom have cached actual references(as long as they are stateless session beans)
 * to good effect. This can be done as one of the optimizations later
 * 
 *  Here are functions which set properties so that 
 *  EJB or CORBA calls will have all they need
 * After some investigation it seems only 2 of the below listed properties
 * ORB and ORBSingleton are enough
	private static void setCORBAParams() {
		System.setProperty("org.omg.CORBA.ORBClass", 					"com.inprise.vbroker.orb.ORB");
		System.setProperty("org.omg.CORBA.ORBSingletonClass",			"com.inprise.vbroker.orb.ORBSingleton");
		System.setProperty("javax.rmi.CORBA.StubClass",					"com.inprise.vbroker.rmi.CORBA.StubImpl");
		System.setProperty("javax.rmi.CORBA.UtilClass",					"com.inprise.vbroker.rmi.CORBA.UtilImpl");
		System.setProperty("javax.rmi.CORBA.PortableRemoteObjectClass",	"com.inprise.vbroker.rmi.CORBA.PortableRemoteObjectImpl");
	}

	public static void setEJBParams() {
		System.setProperty("org.omg.CORBA.ORBClass", 					"com.ibm.rmi.iiop.ORB");
		System.setProperty("org.omg.CORBA.ORBSingletonClass", 			"com.ibm.rmi.corba.ORBSingleton");
		System.setProperty("javax.rmi.CORBA.StubClass",					"com.ibm.rmi.javax.rmi.CORBA.StubDelegateImpl");
		System.setProperty("javax.rmi.CORBA.UtilClass", 				"com.ibm.rmi.javax.rmi.CORBA.Util");
		System.setProperty("javax.rmi.CORBA.PortableRemoteObjectClass",	"com.ibm.rmi.javax.rmi.PortableRemoteObject");
	}
 *
 *  http://java.sun.com/j2se/1.3/docs/guide/reflection/proxy.html
 *  For details on how this works here is a good article on DynamicProxies
 *  While it seems like just a fancy way of doing reflection it gives you
 *  what most High-level language purists would like to see...A type-safe
 *  client API
 * 
 * This class provides 2 methods for each AO locator..
 * One uses the default configured by a app wide system property. 
 * This is what I would expect production code to use.
 * 
 * The second mechanism which accepts an IIOP url can be used to access ad-hoc
 * stagglers on different machines...
 * This can also be a good utility to run most of our EJBs against DEV and then
 * just the one you are working on against your own localhost.
 * 
 * 
 * So for example...
 * Most of your EJB Delegates would be doing this....and using the system defined default
 * 
 *     whateverOutput = OrionEJBLocator.getWhateverAO().runWhateverMethod(whateverInput);
 * and then the only EJB(s) you want to debug/develop
 *     whateverOutput = OrionEJBLocator.getWhateverAO("iiop://localhost:900/").runWhateverMethod(whateverInput);
 * 
 * 
 * 
 */
public class EJBLocator {

	public static final String 	ORBCLASS_PROPERTY = "org.omg.CORBA.ORBClass";
	public static final String 	ORBSINGLETON_PROPERTY = "org.omg.CORBA.ORBSingletonClass";
	public static final String 	ORBSTUB_PROPERTY = "javax.rmi.CORBA.StubClass";
	public static final String 	ORBUTIL_PROPERTY = "javax.rmi.CORBA.UtilClass";
	public static final String 	ORBPORTABLE_PROPERTY = "javax.rmi.CORBA.PortableRemoteObjectClass";
	
	public static final String  IBM_ORBCLASS 	 = "com.ibm.rmi.iiop.ORB";
	public static final String	IBM_ORBSINGLETON = "com.ibm.rmi.corba.ORBSingleton";
	public static final String	IBM_ORBSTUB 	 = "com.ibm.rmi.javax.rmi.CORBA.StubDelegateImpl";
	public static final String	IBM_ORBUTIL 	 = "com.ibm.rmi.javax.rmi.CORBA.Util";
	public static final String	IBM_ORBPORTABLE  = "com.ibm.rmi.javax.rmi.PortableRemoteObject";
	
	public static final String  VBJ_ORBCLASS 	 = "com.inprise.vbroker.orb.ORB";
	public static final String	VBJ_ORBSINGLETON = "com.inprise.vbroker.orb.ORBSingleton";
	public static final String	VBJ_ORBSTUB 	 = "com.inprise.vbroker.rmi.CORBA.StubImpl";
	public static final String	VBJ_ORBUTIL		 = "com.inprise.vbroker.rmi.CORBA.UtilImpl";
	public static final String	VBJ_ORBPORTABLE	 = "com.inprise.vbroker.rmi.CORBA.PortableRemoteObjectImpl";
	
	public static final String DEFAULT_CONTEXT_FACTORY = "com.ibm.websphere.naming.WsnInitialContextFactory";
	/**
		// When a user doesn't pass in the serviceProviderURL we use the configured default
		// This is how production will work
	*/
	public static String defaultServiceProviderURL = "IIOP:///";//which is same as IIOP://localhost:900/

	public static void initCORBAProperties() {
		// For EJB lookups on websphere
		System.setProperty(ORBCLASS_PROPERTY,	 IBM_ORBCLASS);
		System.setProperty(ORBSINGLETON_PROPERTY,IBM_ORBSINGLETON);
		System.setProperty(ORBSTUB_PROPERTY,	 IBM_ORBSTUB);
		System.setProperty(ORBUTIL_PROPERTY, 	 IBM_ORBUTIL);
		System.setProperty(ORBPORTABLE_PROPERTY, IBM_ORBPORTABLE);
	}
	public static void resetCORBAProperties() {
		// set them back to what they were i.e VBJ
		// for DAS calls
		System.setProperty(ORBCLASS_PROPERTY,	 VBJ_ORBCLASS);
		System.setProperty(ORBSINGLETON_PROPERTY,VBJ_ORBSINGLETON);
		System.setProperty(ORBSTUB_PROPERTY,	 VBJ_ORBSTUB);
		System.setProperty(ORBUTIL_PROPERTY, 	 VBJ_ORBUTIL);
		System.setProperty(ORBPORTABLE_PROPERTY, VBJ_ORBPORTABLE);
	}
    
}
