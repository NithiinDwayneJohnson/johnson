/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Occupancy.java                                          */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2000 September 27 at 10:51:44 CDT                       */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Occupancy                                               */
/**
 * Class which contains the occupancy arrangement for an applicant:  rents,
 * owns, lives with parents, or other.
 */
/*======================================================================*/
public  class  Occupancy  extends  COM.novusnet.vision.java.businessobjects.BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Occupancy:Attributes preserve=yes

//##End   Occupancy:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private java.lang.String code;
   private java.lang.String description;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCode                                          */
        /*                                                              */
        /**
         * This method returns the value of value to be sent to ACAPS 
         *  
         * @return      :java.lang.String -
         *                 The value of value to be sent to ACAPS 
         */
        /*==============================================================*/
   public  java.lang.String  getCode (
                                     )
   {
//##Begin Occupancy:getCode() preserve=no

      fetch ();

      return (code);

//##End   Occupancy:getCode()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the "description" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getDescription (
                                            )
   {
//##Begin Occupancy:getDescription() preserve=no

      fetch ();

      return (description);

//##End   Occupancy:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCode                                          */
        /*                                                              */
        /**
         * This method sets the value of value to be sent to ACAPS 
         *  
         * @param       aValue:java.lang.String
         *                 The value of value to be sent to ACAPS 
         */
        /*==============================================================*/
   public  void  setCode (
                          java.lang.String  aValue
                         )
   {
//##Begin Occupancy:setCode(String) preserve=no

      if (code == aValue) {
         return;
      }

      if (code != null) {
         if (code.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = code;
      code = aValue;

      setDirty ("code" , myOldValue , code);

      firePropertyChange ("code", myOldValue, code);

//##End   Occupancy:setCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the "description" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  void  setDescription (
                                 java.lang.String  aValue
                                )
   {
//##Begin Occupancy:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   Occupancy:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Occupancy:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (COM.novusnet.vision.java.commonbos.Occupancy.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      COM.novusnet.vision.java.commonbos.Occupancy  myOther  = (COM.novusnet.vision.java.commonbos.Occupancy) aObject;

      try {
         java.lang.String myCode = getCode ();
         if (myCode != null) {
            if ( ! (myCode.equals (myOther.getCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCode () != null) {
               return (false);
         }

         java.lang.String myDescription = getDescription ();
         if (myDescription != null) {
            if ( ! (myDescription.equals (myOther.getDescription ()))) {
               return (false);
            }
         }
         else if (myOther.getDescription () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "COM.novusnet.vision.java.commonbos.Occupancy::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Occupancy:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Occupancy:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         java.lang.String myCode = getCode ();
         if (myCode != null) {
            myHashCode += (37 * myHashCode) + (myCode.hashCode ());
         }
         java.lang.String myDescription = getDescription ();
         if (myDescription != null) {
            myHashCode += (37 * myHashCode) + (myDescription.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Occupancy::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Occupancy:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception  
         * COM.novusnet.vision.java.persistence.PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws COM.novusnet.vision.java.persistence.PersistenceException
   {
//##Begin Occupancy:processRestoreResult(Object) preserve=no

      Occupancy  myOther  = (Occupancy) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCode (myOther.getCode ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Occupancy::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Occupancy:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Occupancy:printOut() preserve=no

      try {
         System.out.println ("Occupancy:");
         System.out.println ("   code: " + getCode ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Occupancy:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  toString                                         */
        /*                                                              */
        /**
         * This method returns a strng representation for the object
         *  
         * @return      :java.lang.String -
         */
        /*==============================================================*/
   public  java.lang.String  toString (
                                      )
   {
//##Begin Occupancy:toString() preserve=yes

      return ( getDescription() );

//##End   Occupancy:toString()
   }


}
