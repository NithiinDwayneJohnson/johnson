package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class RegionsResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String description
                                          )
   {
      Region region =  new Region ();

      region.setRegionCode(code);
      region.setDescription(description);

      return region;

   }
}
