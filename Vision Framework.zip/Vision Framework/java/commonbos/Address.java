/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Address.java                                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2001 March 19 at 13:18:07 CST                           */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.util.Vector;
import java.util.Locale;


import COM.novusnet.vision.java.businessobjects.BusinessObject;

import COM.novusnet.vision.java.persistence.PO;
import COM.novusnet.vision.java.persistence.POFactory;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.PersistenceException;


/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Address                                                 */
/**
 * This is a generic address class. It has street, city, state and a postal
 * code. 
 */
/*======================================================================*/
public  class  Address  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Address:Attributes preserve=yes

//##End   Address:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private        java.lang.String                              street1;
   private        java.lang.String                              street2;
   private        java.lang.String                              city;
   private        PostalCode postalCode;
   private        java.lang.String                              barCode;
   private        boolean                                       changed;
   private        boolean                                       override;
   private        State      state;
   private        Country    country;
    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   private static States     states     = null;
   private static Countries  countries  = null;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getStreet1                                       */
        /*                                                              */
        /**
         * This method returns the value of the "street1" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "street1" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getStreet1 (
                                        )
   {
//##Begin Address:getStreet1() preserve=no

      fetch ();

      return (street1);

//##End   Address:getStreet1()
   }

        /*==============================================================*/
        /* OPERATION:  getStreet2                                       */
        /*                                                              */
        /**
         * This method returns the value of the "street2" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "street2" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getStreet2 (
                                        )
   {
//##Begin Address:getStreet2() preserve=no

      fetch ();

      return (street2);

//##End   Address:getStreet2()
   }

        /*==============================================================*/
        /* OPERATION:  getCity                                          */
        /*                                                              */
        /**
         * This method returns the value of the "city" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "city" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getCity (
                                     )
   {
//##Begin Address:getCity() preserve=no

      fetch ();

      return (city);

//##End   Address:getCity()
   }

        /*==============================================================*/
        /* OPERATION:  getPostalCode                                    */
        /*                                                              */
        /**
         * This method returns the value of the "postalCode" attribute.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.PostalCode -
         *                 The value of the "postalCode" attribute.
         */
        /*==============================================================*/
   public  PostalCode  getPostalCode (
                                                                        )
   {
//##Begin Address:getPostalCode() preserve=no

      fetch ();

      return (postalCode);

//##End   Address:getPostalCode()
   }

        /*==============================================================*/
        /* OPERATION:  getBarCode                                       */
        /*                                                              */
        /**
         * This method returns the value of the zip code coded in a 'Bar
         * Code Fashion'.  A bar code is the vertical 'strips' which are
         * usually useful for scanning.  
         *  
         * @return      :java.lang.String -
         *                 The value of the zip code coded in a 'Bar Code
         *                 Fashion'.  A bar code is the vertical 'strips'
         *                 which are usually useful for scanning.  
         */
        /*==============================================================*/
   public  java.lang.String  getBarCode (
                                        )
   {
//##Begin Address:getBarCode() preserve=no

      fetch ();

      return (barCode);

//##End   Address:getBarCode()
   }

        /*==============================================================*/
        /* OPERATION:  isChanged                                        */
        /*                                                              */
        /**
         * This method returns the value of the "changed" attribute.
         *  
         * @return      :boolean -
         *                 The value of the "changed" attribute.
         */
        /*==============================================================*/
   public  boolean  isChanged (
                              )
   {
//##Begin Address:isChanged() preserve=no

      fetch ();

      return (changed);

//##End   Address:isChanged()
   }

        /*==============================================================*/
        /* OPERATION:  isOverride                                       */
        /*                                                              */
        /**
         * This method returns the value of the "override" attribute.
         *  
         * @return      :boolean -
         *                 The value of the "override" attribute.
         */
        /*==============================================================*/
   public  boolean  isOverride (
                               )
   {
//##Begin Address:isOverride() preserve=yes

      return (override);

//##End   Address:isOverride()
   }

        /*==============================================================*/
        /* OPERATION:  getState                                         */
        /*                                                              */
        /**
         * This method returns the value of the "state" attribute.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.State -
         *                 The value of the "state" attribute.
         */
        /*==============================================================*/
   public  State  getState (
                                                              )
   {
//##Begin Address:getState() preserve=no

      fetch ();

      return (state);

//##End   Address:getState()
   }

        /*==============================================================*/
        /* OPERATION:  getCountry                                       */
        /*                                                              */
        /**
         * This method returns the value of the "country" attribute.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.Country -
         *                 The value of the "country" attribute.
         */
        /*==============================================================*/
   public  Country  getCountry (
                                                                  )
   {
//##Begin Address:getCountry() preserve=no

      fetch ();

      return (country);

//##End   Address:getCountry()
   }

        /*==============================================================*/
        /* OPERATION:  getStates                                        */
        /*                                                              */
        /**
         * This method returns the value of the "states" attribute.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.States -
         *                 The value of the "states" attribute.
         */
        /*==============================================================*/
   public static  States  getStates (
                                                                       )
   {
//##Begin Address:getStates() preserve=yes

      if (states == null) {
	 POFactory           myFactory   = new POFactory();                        
	 //CommonBOPIDFactory  aPIDFactory = new CommonBOPIDFactory();
	VisionPIDFactory  aPIDFactory    = new VisionPIDFactory();//use VisionPIDFactory, therefore ejbpidfactory will be read, HL, 2005.5
	 PID  myStatesPID  = null;

	 myStatesPID  = aPIDFactory.createPID (States.class);
	 states       = (States)myFactory.create_PO(myStatesPID , null);
      }

                /*======================================================*/
                /* Return the attribute value                           */
                /*======================================================*/
      return (states);

//##End   Address:getStates()
   }

        /*==============================================================*/
        /* OPERATION:  getCountries                                     */
        /*                                                              */
        /**
         * This method returns the value of the "countries" attribute.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.Countries -
         *                 The value of the "countries" attribute.
         */
        /*==============================================================*/
   public static  Countries  getCountries (
                                                                             )
   {
//##Begin Address:getCountries() preserve=yes

      if (countries == null) {
	 PID                 myCountriesPID = null;
	 POFactory           myFactory      = new POFactory();                        
     //CommonBOPIDFactory  aPIDFactory    = new CommonBOPIDFactory();
	 VisionPIDFactory  aPIDFactory    = new VisionPIDFactory();

	 myCountriesPID  = aPIDFactory.createPID (Countries.class);
	 countries       = (Countries)myFactory.create_PO(myCountriesPID, null);
      }

                /*======================================================*/
                /* Return the attribute value                           */
                /*======================================================*/
      return (countries);

//##End   Address:getCountries()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/

        /*==============================================================*/
        /* OPERATION:  setStreet1                                       */
        /*                                                              */
        /**
         * This method sets the value of the "street1" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "street1" attribute.
         */
        /*==============================================================*/
   public  void  setStreet1 (
                             java.lang.String  aValue
                            )
   {
//##Begin Address:setStreet1(String) preserve=no

      if (street1 == aValue) {
         return;
      }

      if (street1 != null) {
         if (street1.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = street1;
      street1 = aValue;

      setDirty ("street1" , myOldValue , street1);

      firePropertyChange ("street1", myOldValue, street1);

//##End   Address:setStreet1(String)
   }

        /*==============================================================*/
        /* OPERATION:  setStreet2                                       */
        /*                                                              */
        /**
         * This method sets the value of the "street2" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "street2" attribute.
         */
        /*==============================================================*/
   public  void  setStreet2 (
                             java.lang.String  aValue
                            )
   {
//##Begin Address:setStreet2(String) preserve=no

      if (street2 == aValue) {
         return;
      }

      if (street2 != null) {
         if (street2.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = street2;
      street2 = aValue;

      setDirty ("street2" , myOldValue , street2);

      firePropertyChange ("street2", myOldValue, street2);

//##End   Address:setStreet2(String)
   }

        /*==============================================================*/
        /* OPERATION:  setCity                                          */
        /*                                                              */
        /**
         * This method sets the value of the "city" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "city" attribute.
         */
        /*==============================================================*/
   public  void  setCity (
                          java.lang.String  aValue
                         )
   {
//##Begin Address:setCity(String) preserve=no

      if (city == aValue) {
         return;
      }

      if (city != null) {
         if (city.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = city;
      city = aValue;

      setDirty ("city" , myOldValue , city);

      firePropertyChange ("city", myOldValue, city);

//##End   Address:setCity(String)
   }

        /*==============================================================*/
        /* OPERATION:  setPostalCode                                    */
        /*                                                              */
        /**
         * This method sets the value of the "postalCode" attribute.
         *  
         * @param      
         * aValue:COM.novusnet.vision.java.commonbos.PostalCode
         *                 The value of the "postalCode" attribute.
         */
        /*==============================================================*/
   public  void  setPostalCode (
                                PostalCode  aValue
                               )
   {
//##Begin Address:setPostalCode(PostalCode) preserve=no

      if (postalCode == aValue) {
         return;
      }

      if (postalCode != null) {
         if (postalCode.equals (aValue)) {
            return;
         }
      }

      PostalCode myOldValue = postalCode;
      postalCode = aValue;

      setDirty ("postalCode" , myOldValue , postalCode);

      firePropertyChange ("postalCode", myOldValue, postalCode);

//##End   Address:setPostalCode(PostalCode)
   }

        /*==============================================================*/
        /* OPERATION:  setBarCode                                       */
        /*                                                              */
        /**
         * This method sets the value of the zip code coded in a 'Bar Code
         * Fashion'.  A bar code is the vertical 'strips' which are usually
         * useful for scanning.  
         *  
         * @param       aValue:java.lang.String
         *                 The value of the zip code coded in a 'Bar Code
         *                 Fashion'.  A bar code is the vertical 'strips'
         *                 which are usually useful for scanning.  
         */
        /*==============================================================*/
   public  void  setBarCode (
                             java.lang.String  aValue
                            )
   {
//##Begin Address:setBarCode(String) preserve=no

      if (barCode == aValue) {
         return;
      }

      if (barCode != null) {
         if (barCode.equals (aValue)) {
            return;
         }
      }

      java.lang.String myOldValue = barCode;
      barCode = aValue;

      setDirty ("barCode" , myOldValue , barCode);

      firePropertyChange ("barCode", myOldValue, barCode);

//##End   Address:setBarCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setChanged                                       */
        /*                                                              */
        /**
         * This method sets the value of the "changed" attribute.
         *  
         * @param       aValue:boolean
         *                 The value of the "changed" attribute.
         */
        /*==============================================================*/
   public  void  setChanged (
                             boolean  aValue
                            )
   {
//##Begin Address:setChanged(boolean) preserve=no

      if (changed == aValue) {
         return;
      }

      boolean myOldValue = changed;
      changed = aValue;

      setDirty ("changed" , myOldValue , changed);

      firePropertyChange ("changed", myOldValue, changed);

//##End   Address:setChanged(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setOverride                                      */
        /*                                                              */
        /**
         * This method sets the value of the "override" attribute.
         *  
         * @param       aValue:boolean
         *                 The value of the "override" attribute.
         */
        /*==============================================================*/
   public  void  setOverride (
                              boolean  aValue
                             )
   {
//##Begin Address:setOverride(boolean) preserve=yes

      override = aValue;

//##End   Address:setOverride(boolean)
   }

        /*==============================================================*/
        /* OPERATION:  setState                                         */
        /*                                                              */
        /**
         * This method sets the value of the "state" attribute.
         *  
         * @param       aValue:COM.novusnet.vision.java.commonbos.State
         *                 The value of the "state" attribute.
         */
        /*==============================================================*/
   public  void  setState (
                           State  aValue
                          )
   {
//##Begin Address:setState(State) preserve=no

      if (state == aValue) {
         return;
      }

      if (state != null) {
         if (state.equals (aValue)) {
            return;
         }
      }

      State myOldValue = state;
      state = aValue;

      setDirty ("state" , myOldValue , state);

      firePropertyChange ("state", myOldValue, state);

//##End   Address:setState(State)
   }

        /*==============================================================*/
        /* OPERATION:  setCountry                                       */
        /*                                                              */
        /**
         * This method sets the value of the "country" attribute.
         *  
         * @param       aValue:COM.novusnet.vision.java.commonbos.Country
         *                 The value of the "country" attribute.
         */
        /*==============================================================*/
   public  void  setCountry (
                             Country  aValue
                            )
   {
//##Begin Address:setCountry(Country) preserve=no

      if (country == aValue) {
         return;
      }

      if (country != null) {
         if (country.equals (aValue)) {
            return;
         }
      }

      Country myOldValue = country;
      country = aValue;

      setDirty ("country" , myOldValue , country);

      firePropertyChange ("country", myOldValue, country);

//##End   Address:setCountry(Country)
   }

    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  addReferencedBusinessObjects                     */
        /*                                                              */
        /**
         * This method is called to obtain active references to other BO's.
         *  
         * @param       aContainer:Vector
         *                 The object into which references are to be
         *                 stored.
         */
        /*==============================================================*/
   public  void  addReferencedBusinessObjects (
                                               Vector  aContainer
                                              )
   {
//##Begin Address:addReferencedBusinessObjects(Vector) preserve=no

      super.addReferencedBusinessObjects(aContainer);

      if (state != null) {
         aContainer.addElement(state);
      }

      if (country != null) {
         aContainer.addElement(country);
      }

      if (states != null) {
         aContainer.addElement(states);
      }

      if (countries != null) {
         aContainer.addElement(countries);
      }


     return;
//##End   Address:addReferencedBusinessObjects(Vector)
   }

        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Address:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (COM.novusnet.vision.java.commonbos.Address.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      COM.novusnet.vision.java.commonbos.Address  myOther  = (COM.novusnet.vision.java.commonbos.Address) aObject;

      try {
         java.lang.String myStreet1 = getStreet1 ();
         if (myStreet1 != null) {
            if ( ! (myStreet1.equals (myOther.getStreet1 ()))) {
               return (false);
            }
         }
         else if (myOther.getStreet1 () != null) {
               return (false);
         }

         java.lang.String myStreet2 = getStreet2 ();
         if (myStreet2 != null) {
            if ( ! (myStreet2.equals (myOther.getStreet2 ()))) {
               return (false);
            }
         }
         else if (myOther.getStreet2 () != null) {
               return (false);
         }

         java.lang.String myCity = getCity ();
         if (myCity != null) {
            if ( ! (myCity.equals (myOther.getCity ()))) {
               return (false);
            }
         }
         else if (myOther.getCity () != null) {
               return (false);
         }

         COM.novusnet.vision.java.commonbos.PostalCode myPostalCode = getPostalCode ();
         if (myPostalCode != null) {
            if ( ! (myPostalCode.equals (myOther.getPostalCode ()))) {
               return (false);
            }
         }
         else if (myOther.getPostalCode () != null) {
               return (false);
         }

         COM.novusnet.vision.java.commonbos.State myState = getState ();
         if (myState != null) {
            if ( ! (myState.equals (myOther.getState ()))) {
               return (false);
            }
         }
         else if (myOther.getState () != null) {
               return (false);
         }

         COM.novusnet.vision.java.commonbos.Country myCountry = getCountry ();
         if (myCountry != null) {
            if ( ! (myCountry.equals (myOther.getCountry ()))) {
               return (false);
            }
         }
         else if (myOther.getCountry () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "COM.novusnet.vision.java.commonbos.Address::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Address:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Address:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         java.lang.String myStreet1 = getStreet1 ();
         if (myStreet1 != null) {
            myHashCode += (37 * myHashCode) + (myStreet1.hashCode ());
         }
         java.lang.String myStreet2 = getStreet2 ();
         if (myStreet2 != null) {
            myHashCode += (37 * myHashCode) + (myStreet2.hashCode ());
         }
         java.lang.String myCity = getCity ();
         if (myCity != null) {
            myHashCode += (37 * myHashCode) + (myCity.hashCode ());
         }
         COM.novusnet.vision.java.commonbos.PostalCode myPostalCode = getPostalCode ();
         if (myPostalCode != null) {
            myHashCode += (37 * myHashCode) + (myPostalCode.hashCode ());
         }
         COM.novusnet.vision.java.commonbos.State myState = getState ();
         if (myState != null) {
            myHashCode += (37 * myHashCode) + (myState.hashCode ());
         }
         COM.novusnet.vision.java.commonbos.Country myCountry = getCountry ();
         if (myCountry != null) {
            myHashCode += (37 * myHashCode) + (myCountry.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Address::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Address:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception  
         * COM.novusnet.vision.java.persistence.PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws COM.novusnet.vision.java.persistence.PersistenceException
   {
//##Begin Address:processRestoreResult(Object) preserve=no

      Address  myOther  = (Address) aObject;

      try {
         super.processRestoreResult  (myOther);
         setStreet1 (myOther.getStreet1 ());
         setStreet2 (myOther.getStreet2 ());
         setCity (myOther.getCity ());
         setPostalCode (myOther.getPostalCode ());
         setBarCode (myOther.getBarCode ());
         setChanged (myOther.isChanged ());
         setOverride (myOther.isOverride ());
         setState (myOther.getState ());
         setCountry (myOther.getCountry ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Address::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Address:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Address:printOut() preserve=no

      try {
         System.out.println ("Address:");
         System.out.println ("   street1: " + getStreet1 ());
         System.out.println ("   street2: " + getStreet2 ());
         System.out.println ("   city: " + getCity ());
         System.out.println ("   postalCode: " + getPostalCode ());
         System.out.println ("   barCode: " + getBarCode ());
         System.out.println ("   changed: " + isChanged ());
         System.out.println ("   override: " + isOverride ());
         State myState = getState ();
         if (myState != null) {
            myState.printOut ();
         }
         Country myCountry = getCountry ();
         if (myCountry != null) {
            myCountry.printOut ();
         }
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Address:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setStateAndCountryFromStateCode                  */
        /*                                                              */
        /**
         * This is a utility method that sets the country to the proper
         * value given a state code. The following rules are applied:
         * <p>
         * If state represents a Foreign country (FC) then country is set
         * to null. If state is not FC then country is set to default
         * country.
         * <p>
         * In either case the caller can set the country object separately.
         *  
         * @param       String stateCode:
         */
        /*==============================================================*/
   public  void  setStateAndCountryFromStateCode (
                                                    String stateCode
                                                 )
   {
//##Begin Address:setStateAndCountryFromStateCode() preserve=yes
      State aState = (State)getStates().get(stateCode);
      if (aState == null) {
	 aState = new State();
	 aState.setStateCode(stateCode);
	 aState.setFullName(stateCode);
      }

      setState (aState);
      if (!stateCode.equals("FC")) {
	 setCountry ((Country)Address.getDefaultCountry());
      } 
      else {
	 setCountry (null);
      }

      
//##End   Address:setStateAndCountryFromStateCode()
   }

        /*==============================================================*/
        /* OPERATION:  toString                                         */
        /*                                                              */
        /**
         * How many times have you felt the need to just display the
         * Address as a String? This is your answer.
         *  
         * @return      :java.lang.String -
         */
        /*==============================================================*/
   public  java.lang.String  toString (
                                      )
   {
//##Begin Address:toString() preserve=yes
      String tmpString = street1 ==null ?  "": street1+", "
                        +street2 ==null ?  "": street2+", "
		        +city    ==null ?  "":city ;
			

      if ( state != null ) {
           tmpString += ", " + state.getStateCode(); 
      }
      if ( postalCode != null )  { 
           tmpString +=  " - " + postalCode.toString();
      }
      if ( country != null ) {
           tmpString += ", " + country.getCountryCode() ;
      }
      return tmpString; 
//##End   Address:toString()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getDefaultCountry                                */
        /*                                                              */
        /**
         * Returns the default country for the current locale. The default
         * country is looked up using the 3 letter ISO code of the current
         * locale.
         *  
         * @return      :COM.novusnet.vision.java.commonbos.Country -
         */
        /*==============================================================*/
   public static  COM.novusnet.vision.java.commonbos.Country  getDefaultCountry (
                                                                                )
   {
//##Begin Address:getDefaultCountry() preserve=yes
      Locale     locale = Locale.getDefault();
      String     code   = locale.getISO3Country();
      return ( (Country)getCountries().get(code) );
            
//##End   Address:getDefaultCountry()
   }


}
