/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      StateToRegions.java                                     */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:45 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.POFactory;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       StateToRegions                                          */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  StateToRegions  extends  BusinessObjectLookupList
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin StateToRegions:Attributes preserve=yes
    private static  StateToRegions  statesToRegionList = null ;
    private static  Regions regionsList = null ;
//##End   StateToRegions:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getContainedClass                                */
        /*                                                              */
        /**
         * This method returns the contained objects class.
         *  
         * @return      :Class -
         */
        /*==============================================================*/
   protected  Class  getContainedClass (
                                       )
   {
//##Begin StateToRegions:getContainedClass() preserve=no

                /*======================================================*/
                /* return the class name of my contained objects.       */
                /*======================================================*/
      return StateToRegion.class ;

//##End   StateToRegions:getContainedClass()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getRegionFromStateCode                           */
        /*                                                              */
        /**
         * @param       aStateCode:String
         * @return      :Region -
         */
        /*==============================================================*/
   public static  Region  getRegionFromStateCode (
                                                  String  aStateCode
                                                 )
   {
//##Begin StateToRegions:getRegionFromStateCode(String) preserve=yes

      StateToRegion sTor = (StateToRegion) statesToRegionList.get( aStateCode ); 

      if ( sTor != null  ) {
         return (Region) regionsList.get( sTor.getRegionCode() );
      }
      return null;
//##End   StateToRegions:getRegionFromStateCode(String)
   }


    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin StateToRegions:StaticInitializer preserve=yes
   static {

     POFactory           aFactory    = new POFactory();
     CommonBOPIDFactory  aPIDFactory = new CommonBOPIDFactory();

     PID statesToRegionPID  = aPIDFactory.createPID(StateToRegions.class);
     PID regionsPID = aPIDFactory.createPID(Regions.class);

     try {
        statesToRegionList = (StateToRegions) aFactory.create_PO(statesToRegionPID, null);
        regionsList = (Regions) aFactory.create_PO(regionsPID, null);
     }
     catch(Exception e) {
         e.printStackTrace();
     }

   }
//##End   StateToRegions:StaticInitializer

}
