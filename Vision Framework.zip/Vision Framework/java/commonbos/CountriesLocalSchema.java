/*======================================================================*/
/*                                                                      */
// MODULE:      CountriesLocalSchema.java
/*======================================================================*/

/*======================================================================*/
/*                              Package Statement                       */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                              Import Statements                       */
/*======================================================================*/
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;

import COM.novusnet.vision.java.persistence.JDBCPersistenceIdentifier;
import COM.novusnet.vision.java.persistence.JDBCSchemaMapper;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;

/*======================================================================*/
/*                               Class Statement                        */
/*======================================================================*/
public  class  CountriesLocalSchema implements JDBCSchemaMapper {

   public  void  restore (
                          Connection                aConnection,
                          ObjectOutputStream        aOStream,
                          JDBCPersistenceIdentifier aPID
                         )
                   throws PersistenceException
      {
	 String path = "";
	 if (System.getProperty("localroot") != null) {
	    path =  System.getProperty("localroot");
	 }
	 else {
	    path = "c:\\accounttest\\";
	 }

	 Countries myCountries = null;
	 try{ 
	    System.out.println("OPENING FILE:" + path + "Countries.dat");  
	    FileInputStream fis = new FileInputStream(path + "Countries.dat");
	    ObjectInputStream ois = new ObjectInputStream(fis);
	    myCountries = (Countries) ois.readObject(); 
	    ois.close();
	    
	    aOStream.writeObject (new ReferenceHolder (myCountries));
	 }
	 catch(Throwable e){
	    System.out.println(e);  
	 }
      }

   public  void  store (
                        Connection                aConnection,
                        ObjectInputStream         aIStream,
                        JDBCPersistenceIdentifier aPID
                       )
                 throws PersistenceException
   {
      throw new PersistenceException ("TXNCOUNTRYBROWSELocalSchema does not support the 'store' operation");
   }

   public  void  Delete (
                         Connection                aConnection,
                         ObjectInputStream         aIStream,
                         JDBCPersistenceIdentifier aPID
                        )
                  throws PersistenceException
   {
      throw new PersistenceException ("TXNCOUNTRYBROWSELocalSchema does not support the 'Delete' operation");
   }


        /*==============================================================*/
        /* METHODS: Custom 'MapTo' and 'MapFrom' methods                */
        /*                                                              */
        /*==============================================================*/
}
