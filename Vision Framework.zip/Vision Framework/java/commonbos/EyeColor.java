/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      EyeColor.java                                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:51 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       EyeColor                                                */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  EyeColor  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin EyeColor:Attributes preserve=yes

//##End   EyeColor:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String code;
   private String description;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCode                                          */
        /*                                                              */
        /**
         * This method returns the value of the "code" attribute.
         *  
         * @return      :String -
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  String  getCode (
                           )
   {
//##Begin EyeColor:getCode() preserve=no

      fetch ();

      return (code);

//##End   EyeColor:getCode()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the "description" attribute.
         *  
         * @return      :String -
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  String  getDescription (
                                  )
   {
//##Begin EyeColor:getDescription() preserve=no

      fetch ();

      return (description);

//##End   EyeColor:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCode                                          */
        /*                                                              */
        /**
         * This method sets the value of the "code" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  void  setCode (
                          String  aValue
                         )
   {
//##Begin EyeColor:setCode(String) preserve=no

      if (code == aValue) {
         return;
      }

      if (code != null) {
         if (code.equals (aValue)) {
            return;
         }
      }

      String myOldValue = code;
      code = aValue;

      setDirty ("code" , myOldValue , code);

      firePropertyChange ("code", myOldValue, code);

//##End   EyeColor:setCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the "description" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  void  setDescription (
                                 String  aValue
                                )
   {
//##Begin EyeColor:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   EyeColor:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin EyeColor:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (EyeColor.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      EyeColor  myOther  = (EyeColor) aObject;

      try {
         String myCode = getCode ();
         if (myCode != null) {
            if ( ! (myCode.equals (myOther.getCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "EyeColor::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   EyeColor:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin EyeColor:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myCode = getCode ();
         if (myCode != null) {
            myHashCode += (37 * myHashCode) + (myCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "EyeColor::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   EyeColor:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin EyeColor:processRestoreResult(Object) preserve=no

      EyeColor  myOther  = (EyeColor) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCode (myOther.getCode ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "EyeColor::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   EyeColor:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin EyeColor:printOut() preserve=no

      try {
         System.out.println ("EyeColor:");
         System.out.println ("   code: " + getCode ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   EyeColor:printOut()
   }


}
