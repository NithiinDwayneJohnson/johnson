package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class StateToRegionsResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String stateCode ,
                                           String regionCode
                                          )
   {
      StateToRegion a =  new StateToRegion ();
      a.setStateCode(stateCode);
      a.setRegionCode(regionCode);
      return a;
   }
}
