/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      AddressAccuracyKeyDescriptor.java                       */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 17 at 12:00:48 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.persistence.KeyDescriptor;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       AddressAccuracyKeyDescriptor                            */
/**
 * The Key Descriptor is an interface which allows the key values required
 * to restore a Persistent Object to be encapulated. 
 * <p>
 * The AddressAccuracyKeyDescriptor implements this interface order to
 * define the key value attributes to be passed to the schema via a pid.
 */
/*======================================================================*/
public  class  AddressAccuracyKeyDescriptor  implements  KeyDescriptor
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin AddressAccuracyKeyDescriptor:Attributes preserve=yes

//##End   AddressAccuracyKeyDescriptor:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private char    functionCode;
   private Address address;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getFunctionCode                                  */
        /*                                                              */
        /**
         * This method returns the value of this indicates which type of
         * search the host program will perform.
         * <p>
         * '1' = Will fill in the City, State and Zip + 4  given an address
         * with a Street and Zip Code.
         * <p>
         * '2' = Will verify and correct a given address. 
         *  
         * @return      :char -
         *                 The value of this indicates which type of search
         *                 the host program will perform.
         * <p>
         *                 '1' = Will fill in the City, State and Zip + 4 
         *                 given an address with a Street and Zip Code.
         * <p>
         *                 '2' = Will verify and correct a given address. 
         */
        /*==============================================================*/
   public  char  getFunctionCode (
                                 )
   {
//##Begin AddressAccuracyKeyDescriptor:getFunctionCode() preserve=no

      return (functionCode);

//##End   AddressAccuracyKeyDescriptor:getFunctionCode()
   }

        /*==============================================================*/
        /* OPERATION:  getAddress                                       */
        /*                                                              */
        /**
         * This method returns the value of this is the address (or partial
         * address) supplied as part of the key.
         *  
         * @return      :Address -
         *                 The value of this is the address (or partial
         *                 address) supplied as part of the key.
         */
        /*==============================================================*/
   public  Address  getAddress (
                               )
   {
//##Begin AddressAccuracyKeyDescriptor:getAddress() preserve=no

      return (address);

//##End   AddressAccuracyKeyDescriptor:getAddress()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setFunctionCode                                  */
        /*                                                              */
        /**
         * This method sets the value of this indicates which type of
         * search the host program will perform.
         * <p>
         * '1' = Will fill in the City, State and Zip + 4  given an address
         * with a Street and Zip Code.
         * <p>
         * '2' = Will verify and correct a given address. 
         *  
         * @param       aValue:char
         *                 The value of this indicates which type of search
         *                 the host program will perform.
         * <p>
         *                 '1' = Will fill in the City, State and Zip + 4 
         *                 given an address with a Street and Zip Code.
         * <p>
         *                 '2' = Will verify and correct a given address. 
         */
        /*==============================================================*/
   public  void  setFunctionCode (
                                  char  aValue
                                 )
   {
//##Begin AddressAccuracyKeyDescriptor:setFunctionCode(char) preserve=no

      functionCode = aValue;

//##End   AddressAccuracyKeyDescriptor:setFunctionCode(char)
   }

        /*==============================================================*/
        /* OPERATION:  setAddress                                       */
        /*                                                              */
        /**
         * This method sets the value of this is the address (or partial
         * address) supplied as part of the key.
         *  
         * @param       aValue:Address
         *                 The value of this is the address (or partial
         *                 address) supplied as part of the key.
         */
        /*==============================================================*/
   public  void  setAddress (
                             Address  aValue
                            )
   {
//##Begin AddressAccuracyKeyDescriptor:setAddress(Address) preserve=no

      address = aValue;

//##End   AddressAccuracyKeyDescriptor:setAddress(Address)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin AddressAccuracyKeyDescriptor:printOut() preserve=no

      try {
         System.out.println ("AddressAccuracyKeyDescriptor:");
         System.out.println ("   functionCode: " + getFunctionCode ());
         System.out.println ("   address: " + getAddress ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   AddressAccuracyKeyDescriptor:printOut()
   }


}
