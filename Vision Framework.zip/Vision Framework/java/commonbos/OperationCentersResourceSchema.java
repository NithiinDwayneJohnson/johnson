package COM.novusnet.vision.java.commonbos;


import java.util.StringTokenizer;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;

public class OperationCentersResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String shortName
                                          )
   {
      OperationCenter operationCenter =  new OperationCenter ();

      operationCenter.setCenterCode(code);

      String delimiter = new String(".");
      StringTokenizer st = new StringTokenizer(shortName, delimiter);

      operationCenter.setShortName(st.nextToken());
      operationCenter.setDescription(st.nextToken());

      return operationCenter;
   }
}
