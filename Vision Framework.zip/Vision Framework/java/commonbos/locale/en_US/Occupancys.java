/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for Occupancys in the US_EN locale.
 */
/*======================================================================*/
public class Occupancys extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
	 {" ", ""},
         {"R", "Rent"} ,
         {"O", "Own"} ,
         {"P", "w/Parents" } ,
         {"X", "Other" }

     };
} 







