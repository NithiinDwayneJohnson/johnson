/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for EyeColors in the US_EN locale.
 */
/*======================================================================*/
public class EyeColors extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
          {"BRN"   ,  "Brown" },
          {"BLK"   ,  "Black" },
          {"GRN"   ,  "Green" },
          {"BLU"   ,  "Blue"  },
          {"HZL"   ,  "Hazel" },
          {"ALB"   ,  "Albino"},
     };
} 
