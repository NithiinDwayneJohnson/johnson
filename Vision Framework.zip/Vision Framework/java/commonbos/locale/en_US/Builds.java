/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for Builds in the US_EN locale.
 */
/*======================================================================*/
public class Builds extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
         {"VSML", "Very Small"} ,
         {"SML ", "Small"} ,
         {"AVG ", "Average"},
         {"LRG",  "Large"}, 
         {"VLRG", "Very Large"} ,
     };
} 
