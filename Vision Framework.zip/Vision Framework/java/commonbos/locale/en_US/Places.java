/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for Places in the US_EN locale.
 */
/*======================================================================*/
public class Places extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
        { "1", "Home"},
        { "2", "Auto"},
        { "3", "Office/Work"},
        { "4", "Store/Mall"},
        { "5", "Public Transit"},
        { "6", "Bar/Restaurant"},
        { "7", "Hotel/Motel"},
        { "8", "Unknown/Other" },
     };
} 
