/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The regions for the US_EN locale
 */
/*======================================================================*/
public class Regions extends ListResourceBundle
{
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
         { "00"  , "Unknown"        } ,                  
         { "01"  , "North-East"     } ,                  
         { "02"  , "South-Central"  } , 
         { "03"  , "Midwest"        } ,
         { "04"  , "Central"        } ,
         { "05"  , "South"          } ,                    
         { "06"  , "North-Western"  } ,                    
         { "07"  , "South-Western"  }                                
    };
}
