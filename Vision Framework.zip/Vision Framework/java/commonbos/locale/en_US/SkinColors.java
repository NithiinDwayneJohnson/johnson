/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;
;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for SkinColors in the US_EN locale.
 */
/*======================================================================*/
public class SkinColors extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
        {"WHITE", "White"},
        {"BLACK", "Black"},
        {"BROWN", "Brown"},
        {"ALBINO", "Albino"},
     };
} 
