/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for States in the US_EN locale.
 */
/*======================================================================*/
public class States extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
         {"AA", "Armed Forces America"} ,
         {"AE", "Armed Forces Europe"} ,
         {"AK", "Alaska" } ,
         {"AL", "Alabama" } ,
         {"AR", "Arkansas"} ,
         {"AP", "Armed Forces Pacific"} ,
         {"AZ", "Arizona" } ,
         {"CA", "California"} ,
         {"CO", "Colorado"} ,
         {"CT", "Connecticut"} ,
         {"CZ", "Canal Zone"} ,
         {"DC", "District of Columbia"} ,
         {"DE", "Delaware"} ,
         {"FC", "Foreign country"} ,
         {"FL", "Florida"} ,
         {"GA", "Georgia"} ,
         {"GU", "Guam"} ,
         {"HI", "Hawaii"} ,
         {"IA", "Iowa"} ,
         {"ID", "Idaho"} ,
         {"IL", "Illinois"} ,
         {"IN", "Indiana"} ,
         {"KS", "Kansas"} ,
         {"KY", "Kentucky"} ,
         {"LA", "Louisiana"} ,
         {"MA", "Massachusetts"} ,
         {"MD", "Maryland"} ,
         {"ME", "Maine"} ,
         {"MI", "Michigan"} ,
         {"MN", "Minnesota"} ,
         {"MO", "Missouri"} ,
         {"MS", "Mississippi"} ,
         {"MT", "Montana"} ,
         {"NC", "North Carolina"} ,
         {"ND", "North Dakota"} ,
         {"NE", "Nebraska"} ,
         {"NH", "New Hampshire"} ,
         {"NJ", "New Jersey"} ,
         {"NM", "New Mexico"} ,
         {"NV", "Nevada"} ,
         {"NY", "New York"} ,
         {"OH", "Ohio"} ,
         {"OK", "Oklahoma"} ,
         {"OR", "Oregon"} ,
         {"PA", "Pennsylvania"} ,
         {"PR", "Puerto Rico"} ,
         {"RI", "Rhode Island"} ,
         {"SC", "South Carolina"} ,
         {"SD", "South Dakota"} ,
         {"TN", "Tennessee"} ,
         {"TX", "Texas"} ,
         {"UT", "Utah"} ,
         {"VA", "Virginia"} ,
         {"VI", "Virgin Islands"} ,
         {"VT", "Vermont"} ,
         {"WA", "Washington"} ,
         {"WI", "Wisconsin"} ,
         {"WV", "West Virginia"} ,
         {"WY", "Wyoming"} ,

         // The following were added for Ticket #PM440290
         {"AS", "American Samoa"} ,
         {"FM", "Federated States of Micronesia"} ,
         {"MH", "Marshall Island"} ,
         {"MP", "Northern Mariana Island"} ,
         {"PW", "Palau"} ,
         {"PI", "Pacific Islands"},
     };
} 
