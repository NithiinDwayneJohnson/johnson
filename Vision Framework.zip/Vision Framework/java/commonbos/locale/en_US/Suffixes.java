/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for Suffixes in the US_EN locale.
 */
/*======================================================================*/
public class Suffixes extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
       {"0", ""} ,      
       {"1", "II"} ,
       {"2", "III"} ,	
       {"3", "IV"} ,
       {"4", "V"} ,
       {"5", "CO"} ,
       {"6", "CORP"} ,
       {"7", "DDS"} ,
       {"8", "DO"} ,
       {"9", "DVM"} ,
       {"10", "ESQ"} ,
       {"11", "INC"} ,
       {"12", "JR"} ,
       {"13", "MD"} ,
       {"14", "MP"} ,
       {"15", "OD"} ,
       {"16", "PHD"} ,
       {"17", "RET"} ,	
       {"18", "RN"} ,
       {"19", "SR"} ,
     };
} 

