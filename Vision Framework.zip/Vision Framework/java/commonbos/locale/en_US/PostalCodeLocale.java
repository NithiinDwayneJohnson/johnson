/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PostalCodeLocale.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 12 at 10:32:03 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
import java.text.MessageFormat;

import COM.novusnet.vision.java.commonbos.AbstractPostalCodeLocale;
import COM.novusnet.vision.java.commonbos.PostalCode;

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PostalCodeLocale                                           */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  PostalCodeLocale  extends  AbstractPostalCodeLocale
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PostalCodeLocale:Attributes preserve=yes

//##End   PostalCodeLocale:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/

        /*==============================================================*/
        /* OPERATION:  getValidationRegEx                               */
        /*                                                              */
        /**
         * Returns the validation regular expresion.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public  String[][]  getRules (
				)
   {
      String  rules[][] = 
      {
	 {"(\\d{5})-?(\\d{4})" , "$1:$2"   },
	 {"(\\d{5})"           , "$1:0000" },
	 {"(\\d{5})(\\d{4})"   , "$1:$2"   }
      };

      return (rules);
   }
        /*==============================================================*/
        /* OPERATION:  getFormattedPostalCode                           */
        /*                                                              */
        /**
         * Returns a formatted postal code
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPostalCode (
					   PostalCode postalCode
					  )
   {
      String        zip1 =  "00000";
      String        zip2 =  "0000";

      if (postalCode.getPostalCodeComponents() != null) { 
	 zip1 = (postalCode.getPostalCodeComponents()[0] != null) ? postalCode.getPostalCodeComponents()[0] : zip1;
	 zip2 = (postalCode.getPostalCodeComponents().length > 1 && postalCode.getPostalCodeComponents()[1] != null) ? postalCode.getPostalCodeComponents()[1] : zip2;
      }

      MessageFormat form   = new MessageFormat("{0}-{1}");

      Object[]      args   = { zip1, zip2 };
      			       
      return (form.format(args));
   }

}











