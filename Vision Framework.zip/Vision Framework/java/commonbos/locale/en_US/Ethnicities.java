/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for Ethnicities in the US_EN locale.
 */
/*======================================================================*/
public class Ethnicities extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
         {"CAUCASIAN", "Caucasian" } ,
         {"AFRO-AMER", "African-American" } ,
         {"HISPANIC ", "Hispanic" } ,
         {"ASIAN    ", "Asian" } ,
         {"ASIAN-IND", "Asian-Indian" } ,
         {"PACF ISLE", "Pacific Islands" } ,
         {"OTHER    ", "Other" } ,
     };
} 
