/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The OperationCenters for the US_EN locale.
 */
/*======================================================================*/
public class OperationCenters extends ListResourceBundle
{
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {      
         { "PH"  ,    "PHA.Phoenix"                },     
         { "HQ"  ,    "ITG.Headquarters"           }, 
         { "MR"  ,    "MRO.Mill Run"               }, 
         { "UT"  ,    "LPK.Utah"                   },
         { "SC"  ,    "SCD.Phoenix - CMA,Security" },
         { "NE"  ,    "NCD.New Castle"             },
         { "CO"  ,    "NAO.New Albany"             },
         { "WE"  ,    "WES.Columbus - Merchant"    },
         { "PA"  ,    "PHX.Phoenix - Merchant"     },
         { "HM"  ,    "ITG.Headquarters - Merchant"},
         { "AP"  ,    "NCD.Dover"}
         //{ "CO"  ,    "EAS.Columbus - Eastland"   }
     };
}
