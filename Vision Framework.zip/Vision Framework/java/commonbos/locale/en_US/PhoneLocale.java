/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PhoneLocale.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 12 at 10:32:03 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
import java.text.MessageFormat;

import COM.novusnet.vision.java.commonbos.AbstractPhoneLocale;
import COM.novusnet.vision.java.commonbos.PhoneNumber;


/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PhoneLocale                                           */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  PhoneLocale  extends  AbstractPhoneLocale
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PhoneLocale:Attributes preserve=yes

//##End   PhoneLocale:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getShortFormatString                             */
        /*                                                              */
        /**
         * Returns the format string for short formats.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getShortFormatString (
                                        )
   {
//##Begin PhoneLocale:getShortFormatString() preserve=yes
      return "({0})-{1}";
//##End   PhoneLocale:getShortFormatString()
   }

        /*==============================================================*/
        /* OPERATION:  getLongFormatString                              */
        /*                                                              */
        /**
         * Returns the format string for long formats.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getLongFormatString (
                                       )
   {
//##Begin PhoneLocale:getLongFormatString() preserve=yes
      return "({0})-({1})-{2}";
//##End   PhoneLocale:getLongFormatString()
   }

        /*==============================================================*/
        /* OPERATION:  getValidationRegEx                               */
        /*                                                              */
        /**
         * Returns the validation regular expresion.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public  String[][]  getRules (
				)
   {
//##Begin PhoneLocale:getRules() preserve=yes
      String  rules[][] = 
      {
	 {"(\\d{3})-(\\d{3})-(\\d{4})"       , "C:A:$1P:$2$3E:" },
	 {"\\((\\d{3})\\)-(\\d{3})-(\\d{4})" , "C:A:$1P:$2$3E:" },
	 {"\\((\\d{3})\\) (\\d{3})-(\\d{4})" , "C:A:$1P:$2$3E:" },
	 {"(\\d{3})(\\d{3}\\d{4})"           , "C:A:$1P:$2E:"   },
	 {"(\\d{7})"                         , "C:A:P:$1E:"     }
      };

      return (rules);

//##End   PhoneLocale:getRules()
   }

        /*==============================================================*/
        /* OPERATION:  getCountryCode                                   */
        /*                                                              */
        /**
         * Returns the country code.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getCountryCode (
                                  )
   {
//##Begin PhoneLocale:getCountryCode() preserve=yes
      return ("001");
//##End   PhoneLocale:getCountryCode()
   }

        /*==============================================================*/
        /* OPERATION:  getMaxAreaCodeLength                             */
        /*                                                              */
        /**
         * Returns the maximum length of the area code.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxAreaCodeLength (
                                     )
   {
//##Begin PhoneLocale:getMaxAreaCodeLength() preserve=yes
      return (3);
//##End   PhoneLocale:getMaxAreaCodeLength()
   }

        /*==============================================================*/
        /* OPERATION:  getCountryCodeLength                             */
        /*                                                              */
        /**
         * Returns the country code length.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getCountryCodeLength (
                                     )
   {
//##Begin PhoneLocale:getCountryCodeLength() preserve=yes
      return (1);
//##End   PhoneLocale:getCountryCodeLength()
   }

        /*==============================================================*/
        /* OPERATION:  getMaxLocalPhoneNumberLength                     */
        /*                                                              */
        /**
         * Returns the maximum length of a local phone number.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxLocalPhoneNumberLength (
                                             )
   {
//##Begin PhoneLocale:getMaxLocalPhoneNumberLength() preserve=yes
      return (7);
//##End   PhoneLocale:getMaxLocalPhoneNumberLength()
   }

        /*==============================================================*/
        /* OPERATION:  getFormatFillCharacter                           */
        /*                                                              */
        /**
         * Returns the format fill character. This is used in case one of
         * the attributes is missing. 
         *  
         * @return      :char -
         */
        /*==============================================================*/
   public  char  getFormatFillCharacter (
                                        )
   {
//##Begin PhoneLocale:getFormatFillCharacter() preserve=yes
      return '0';
//##End   PhoneLocale:getFormatFillCharacter()
   }

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberShort                     */
        /*                                                              */
        /**
         * Returns a formatted phone number in simple form. This usually is
         * the area code followed by the phone number.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberShort (
						PhoneNumber phoneNumber
                                                )
   {
//##Begin PhoneLocale:getFormattedPhoneNumberShort(PhoneNumber) preserve=yes
      String        areaCode    = (phoneNumber.getAreaCode() == null)    ? "000" : phoneNumber.getAreaCode();
      String        phone       = (phoneNumber.getLocalPhoneNumber() == null)    ? "0000000" : phoneNumber.getLocalPhoneNumber();

      MessageFormat form   = new MessageFormat("({0})-{1}-{2}");

      Object[]      args   = { areaCode, 
			       phone.substring(0,3),
			       phone.substring(3)
      };
			       

      return (form.format(args));

//##End   PhoneLocale:getFormattedPhoneNumberShort(PhoneNumber)
   }

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberLong                      */
        /*                                                              */
        /**
         * Returns a formatted phone number in long form. This usually is
         * the country code followed by the area code and the phone number.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberLong (
						PhoneNumber phoneNumber
                                               )
   {
//##Begin PhoneLocale:getFormattedPhoneNumberLong(PhoneNumber) preserve=yes
      String        countryCode = (phoneNumber.getCountryCode() == null) ? "0"   : phoneNumber.getCountryCode();
      String        areaCode    = (phoneNumber.getAreaCode() == null)    ? "000" : phoneNumber.getAreaCode();
      String        phone       = (phoneNumber.getLocalPhoneNumber() == null)    ? "0000000" : phoneNumber.getLocalPhoneNumber();

      MessageFormat form   = new MessageFormat("({0})-({1})-{2}-{3}");

      Object[]      args   = { countryCode,
			       areaCode, 
			       phone.substring(0,3),
			       phone.substring(3)
      };
			       

      return (form.format(args));

//##End   PhoneLocale:getFormattedPhoneNumberLong(PhoneNumber)
   }

        /*==============================================================*/
        /* OPERATION:  getUnformattedPhoneNumberShort                   */
        /*                                                              */
        /**
         * Returns an unformatted phone number in simple form. This usually
         * is the area code followed by the phone number. If any of the
         * fields are missing the PhoneLocale typically fills these with a
         * filler character.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPhoneNumberShort (
						   PhoneNumber phoneNumber
                                                  )
   {
//##Begin PhoneLocale:getUnformattedPhoneNumberShort() preserve=yes
      String        areaCode    = (phoneNumber.getAreaCode() == null)    ? "000" : phoneNumber.getAreaCode();
      String        phone       = (phoneNumber.getLocalPhoneNumber() == null)    ? "0000000" : phoneNumber.getLocalPhoneNumber();

      MessageFormat form   = new MessageFormat("{0}{1}{2}");

      Object[]      args   = { areaCode, 
			       phone.substring(0,3),
			       phone.substring(3)
      };
			       

      return (form.format(args));

//##End   PhoneLocale:getUnformattedPhoneNumberShort()
   }

}











