/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos.locale.en_US;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import java.util.ListResourceBundle;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/**
 * The resource class for HairColors in the US_EN locale.
 */
/*======================================================================*/
public class HairColors extends ListResourceBundle
{    
     public Object[][] getContents() 
     {
        return contents;
     }
     
     static final Object[][] contents = 
     {
      { "BLONDE  " , "Blonde" },
      { "BROWN   " , "Brown"  },
      { "BLACK   " , "Black"  },
      { "GRAY    " , "Gray"   },
      { "RED     " , "Red"   },
      { "WHITE   " , "White"   },
      { "BLO/BRO " , "Blonde/Brown" },
      { "BRN/GRY " , "Brown/Gray"},
      { "BLK/GRY " , "Black/Gray"},
      { "WHT/GRY " , "White/Gray"},
      { "BALD"     , "Bald"},
      { "OTHER"    , "Other"},
     };
} 
