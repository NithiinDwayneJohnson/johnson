package COM.novusnet.vision.java.commonbos;

import java.net.URL;
import java.util.Properties;

import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.PersistenceException;

/**
 *
 * We used to hardcode things in the PCSolarPIDFactory.
 * Now we load them from a property file and try to find
 * a match on the class name. If nothing is specified we fall
 * back to using the PCSolarPIDFactory.
 *
 *
 */
public class VisionPIDFactory extends CommonBOPIDFactory {

	Properties props = new Properties();
	public VisionPIDFactory(){
		try {
			//System.out.println("A dummy call to init the EJB Data Access System");
			//OrionEJBLocator.getOrionDirectoryServices();

			//HL, 2005.5 release, either use regular EJBPidFactory or the backup version
			// based on what OrionPidFactory sets up.
			String pidFactoryConfigUrlStr = null;
			String SI = "ON";
			if ( "OFF".equals(System.getProperty("SI")) ) SI = "OFF";
			if ( !SI.equals("OFF") ) {
				pidFactoryConfigUrlStr = System.getProperty("SI_PID_FACTORY_CONFIGURATOR");
				System.out.println("Use SI PID Factory Configuration: " + pidFactoryConfigUrlStr);
			} else {
				pidFactoryConfigUrlStr = System.getProperty("PID_FACTORY_CONFIGURATOR");
				System.out.println("Use PID Factory Configuration: " + pidFactoryConfigUrlStr);
			}
			if ( pidFactoryConfigUrlStr != null ) {
			   URL url = new URL(pidFactoryConfigUrlStr);
			   props.load(url.openStream());
			   props.list(System.err);
			}
		} catch (Throwable t) {
			t.printStackTrace();
			System.err.println(
				"Unable to get WebSphere conversion PID Factory Configuration.");
		}
	}

//	public PID create_PID_from_class(Class aClass) throws PersistenceException {
//		String schemaName = props.getProperty(aClass.getName());
//		if (schemaName != null) {
//			GenericPID myPID = new GenericPID();
//		    myPID.setClassName  (aClass.getName ());
//		    myPID.setSchemaName (schemaName);
//			return myPID;
//		}
//		// DO what our old PCSolarPIDFactory
//		return super.create_PID_from_class(aClass);
//	}

	public PID create_PID_from_class(Class aClass) throws PersistenceException
	{
			String schemaName = props.getProperty(aClass.getName());

			// iHateWebsphere is used by our JUnit testers to bypass the EJBBusinessDelegates in the event that an
			// ejbpidfactory.properties file is present.
			String iHateWebsphere = System.getProperty("iHateWebsphere");

			if (iHateWebsphere != null)
			{
				if (iHateWebsphere.equals("true") || iHateWebsphere.equals("on"))
				{
					// DO what our old PCSolarPIDFactory
					return super.create_PID_from_class(aClass);
				}
				else
				{
					if (schemaName != null)
					{
						GenericPID myPID = new GenericPID();
			    		myPID.setClassName  (aClass.getName ());
			    		myPID.setSchemaName (schemaName);
						return myPID;
					}
				}
				// DO what our old PCSolarPIDFactory
				return super.create_PID_from_class(aClass);
			}
			else
			{
				if (schemaName != null)
				{
					GenericPID myPID = new GenericPID();
				   	myPID.setClassName  (aClass.getName ());
				   	myPID.setSchemaName (schemaName);
					return myPID;
				}
				// DO what our old PCSolarPIDFactory
				return super.create_PID_from_class(aClass);
			}
	}

}
