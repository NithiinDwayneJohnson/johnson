/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      LanguagePreferences.java                                */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2002 August 08 at 12:03:59 CDT                          */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.POFactory;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       LanguagePreferences                                     */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  LanguagePreferences  extends  COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin LanguagePreferences:Attributes preserve=yes

//##End   LanguagePreferences:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getContainedClass                                */
        /*                                                              */
        /**
         * This method returns the contained objects class.
         *  
         * @return      :Class -
         */
        /*==============================================================*/
   protected  Class  getContainedClass (
                                       )
   {
//##Begin LanguagePreferences:getContainedClass() preserve=no

                /*======================================================*/
                /* return the class name of my contained objects.       */
                /*======================================================*/
      return LanguagePreference.class ;

//##End   LanguagePreferences:getContainedClass()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getLanguagePreferences                           */
        /*                                                              */
        /**
         * getLanguagePreferences returns a collection of
         * LanguagePreferences which are retrieved from the
         * LanguagePreferencesResourceSchema.
         *  
         * @return     
         * :COM.novusnet.vision.java.commonbos.LanguagePreferences -
         */
        /*==============================================================*/
   public static  COM.novusnet.vision.java.commonbos.LanguagePreferences  getLanguagePreferences (
                                                                                                 )
   {
//##Begin LanguagePreferences:getLanguagePreferences() preserve=yes
	 LanguagePreferences  myLanguages = new LanguagePreferences();
	 CommonBOPIDFactory  aPIDFactory = new CommonBOPIDFactory();

	 try {
	    POFactory   aFactory = new POFactory();
	    GenericPID  myPID ;
	    
	    myPID = (GenericPID)aPIDFactory.createPID (LanguagePreferences.class);
	    myLanguages = (LanguagePreferences)aFactory.create_PO(myPID, null);
	 }
	 catch (Throwable myThrowable) {
	    System.out.println (
				"getLanguagePreferences: "     +
				myThrowable.toString   () +
				": "                      +
				myThrowable.getMessage ()
				);
	 }
	 return ( myLanguages );

//##End   LanguagePreferences:getLanguagePreferences()
   }


}
