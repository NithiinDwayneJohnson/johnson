/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      DapError.java                                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2000 July 07 at 11:47:43 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       DapError                                                */
/**
 * this class represents a dap error. This may be returned by a call to DAS
 * to execute a transaction.
 */
/*======================================================================*/
public  class  DapError
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin DapError:Attributes preserve=yes

//##End   DapError:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private int              majorCode = 0;
   private int              minorCode = 0;
   private java.lang.String errorText = "";

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  DapError                                         */
        /*                                                              */
        /**
         * contructor, takes the major, minor codes and the error text as
         * paramaters.
         *  
         * @param       aMajorCode:int
         * @param       aMinorCode:int
         * @param       aErrorText:java.lang.String
         */
        /*==============================================================*/
   public    DapError (
                       int               aMajorCode,
                       int               aMinorCode,
                       java.lang.String  aErrorText
                      )
   {
//##Begin DapError:DapError(int,int,String) preserve=yes
      setMajorCode(aMajorCode);
      setMinorCode(aMinorCode);
      setErrorText(aErrorText);
//##End   DapError:DapError(int,int,String)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getMajorCode                                     */
        /*                                                              */
        /**
         * This method returns the value of the "majorCode" attribute.
         *  
         * @return      :int -
         *                 The value of the "majorCode" attribute.
         */
        /*==============================================================*/
   public  int  getMajorCode (
                             )
   {
//##Begin DapError:getMajorCode() preserve=yes

      return (majorCode);

//##End   DapError:getMajorCode()
   }

        /*==============================================================*/
        /* OPERATION:  getMinorCode                                     */
        /*                                                              */
        /**
         * This method returns the value of the "minorCode" attribute.
         *  
         * @return      :int -
         *                 The value of the "minorCode" attribute.
         */
        /*==============================================================*/
   public  int  getMinorCode (
                             )
   {
//##Begin DapError:getMinorCode() preserve=yes

      return (minorCode);

//##End   DapError:getMinorCode()
   }

        /*==============================================================*/
        /* OPERATION:  getErrorText                                     */
        /*                                                              */
        /**
         * This method returns the value of the "errorText" attribute.
         *  
         * @return      :java.lang.String -
         *                 The value of the "errorText" attribute.
         */
        /*==============================================================*/
   public  java.lang.String  getErrorText (
                                          )
   {
//##Begin DapError:getErrorText() preserve=yes

      return (errorText);

//##End   DapError:getErrorText()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setMajorCode                                     */
        /*                                                              */
        /**
         * This method sets the value of the "majorCode" attribute.
         *  
         * @param       aValue:int
         *                 The value of the "majorCode" attribute.
         */
        /*==============================================================*/
   public  void  setMajorCode (
                               int  aValue
                              )
   {
//##Begin DapError:setMajorCode(int) preserve=no

      majorCode = aValue;

//##End   DapError:setMajorCode(int)
   }

        /*==============================================================*/
        /* OPERATION:  setMinorCode                                     */
        /*                                                              */
        /**
         * This method sets the value of the "minorCode" attribute.
         *  
         * @param       aValue:int
         *                 The value of the "minorCode" attribute.
         */
        /*==============================================================*/
   public  void  setMinorCode (
                               int  aValue
                              )
   {
//##Begin DapError:setMinorCode(int) preserve=no

      minorCode = aValue;

//##End   DapError:setMinorCode(int)
   }

        /*==============================================================*/
        /* OPERATION:  setErrorText                                     */
        /*                                                              */
        /**
         * This method sets the value of the "errorText" attribute.
         *  
         * @param       aValue:java.lang.String
         *                 The value of the "errorText" attribute.
         */
        /*==============================================================*/
   public  void  setErrorText (
                               java.lang.String  aValue
                              )
   {
//##Begin DapError:setErrorText(String) preserve=no

      errorText = aValue;

//##End   DapError:setErrorText(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin DapError:printOut() preserve=no

      try {
         System.out.println ("DapError:");
         System.out.println ("   majorCode: " + getMajorCode ());
         System.out.println ("   minorCode: " + getMinorCode ());
         System.out.println ("   errorText: " + getErrorText ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   DapError:printOut()
   }



}
