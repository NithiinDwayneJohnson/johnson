/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*    ==============================================================    */
/*                                                                      */
/* CLASS:       InvalidMediaType                                        */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/

package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                         Imports                                      */
/*======================================================================*/

import COM.novusnet.vision.java.businessobjects.BusinessObjectException;

/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
/**
 * <p><b>DESCRIPTION:</b>
 *       This is a place holder for the exception: Invalid Address 
 * <p><b>PURPOSE:</b>
 *       To provide proper error handling when an Address  is invalid
 *       or null
 *       
 * <p><b>REVISIONS:</b>
 *       <table border="2">
 *           <tr>
 *               <td><h4 align="center">Rev        </h4></td>
 *               <td><h4 align="center">Date       </h4></td>
 *               <td><h4 align="center">Author     </h4></td>
 *               <td><h4 align="center">Description</h4></td>
 *           </tr>
 *           <tr>
 *               <td><h5 align="left">O           </h5></td>
 *               <td><h5 align="left">23-JUN-97   </h5></td>
 *               <td><h5 align="left">Eoin Flannery</h5></td>
 *               <td><h5 align="left">Original    </h5></td>
 *           </tr>
 *       </table>
 */
/*  =================================================================== */
public class InvalidAddressException extends BusinessObjectException {
   
   public InvalidAddressException () {
      super("");
   }
   public InvalidAddressException (String aValue) {
      super("Invalid Address Exception :" + aValue);
   }


}
