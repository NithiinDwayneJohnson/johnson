/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Country.java                                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:43 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Country                                                 */
/**
 * This class represents a given country.
 */
/*======================================================================*/
public  class  Country  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Country:Attributes preserve=yes

//##End   Country:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String countryCode;
   private String countryName;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCountryCode                                   */
        /*                                                              */
        /**
         * This method returns the value of the country code.
         *  
         * @return      :String -
         *                 The value of the country code.
         */
        /*==============================================================*/
   public  String  getCountryCode (
                                  )
   {
//##Begin Country:getCountryCode() preserve=no

      fetch ();

      return (countryCode);

//##End   Country:getCountryCode()
   }

        /*==============================================================*/
        /* OPERATION:  getCountryName                                   */
        /*                                                              */
        /**
         * This method returns the value of the country name.
         *  
         * @return      :String -
         *                 The value of the country name.
         */
        /*==============================================================*/
   public  String  getCountryName (
                                  )
   {
//##Begin Country:getCountryName() preserve=no

      fetch ();

      return (countryName);

//##End   Country:getCountryName()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCountryCode                                   */
        /*                                                              */
        /**
         * This method sets the value of the country code.
         *  
         * @param       aValue:String
         *                 The value of the country code.
         */
        /*==============================================================*/
    public void  setCountryCode (
                           String  aValue
                          )
   {
//##Begin Country:setCountryCode(String) preserve=no

      if (countryCode == aValue) {
         return;
      }

      if (countryCode != null) {
         if (countryCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = countryCode;
      countryCode = aValue;

      setDirty ("countryCode" , myOldValue , countryCode);

      firePropertyChange ("countryCode", myOldValue, countryCode);

//##End   Country:setCountryCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setCountryName                                   */
        /*                                                              */
        /**
         * This method sets the value of the country name.
         *  
         * @param       aValue:String
         *                 The value of the country name.
         */
        /*==============================================================*/
	public	void  setCountryName (
                           String  aValue
                          )
   {
//##Begin Country:setCountryName(String) preserve=no

      if (countryName == aValue) {
         return;
      }

      if (countryName != null) {
         if (countryName.equals (aValue)) {
            return;
         }
      }

      String myOldValue = countryName;
      countryName = aValue;

      setDirty ("countryName" , myOldValue , countryName);

      firePropertyChange ("countryName", myOldValue, countryName);

//##End   Country:setCountryName(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Country:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (Country.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      Country  myOther  = (Country) aObject;

      try {
         String myCountryCode = getCountryCode ();
         if (myCountryCode != null) {
            if ( ! (myCountryCode.equals (myOther.getCountryCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCountryCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Country::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Country:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Country:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myCountryCode = getCountryCode ();
         if (myCountryCode != null) {
            myHashCode += (37 * myHashCode) + (myCountryCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Country::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Country:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin Country:processRestoreResult(Object) preserve=no

      Country  myOther  = (Country) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCountryCode (myOther.getCountryCode ());
         setCountryName (myOther.getCountryName ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Country::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Country:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Country:printOut() preserve=no

      try {
         System.out.println ("Country:");
         System.out.println ("   countryCode: " + getCountryCode ());
         System.out.println ("   countryName: " + getCountryName ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Country:printOut()
   }


}
