/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Airport.java                                            */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 December 20 at 19:09:04 CST                        */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.util.Vector;

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Airport                                                 */
/**
 * This class represents a given airport. There are airports that share the
 * same code. 
 */
/*======================================================================*/
public  class  Airport  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Airport:Attributes preserve=yes

//##End   Airport:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String  airportCode;
   private String  airportName;
   private Address address;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getAirportCode                                   */
        /*                                                              */
        /**
         * This method returns the value of the airport code name.
         *  
         * @return      :String -
         *                 The value of the airport code name.
         */
        /*==============================================================*/
   public  String  getAirportCode (
                                  )
   {
//##Begin Airport:getAirportCode() preserve=no

      fetch ();

      return (airportCode);

//##End   Airport:getAirportCode()
   }

        /*==============================================================*/
        /* OPERATION:  getAirportName                                   */
        /*                                                              */
        /**
         * This method returns the value of the airport name.
         *  
         * @return      :String -
         *                 The value of the airport name.
         */
        /*==============================================================*/
   public  String  getAirportName (
                                  )
   {
//##Begin Airport:getAirportName() preserve=no

      fetch ();

      return (airportName);

//##End   Airport:getAirportName()
   }

        /*==============================================================*/
        /* OPERATION:  getAddress                                       */
        /*                                                              */
        /**
         * This method returns the value of the "address" attribute.
         *  
         * @return      :Address -
         *                 The value of the "address" attribute.
         */
        /*==============================================================*/
   public  Address  getAddress (
                               )
   {
//##Begin Airport:getAddress() preserve=no

      fetch ();

      return (address);

//##End   Airport:getAddress()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setAirportCode                                   */
        /*                                                              */
        /**
         * This method sets the value of the airport code name.
         *  
         * @param       aValue:String
         *                 The value of the airport code name.
         */
        /*==============================================================*/
    public  void  setAirportCode (
                           String  aValue
                          )
   {
//##Begin Airport:setAirportCode(String) preserve=no

      if (airportCode == aValue) {
         return;
      }

      if (airportCode != null) {
         if (airportCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = airportCode;
      airportCode = aValue;

      setDirty ("airportCode" , myOldValue , airportCode);

      firePropertyChange ("airportCode", myOldValue, airportCode);

//##End   Airport:setAirportCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setAirportName                                   */
        /*                                                              */
        /**
         * This method sets the value of the airport name.
         *  
         * @param       aValue:String
         *                 The value of the airport name.
         */
        /*==============================================================*/
    public  void  setAirportName (
                           String  aValue
                          )
   {
//##Begin Airport:setAirportName(String) preserve=no

      if (airportName == aValue) {
         return;
      }

      if (airportName != null) {
         if (airportName.equals (aValue)) {
            return;
         }
      }

      String myOldValue = airportName;
      airportName = aValue;

      setDirty ("airportName" , myOldValue , airportName);

      firePropertyChange ("airportName", myOldValue, airportName);

//##End   Airport:setAirportName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setAddress                                       */
        /*                                                              */
        /**
         * This method sets the value of the "address" attribute.
         *  
         * @param       aValue:Address
         *                 The value of the "address" attribute.
         */
        /*==============================================================*/
   public  void  setAddress (
                                Address  aValue
                               )
   {
//##Begin Airport:setAddress(Address) preserve=no

      if (address == aValue) {
         return;
      }

      if (address != null) {
         if (address.equals (aValue)) {
            return;
         }
      }

      Address myOldValue = address;
      address = aValue;

      setDirty ("address" , myOldValue , address);

      firePropertyChange ("address", myOldValue, address);

//##End   Airport:setAddress(Address)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  addReferencedBusinessObjects                     */
        /*                                                              */
        /**
         * This method is called to obtain active references to other BO's.
         *  
         * @param       aContainer:Vector
         *                 The object into which references are to be
         *                 stored.
         */
        /*==============================================================*/
   public  void  addReferencedBusinessObjects (
                                               Vector  aContainer
                                              )
   {
//##Begin Airport:addReferencedBusinessObjects(Vector) preserve=no

      super.addReferencedBusinessObjects(aContainer);

      if (address != null) {
         aContainer.addElement(address);
      }


     return;
//##End   Airport:addReferencedBusinessObjects(Vector)
   }

        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Airport:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (Airport.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      Airport  myOther  = (Airport) aObject;

      try {
         String myAirportCode = getAirportCode ();
         if (myAirportCode != null) {
            if ( ! (myAirportCode.equals (myOther.getAirportCode ()))) {
               return (false);
            }
         }
         else if (myOther.getAirportCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Airport::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Airport:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Airport:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myAirportCode = getAirportCode ();
         if (myAirportCode != null) {
            myHashCode += (37 * myHashCode) + (myAirportCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Airport::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Airport:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin Airport:processRestoreResult(Object) preserve=no

      Airport  myOther  = (Airport) aObject;

      try {
         super.processRestoreResult  (myOther);
         setAirportCode (myOther.getAirportCode ());
         setAirportName (myOther.getAirportName ());
         setAddress (myOther.getAddress ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Airport::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Airport:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Airport:printOut() preserve=no

      try {
         System.out.println ("Airport:");
         System.out.println ("   airportCode: " + getAirportCode ());
         System.out.println ("   airportName: " + getAirportName ());
         Address myAddress = getAddress ();
         if (myAddress != null) {
            myAddress.printOut ();
         }
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Airport:printOut()
   }


}
