/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      AbstractPhoneLocale.java                                */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 16 at 13:31:34 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       AbstractPhoneLocale                                     */
/**
 * The abstract phone locale is an implementation of the PhoneLocale
 * interface. It provides base behavior for all implementations of a
 * PhoneLocale. The most important functionality provided by this class is
 * defining conversion and mapping rules for telephone numbers. Every
 * Locale can accept different representations of a phone number. In the
 * case of the USA, (847)-555-1212 and (847) 555-1212 or 847-555-1212 are
 * all valid phone numbers. The locale must provide rules (regular
 * expressions) that validates different representations.
 * <p>
 * For each accepted representation, the phone locale must provide a
 * conversion rule. This rule takes a phone number and returns it in the
 * normalized format accepted by this class. The format is as follows:
 * <p>
 * "C:(\\d*)A:(\\d+)P:(\\d+)E:(\\d*)"
 * <p>
 * Which is a country code (optional) followed by area code, phone number
 * and extension.
 * <p>
 * Thus every phone locale subclass must define acceptable representations
 * and rules to convert from those representations to the standard format.
 * For example a rule for the US:
 * <p>
 * {"(\\d{3})(\\d{3}\\d{4})"           , "C:A:$1P:$2E:"   }
 * <p>
 * This accepts number in the 8475551212 format and break
 * <p>
 * the supplied number into:
 * <p>
 * C:A:847:P:5551212E:
 * <p>
 * No country code.
 * <p>
 * Area code of 847
 * <p>
 * Phone 5551212
 * <p>
 * No extension.
 * <p>
 * The locale author can specify any rules as long as he/she can convert
 * the result to the common format. These rules conform to the Perl regular
 * expression. There many books on the subject.
 */
/*======================================================================*/
public abstract  class  AbstractPhoneLocale  implements  PhoneLocale
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin AbstractPhoneLocale:Attributes preserve=yes

//##End   AbstractPhoneLocale:Attributes

    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   protected static Pattern globalMatchPattern;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getGlobalMatchPattern                            */
        /*                                                              */
        /**
         * This method returns the value of the global match patter of the
         * form:
         * <p>
         * country code:area code:phone number:extension.
         *  
         * @return      :Pattern -
         *                 The value of the global match patter of the
         *                 form:
         * <p>
         *                 country code:area code:phone number:extension.
         */
        /*==============================================================*/
   public static  Pattern  getGlobalMatchPattern (
                                                 )
   {
//##Begin AbstractPhoneLocale:getGlobalMatchPattern() preserve=no

      return (globalMatchPattern);

//##End   AbstractPhoneLocale:getGlobalMatchPattern()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setGlobalMatchPattern                            */
        /*                                                              */
        /**
         * This method sets the value of the global match patter of the
         * form:
         * <p>
         * country code:area code:phone number:extension.
         *  
         * @param       aValue:Pattern
         *                 The value of the global match patter of the
         *                 form:
         * <p>
         *                 country code:area code:phone number:extension.
         */
        /*==============================================================*/
   public static  void  setGlobalMatchPattern (
                                               Pattern  aValue
                                              )
   {
//##Begin AbstractPhoneLocale:setGlobalMatchPattern(Pattern) preserve=no

      globalMatchPattern = aValue;

//##End   AbstractPhoneLocale:setGlobalMatchPattern(Pattern)
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Checks the validity of a phone number in string format.
         *  
         * @param       phoneNumber:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                             String  phoneNumber
                            )
   {
//##Begin AbstractPhoneLocale:isValid(String) preserve=yes
      Pattern           pattern = null;
      Matcher			matcher = null;
	
      if (phoneNumber == null) return false;

      //===============================================================
      // Attempt to compile the pattern. If the pattern is not valid,
      // report the error.
      //===============================================================

      String rules[][] = getRules();

      for (int i = 0; i < rules.length; i++) {

	 try {                         
	    pattern = Pattern.compile(rules[i][0]);
	 } catch(PatternSyntaxException e) {
	    e.printStackTrace();
	    return (false);
	 }
	 matcher = pattern.matcher(phoneNumber);
	 if ( matcher.matches() ) {
	    return (true);
	 }
      }

      return (false);

//##End   AbstractPhoneLocale:isValid(String)
   }

        /*==============================================================*/
        /* OPERATION:  setPhoneNumberToEmpty                            */
        /*                                                              */
        /**
         * This is usually prefills a phone object with nulls.
         *  
         * @param       phoneNumber:PhoneNumber
         */
        /*==============================================================*/
   public  void  setPhoneNumberToEmpty (
                                        PhoneNumber  phoneNumber
                                       )
   {
//##Begin AbstractPhoneLocale:setPhoneNumberToEmpty(PhoneNumber) preserve=yes
      phoneNumber.setAreaCode(null);
      phoneNumber.setLocalPhoneNumber(null);
      phoneNumber.setExtension(null);
      phoneNumber.setCountryCode(null);
//##End   AbstractPhoneLocale:setPhoneNumberToEmpty(PhoneNumber)
   }

        /*==============================================================*/
        /* OPERATION:  getRules                                         */
        /*                                                              */
        /**
         * Returns the validation regular expresion.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public abstract  String[][]  getRules (
                                         );

        /*==============================================================*/
        /* OPERATION:  getCountryCode                                   */
        /*                                                              */
        /**
         * Returns the country code.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public abstract  String  getCountryCode (
                                           );

        /*==============================================================*/
        /* OPERATION:  parsePhoneNumber                                 */
        /*                                                              */
        /**
         * Parses a string representation of a phone and returns a phone
         * object, A null is returned if the phone number is invalid. The
         * implementation in this method expects the grouping of the
         * regular expression to return the area code followed by the phone
         * number. If the grouping differs, then this method must be
         * overridden.
         *  
         * @param       phoneNumberString:String
         * @param       phoneNumber:PhoneNumber
         */
        /*==============================================================*/
   public  void  parsePhoneNumber (
                                   String       phoneNumberString,
                                   PhoneNumber  phoneNumber
                                  )
   {
//##Begin AbstractPhoneLocale:parsePhoneNumber(String,PhoneNumber) preserve=yes
      Matcher      matcher;
      Pattern             pattern = null;
       
      if (phoneNumberString == null) {
	 setPhoneNumberToEmpty(phoneNumber);
	 return;
      }

      String rules[][] = getRules();
      setPhoneNumberToEmpty(phoneNumber);
      phoneNumber.setCountryCode(getCountryCode());

      for (int i = 0; i < rules.length; i++) {

	 //===============================================================
	 // Attempt to compile the pattern. If the pattern is not valid,
	 // report the error.
	 //===============================================================
	 try {
	    pattern = Pattern.compile(rules[i][0]);
	 } catch(PatternSyntaxException e) {
 	    e.printStackTrace();
	    continue;
	 }

	 //===============================================================
	 // Transform to standard format.
	 //===============================================================      
	 matcher = pattern.matcher(phoneNumberString);
	 if (matcher.matches()) {

	  	// Here we have a given string that matches a case rule (ex \d{3}\d{3}\d{4}) and wish to put that
	  	// string into another format rule (ex C:A:$1P:$2E:) using variable interpolation. 
	  	// See PhoneLocale for all the case-format rules. 
	    String myresult = matcher.replaceAll(rules[i][1]);
	    
	    //===============================================================
	    // Extract values from standard format
	    //=============================================================== 
	    Matcher matcherGlobal = globalMatchPattern.matcher(myresult);     
	  
	    if (matcherGlobal.matches()) {

	       for (int j = 0; j < matcherGlobal.groupCount(); j++) {

		  String resultgroup = null;

		  if (matcherGlobal.group(j).equals("")) {
		     resultgroup = null;
		  }
		  else {
		     resultgroup = matcherGlobal.group(j);
		  }
		  
		  switch(j) {

		     case 1:
			phoneNumber.setCountryCode(resultgroup);
			break;

		     case 2:
			phoneNumber.setAreaCode(resultgroup);
			break;

		     case 3:
			phoneNumber.setLocalPhoneNumber(resultgroup);
			break;

		     case 4:
			phoneNumber.setExtension(resultgroup);
			break;
		  }
	       }

	       if (phoneNumber.getCountryCode() == null) {
		  phoneNumber.setCountryCode(getCountryCode());
	       }

	       return;
	    }
	 }
      }

      return;

//##End   AbstractPhoneLocale:parsePhoneNumber(String,PhoneNumber)
   }

        /*==============================================================*/
        /* OPERATION:  getMaxAreaCodeLength                             */
        /*                                                              */
        /**
         * Returns the maximum length of the area code.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public abstract  int  getMaxAreaCodeLength (
                                              );

        /*==============================================================*/
        /* OPERATION:  getCountryCodeLength                             */
        /*                                                              */
        /**
         * Returns the country code length.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public abstract  int  getCountryCodeLength (
                                              );

        /*==============================================================*/
        /* OPERATION:  getMaxLocalPhoneNumberLength                     */
        /*                                                              */
        /**
         * Returns the maximum length of a local phone number.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public abstract  int  getMaxLocalPhoneNumberLength (
                                                      );

        /*==============================================================*/
        /* OPERATION:  getFormatFillCharacter                           */
        /*                                                              */
        /**
         * Returns the format fill character. This is used in case one of
         * the attributes is missing. 
         *  
         * @return      :char -
         */
        /*==============================================================*/
   public abstract  char  getFormatFillCharacter (
                                                 );

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberShort                     */
        /*                                                              */
        /**
         * Returns a formatted phone number in simple form. This usually is
         * the area code followed by the phone number.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public abstract  String  getFormattedPhoneNumberShort (
                                                          PhoneNumber  phoneNumber
                                                         );

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberLong                      */
        /*                                                              */
        /**
         * Returns a formatted phone number in long form. This usually is
         * the country code followed by the area code and the phone number.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public abstract  String  getFormattedPhoneNumberLong (
                                                         PhoneNumber  phoneNumber
                                                        );

        /*==============================================================*/
        /* OPERATION:  getUnformattedPhoneNumberShort                   */
        /*                                                              */
        /**
         * Returns an unformatted phone number in simple form. This usually
         * is the area code followed by the phone number. If any of the
         * fields are missing the PhoneLocale typically fills these with a
         * filler character.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public abstract  String  getUnformattedPhoneNumberShort (
                                                            PhoneNumber  phoneNumber
                                                           );


    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin AbstractPhoneLocale:StaticInitializer preserve=yes
   static {
      try {
	 globalMatchPattern = Pattern.compile("C:(\\d*)A:(\\d+)P:(\\d+)E:(\\d*)");
      } catch(PatternSyntaxException e) {
	 e.printStackTrace();
      }
   }

//##End   AbstractPhoneLocale:StaticInitializer

}
