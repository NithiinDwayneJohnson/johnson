/*======================================================================*/
/* MODULE:      AddressAccuracyEJBBusinessDelegate.java                */
/*======================================================================*/


/*======================================================================*/
/*                              Package Statement                       */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;
import java.text.MessageFormat;

import COM.novusnet.vision.java.commonbos.Address;
import COM.novusnet.vision.java.commonbos.AddressAccuracyKeyDescriptor;
import COM.novusnet.vision.java.commonbos.InvalidAddressException;
import COM.novusnet.vision.java.commonbos.PostalCode;
import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.GenericSchema;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;
import COM.novusnet.vision.java.utility.typeconversion.Convert;
import COM.dfs.cms.serviceinvocation.DFSClientConsumerServiceAccess;
import com.dfs.commonserver.dao.DAOException;
import com.dfs.dmdhtxns.vo.INPUTTXNADDRESSSTD_VO;
import com.dfs.dmdhtxns.vo.OUTPUTTXNADDRESSSTD_VO;



/**
 * CLASS: AddressAccuracyEJBBusinessDelegate
 * 
 **
 * This implements the GenericSchema so that the vision framework will
 * call this as configured by the property file pidfactory.properties
 * This file itself can be downloaded from our webservvice application.
 * 
 * This Schema is called BusinessDelegate whose job is to
 * translate the Orion Objects into EJB Objects for use with the EJB proxy
 */
public class AddressSchema implements GenericSchema {


	/**
	 * OPERATION:	store
	 * 
	 * @param	aPID:GenericPID
	 * @param	aIStream:ObjectInputStream
	 * @throws	PersistenceException
	 */
	public void store(ObjectInputStream aIStream, GenericPID aPID) throws PersistenceException {
		throw new PersistenceException("AddressAccuracyEJBBusinessDelegate: TXNADDRESSSTD does not support the 'store' operation");
	}


	/**
	 * OPERATION:	Delete
	 * 
	 * @param	aPID:GenericPID
	 * @param	aIStream:ObjectInputStream
	 * @throws	PersistenceException
	 */
	public void Delete(ObjectInputStream aIStream, GenericPID aPID) throws PersistenceException {
		throw new PersistenceException("AddressAccuracyEJBBusinessDelegate: TXNADDRESSSTD does not support the 'Delete' operation");
	}


	/**
	 * OPERATION:	restore
	 *
	 * @param	aPID:GenericPID
	 * @param	aIStream:ObjectOutputStream
	 * @throws	PersistenceException
	 */
	public void restore(ObjectOutputStream aOStream, GenericPID aPID) throws PersistenceException {
		try {
			AddressAccuracyKeyDescriptor key = (AddressAccuracyKeyDescriptor) aPID.readObject();
			Address myAddress = this.readAddressAccuracy(key);
			aOStream.writeObject(new ReferenceHolder(myAddress));
		}
		catch (Exception t) {
			throw new PersistenceException(t);
		}
	}



	/**
	 * OPERATION: readAddressAccuracy
	 * 
	 **
	 *	The read for address accuracy, also known as finalist, actually contains
	 * two different type of calls. The first is fillCityState which will fill in the
	 * city and state given and postal code. A function code value of 1 indicates this call.
	 * The other call is verifyAndCorrectAddress that will take a given full address and try to 
	 * verify that it is correct. A function code of 2 indicates this call.
	 * 
	 * @param		key:AddressAccuracyKeyDescriptor
	 * @return		Address
	 * 
	 */
	public Address readAddressAccuracy(AddressAccuracyKeyDescriptor key) throws RemoteException, DAOException, InvalidAddressException {
		Address result = null;


		INPUTTXNADDRESSSTD_VO input = new INPUTTXNADDRESSSTD_VO();
		if (key.getAddress().getStreet1() != null)
			input.setAddressline1(key.getAddress().getStreet1().toUpperCase());
			
		if (key.getAddress().getStreet2() != null)
			input.setAddressline2(key.getAddress().getStreet2().toUpperCase());
			
		if (key.getAddress().getCity() != null)
			input.setCity(key.getAddress().getCity().toUpperCase());
			
		if (key.getAddress().getState() != null)
			input.setStateus(key.getAddress().getState().getStateCode().toUpperCase());
			
		if (key.getAddress().getPostalCode() != null) {
			if (key.getAddress().getPostalCode().getUnformattedPostalCode().length() >= 9) {
		 		input.setZip4(key.getAddress().getPostalCode().getUnformattedPostalCode().substring(5,9));
	       }
		}


		if (key.getAddress().getPostalCode() != null)
			input.setZip5(extractZipCode(key.getAddress().getPostalCode()));



		OUTPUTTXNADDRESSSTD_VO output = null;
		if (key.getFunctionCode() == '1' /*AddressAccuracy.FILL_IN_CITY_STATE*/) {
			output = DFSClientConsumerServiceAccess.getAddressServicesInterface().fillCityState(input);
		}
		else if (key.getFunctionCode() == '2' /*AddressAccuracy.VERIFY_AND_CORRECT_ADDRESS*/) {
			output = DFSClientConsumerServiceAccess.getAddressServicesInterface().verifyAndCorrectAddress(input);
		}


		if (output != null) {
			result = new Address();
			result.setStreet1(output.getAddressline1().trim());
			result.setStreet2(output.getAddressline2().trim());
			result.setCity(output.getCity().trim());
			
			// 03-22-2005, HHU
			// This fix will have Finalist popup to give you 
			// what the last four digits of the zip code should be if needed. 
			//result.setPostalCode(new PostalCode(output.getZip5()));
			// 05-03-2005, JLC
			// Added trim to both zip4 and zip5.  There are addresses which return "   " for zip4.
			// new PostalCode was returning a zip of "00000-0000" if zip 4 had blanks.
			result.setPostalCode(new PostalCode(output.getZip5().trim() + output.getZip4().trim()));
			
			result.setStateAndCountryFromStateCode(output.getStateus());

                         /*********************************************************/
			 /* 05-03-2005 JLC, copied logic from AddressAccuracyJDBC */
			 /* schema file for bar code.                             */
                         /*********************************************************/
                         /* Get the Barcode ABCW seq and check digit and concat   */
                         /* them together for our bar code.  Bar code must be kept*/
	                 /* as follows: XXY where XX is the ABCW seq and Y is the */
	                 /* check digit.  If XX has a length=1, we must put in a  */
	                 /* blank ex:     "826" is valid,                         */
			 /*               "86"  is not valid,                     */
	                 /*               "8 6" is valid.                         */
	                 /* Therefore, if ABCW seq comes in with as length one,   */
	                 /* or zero, fill in with blank spaces.                   */
                         /*********************************************************/
			String myTotalBarCode;
			String tempBarCodeSeq = output.getBarcodeabcwseq().trim();
			String tempBarCodeChk = output.getBarcodeckdigit().trim();
			
			if (tempBarCodeSeq.length() >= 2) {
			   myTotalBarCode = tempBarCodeSeq.substring(0, 2) + tempBarCodeChk;
			}
			else if (tempBarCodeSeq.length() == 1) {
			   myTotalBarCode = tempBarCodeSeq + " " + tempBarCodeChk;
			}
			else {
			   myTotalBarCode = "  " + tempBarCodeChk;
			}
			
			result.setBarCode(myTotalBarCode);

			int errorCode = 0;
			String returnCode = null;
			String informationCodes = null;
			String reasonCodes = null;


			errorCode = Convert.intoInt(output.getFinalisterrormessagecode1());
			returnCode = output.getFinalistreturncode1();
			informationCodes = output.getFinalistaddressinfocodes();
			reasonCodes = output.getFinalistreasoncodes();
			
			if (errorCode != 0) {
				String messageText = "Unable to identify new address as valid. Confirm change of address. ";
				if (returnCode.equals("E")) {
					messageText = "System problem with address accuracy software. When reporting this problem use the following error message:{0} {1} {2} ";
					Object arguments[] = { new String(Convert.intoString(errorCode)), new String(informationCodes), new String(reasonCodes)};
					messageText = MessageFormat.format(messageText, arguments);
				}
				throw new InvalidAddressException(messageText);
			}
		}


		return result;
	}
	
	/**
	*	OPERATION: extractZipCode
	*	
	*	@param		postalCode:PostalCode
	* 	@return		returnZip:String
	*/


	private String extractZipCode(PostalCode postalCode)
	{
		String returnZip = "";
		try {
        	returnZip = postalCode.getUnformattedPostalCode().substring(0,5);
	    }                    
	    catch (StringIndexOutOfBoundsException e){
	    /* if we get this exception it is because the zip code is incomplete 
	       so if we have at least the first five digits then we can set this
	       and ignore the missing zip+4 part.
	       otherwise dont attempt a substring just fillin whatever we have.
	       */
   	       if (postalCode.getUnformattedPostalCode().length() >= 5) {
   	       	returnZip = postalCode.getUnformattedPostalCode().substring(0,5);
	       }
	       else {
	       	returnZip = postalCode.getUnformattedPostalCode();
	       }
	  	}


	  	return ( returnZip );
	}
}
