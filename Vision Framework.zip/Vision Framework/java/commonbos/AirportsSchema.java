/*======================================================================*/
/* MODULE:      AirportsEJBBusinessDelegate.java                        */
/*======================================================================*/


/*======================================================================*/
/*                              Package Statement                       */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;

import COM.novusnet.vision.java.commonbos.Address;
import COM.novusnet.vision.java.commonbos.Airport;
import COM.novusnet.vision.java.commonbos.Airports;
import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.GenericSchema;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;
import COM.dfs.cms.serviceinvocation.DFSClientConsumerServiceAccess;
import com.dfs.commonserver.dao.DAOException;
import com.dfs.dmdhtxns.vo.INPUTTXNAIRPORTSEARCH_VO;
import com.dfs.dmdhtxns.vo.OUTPUTTXNAIRPORTSEARCH_VO;


/*======================================================================*/
/*                               Class Statement                        */
/*======================================================================*/
public class AirportsSchema implements GenericSchema {


	private static Airports result = null;
	private static boolean debug = false;


	public void store(ObjectInputStream aIStream, GenericPID aPID)
		throws PersistenceException {
		throw new PersistenceException("AirportsEJBBusinessDelegate : TXNAIRPORTSEARCH does not support the 'store' operation");
	}


	public void Delete(ObjectInputStream aIStream, GenericPID aPID)
		throws PersistenceException {
		throw new PersistenceException("AirportsEJBBusinessDelegate : TXNAIRPORTSEARCH does not support the 'Delete' operation");
	}


	public void restore(ObjectOutputStream aOStream, GenericPID aPID)
		throws PersistenceException {
		try {
			Airports myAirports = this.searchAirports();


			aOStream.writeObject(new ReferenceHolder(myAirports));
		} catch (Exception t) {
			throw new PersistenceException(t);
		}
	}


	private Airports searchAirports() throws RemoteException, DAOException {


		if (result != null) {
			return result;
		}


		result = new Airports();


		INPUTTXNAIRPORTSEARCH_VO ivo = new INPUTTXNAIRPORTSEARCH_VO();
		// Start with A
		ivo.setKeyfieldsearchposition("A");
		OUTPUTTXNAIRPORTSEARCH_VO[] ovo = null;


		try {
			ovo = DFSClientConsumerServiceAccess.getSearchServicesInterface().searchAirport(ivo);


			populateResults(result, ovo);


			if (debug) {
				System.out.println(" Executed Airport Search " + ovo.length);
				System.out.println(
					" Last airport city= " + ovo[ovo.length - 1].getAirportcity());
				System.out.println(
					" Last airport code= " + ovo[ovo.length - 1].getAirportcode());
				System.out.println(
					" Last airport name= " + ovo[ovo.length - 1].getAirportname());
				System.out.println(
					" Last airport state= " + ovo[ovo.length - 1].getAirportstate());
			}
		} catch (Throwable t) {
			throw new PersistenceException(t);
		}
		return result;
	}


	private void populateResults(
		Airports myAirports,
		OUTPUTTXNAIRPORTSEARCH_VO[] ovo) {
		Airport myAirport = null;
		Address myAddress = null;


		for (int i = 0; i < ovo.length; i++) {
			myAirport = new Airport();
			myAddress = new Address();


			myAddress.setCity(ovo[i].getAirportcity());
			myAddress.setStateAndCountryFromStateCode(ovo[i].getAirportstate());
			myAirport.setAirportCode(ovo[i].getAirportcode());
			myAirport.setAirportName(ovo[i].getAirportname());
			myAirport.setAddress(myAddress);


			myAirports.put(myAirport.getAirportCode(), myAirport);


		}


		return;
	}
}
