/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      State.java                                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:35 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       State                                                   */
/**
 * A State represents a named geographical region with its own laws(??only
 * in America!!), language or culture in a given country. 
 */
/*======================================================================*/
public  class  State  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin State:Attributes preserve=yes

//##End   State:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String fullName;
   private String stateCode;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getFullName                                      */
        /*                                                              */
        /**
         * This method returns the value of the "fullName" attribute.
         *  
         * @return      :String -
         *                 The value of the "fullName" attribute.
         */
        /*==============================================================*/
   public  String  getFullName (
                               )
   {
//##Begin State:getFullName() preserve=no

      fetch ();

      return (fullName);

//##End   State:getFullName()
   }

        /*==============================================================*/
        /* OPERATION:  getStateCode                                     */
        /*                                                              */
        /**
         * This method returns the value of the "stateCode" attribute.
         *  
         * @return      :String -
         *                 The value of the "stateCode" attribute.
         */
        /*==============================================================*/
   public  String  getStateCode (
                                )
   {
//##Begin State:getStateCode() preserve=no

      fetch ();

      return (stateCode);

//##End   State:getStateCode()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setFullName                                      */
        /*                                                              */
        /**
         * This method sets the value of the "fullName" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "fullName" attribute.
         */
        /*==============================================================*/
   public  void  setFullName (
                              String  aValue
                             )
   {
//##Begin State:setFullName(String) preserve=no

      if (fullName == aValue) {
         return;
      }

      if (fullName != null) {
         if (fullName.equals (aValue)) {
            return;
         }
      }

      String myOldValue = fullName;
      fullName = aValue;

      setDirty ("fullName" , myOldValue , fullName);

      firePropertyChange ("fullName", myOldValue, fullName);

//##End   State:setFullName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setStateCode                                     */
        /*                                                              */
        /**
         * This method sets the value of the "stateCode" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "stateCode" attribute.
         */
        /*==============================================================*/
   public  void  setStateCode (
                               String  aValue
                              )
   {
//##Begin State:setStateCode(String) preserve=no

      if (stateCode == aValue) {
         return;
      }

      if (stateCode != null) {
         if (stateCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = stateCode;
      stateCode = aValue;

      setDirty ("stateCode" , myOldValue , stateCode);

      firePropertyChange ("stateCode", myOldValue, stateCode);

//##End   State:setStateCode(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin State:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (State.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      State  myOther  = (State) aObject;

      try {
         String myFullName = getFullName ();
         if (myFullName != null) {
            if ( ! (myFullName.equals (myOther.getFullName ()))) {
               return (false);
            }
         }
         else if (myOther.getFullName () != null) {
               return (false);
         }

         String myStateCode = getStateCode ();
         if (myStateCode != null) {
            if ( ! (myStateCode.equals (myOther.getStateCode ()))) {
               return (false);
            }
         }
         else if (myOther.getStateCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "State::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   State:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin State:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myFullName = getFullName ();
         if (myFullName != null) {
            myHashCode += (37 * myHashCode) + (myFullName.hashCode ());
         }
         String myStateCode = getStateCode ();
         if (myStateCode != null) {
            myHashCode += (37 * myHashCode) + (myStateCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "State::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   State:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin State:processRestoreResult(Object) preserve=no

      State  myOther  = (State) aObject;

      try {
         super.processRestoreResult  (myOther);
         setFullName (myOther.getFullName ());
         setStateCode (myOther.getStateCode ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "State::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   State:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin State:printOut() preserve=no

      try {
         System.out.println ("State:");
         System.out.println ("   fullName: " + getFullName ());
         System.out.println ("   stateCode: " + getStateCode ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   State:printOut()
   }


}
