package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class OccupancysResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String description
                                          )
   {
      Occupancy occ = new Occupancy();

      occ.setCode(code);
      occ.setDescription(description);

      return occ;

   }
}
