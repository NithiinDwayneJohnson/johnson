package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class EthnicitiesResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String description
                                          )
   {
      Ethnicity a =  new Ethnicity ();
      a.setCode( code );
      a.setDescription( description );
      return a;
   }
}
