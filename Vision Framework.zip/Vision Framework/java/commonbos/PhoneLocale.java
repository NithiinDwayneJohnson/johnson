/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PhoneLocale.java                                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 25 at 16:00:50 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.Serializable;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PhoneLocale                                             */
/**
 * The PhoneLocale interface is implemented on a per locale basis to
 * provide metadata, conversion and validation methods. Every locale will
 * have a specific instance of a PhoneLocale object. The system will
 * provide a default phone locale object from which all specific instances
 * will inherit.
 */
/*======================================================================*/
public interface  PhoneLocale  extends  Serializable
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PhoneLocale:Attributes preserve=yes

//##End   PhoneLocale:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Checks the validity of a phone number in string format.
         *  
         * @param       phoneNumber:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                             String  phoneNumber
                            );

        /*==============================================================*/
        /* OPERATION:  parsePhoneNumber                                 */
        /*                                                              */
        /**
         * Parses a string representation of a phone and returns a phone
         * object, A null is returned if the phone number is invalid.
         *  
         * @param       phoneNumberString:String
         * @param       phoneNumber:PhoneNumber
         */
        /*==============================================================*/
   public  void  parsePhoneNumber (
                                   String       phoneNumberString,
                                   PhoneNumber  phoneNumber
                                  );

        /*==============================================================*/
        /* OPERATION:  getRules                                         */
        /*                                                              */
        /**
         * Returns the validation regular expresion.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public  String[][]  getRules (
                                );

        /*==============================================================*/
        /* OPERATION:  getCountryCode                                   */
        /*                                                              */
        /**
         * Returns the country code.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getCountryCode (
                                  );

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberShort                     */
        /*                                                              */
        /**
         * Returns a formatted phone number in simple form. This usually is
         * the area code followed by the phone number.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberShort (
                                                 PhoneNumber  phoneNumber
                                                );

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberLong                      */
        /*                                                              */
        /**
         * Returns a formatted phone number in long form. This usually is
         * the country code followed by the area code and the phone number.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberLong (
                                                PhoneNumber  phoneNumber
                                               );

        /*==============================================================*/
        /* OPERATION:  getMaxAreaCodeLength                             */
        /*                                                              */
        /**
         * Returns the maximum length of the area code.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxAreaCodeLength (
                                     );

        /*==============================================================*/
        /* OPERATION:  getCountryCodeLength                             */
        /*                                                              */
        /**
         * Returns the country code length.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getCountryCodeLength (
                                     );

        /*==============================================================*/
        /* OPERATION:  getMaxLocalPhoneNumberLength                     */
        /*                                                              */
        /**
         * Returns the maximum length of a local phone number.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxLocalPhoneNumberLength (
                                             );

        /*==============================================================*/
        /* OPERATION:  getFormatFillCharacter                           */
        /*                                                              */
        /**
         * Returns the format fill character. This is used in case one of
         * the attributes is missing. 
         *  
         * @return      :char -
         */
        /*==============================================================*/
   public  char  getFormatFillCharacter (
                                        );

        /*==============================================================*/
        /* OPERATION:  getUnformattedPhoneNumberShort                   */
        /*                                                              */
        /**
         * Returns an unformatted phone number in simple form. This usually
         * is the area code followed by the phone number. If any of the
         * fields are missing the PhoneLocale typically fills these with a
         * filler character.
         *  
         * @param       phoneNumber:PhoneNumber
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPhoneNumberShort (
                                                   PhoneNumber  phoneNumber
                                                  );


}
