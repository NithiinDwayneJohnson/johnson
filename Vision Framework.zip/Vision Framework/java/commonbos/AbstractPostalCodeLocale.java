/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      AbstractPostalCodeLocale.java                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 23 at 11:58:27 GMT+00:00                  */
/*======================================================================*/


/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;


/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
import java.util.Vector;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/


/*======================================================================*/
/* CLASS:       AbstractPostalCodeLocale                                */
/**
 * This is a default implementation of PostalCodeLocale. For each locale, a
 * developer should subclass this class instead of creating a new
 * implmentation.
 */
/*======================================================================*/
public abstract  class  AbstractPostalCodeLocale  implements  PostalCodeLocale
{




    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/


    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin AbstractPostalCodeLocale:Attributes preserve=yes


//##End   AbstractPostalCodeLocale:Attributes


    /*==================================================================*/
    /* Class Attributes                                                 */
    /*==================================================================*/
   protected static Pattern globalMatchPattern;


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getGlobalMatchPattern                            */
        /*                                                              */
        /**
         * This method returns the value of the global match patter of the
         * form:
         * <p>
         * (.*)+
         *  
         * @return      :Pattern -
         *                 The value of the global match patter of the
         *                 form:
         * <p>
         *                 (.*)+
         */
        /*==============================================================*/
   public static  Pattern  getGlobalMatchPattern (
                                                 )
   {
//##Begin AbstractPostalCodeLocale:getGlobalMatchPattern() preserve=no


      return (globalMatchPattern);


//##End   AbstractPostalCodeLocale:getGlobalMatchPattern()
   }




    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setGlobalMatchPattern                            */
        /*                                                              */
        /**
         * This method sets the value of the global match patter of the
         * form:
         * <p>
         * (.*)+
         *  
         * @param       aValue:Pattern
         *                 The value of the global match patter of the
         *                 form:
         * <p>
         *                 (.*)+
         */
        /*==============================================================*/
   public static  void  setGlobalMatchPattern (
                                               Pattern  aValue
                                              )
   {
//##Begin AbstractPostalCodeLocale:setGlobalMatchPattern(Pattern) preserve=no


      globalMatchPattern = aValue;


//##End   AbstractPostalCodeLocale:setGlobalMatchPattern(Pattern)
   }




    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * This method checks the validity of a postal code. The Locale
         * specific implementation must return one or mopre regular
         * expressions in which the postal code is checked againts.
         *  
         * @param       postalCode:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                             String  postalCode
                            )
   {
//##Begin AbstractPostalCodeLocale:isValid(String) preserve=yes
	Matcher      matcher;
    Pattern             pattern = null;


    if (postalCode == null) return false;


      //===============================================================
      // Attempt to compile the pattern. If the pattern is not valid,
      // report the error.
      //===============================================================

    String rules[][] = getRules();

    for (int i = 0; i < rules.length; i++) {

		try {                         
			pattern = Pattern.compile(rules[i][0]);
		} catch(PatternSyntaxException e) {
	    	e.printStackTrace();
	    	return (false);
	 	}

		matcher = pattern.matcher(postalCode);
	 	if ( matcher.matches() ) {
	    	return (true);
	 	}
     }


	return (false);


//##End   AbstractPostalCodeLocale:isValid(String)
   }


        /*==============================================================*/
        /* OPERATION:  parsePostalCode                                  */
        /*                                                              */
        /**
         * Parses a string representation of a postal code setting the
         * field in the PostalCode object. The Locale specific
         * implementation must return one or more regular expressions in
         * which the postal code is parsed against. 
         * <p>
         * These regular expressions are used for substitutions. 
         * <p>
         * Developers should ensure that the regular expression is grouped
         * in such a way to represent valid components of a postal code.
         * These components are then set on the PostalCode object in the
         * form of a vector. For example a valid US postal code is:
         * <p>
         * (/d{5})-(/d{4}) which is a 5 digit number followed by 4 digits
         * and separated by a dash. Notice the groupings which return the
         * two components. Groups are surrounded by the ( and ) characters.
         * <p>
         * In some cases, the regular expression and substitution
         * expression are different. Again taking the US as an example, a
         * zip code of 5 digits is valid but a developer might want to
         * enusre that the last 4 digits are 0's. The validation regular
         * expression thus is:
         * <p>
         * \d{5} and the substiutation regular expression is
         * <p>
         * ($1)(0000).
         *  
         * @param       postalCodeString:String
         * @param       postalCode:PostalCode
         */
        /*==============================================================*/
   public  void  parsePostalCode (
                                  String      postalCodeString,
                                  PostalCode  postalCode
                                 )
   {
//##Begin AbstractPostalCodeLocale:parsePostalCode(String,PostalCode) preserve=yes
    Matcher      matcher;
    Pattern             pattern = null;
	
 
    if (postalCodeString == null) {
		postalCode.setPostalCodeComponents(null);
	 	return;
    }


    String rules[][] = getRules();


    for (int i = 0; i < rules.length; i++) {


	 //===============================================================
	 // Attempt to compile the pattern. If the pattern is not valid,
	 // report the error.
	 //===============================================================
	 try {
	    pattern = Pattern.compile(rules[i][0]);
	 } catch(PatternSyntaxException e) {
 	    e.printStackTrace();
	    continue;
	 }


	 //===============================================================
	 // Transform to standard format.
	 //=============================================================== 
	 matcher = pattern.matcher(postalCodeString);     
	 if (matcher.matches()) {

		//String myresult = matcher.replaceAll(postalCodeString);
		// 09-01-2005, we should use the rules[i][1] to replace the original string.
		String myresult = matcher.replaceAll(rules[i][1]);

	    //===============================================================
	    // Extract values from standard format
	    //===============================================================      

		String [] myStrings = null;
		myStrings = myresult.split(globalMatchPattern.pattern());


	    if (myStrings != null) {
		    postalCode.setPostalCodeComponents(myStrings);
	    }
	    else {
	       postalCode.setPostalCodeComponents(null);
	    }


	 }
      }


      return;


//##End   AbstractPostalCodeLocale:parsePostalCode(String,PostalCode)
   }


        /*==============================================================*/
        /* OPERATION:  getRules                                         */
        /*                                                              */
        /**
         * Returns the validation and substitution regular expresions.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public abstract  String[][]  getRules (
                                         );


        /*==============================================================*/
        /* OPERATION:  getFormattedPostalCode                           */
        /*                                                              */
        /**
         * Returns a formatted representation of a postal code. Delegate to
         * locale subclass.
         *  
         * @param       postalCode:PostalCode
         * @return      :String -
         */
        /*==============================================================*/
   public abstract  String  getFormattedPostalCode (
                                                    PostalCode  postalCode
                                                   );


        /*==============================================================*/
        /* OPERATION:  getUnformattedPostalCode                         */
        /*                                                              */
        /**
         * Returns an unformatted representation of a postal code. The
         * default implementation simply concatenates all postal code
         * components.
         *  
         * @param       postalCode:PostalCode
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPostalCode (
                                             PostalCode  postalCode
                                            )
   {
//##Begin AbstractPostalCodeLocale:getUnformattedPostalCode(PostalCode) preserve=yes
      String myString = "";


      if (postalCode.getPostalCodeComponents() != null) {
	 for (int i = 0; i < postalCode.getPostalCodeComponents().length; i++) {
	    myString += postalCode.getPostalCodeComponents()[i];
	 }
      }


      return (myString);
//##End   AbstractPostalCodeLocale:getUnformattedPostalCode(PostalCode)
   }




    /*==================================================================*/
    /*==========================             ===========================*/
    /*========================== Initializer ===========================*/
    /*==========================             ===========================*/
    /*==================================================================*/
//##Begin AbstractPostalCodeLocale:StaticInitializer preserve=yes
   static {
      try {
      	 globalMatchPattern = Pattern.compile(":");
      } catch(PatternSyntaxException e) {
	 e.printStackTrace();
      }
   }


//##End   AbstractPostalCodeLocale:StaticInitializer


}
