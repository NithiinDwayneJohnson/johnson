/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PostalCodeLocale.java                                   */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 25 at 16:01:04 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.io.Serializable;

                /*======================================================*/
                /* Third-Party Classes                                  */
                /*======================================================*/

                /*======================================================*/
                /* Novus Classes                                        */
                /*======================================================*/

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PostalCodeLocale                                        */
/**
 * This interface must be implemented for each locale. It provides locale
 * specific behavior like formatting and validations.
 */
/*======================================================================*/
public interface  PostalCodeLocale  extends  Serializable
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PostalCodeLocale:Attributes preserve=yes

//##End   PostalCodeLocale:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Checks the validity of a postal code in string format.
         *  
         * @param       postalCode:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isValid (
                             String  postalCode
                            );

        /*==============================================================*/
        /* OPERATION:  parsePostalCode                                  */
        /*                                                              */
        /**
         * Parses a string representation of a postal code setting the
         * field in the PostalCode object.
         *  
         * @param       postalCodeString:String
         * @param       postalCode:PostalCode
         */
        /*==============================================================*/
   public  void  parsePostalCode (
                                  String      postalCodeString,
                                  PostalCode  postalCode
                                 );

        /*==============================================================*/
        /* OPERATION:  getRules                                         */
        /*                                                              */
        /**
         * Returns the validation and substitution regular expresions.
         *  
         * @return      :String[][] -
         */
        /*==============================================================*/
   public  String[][]  getRules (
                                );

        /*==============================================================*/
        /* OPERATION:  getFormattedPostalCode                           */
        /*                                                              */
        /**
         * Returns a formatted representation of a postal code.
         *  
         * @param       postalCode:PostalCode
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPostalCode (
                                           PostalCode  postalCode
                                          );

        /*==============================================================*/
        /* OPERATION:  getUnformattedPostalCode                         */
        /*                                                              */
        /**
         * Returns an unformatted representation of a postal code.
         *  
         * @param       postalCode:PostalCode
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPostalCode (
                                             PostalCode  postalCode
                                            );


}
