/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      StateToRegion.java                                      */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:46 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       StateToRegion                                           */
/**
 * Contains the State to Region mapping.
 */
/*======================================================================*/
public  class  StateToRegion  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin StateToRegion:Attributes preserve=yes

//##End   StateToRegion:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String stateCode;
   private String regionCode;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getStateCode                                     */
        /*                                                              */
        /**
         * This method returns the value of the "stateCode" attribute.
         *  
         * @return      :String -
         *                 The value of the "stateCode" attribute.
         */
        /*==============================================================*/
   public  String  getStateCode (
                                )
   {
//##Begin StateToRegion:getStateCode() preserve=no

      fetch ();

      return (stateCode);

//##End   StateToRegion:getStateCode()
   }

        /*==============================================================*/
        /* OPERATION:  getRegionCode                                    */
        /*                                                              */
        /**
         * This method returns the value of the "regionCode" attribute.
         *  
         * @return      :String -
         *                 The value of the "regionCode" attribute.
         */
        /*==============================================================*/
   public  String  getRegionCode (
                                 )
   {
//##Begin StateToRegion:getRegionCode() preserve=no

      fetch ();

      return (regionCode);

//##End   StateToRegion:getRegionCode()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setStateCode                                     */
        /*                                                              */
        /**
         * This method sets the value of the "stateCode" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "stateCode" attribute.
         */
        /*==============================================================*/
   public  void  setStateCode (
                               String  aValue
                              )
   {
//##Begin StateToRegion:setStateCode(String) preserve=no

      if (stateCode == aValue) {
         return;
      }

      if (stateCode != null) {
         if (stateCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = stateCode;
      stateCode = aValue;

      setDirty ("stateCode" , myOldValue , stateCode);

      firePropertyChange ("stateCode", myOldValue, stateCode);

//##End   StateToRegion:setStateCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setRegionCode                                    */
        /*                                                              */
        /**
         * This method sets the value of the "regionCode" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "regionCode" attribute.
         */
        /*==============================================================*/
   public  void  setRegionCode (
                                String  aValue
                               )
   {
//##Begin StateToRegion:setRegionCode(String) preserve=no

      if (regionCode == aValue) {
         return;
      }

      if (regionCode != null) {
         if (regionCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = regionCode;
      regionCode = aValue;

      setDirty ("regionCode" , myOldValue , regionCode);

      firePropertyChange ("regionCode", myOldValue, regionCode);

//##End   StateToRegion:setRegionCode(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin StateToRegion:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (StateToRegion.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      StateToRegion  myOther  = (StateToRegion) aObject;

      try {
         String myStateCode = getStateCode ();
         if (myStateCode != null) {
            if ( ! (myStateCode.equals (myOther.getStateCode ()))) {
               return (false);
            }
         }
         else if (myOther.getStateCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "StateToRegion::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   StateToRegion:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin StateToRegion:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myStateCode = getStateCode ();
         if (myStateCode != null) {
            myHashCode += (37 * myHashCode) + (myStateCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "StateToRegion::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   StateToRegion:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin StateToRegion:processRestoreResult(Object) preserve=no

      StateToRegion  myOther  = (StateToRegion) aObject;

      try {
         super.processRestoreResult  (myOther);
         setStateCode (myOther.getStateCode ());
         setRegionCode (myOther.getRegionCode ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "StateToRegion::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   StateToRegion:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin StateToRegion:printOut() preserve=no

      try {
         System.out.println ("StateToRegion:");
         System.out.println ("   stateCode: " + getStateCode ());
         System.out.println ("   regionCode: " + getRegionCode ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   StateToRegion:printOut()
   }


}
