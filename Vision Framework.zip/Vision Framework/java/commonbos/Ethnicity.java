/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Ethnicity.java                                          */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:53 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Ethnicity                                               */
/**
 * The Cultural/Racial background of a person For eg American Indian,
 * Hispanic African America .
 */
/*======================================================================*/
public  class  Ethnicity  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Ethnicity:Attributes preserve=yes

//##End   Ethnicity:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String code;
   private String description;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCode                                          */
        /*                                                              */
        /**
         * This method returns the value of the "code" attribute.
         *  
         * @return      :String -
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  String  getCode (
                           )
   {
//##Begin Ethnicity:getCode() preserve=no

      fetch ();

      return (code);

//##End   Ethnicity:getCode()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the "description" attribute.
         *  
         * @return      :String -
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  String  getDescription (
                                  )
   {
//##Begin Ethnicity:getDescription() preserve=no

      fetch ();

      return (description);

//##End   Ethnicity:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCode                                          */
        /*                                                              */
        /**
         * This method sets the value of the "code" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  void  setCode (
                          String  aValue
                         )
   {
//##Begin Ethnicity:setCode(String) preserve=no

      if (code == aValue) {
         return;
      }

      if (code != null) {
         if (code.equals (aValue)) {
            return;
         }
      }

      String myOldValue = code;
      code = aValue;

      setDirty ("code" , myOldValue , code);

      firePropertyChange ("code", myOldValue, code);

//##End   Ethnicity:setCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the "description" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  void  setDescription (
                                 String  aValue
                                )
   {
//##Begin Ethnicity:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   Ethnicity:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Ethnicity:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (Ethnicity.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      Ethnicity  myOther  = (Ethnicity) aObject;

      try {
         String myCode = getCode ();
         if (myCode != null) {
            if ( ! (myCode.equals (myOther.getCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Ethnicity::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Ethnicity:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Ethnicity:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myCode = getCode ();
         if (myCode != null) {
            myHashCode += (37 * myHashCode) + (myCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Ethnicity::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Ethnicity:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin Ethnicity:processRestoreResult(Object) preserve=no

      Ethnicity  myOther  = (Ethnicity) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCode (myOther.getCode ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Ethnicity::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Ethnicity:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Ethnicity:printOut() preserve=no

      try {
         System.out.println ("Ethnicity:");
         System.out.println ("   code: " + getCode ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Ethnicity:printOut()
   }


}
