package COM.novusnet.vision.java.commonbos;


import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.ResourceSchemaMapper;


public class PlacesResourceSchema extends ResourceSchemaMapper
{
   public BusinessObject createAndPopulateItem(
                                           String code ,
                                           String description
                                          )
   {
      Place place =  new Place ();
      place.setCode(code);
      place.setDescription(description);
      return place;
   }
}
