/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Countries.java                                          */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:42 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.POFactory;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Countries                                               */
/**
 * Holds country objects.
 */
/*======================================================================*/
public  class  Countries  extends  BusinessObjectLookupList
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Countries:Attributes preserve=yes

//##End   Countries:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getContainedClass                                */
        /*                                                              */
        /**
         * This method returns the contained objects class.
         *  
         * @return      :Class -
         */
        /*==============================================================*/
   protected  Class  getContainedClass (
                                       )
   {
//##Begin Countries:getContainedClass() preserve=no

                /*======================================================*/
                /* return the class name of my contained objects.       */
                /*======================================================*/
      return Country.class ;

//##End   Countries:getContainedClass()
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the Countries class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin Countries:main(String[]) preserve=yes

	 POFactory           myFactory   = new POFactory();                        
	 CommonBOPIDFactory  aPIDFactory = new CommonBOPIDFactory();

	 PID  myCountries  = null;

	 myCountries  = aPIDFactory.createPID (Countries.class);
	 Countries instance       = (Countries)myFactory.create_PO(myCountries , null);

//##End   Countries:main(String[])
   }


}
