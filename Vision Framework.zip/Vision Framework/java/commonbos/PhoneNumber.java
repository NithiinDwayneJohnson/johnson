/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PhoneNumber.java                                        */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 April 30 at 12:03:17 GMT+00:00                     */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PhoneNumber                                             */
/**
 * This class holds phone information, such as country code, area code and
 * number. A number's validity in a country depends on the phone number
 * format for that country. Similarly, the way a phone number looks also
 * depeneds on a specific country. For example, in the US it acceptable for
 * a phone number to look as (847)-555-1212 or  847-555-1212. 
 * <p>
 *  
 * <p>
 * This class also provides a set of methods to obtain a formatted
 * telephone number. The format to be applied is performed using specific
 * locale strings.
 * <p>
 *  
 * <p>
 * Most of the methods in this class are delegated to a PhoneLocale
 * instance. The PhoneLocale instance is locale specific and must reside in
 * the locale package per the vision specifications. For each Locale that
 * your application needs to support, there must be a corresponding phone
 * locale object. The current system supplies an implementation for the
 * USA. It is relatively easy (if you know regular expressions) to create a
 * new PhoneLocale object.
 */
/*======================================================================*/
public  class  PhoneNumber  implements  Serializable
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PhoneNumber:Attributes preserve=yes

//##End   PhoneNumber:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private           String                countryCode;
   private           String                areaCode;
   private           String                localPhoneNumber;
   private           String                extension;
   private transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
   private           PhoneLocale           phoneLocale;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  PhoneNumber                                      */
        /*                                                              */
        /**
         * This constructor constructs an empty phone. The class attributes
         * are prefilled with 0's. The number of 0's to prefill are
         * obtained from the phone locale object.
         *  
         */
        /*==============================================================*/
   public    PhoneNumber (
                         )
   {
//##Begin PhoneNumber:PhoneNumber() preserve=yes
      this(null);
//##End   PhoneNumber:PhoneNumber()
   }

        /*==============================================================*/
        /* OPERATION:  PhoneNumber                                      */
        /*                                                              */
        /**
         * This contructor takes a phone number in a string format and
         * breaks it down. The break down process is accomplished using
         * regular expressions. If the phone number is invalid, then the
         * phone is prefilled with 0's. Thus this constructor is lenient.
         *  
         * @param       phoneNumber:String
         */
        /*==============================================================*/
   public    PhoneNumber (
                          String  phoneNumber
                         )
   {
//##Begin PhoneNumber:PhoneNumber(String) preserve=yes
      setPhoneLocale(createPhoneLocale());
      setPhoneNumber(phoneNumber);
//##End   PhoneNumber:PhoneNumber(String)
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCountryCode                                   */
        /*                                                              */
        /**
         * This method returns the value of the country code of the phone
         * number. This is usually obtained from the PhoneLocale instance.
         *  
         * @return      :String -
         *                 The value of the country code of the phone
         *                 number. This is usually obtained from the
         *                 PhoneLocale instance.
         */
        /*==============================================================*/
   public  String  getCountryCode (
                                  )
   {
//##Begin PhoneNumber:getCountryCode() preserve=no

      return (countryCode);

//##End   PhoneNumber:getCountryCode()
   }

        /*==============================================================*/
        /* OPERATION:  getAreaCode                                      */
        /*                                                              */
        /**
         * This method returns the value of the area code of the phone
         * number.
         *  
         * @return      :String -
         *                 The value of the area code of the phone number.
         */
        /*==============================================================*/
   public  String  getAreaCode (
                               )
   {
//##Begin PhoneNumber:getAreaCode() preserve=no

      return (areaCode);

//##End   PhoneNumber:getAreaCode()
   }

        /*==============================================================*/
        /* OPERATION:  getLocalPhoneNumber                              */
        /*                                                              */
        /**
         * This method returns the value of the phone number.
         *  
         * @return      :String -
         *                 The value of the phone number.
         */
        /*==============================================================*/
   public  String  getLocalPhoneNumber (
                                       )
   {
//##Begin PhoneNumber:getLocalPhoneNumber() preserve=no

      return (localPhoneNumber);

//##End   PhoneNumber:getLocalPhoneNumber()
   }

        /*==============================================================*/
        /* OPERATION:  getExtension                                     */
        /*                                                              */
        /**
         * This method returns the value of an optional phone extension.
         *  
         * @return      :String -
         *                 The value of an optional phone extension.
         */
        /*==============================================================*/
   public  String  getExtension (
                                )
   {
//##Begin PhoneNumber:getExtension() preserve=no

      return (extension);

//##End   PhoneNumber:getExtension()
   }

        /*==============================================================*/
        /* OPERATION:  getPropertyChangeSupport                         */
        /*                                                              */
        /**
         * This method returns the value of the "propertyChangeSupport"
         * attribute.
         *  
         * @return      :PropertyChangeSupport -
         *                 The value of the "propertyChangeSupport"
         *                 attribute.
         */
        /*==============================================================*/
   private  PropertyChangeSupport  getPropertyChangeSupport (
                                                            )
   {
//##Begin PhoneNumber:getPropertyChangeSupport() preserve=no

      return (propertyChangeSupport);

//##End   PhoneNumber:getPropertyChangeSupport()
   }

        /*==============================================================*/
        /* OPERATION:  getPhoneLocale                                   */
        /*                                                              */
        /**
         * This method returns the value of the "phoneLocale" attribute.
         *  
         * @return      :PhoneLocale -
         *                 The value of the "phoneLocale" attribute.
         */
        /*==============================================================*/
   private  PhoneLocale  getPhoneLocale (
                                        )
   {
//##Begin PhoneNumber:getPhoneLocale() preserve=no

      return (phoneLocale);

//##End   PhoneNumber:getPhoneLocale()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCountryCode                                   */
        /*                                                              */
        /**
         * This method sets the value of the country code of the phone
         * number. This is usually obtained from the PhoneLocale instance.
         *  
         * @param       aValue:String
         *                 The value of the country code of the phone
         *                 number. This is usually obtained from the
         *                 PhoneLocale instance.
         */
        /*==============================================================*/
   public  void  setCountryCode (
                                 String  aValue
                                )
   {
//##Begin PhoneNumber:setCountryCode(String) preserve=yes

      if (countryCode == aValue) {
         return;
      }

      String  myOldValue = countryCode;

      countryCode = aValue;

      firePropertyChange ("countryCode",  myOldValue, countryCode);

//##End   PhoneNumber:setCountryCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setAreaCode                                      */
        /*                                                              */
        /**
         * This method sets the value of the area code of the phone number.
         *  
         * @param       aValue:String
         *                 The value of the area code of the phone number.
         */
        /*==============================================================*/
   public  void  setAreaCode (
                              String  aValue
                             )
   {
//##Begin PhoneNumber:setAreaCode(String) preserve=yes

      if (areaCode == aValue) {
         return;
      }

      String  myOldValue = areaCode;

      areaCode = aValue;

      firePropertyChange ("areaCode",  myOldValue, areaCode);


//##End   PhoneNumber:setAreaCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setLocalPhoneNumber                              */
        /*                                                              */
        /**
         * This method sets the value of the phone number.
         *  
         * @param       aValue:String
         *                 The value of the phone number.
         */
        /*==============================================================*/
   public  void  setLocalPhoneNumber (
                                      String  aValue
                                     )
   {
//##Begin PhoneNumber:setLocalPhoneNumber(String) preserve=yes

      if (localPhoneNumber == aValue) {
         return;
      }

      String  myOldValue = localPhoneNumber;

      localPhoneNumber = aValue;

      firePropertyChange ("localPhoneNumber",  myOldValue, localPhoneNumber);


//##End   PhoneNumber:setLocalPhoneNumber(String)
   }

        /*==============================================================*/
        /* OPERATION:  setExtension                                     */
        /*                                                              */
        /**
         * This method sets the value of an optional phone extension.
         *  
         * @param       aValue:String
         *                 The value of an optional phone extension.
         */
        /*==============================================================*/
   public  void  setExtension (
                               String  aValue
                              )
   {
//##Begin PhoneNumber:setExtension(String) preserve=no

      extension = aValue;

//##End   PhoneNumber:setExtension(String)
   }

        /*==============================================================*/
        /* OPERATION:  setPhoneLocale                                   */
        /*                                                              */
        /**
         * This method sets the value of the "phoneLocale" attribute.
         *  
         * @param       aValue:PhoneLocale
         *                 The value of the "phoneLocale" attribute.
         */
        /*==============================================================*/
   private  void  setPhoneLocale (
                                  PhoneLocale  aValue
                                 )
   {
//##Begin PhoneNumber:setPhoneLocale(PhoneLocale) preserve=no

      phoneLocale = aValue;

//##End   PhoneNumber:setPhoneLocale(PhoneLocale)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin PhoneNumber:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (PhoneNumber.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      PhoneNumber  myOther  = (PhoneNumber) aObject;

      try {
         String myCountryCode = getCountryCode ();
         if (myCountryCode != null) {
            if ( ! (myCountryCode.equals (myOther.getCountryCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCountryCode () != null) {
               return (false);
         }

         String myAreaCode = getAreaCode ();
         if (myAreaCode != null) {
            if ( ! (myAreaCode.equals (myOther.getAreaCode ()))) {
               return (false);
            }
         }
         else if (myOther.getAreaCode () != null) {
               return (false);
         }

         String myLocalPhoneNumber = getLocalPhoneNumber ();
         if (myLocalPhoneNumber != null) {
            if ( ! (myLocalPhoneNumber.equals (myOther.getLocalPhoneNumber ()))) {
               return (false);
            }
         }
         else if (myOther.getLocalPhoneNumber () != null) {
               return (false);
         }

         String myExtension = getExtension ();
         if (myExtension != null) {
            if ( ! (myExtension.equals (myOther.getExtension ()))) {
               return (false);
            }
         }
         else if (myOther.getExtension () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "PhoneNumber::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   PhoneNumber:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin PhoneNumber:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         String myCountryCode = getCountryCode ();
         if (myCountryCode != null) {
            myHashCode += (37 * myHashCode) + (myCountryCode.hashCode ());
         }
         String myAreaCode = getAreaCode ();
         if (myAreaCode != null) {
            myHashCode += (37 * myHashCode) + (myAreaCode.hashCode ());
         }
         String myLocalPhoneNumber = getLocalPhoneNumber ();
         if (myLocalPhoneNumber != null) {
            myHashCode += (37 * myHashCode) + (myLocalPhoneNumber.hashCode ());
         }
         String myExtension = getExtension ();
         if (myExtension != null) {
            myHashCode += (37 * myHashCode) + (myExtension.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "PhoneNumber::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   PhoneNumber:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin PhoneNumber:printOut() preserve=no

      try {
         System.out.println ("PhoneNumber:");
         System.out.println ("   countryCode: " + getCountryCode ());
         System.out.println ("   areaCode: " + getAreaCode ());
         System.out.println ("   localPhoneNumber: " + getLocalPhoneNumber ());
         System.out.println ("   extension: " + getExtension ());
         System.out.println ("   propertyChangeSupport: " + getPropertyChangeSupport ());
         System.out.println ("   phoneLocale: " + getPhoneLocale ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   PhoneNumber:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  toString                                         */
        /*                                                              */
        /**
         * Returns the phone representation in string format.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  toString (
                            )
   {
//##Begin PhoneNumber:toString() preserve=yes
      return (getFormattedPhoneNumberShort());
//##End   PhoneNumber:toString()
   }

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberShort                     */
        /*                                                              */
        /**
         * Returns a formatted phone number in simple form. This usually is
         * the area code followed by the phone number.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberShort (
                                                )
   {
//##Begin PhoneNumber:getFormattedPhoneNumberShort() preserve=yes
      return (getPhoneLocale().getFormattedPhoneNumberShort(this));
//##End   PhoneNumber:getFormattedPhoneNumberShort()
   }

        /*==============================================================*/
        /* OPERATION:  getFormattedPhoneNumberLong                      */
        /*                                                              */
        /**
         * Returns a formatted phone number in long form. This usually is
         * the country code followed by the area code and the phone number.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPhoneNumberLong (
                                               )
   {
//##Begin PhoneNumber:getFormattedPhoneNumberLong() preserve=yes
      return (getPhoneLocale().getFormattedPhoneNumberLong(this));
//##End   PhoneNumber:getFormattedPhoneNumberLong()
   }

        /*==============================================================*/
        /* OPERATION:  getUnformattedPhoneNumberShort                   */
        /*                                                              */
        /**
         * Returns an unformatted phone number in simple form. This usually
         * is the area code followed by the phone number. If any of the
         * fields are missing the PhoneLocale typically fills these with a
         * filler character. This method is typically used for databases
         * that do not have separate area code and phone number fields.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPhoneNumberShort (
                                                  )
   {
//##Begin PhoneNumber:getUnformattedPhoneNumberShort() preserve=yes
      return (getPhoneLocale().getUnformattedPhoneNumberShort(this));
//##End   PhoneNumber:getUnformattedPhoneNumberShort()
   }

        /*==============================================================*/
        /* OPERATION:  setPhoneNumber                                   */
        /*                                                              */
        /**
         * Parses and sets the phone number. If the number passed in is
         * null, this method empties the PhoneNumber (i.e fills it with
         * nulls)
         *  
         * @param       phoneNumber:String
         */
        /*==============================================================*/
   public  void  setPhoneNumber (
                                 String  phoneNumber
                                )
   {
//##Begin PhoneNumber:setPhoneNumber(String) preserve=yes

      getPhoneLocale().parsePhoneNumber(phoneNumber, 
					this);
//##End   PhoneNumber:setPhoneNumber(String)
   }

        /*==============================================================*/
        /* OPERATION:  getMaxAreaCodeLength                             */
        /*                                                              */
        /**
         * Returns the maximum length of the area code.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxAreaCodeLength (
                                     )
   {
//##Begin PhoneNumber:getMaxAreaCodeLength() preserve=yes
      return (getPhoneLocale().getMaxAreaCodeLength());
//##End   PhoneNumber:getMaxAreaCodeLength()
   }

        /*==============================================================*/
        /* OPERATION:  getCountryCodeLength                             */
        /*                                                              */
        /**
         * Returns the country code length.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getCountryCodeLength (
                                     )
   {
//##Begin PhoneNumber:getCountryCodeLength() preserve=yes
      return (getPhoneLocale().getCountryCodeLength());
//##End   PhoneNumber:getCountryCodeLength()
   }

        /*==============================================================*/
        /* OPERATION:  getMaxLocalPhoneNumberLength                     */
        /*                                                              */
        /**
         * Returns the maximum length of a local phone number.
         *  
         * @return      :int -
         */
        /*==============================================================*/
   public  int  getMaxLocalPhoneNumberLength (
                                             )
   {
//##Begin PhoneNumber:getMaxLocalPhoneNumberLength() preserve=yes
      return (getPhoneLocale().getMaxLocalPhoneNumberLength());
//##End   PhoneNumber:getMaxLocalPhoneNumberLength()
   }

        /*==============================================================*/
        /* OPERATION:  getFormatFillCharacter                           */
        /*                                                              */
        /**
         * Returns the format fill character. This is used in case one of
         * the attributes is missing. 
         *  
         * @return      :char -
         */
        /*==============================================================*/
   public  char  getFormatFillCharacter (
                                        )
   {
//##Begin PhoneNumber:getFormatFillCharacter() preserve=yes
      return (getPhoneLocale().getFormatFillCharacter());
//##End   PhoneNumber:getFormatFillCharacter()
   }

        /*==============================================================*/
        /* OPERATION:  addPropertyChangeListener                        */
        /*                                                              */
        /**
         * Adds a property change listener to the list of listeners. Used
         * by objects that are interested in events fiered by this object.
         *  
         * @param       aListener:PropertyChangeListener
         */
        /*==============================================================*/
   public  void  addPropertyChangeListener (
                                            PropertyChangeListener  aListener
                                           )
   {
//##Begin PhoneNumber:addPropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().addPropertyChangeListener (aListener);
//##End   PhoneNumber:addPropertyChangeListener(PropertyChangeListener)
   }

        /*==============================================================*/
        /* OPERATION:  removePropertyChangeListener                     */
        /*                                                              */
        /**
         * Removes the listener from the listener list.
         *  
         * @param       aListener:PropertyChangeListener
         */
        /*==============================================================*/
   public  void  removePropertyChangeListener (
                                               PropertyChangeListener  aListener
                                              )
   {
//##Begin PhoneNumber:removePropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().removePropertyChangeListener (aListener);
//##End   PhoneNumber:removePropertyChangeListener(PropertyChangeListener)
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * An internal version of isValid for performance reasons.
         *  
         * @param       phoneNumber:String
         * @param       phoneLocale:PhoneLocale
         * @return      :boolean -
         */
        /*==============================================================*/
   private  boolean  isValid (
                              String       phoneNumber,
                              PhoneLocale  phoneLocale
                             )
   {
//##Begin PhoneNumber:isValid(String,PhoneLocale) preserve=yes
      return (phoneLocale.isValid(phoneNumber));
//##End   PhoneNumber:isValid(String,PhoneLocale)
   }

        /*==============================================================*/
        /* OPERATION:  firePropertyChange                               */
        /*                                                              */
        /**
         * @param       propertyName:String
         * @param       oldValue:Object
         * @param       newValue:Object
         */
        /*==============================================================*/
   private  void  firePropertyChange (
                                      String  propertyName,
                                      Object  oldValue,
                                      Object  newValue
                                     )
   {
//##Begin PhoneNumber:firePropertyChange(String,Object,Object) preserve=yes
      getPropertyChangeSupport ().firePropertyChange (propertyName, oldValue, newValue);    
//##End   PhoneNumber:firePropertyChange(String,Object,Object)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Takes a phone number representation in string format and applies
         * country specific validation rules. Each locale defines its own
         * valid representations. For example, the US defines:
         * <p>
         * - Have the form 9999999999 or
         * <p>
         * - Have the form (999)-999-9999 or
         * <p>
         * - Have the form 999-999-9999
         * <p>
         * to be valid.
         *  
         * @param       phoneNumber:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public static  boolean  isValid (
                                    String  phoneNumber
                                   )
   {
//##Begin PhoneNumber:isValid(String) preserve=yes
      PhoneLocale myPhoneLocale = createPhoneLocale();
      return (myPhoneLocale.isValid(phoneNumber));
//##End   PhoneNumber:isValid(String)
   }

        /*==============================================================*/
        /* OPERATION:  createPhoneLocale                                */
        /*                                                              */
        /**
         * Creates the appropriate phone locale object.
         *  
         * @return      :PhoneLocale -
         */
        /*==============================================================*/
   private static  PhoneLocale  createPhoneLocale (
                                                  )
   {
//##Begin PhoneNumber:createPhoneLocale() preserve=yes

      ResourceResolver rr = new ResourceResolver();

      //=================================================================
      // Create a phone locale instance based on the current locale
      // We will look for the PhoneLocale object in the proper locale
      // subdirectory.
      //=================================================================
      PhoneLocale myPhoneLocale = (PhoneLocale)rr.getResourceForClass(PhoneNumber.class, "PhoneLocale");

      if (myPhoneLocale == null) {
	 throw new RuntimeException("Missing phone locale information.");
      }

      return (myPhoneLocale);
//##End   PhoneNumber:createPhoneLocale()
   }

        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the PhoneNumber class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin PhoneNumber:main(String[]) preserve=yes
      System.out.println( "(847) 310-8864" + ":" + PhoneNumber.isValid("(847) 310-8864") );
      System.out.println( "(847)-310-8864" + ":" + PhoneNumber.isValid("(847)-310-8864") );
      System.out.println( "847-310-8864"   + ":" + PhoneNumber.isValid("847-310-8864") );
      System.out.println( "8473108864"     + ":" + PhoneNumber.isValid("8473108864") );
      System.out.println( "473108864"      + ":" + PhoneNumber.isValid("473108864") );
      System.out.println( "null"           + ":" + PhoneNumber.isValid(null));

      PhoneNumber myPhoneNumber2 = new PhoneNumber("(847)-310-8864");
      System.out.println(myPhoneNumber2);

      PhoneNumber myPhoneNumber = new PhoneNumber("8473108864");
      System.out.println(myPhoneNumber);
      System.out.println(myPhoneNumber.equals(myPhoneNumber2));
      myPhoneNumber.printOut();
      myPhoneNumber2.printOut();

      PhoneNumber myPhoneNumber3 = new PhoneNumber("3108864");
      System.out.println(myPhoneNumber3);
 
//##End   PhoneNumber:main(String[])
   }


}
