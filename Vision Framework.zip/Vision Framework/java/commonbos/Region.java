/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Region.java                                             */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:37 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Region                                                  */
/**
 * A region represents a geographical region. A region might encompass many
 * states.
 */
/*======================================================================*/
public  class  Region  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Region:Attributes preserve=yes

//##End   Region:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String regionCode;
   private String description;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getRegionCode                                    */
        /*                                                              */
        /**
         * This method returns the value of the "regionCode" attribute.
         *  
         * @return      :String -
         *                 The value of the "regionCode" attribute.
         */
        /*==============================================================*/
   public  String  getRegionCode (
                                 )
   {
//##Begin Region:getRegionCode() preserve=no

      fetch ();

      return (regionCode);

//##End   Region:getRegionCode()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the "description" attribute.
         *  
         * @return      :String -
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  String  getDescription (
                                  )
   {
//##Begin Region:getDescription() preserve=no

      fetch ();

      return (description);

//##End   Region:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setRegionCode                                    */
        /*                                                              */
        /**
         * This method sets the value of the "regionCode" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "regionCode" attribute.
         */
        /*==============================================================*/
     void  setRegionCode (
                          String  aValue
                         )
   {
//##Begin Region:setRegionCode(String) preserve=no

      if (regionCode == aValue) {
         return;
      }

      if (regionCode != null) {
         if (regionCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = regionCode;
      regionCode = aValue;

      setDirty ("regionCode" , myOldValue , regionCode);

      firePropertyChange ("regionCode", myOldValue, regionCode);

//##End   Region:setRegionCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the "description" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
     void  setDescription (
                           String  aValue
                          )
   {
//##Begin Region:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   Region:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Region:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (Region.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      Region  myOther  = (Region) aObject;

      try {
         String myRegionCode = getRegionCode ();
         if (myRegionCode != null) {
            if ( ! (myRegionCode.equals (myOther.getRegionCode ()))) {
               return (false);
            }
         }
         else if (myOther.getRegionCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Region::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Region:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Region:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myRegionCode = getRegionCode ();
         if (myRegionCode != null) {
            myHashCode += (37 * myHashCode) + (myRegionCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Region::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Region:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin Region:processRestoreResult(Object) preserve=no

      Region  myOther  = (Region) aObject;

      try {
         super.processRestoreResult  (myOther);
         setRegionCode (myOther.getRegionCode ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Region::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Region:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Region:printOut() preserve=no

      try {
         System.out.println ("Region:");
         System.out.println ("   regionCode: " + getRegionCode ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Region:printOut()
   }


}
