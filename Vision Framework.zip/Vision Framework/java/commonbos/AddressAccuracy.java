/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      AddressAccuracy.java                                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:47 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/

import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.POFactory;


/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       AddressAccuracy                                         */
/**
 * This business object is the interface to the Finalist Standard Module, a
 * program which runs on the host and will verify addresses according to
 * postal standards.
 */
/*======================================================================*/
public  class  AddressAccuracy  extends  BusinessObject
{
	public static final char FILL_IN_CITY_STATE = '1';
	public static final char VERIFY_AND_CORRECT_ADDRESS = '2';


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin AddressAccuracy:Attributes preserve=yes

//##End   AddressAccuracy:Attributes

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  fillInCityState                                  */
        /*                                                              */
        /**
         * This method given an address with a street address and zip code
         * will get the city and state and if necessary the Zip + 4 portion
         * of the zip code.
         * <p>
         * * functionCode  must be set to FILL_IN_CITY_STATE to use this search.
         * <p>
         * This methos returns an Address object.
         *
         * @param       address:Address
         * @exception   InvalidAddressException -
         */
        /*==============================================================*/
   public static  void  fillInCityState (
                                         Address  address
                                        )
                                  throws InvalidAddressException
   {
//##Begin AddressAccuracy:fillInCityState(Address) preserve=yes
      try {
	 PID                 myAddressAccuracyPID   =  null;
	 POFactory           myFactory              =  new POFactory();
	 CommonBOPIDFactory  myPIDFactory           = new VisionPIDFactory();

	 myAddressAccuracyPID = myPIDFactory.createPID(AddressAccuracy.class);

	 AddressAccuracyKeyDescriptor aKey = new AddressAccuracyKeyDescriptor();
	 aKey.setFunctionCode (FILL_IN_CITY_STATE);
	 aKey.setAddress (address);
	 myAddressAccuracyPID.writeObject (aKey);

	 Address anAddress = (Address)myFactory.create_PO(myAddressAccuracyPID, null);

	 address.setStreet1(anAddress.getStreet1());
	 address.setStreet2(anAddress.getStreet2());
	 address.setCity(anAddress.getCity());
	 // Do not copy in postal code.  Say user needs postal code to be 60015 and
	 // MF dap returns 60015-3851.  If this method updates the address given with
	 // 60015-3851, the user never has a way to set the code to 60015.
// 	 address.setPostalCode(anAddress.getPostalCode());
	 address.setState(anAddress.getState());
	 address.setCountry(anAddress.getCountry());
	 address.setBarCode (anAddress.getBarCode());

	 if (anAddress.getState() == null)
	   throw new InvalidAddressException();

	 return;
      }

      catch (InvalidAddressException e) {
         throw e;
      }

      catch (Throwable myThrowable) {
	 myThrowable.printStackTrace();
//           throw new RuntimeException ( myThrowable.toString() );
      }

//##End   AddressAccuracy:fillInCityState(Address)
   }

        /*==============================================================*/
        /* OPERATION:  verifyAndCorrectAddress                          */
        /*                                                              */
        /**
         * This method will use the FSM program on the host to verify the
         * address and will if possible return a corrected address in the
         * address structure or an exception.
         * <p>
         * An address object must be set on AddressAcuracy before calling
         * this method.
         * <p>
         * The fuctionCode must be set to VERIFY_AND_CORRECT_ADDRESS to use this type of search.
         * <p>
         * This method returns an Address object.
         *
         * @param       address:Address
         * @exception   InvalidAddressException -
         */
        /*==============================================================*/
   public static  void  verifyAndCorrectAddress (
                                                 Address  address
                                                )
                                          throws InvalidAddressException
   {
//##Begin AddressAccuracy:verifyAndCorrectAddress(Address) preserve=yes

      try {

	 PID                  myAddressAccuracyPID   =  null;
	 POFactory            myFactory              =  new POFactory();
	 CommonBOPIDFactory   myPIDFactory           =  new VisionPIDFactory();

	 myAddressAccuracyPID               =  myPIDFactory.createPID(AddressAccuracy.class);

	 AddressAccuracyKeyDescriptor aKey = new AddressAccuracyKeyDescriptor();

	 aKey.setFunctionCode (VERIFY_AND_CORRECT_ADDRESS);
	 aKey.setAddress (address);
	 myAddressAccuracyPID.writeObject (aKey);

	 Address anAddress = (Address)myFactory.create_PO(myAddressAccuracyPID, null);

	 address.setStreet1(anAddress.getStreet1());
	 address.setStreet2(anAddress.getStreet2());
	 address.setCity(anAddress.getCity());
	 address.setPostalCode(anAddress.getPostalCode());
	 address.setState(anAddress.getState());
	 address.setCountry(anAddress.getCountry());
	 address.setBarCode(anAddress.getBarCode());
      }
      catch (Throwable myThrowable) {
	 throw new InvalidAddressException ( myThrowable.toString() );
      }

      return;

//##End   AddressAccuracy:verifyAndCorrectAddress(Address)
   }

        /*==============================================================*/
        /* OPERATION:  isAddressAccurate                                */
        /*                                                              */
        /**
         * Returns true or false, indicating whether the supplied address
         * is accurate or not.
         * <p>
         * This method calls the verifyAndCorrectAddress method and
         * compares the returned address with the supplied on eto determine
         * equality.
         *
         * @param       address:Address
         * @return      :boolean -
         */
        /*==============================================================*/
   public static  boolean  isAddressAccurate (
                                              Address  address
                                             )
   {
//##Begin AddressAccuracy:isAddressAccurate(Address) preserve=yes

      try {
	 Address anAddress = new Address();

	 anAddress = (Address) address.clone();

	 AddressAccuracy.verifyAndCorrectAddress( anAddress );

	 if (anAddress != address)
	   return false;
	 else
	   return true;
      }
      catch (Throwable myThrowable) {
	 throw new RuntimeException (
                                     "AddressAccuracy::: " +
                                     myThrowable.toString ()
				     );
      }
//##End   AddressAccuracy:isAddressAccurate(Address)
   }

        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the AddressAccuracy class.
         *
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin AddressAccuracy:main(String[]) preserve=yes
//##End   AddressAccuracy:main(String[])
   }


}
