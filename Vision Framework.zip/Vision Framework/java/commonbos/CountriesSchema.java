package COM.novusnet.vision.java.commonbos;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.GenericSchema;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.utility.streamhelpers.ReferenceHolder;
import COM.dfs.cms.serviceinvocation.DFSClientConsumerServiceAccess;
import com.dfs.ncs.NCSCOUNTRY_READOutputVO;

public class CountriesSchema implements GenericSchema
{
	
	public  void  restore (ObjectOutputStream aOStream, GenericPID aPID) throws PersistenceException
   	{
      	try 
      	{
		 	Countries myCountries = new Countries ();
	 		Country   myCountry;
	 		String    countryCode = " ";

	 		NCSCOUNTRY_READOutputVO[] ovo = DFSClientConsumerServiceAccess.getCountriesServicesInterface().getCountries(countryCode);
				
	    	for (int i=0; i < ovo.length; i++) 
	    	{
	     		myCountry = new Country ();
	       		myCountry.setCountryCode (ovo[i].getCntryCde());
	       		myCountry.setCountryName (ovo[i].getCntryNm());
	       		myCountries.put (myCountry.getCountryCode(), myCountry);
	       		countryCode = myCountry.getCountryCode();
	    	}

//	   		if ( myCountries.getSize() - count < 50) 
//	   		{
//	     		break;
//	   		}
	   		
         	aOStream.writeObject (new ReferenceHolder (myCountries));
      	}
        /*======================================================*/
        /* Map any exceptions to a persistence exception        */
        /*======================================================*/
      	catch (Throwable myThrowable) 
      	{
         	myThrowable.printStackTrace ();
         	throw new PersistenceException ("CountriesEJBBusinessDelegate: " + myThrowable.toString ());
      	}
   	}

   	public  void  store (ObjectInputStream aIStream, GenericPID aPID) throws PersistenceException
   	{
      	throw new PersistenceException ("CountriesEJBBusinessDelegate does not support the 'store' operation");
   	}

   	public  void  Delete (ObjectInputStream aIStream, GenericPID aPID) throws PersistenceException
   	{
      	throw new PersistenceException ("CountriesEJBBusinessDelegate does not support the 'Delete' operation");
   	}
	
}

