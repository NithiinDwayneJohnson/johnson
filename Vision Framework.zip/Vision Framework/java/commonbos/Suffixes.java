/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Suffixes.java                                           */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   2000 August 15 at 11:17:51 CDT                          */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
/*==============================================================*/
/* Generated Imports                                            */
/*==============================================================*/
/*======================================================*/
/* Java Platform Core APIs                              */
/*======================================================*/
import java.util.Iterator;

import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.POFactory;

/*==============================================================*/
/* Custom Imports                                               */
/*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Suffixes                                                */
/**
 * This represents a container class for Suffix.
 */
/*======================================================================*/
public class Suffixes
	extends COM.novusnet.vision.java.businessobjects.BusinessObjectLookupList {

	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Attributes ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/

	/*==================================================================*/
	/* Custom Attributes                                                */
	/*==================================================================*/
	//##Begin Suffixes:Attributes preserve=yes

	//##End   Suffixes:Attributes

	private static COM.novusnet.vision.java.commonbos.Suffixes instance = null;

	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Operations ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/

	/*==================================================================*/
	/* Protected Operations                                             */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  getContainedClass                                */
	/*                                                              */
	/**
	 * This method returns the contained objects class.
	 *  
	 * @return      :Class -
	 */
	/*==============================================================*/
	protected Class getContainedClass() {
		//##Begin Suffixes:getContainedClass() preserve=no

		/*======================================================*/
		/* return the class name of my contained objects.       */
		/*======================================================*/
		return Suffix.class;

		//##End   Suffixes:getContainedClass()
	}

	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  getSuffix                                         */
	/*                                                              */
	/**
	 * @param       aSuffixDescription:java.lang.String
	 * @return      :COM.novusnet.vision.java.commonbos.Suffix -
	 */
	/*==============================================================*/
	public COM.novusnet.vision.java.commonbos.Suffix getSuffix(
		java.lang.String aSuffixDescription) {
		//##Begin Suffixes:getSuffix(String) preserve=yes
		Iterator itr = ((Suffixes) getInstance()).elements();
		boolean found = false;
		Suffix mySuffix = new Suffix();

		if (aSuffixDescription.endsWith("."))
			aSuffixDescription =
				aSuffixDescription.substring(
					0,
					aSuffixDescription.indexOf("."));

		while (!found) {
			if (!itr.hasNext())
				found = true;
			else {
				mySuffix = (Suffix) itr.next();
				if (mySuffix
					.getDescription()
					.equalsIgnoreCase(aSuffixDescription))
					found = true;
				else
					mySuffix = (Suffix) get("0");
			}
		}

		return (mySuffix);

		//##End   Suffixes:getSuffix(String)
	}

	/*==================================================================*/
	/* Class Operations                                                 */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  getInstance                                      */
	/*                                                              */
	/**
	 * @return      :COM.novusnet.vision.java.commonbos.Suffixes -
	 */
	/*==============================================================*/
	public static COM.novusnet.vision.java.commonbos.Suffixes getInstance() {
		//##Begin Suffixes:getInstance() preserve=yes
		if (instance == null) {
			GenericPID myPID;
			POFactory aFactory = new POFactory();
			CommonBOPIDFactory aPIDFactory = new CommonBOPIDFactory();

			myPID = (GenericPID) aPIDFactory.createPID(Suffixes.class);

			Suffixes mySuffixes;

			mySuffixes = (Suffixes) aFactory.create_PO(myPID, null);

			instance = mySuffixes;
		}

		return instance;

		//##End   Suffixes:getInstance()
	}

}
