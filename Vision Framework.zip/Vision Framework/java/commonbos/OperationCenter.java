/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      OperationCenter.java                                    */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:33 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       OperationCenter                                         */
/**
 * An operation center represents a workarea for customer support.
 */
/*======================================================================*/
public  class  OperationCenter  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin OperationCenter:Attributes preserve=yes

//##End   OperationCenter:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String centerCode;
   private String shortName;
   private String description;
   private static final java.lang.String HEADQUARTERS            = "HQ";
   private static final java.lang.String PHOENIX                 = "PH";
   private static final java.lang.String SCOTTSDALE              = "SC";
   private static final java.lang.String MILL_RUN                = "MR";
   private static final java.lang.String LAKE_PARK               = "UT";
   private static final java.lang.String NEW_CASTLE              = "NC";
   private static final java.lang.String WESTLAND                = "WE";
   private static final java.lang.String EASTLAND                = "CO";
    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  OperationCenter                                  */
        /*                                                              */
        /**
         * @param       aCenterCode:String
         * @param       aShortName:String
         * @param       aDescription:String
         */
        /*==============================================================*/
   public    OperationCenter (
                              String  aCenterCode,
                              String  aShortName,
                              String  aDescription
                             )
   {
//##Begin OperationCenter:OperationCenter(String,String,String) preserve=yes

      centerCode  = aCenterCode;
      shortName   = aShortName;
      description = aDescription;

//##End   OperationCenter:OperationCenter(String,String,String)
   }

        /*==============================================================*/
        /* OPERATION:  OperationCenter                                  */
        /*                                                              */
        /**
         */
        /*==============================================================*/
   protected    OperationCenter (
                                )
   {
//##Begin OperationCenter:OperationCenter() preserve=yes
      super();
//##End   OperationCenter:OperationCenter()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCenterCode                                    */
        /*                                                              */
        /**
         * This method returns the value of the code that PC Solar uses for
         * an operation center e.g.
         * <p>
         * PH, UT, NE, HQ etc.
         *  
         * @return      :String -
         *                 The value of the code that PC Solar uses for an
         *                 operation center e.g.
         * <p>
         *                 PH, UT, NE, HQ etc.
         */
        /*==============================================================*/
   public  String  getCenterCode (
                                 )
   {
//##Begin OperationCenter:getCenterCode() preserve=no

      fetch ();

      return (centerCode);

//##End   OperationCenter:getCenterCode()
   }

        /*==============================================================*/
        /* OPERATION:  getShortName                                     */
        /*                                                              */
        /**
         * This method returns the value of the 3 character short name for
         * each operation center.  e.g.
         * <p>
         * ITG, PHA, SAU, NCD, this name is often used in making up machine
         * names eg RISITG01
         *  
         * @return      :String -
         *                 The value of the 3 character short name for each
         *                 operation center.  e.g.
         * <p>
         *                 ITG, PHA, SAU, NCD, this name is often used in
         *                 making up machine names eg RISITG01
         */
        /*==============================================================*/
   public  String  getShortName (
                                )
   {
//##Begin OperationCenter:getShortName() preserve=no

      fetch ();

      return (shortName);

//##End   OperationCenter:getShortName()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the longer descriptive name for
         * a center.  Can be used for display purposes.
         * <p>
         * <b>Examples:</b>
<pre>
</pre>
         *  
         * @return      :String -
         *                 The value of the longer descriptive name for a
         *                 center.  Can be used for display purposes.
         * <p>
         *                 <b>Examples:</b>
<pre>
</pre>
         */
        /*==============================================================*/
   public  String  getDescription (
                                  )
   {
//##Begin OperationCenter:getDescription() preserve=no

      fetch ();

      return (description);

//##End   OperationCenter:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCenterCode                                    */
        /*                                                              */
        /**
         * This method sets the value of the code that PC Solar uses for an
         * operation center e.g.
         * <p>
         * PH, UT, NE, HQ etc.
         *  
         * @param       aValue:String
         *                 The value of the code that PC Solar uses for an
         *                 operation center e.g.
         * <p>
         *                 PH, UT, NE, HQ etc.
         */
        /*==============================================================*/
     void  setCenterCode (
                          String  aValue
                         )
   {
//##Begin OperationCenter:setCenterCode(String) preserve=no

      if (centerCode == aValue) {
         return;
      }

      if (centerCode != null) {
         if (centerCode.equals (aValue)) {
            return;
         }
      }

      String myOldValue = centerCode;
      centerCode = aValue;

      setDirty ("centerCode" , myOldValue , centerCode);

      firePropertyChange ("centerCode", myOldValue, centerCode);

//##End   OperationCenter:setCenterCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setShortName                                     */
        /*                                                              */
        /**
         * This method sets the value of the 3 character short name for
         * each operation center.  e.g.
         * <p>
         * ITG, PHA, SAU, NCD, this name is often used in making up machine
         * names eg RISITG01
         *  
         * @param       aValue:String
         *                 The value of the 3 character short name for each
         *                 operation center.  e.g.
         * <p>
         *                 ITG, PHA, SAU, NCD, this name is often used in
         *                 making up machine names eg RISITG01
         */
        /*==============================================================*/
   public  void  setShortName (
                               String  aValue
                              )
   {
//##Begin OperationCenter:setShortName(String) preserve=no

      if (shortName == aValue) {
         return;
      }

      if (shortName != null) {
         if (shortName.equals (aValue)) {
            return;
         }
      }

      String myOldValue = shortName;
      shortName = aValue;

      setDirty ("shortName" , myOldValue , shortName);

      firePropertyChange ("shortName", myOldValue, shortName);

//##End   OperationCenter:setShortName(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the longer descriptive name for a
         * center.  Can be used for display purposes.
         * <p>
         * <b>Examples:</b>
<pre>
</pre>
         *  
         * @param       aValue:String
         *                 The value of the longer descriptive name for a
         *                 center.  Can be used for display purposes.
         * <p>
         *                 <b>Examples:</b>
<pre>
</pre>
         */
        /*==============================================================*/
   public  void  setDescription (
                                 String  aValue
                                )
   {
//##Begin OperationCenter:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   OperationCenter:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin OperationCenter:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (OperationCenter.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      OperationCenter  myOther  = (OperationCenter) aObject;

      try {
         String myCenterCode = getCenterCode ();
         if (myCenterCode != null) {
            if ( ! (myCenterCode.equals (myOther.getCenterCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCenterCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "OperationCenter::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   OperationCenter:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin OperationCenter:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myCenterCode = getCenterCode ();
         if (myCenterCode != null) {
            myHashCode += (37 * myHashCode) + (myCenterCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "OperationCenter::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   OperationCenter:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin OperationCenter:processRestoreResult(Object) preserve=no

      OperationCenter  myOther  = (OperationCenter) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCenterCode (myOther.getCenterCode ());
         setShortName (myOther.getShortName ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "OperationCenter::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   OperationCenter:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin OperationCenter:printOut() preserve=no

      try {
         System.out.println ("OperationCenter:");
         System.out.println ("   centerCode: " + getCenterCode ());
         System.out.println ("   shortName: " + getShortName ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   OperationCenter:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isHeadQuarters                                   */
        /*                                                              */
        /**
         * This method returns true if the center code equals HEADQUARTERS
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isHeadQuarters (
                                    )
      {
//##Begin OperationCenter:isHeadQuarters() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (HEADQUARTERS));

//##End   OperationCenter:isHeadQuarters()
   }

        /*==============================================================*/
        /* OPERATION:  isPhoenix                                        */
        /*                                                              */
        /**
         * This method returns true if the center code equals PHOENIX
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isPhoenix (
                                    )
      {
//##Begin OperationCenter:isPhoenix() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (PHOENIX));

//##End   OperationCenter:isPhoenix()
   }

        /*==============================================================*/
        /* OPERATION:  isUtah                                           */
        /*                                                              */
        /**
         * This method returns true if the center code equals LAKE_PARK *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isUtah (
                                    )
      {
//##Begin OperationCenter:isUtah() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (LAKE_PARK));

//##End   OperationCenter:isUtah()
   }

        /*==============================================================*/
        /* OPERATION:  isMillRun                                        */
        /*                                                              */
        /**
         * This method returns true if the center code equals MILL_RUN
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isMillRun (
                                    )
      {
//##Begin OperationCenter:isMillRun() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (MILL_RUN));

//##End   OperationCenter:isMillRun()
   }

        /*==============================================================*/
        /* OPERATION:  isScottsdale                                     */
        /*                                                              */
        /**
         * This method returns true if the center code equals SCOTTSDALE
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isScottsdale (
                                    )
      {
//##Begin OperationCenter:isScottsdale() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (SCOTTSDALE));

//##End   OperationCenter:isScottsdale()
   }

        /*==============================================================*/
        /* OPERATION:  isWestland                                       */
        /*                                                              */
        /**
         * This method returns true if the center code equals WESTLAND
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isWestland (
                                    )
      {
//##Begin OperationCenter:isWestland() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (WESTLAND));

//##End   OperationCenter:isWestland()
   }

        /*==============================================================*/
        /* OPERATION:  isEastland                                       */
        /*                                                              */
        /**
         * This method returns true if the center code equals EASTLAND
         *  
         * @return      :boolean -
         */
        /*==============================================================*/
   public  boolean  isEastland (
                                    )
      {
//##Begin OperationCenter:isEastland() preserve=yes

      if (getCenterCode() == null) {
         return (false);
      }
      return (getCenterCode().equals (EASTLAND));

//##End   OperationCenter:isEastland()
   }

        /*==============================================================*/
        /* OPERATION:  toString                                         */
        /*                                                              */
        /**
         * @return      :String -
         */
        /*==============================================================*/
   public  String  toString (
                            )
   {
//##Begin OperationCenter:toString() preserve=yes
      return (getDescription());
//##End   OperationCenter:toString()
   }


}
