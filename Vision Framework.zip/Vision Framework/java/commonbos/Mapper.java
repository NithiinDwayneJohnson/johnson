/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*    ==============================================================    */
/*                                                                      */
/* MODULE:          Mapper.java                                         */
/*======================================================================*/

/*======================================================================*/
/*                         Package Definition                           */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                              Imports                                 */
/*======================================================================*/
import java.sql.SQLException;
import java.util.Hashtable;


/*======================================================================*/
/*                     Class Definition / Implementation                */
/*======================================================================*/
/**
 * <p><b>DESCRIPTION:</b>
 *       The abstract base class for concrete mapper classes
 *       CallableStatement interface.
 * <p><b>PURPOSE:</b>
 *       To provide method signatures for determining the types and
 *       offsets of elements within a Das transaction key or record
 *       buffer.
 * <p><b>REMARKS:</b>
 *       <ol>
 *           <li>
 *               The definition of this base class leaves the concrete
 *               subclasses as simply a set of static data that is
 *               specific to any given DAS transaction (as defined in the
 *               TDT), thus making them easily generatable.
 *           </li>
 *       </ol>
 */
public abstract  class  Mapper  extends  Object {


       public static final long MAJROLLBACK = -990;
       public static final long MAINFRAME_MAJROLLBACK = -9036;
       public final long MINLATERERR = -300;
       public final long MAJBYPASSED = -900;
       public final long MAINFRAME_MAJBYPASSED = -9010;
       public final long MINPRIORERR = -100;
    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Attributes  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/
        /*==============================================================*/
        /* Class attributes                                             */
        /*==============================================================*/
                /*======================================================*/
                /* Attribute type definitions                           */
                /*======================================================*/
      public  static  final   int       type_char       =  0;
      public  static  final   int       type_string     =  1;
      public  static  final   int       type_truncated  =  2;
      public  static  final   int       type_integer    =  3;
      public  static  final   int       type_ulong      =  4;
      public  static  final   int       type_long       =  5;
      public  static  final   int       type_float      =  6;
      public  static  final   int       type_double     =  7;
      public  static  final   int       type_longdouble =  8;
      public  static  final   int       type_upacked    =  9;
      public  static  final   int       type_spacked    = 10;
      public  static  final   int       type_packed     = 11;
      public  static  final   int       type_uzoned     = 12;
      public  static  final   int       type_zoned      = 13;
      public  static  final   int       type_hex        = 14;
      public  static  final   int       type_compound   = 15;
      public  static  final   int       type_phone      = 16;
      public  static  final   int       type_compress   = 17;
      public  static  final   int       type_internal   = 18;
      public  static  final   int       type_ebcdic     = 19;

                /*======================================================*/
                /* Concrete subclass attributes                         */
                /*======================================================*/
      String            s_TransactionId;
      String            s_Qualifier;
      int               s_VersionNumber = -1;   // Temporary HACK for backward compatibility
      int               s_TimeoutValue;
      int               s_KeyBufferLength;
      int               s_NumberOfKeyFields;
      String []         s_KeyNameArray;
      int    []         s_KeyLengthArray;
      int    []         s_KeyTypeArray;
      int    []         s_KeyOffsetArray;
      int    []         s_KeyScaleArray;

      int               s_RecordBufferLength;
      int               s_NumberOfRecordFields;
      String []         s_RecordNameArray;
      int    []         s_RecordLengthArray;
      int    []         s_RecordTypeArray;
      int    []         s_RecordOffsetArray;
      int    []         s_RecordScaleArray;
      boolean           s_CacheOnServer;
      boolean           s_CacheOnFail;
      COM.novusnet.vision.java.commonbos.DapError s_DapError;

        /*==============================================================*/
        /* Protected Attributes                                         */
        /*==============================================================*/

        /*==============================================================*/
        /* Private attributes                                           */
        /*==============================================================*/

      private   Hashtable  recordHashtable;
      private   Hashtable  keyHashtable;

    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Operations  ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Class  Operations                                                */
    /*==================================================================*/

    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  getTransactionId                                */
        /**
         * This method returns the identifier string of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the static final transaction
         * ID of the concrete mapper subclass.
         *
         * @return      :String
         *               - the underlying DAS transaction identifier.
         */
        /*==============================================================*/
   public  String  getTransactionId (
                                    )
   {
      return (s_TransactionId);
   }
        /*==============================================================*/
        /*  OPERATION:  getQualifier                                */
        /**
         * This method returns the Qualifier string of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the Qualifier for this transaction
         *
         * @return      :String
         *               - the underlying DAS transaction Qualifier.
         */
        /*==============================================================*/
   public  String  getQualifier (
                                    )
   {
      return (s_Qualifier);
   }

        /*==============================================================*/
        /*  OPERATION:  getVersionNumber                                */
        /**
         * This method returns the version number of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the transaction version number
         * of the concrete subclass.
         *
         * @return      :int
         *               - the transaction version number
         */
        /*==============================================================*/
   public  int  getVersionNumber   (
                                   )
   {
      return (s_VersionNumber);
   }

        /*==============================================================*/
        /*  OPERATION:  getTimeoutValue                                 */
        /**
         * This method returns the (client) timeout value of the 
         * underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the transaction (client) timeout
         * value of the concrete subclass.
         *
         * @return      :int
         *               - the transaction timeout value
         */
        /*==============================================================*/
   public  int  getTimeoutValue    (
                                   )
   {
      return (s_TimeoutValue);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyBufferLength                              */
        /**
         * This method returns the key buffer length of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the static final key buffer length
         * of the concrete subclass.
         *
         * @return      :int
         *               - the length of the transaction's key buffer.
         */
        /*==============================================================*/
   public  int  getKeyBufferLength (
                                   )
   {
      return (s_KeyBufferLength);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordBufferLength                           */
        /**
         * This method returns the record buffer length of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the static final record buffer length
         * of the concrete subclass.
         *
         * @return      :int
         *               - the length of the transaction's record buffer.
         */
        /*==============================================================*/
   public  int  getRecordBufferLength (
                                      )
   {
      return (s_RecordBufferLength);
   }

        /*==============================================================*/
        /*  OPERATION:  getNumberOfKeyFields                            */
        /**
         * This method returns the number of fields in the key buffer
         * of the underlying DAS transaction (as defined in the
         * DAS TDT).
         * <p>
         * The method simply returns the static final key
         * buffer number of fields of the concrete subclass.
         *
         * @return      :int
         *               - The number of fields in the transaction's
         *                 key buffer.
         */
        /*==============================================================*/
   public  int  getNumberOfKeyFields (
                                     )
   {
      return (s_NumberOfKeyFields);
   }

        /*==============================================================*/
        /*  OPERATION:  getNumberOfRecordFields                         */
        /**
         * This method returns the number of fields in the record buffer
         * of the underlying DAS transaction (as defined in the
         * DAS TDT).
         * <p>
         * The method simply returns the static final record
         * buffer number of fields of the concrete subclass.
         *
         * @return      :int
         *               - The number of fields in the transaction's
         *                 record buffer.
         */
        /*==============================================================*/
   public  int  getNumberOfRecordFields (
                                        )
   {
      return (s_NumberOfRecordFields);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyName                                      */
        /**
         * This method returns the name associated with the specified
         * field (by index) within the key buffer of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final key field name array of the concrete subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of key fields.
         * @return      :String
         *               - the name of the indexed field within the
         *                 key buffer.
         */
        /*==============================================================*/
   public  String  getKeyName (
                               int  aIndex
                              )
                        throws ArrayIndexOutOfBoundsException
   {
      return (s_KeyNameArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordName                                   */
        /**
         * This method returns the name associated with the specified
         * field (by index) within the record buffer of the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final record field name array of the concrete subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of record fields.
         * @return      :String
         *               - the name of the indexed field within the
         *                 record buffer.
         */
        /*==============================================================*/
   public  String  getRecordName (
                                  int  aIndex
                                 )
                           throws ArrayIndexOutOfBoundsException
   {
      return (s_RecordNameArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyOffset                                    */
        /**
         * This method returns the offset associated with the specified
         * field (by index) within the key buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final key field offset array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of key fields.
         * @return      :int
         *               - the offset of the indexed field within the
         *                 key buffer.
         */
        /*==============================================================*/
   public  int  getKeyOffset (
                              int  aIndex
                             )
                       throws ArrayIndexOutOfBoundsException
   {
      return (s_KeyOffsetArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordOffset                                 */
        /**
         * This method returns the offset associated with the specified
         * field (by index) within the record buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final record field offset array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of record fields.
         * @return      :int
         *               - the offset of the indexed field within the
         *                 record buffer.
         */
        /*==============================================================*/
   public  int  getRecordOffset (
                                 int  aIndex
                                )
                          throws ArrayIndexOutOfBoundsException
   {
      return (s_RecordOffsetArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyLength                                    */
        /**
         * This method returns the length associated with the specified
         * field (by index) within the key buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final key field length array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of key fields.
         * @return      :int
         *               - the length of the indexed field in the
         *                 key buffer.
         */
        /*==============================================================*/
   public  int  getKeyLength (
                              int  aIndex
                             )
                       throws ArrayIndexOutOfBoundsException
   {
      return (s_KeyLengthArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordLength                                 */
        /**
         * This method returns the length associated with the specified
         * field (by index) within the record buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final record field length array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of record fields.
         * @return      :int
         *               - the length of the indexed field in the
         *                 record buffer.
         */
        /*==============================================================*/
   public  int  getRecordLength (
                                 int  aIndex
                                )
                          throws ArrayIndexOutOfBoundsException
   {
      return (s_RecordLengthArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyType                                      */
        /**
         * This method returns the type associated with the specified
         * field (by index) within the key buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final key field type array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of key fields.
         * @return      :int
         *               - the type of the indexed field in the
         *                 key buffer.
         */
        /*==============================================================*/
   public  int  getKeyType (
                            int  aIndex
                           )
                     throws ArrayIndexOutOfBoundsException
   {
      return (s_KeyTypeArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordType                                   */
        /**
         * This method returns the type associated with the specified
         * field (by index) within the record buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final record field type array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of record fields.
         * @return      :int
         *               - the type of the indexed field in the
         *                 record buffer.
         */
        /*==============================================================*/
   public  int  getRecordType (
                               int  aIndex
                              )
                        throws ArrayIndexOutOfBoundsException
   {
      return (s_RecordTypeArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getKeyIndexFromName                             */
        /**
         * This method returns the index associated with the specified
         * field (by name) within the key buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply searches through the static final
         * key field name array of the concrete subclass.
         *
         * @param       aName:String
         *                 the name associated with a field within the
         *                 vector of key fields.
         * @return      :int
         *               - the index of the named field in the
         *                 key buffer.
         * @exception   SQLException
         *                 This provides information about a database
         *                 access error.
         */
        /*==============================================================*/
   public  int  getKeyIndexFromName (
                                     String  aName
                                    )
                              throws ArrayIndexOutOfBoundsException,
                                     SQLException
   {
      int             myIndex;

      if (keyHashtable == null) {
	 keyHashtable = new Hashtable();
	 for (myIndex = 0; myIndex < s_NumberOfKeyFields; myIndex++) {
	    keyHashtable.put(s_KeyNameArray[myIndex] , new Integer(myIndex));	    
	 }
      }

      return ((Integer)keyHashtable.get(aName)).intValue();
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordIndexFromName                          */
        /**
         * This method returns the index associated with the specified
         * field (by name) within the record buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply searches through the static final
         * record field name array of the concrete subclass.
         *
         * @param       aName:String
         *                 the name associated with a field within the
         *                 vector of record fields.
         * @return      :int
         *               - the index of the named field in the
         *                 record buffer.
         * @exception   SQLException
         *                 This provides information about a database
         *                 access error.
         */
        /*==============================================================*/
   public  int  getRecordIndexFromName (
                                        String  aName
                                       )
                                 throws ArrayIndexOutOfBoundsException,
                                        SQLException
   {
      int myIndex;

      if (recordHashtable == null) {
	 recordHashtable = new Hashtable();
	 for (myIndex = 0; myIndex < s_NumberOfRecordFields; myIndex++) {
	    recordHashtable.put(s_RecordNameArray[myIndex] , new Integer(myIndex));
	 }
      }

      return ((Integer)recordHashtable.get(aName)).intValue();
   }


        /*==============================================================*/
        /*  OPERATION:  getKeyScale                                    */
        /**
         * This method returns the scale associated with the specified
         * field (by index) within the key buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final key field scale array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of key fields.
         * @return      :int
         *               - the scale of the indexed field within the
         *                 key buffer.
         */
        /*==============================================================*/
   public  int  getKeyScale (
                              int  aIndex
                             )
                       throws ArrayIndexOutOfBoundsException
   {
      return (s_KeyScaleArray [aIndex]);
   }

        /*==============================================================*/
        /*  OPERATION:  getRecordScale                                 */
        /**
         * This method returns the scale associated with the specified
         * field (by index) within the record buffer of the underlying DAS
         * transaction (as defined in the DAS TDT).
         * <p>
         * The method simply returns the appropriate entry in the
         * static final record field scale array of the concrete
         * subclass.
         *
         * @param       aIndex:int
         *                 the one-based index of the field within the
         *                 vector of record fields.
         * @return      :int
         *               - the scale of the indexed field within the
         *                 record buffer.
         */
        /*==============================================================*/
   public  int  getRecordScale (
                                 int  aIndex
                                )
                          throws ArrayIndexOutOfBoundsException
   {
      return (s_RecordScaleArray [aIndex]);
   }
        /*==============================================================*/
        /*  OPERATION:  isCacheOnFail                                 */
        /**
         * This method returns true or false based on if the the user 
         * deems this TXN cacheable on failure or not.  
         * <p>
         * @return      :boolean
         *               - True if cached, false if not.
         */
        /*==============================================================*/
   public  boolean  isCacheOnFail (
                                    )
   {
      return (s_CacheOnFail);
   }
 
        /*==============================================================*/
        /*  OPERATION:  isCacheOnserver                                 */
        /**
         * This method returns true or false based on if the the user 
         * deems this TXN cacheable on server or not.  
         * <p>
         * @return      :boolean
         *               - True if cached, false if not.
         */
        /*==============================================================*/
   public  boolean  isCacheOnServer (
                                    )
   {
      return (s_CacheOnServer);
   }

        /*==============================================================*/
        /*  OPERATION:  getDapError                                     */
        /**
         * This method returns the Dap Error returned by the underlying
         * DAS transaction (as defined in the DAS TDT).
         * <p>
         *
         * @return      :DapError
         *               - the underlying DAS transaction error.
         */
        /*==============================================================*/
   public  COM.novusnet.vision.java.commonbos.DapError  getDasError (
                                    )
   {
      return (s_DapError);
   }


    /*==================================================================*/
    /* Abstract Operations                                              */
    /*==================================================================*/
   public Exception  mapError (int    aMajorCode,
                               int    aMinorCode,
                               String aErrorText)
   {
      // rollback is not considered fatal, usually the txn that has really failed 
      // which caused the rollback is considered fatal error
      if ( aMajorCode == 0 || isRollBack(aMajorCode, aMinorCode) ) {
         return null;
      }

      return (new DapErrorException (aMajorCode, aMinorCode, aErrorText));
   }
    /*==================================================================*/
    /* Protected Operations                                             */
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  setTransactionId                                */
        /**
         * This method is used to set the identifier string of the
         * underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aTransactionId:String
         *               - the underlying DAS transaction identifier.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setTransactionId (
                                      String  aTransactionId
                                     )
   {
      s_TransactionId = aTransactionId;
   }
        /*==============================================================*/
        /*  OPERATION:  setQualifier                                */
        /**
         * This method is used to set the Qualifier string of the
         * underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aTransactionId:String
         *               - the underlying DAS transaction identifier.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setQualifier (
                                      String  aQualifier
                                     )
   {
      s_Qualifier = aQualifier;
   }

        /*==============================================================*/
        /*  OPERATION:  setVersionNumber                                */
        /**
         * This method is used to set the version number of the
         * underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aVersionNumber:int
         *               - the DAS transaction version number.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setVersionNumber (
                                      int  aVersionNumber
                                     )
   {
      s_VersionNumber = aVersionNumber;
   }

        /*==============================================================*/
        /*  OPERATION:  setTimeoutValue                                 */
        /**
         * This method is used to set the (client) timeout value of the
         * underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aTimeoutValue:int
         *               - the DAS transaction (client) timeout value.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setTimeoutValue  (
                                      int  aTimeoutValue
                                     )
   {
      s_TimeoutValue = aTimeoutValue;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyBufferLength                              */
        /**
         * This method is used to  set the length of the key buffer of
         * the underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyBufferLength:int
         *               - the key buffer length of the underlying
         *                 DAS transaction.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyBufferLength (
                                        int  aKeyBufferLength
                                       )
   {
      s_KeyBufferLength = aKeyBufferLength;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordBufferLength                           */
        /**
         * This method is used to set the length of the record buffer of
         * the underlying DAS transaction (as defined in the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordBufferLength:int
         *               - the record buffer length of the underlying
         *                 DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordBufferLength (
                                           int  aRecordBufferLength
                                          )
   {
      s_RecordBufferLength = aRecordBufferLength;
   }

        /*==============================================================*/
        /*  OPERATION:  setNumberOfKeyFields                            */
        /**
         * This method is used to set the number of fields in the key
         * buffer of the underlying DAS transaction (as defined in the
         * DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aNumberOfKeyFields:int
         *               - the number of key buffer fields in the
         *                 underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setNumberOfKeyFields (
                                          int  aNumberOfKeyFields
                                         )
   {
      s_NumberOfKeyFields = aNumberOfKeyFields;
   }

        /*==============================================================*/
        /*  OPERATION:  setNumberOfRecordFields                         */
        /**
         * This method is used to set the number of fields in the record
         * buffer of the underlying DAS transaction (as defined in the
         * DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aNumberOfRecordFields:int
         *               - the number of record buffer fields in the
         *                 underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setNumberOfRecordFields (
                                             int  aNumberOfRecordFields
                                            )
   {
      s_NumberOfRecordFields = aNumberOfRecordFields;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyNameArray                                 */
        /**
         * This method is used to set the array of field names of the
         * key buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyNameArray:String[]
         *               - the array of names of the key buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyNameArray (
                                     String []  aKeyNameArray
                                    )
   {
      s_KeyNameArray = aKeyNameArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordNameArray                              */
        /**
         * This method is used to set the array of field names of the
         * record buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordNameArray:String[]
         *               - the array of names of the record buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordNameArray (
                                        String []  aRecordNameArray
                                       )
   {
      s_RecordNameArray = aRecordNameArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyTypeArray                                 */
        /**
         * This method is used to set the array of field types of the
         * key buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyTypeArray:int[]
         *               - the array of types of the key buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyTypeArray (
                                     int []  aKeyTypeArray
                                    )
   {
      s_KeyTypeArray = aKeyTypeArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordTypeArray                              */
        /**
         * This method is used to set the array of field types of the
         * record buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordTypeArray:int[]
         *               - the array of types of the record buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordTypeArray (
                                        int []  aRecordTypeArray
                                       )
   {
      s_RecordTypeArray = aRecordTypeArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyOffsetArray                               */
        /**
         * This method is used to set the array of field offsets of the
         * key buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyOffsetArray:int[]
         *               - the array of offsets of the key buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyOffsetArray (
                                       int []  aKeyOffsetArray
                                      )
   {
      s_KeyOffsetArray = aKeyOffsetArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordOffsetArray                            */
        /**
         * This method is used to set the array of field offsets of the
         * record buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordOffsetArray:int[]
         *               - the array of offsets of the record buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordOffsetArray (
                                          int []  aRecordOffsetArray
                                         )
   {
      s_RecordOffsetArray = aRecordOffsetArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyLengthArray                               */
        /**
         * This method is used to set the array of field lengths of the
         * key buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyLengthArray:int[]
         *               - the array of lengths of the key buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyLengthArray (
                                       int []  aKeyLengthArray
                                      )
   {
      s_KeyLengthArray = aKeyLengthArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordLengthArray                            */
        /**
         * This method is used to set the array of field lengths of the
         * record buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordLengthArray:int[]
         *               - the array of lengths of the record buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordLengthArray (
                                          int []  aRecordLengthArray
                                         )
   {
      s_RecordLengthArray = aRecordLengthArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setKeyScaleArray                               */
        /**
         * This method is used to set the array of field scales of the
         * key buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aKeyScaleArray:int[]
         *               - the array of offsets of the key buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setKeyScaleArray (
                                       int []  aKeyScaleArray
                                      )
   {
      s_KeyScaleArray = aKeyScaleArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setRecordScaleArray                            */
        /**
         * This method is used to set the array of field scales of the
         * record buffer of the underlying DAS transaction (as defined in
         * the DAS TDT).
         * <p>
         * This protected method is used by the concrete subclass
         * to initialize the the base class's attribute so that
         * it can be accessed by base class methods.
         *
         * @param       aRecordScaleArray:int[]
         *               - the array of offsets of the record buffer fields
         *                 in the underlying DAS transaction
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setRecordScaleArray (
                                          int []  aRecordScaleArray
                                         )
   {
      s_RecordScaleArray = aRecordScaleArray;
   }

        /*==============================================================*/
        /*  OPERATION:  setCacheOnServer                                */
        /**
         * This method is used to set the cacheOnServer
         *
         * @param       aCacheOnServer:boolean
         *               - to cache or not to cache, that is the question
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setCacheOnServer (
                                      boolean aCacheOnServer
                                     )
   {
      s_CacheOnServer = aCacheOnServer;
   }
        /*==============================================================*/
        /*  OPERATION:  setCacheOnFail                                */
        /**
         * This method is used to set the cacheOnFail
         *
         * @param       aCacheOnFail:boolean
         *               - to cache or not to cache, that is the question
         *               even on failure of txn
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setCacheOnFail (
                                      boolean aCacheOnFail
                                     )
   {
      s_CacheOnFail = aCacheOnFail;
   }

        /*==============================================================*/
        /*  OPERATION:  setDapError                                     */
        /**
         * This method is used to set the Dap Error if the underlying 
	 * DAS transaction (as defined in the DAS TDT) creates one.
         * <p>
         *
         * @param       aDapError:DapError
         *               - the underlying DAS transaction error.
         * @return      :void
         */
        /*==============================================================*/
   protected  void  setDapError (
				 COM.novusnet.vision.java.commonbos.DapError aDapError
                                     )
   {
      s_DapError = aDapError;
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/


    /*==================================================================*/
    /*==========================              ==========================*/
    /*==========================  Unit Test   ==========================*/
    /*==========================              ==========================*/
    /*==================================================================*/
        /*==============================================================*/
        /*  OPERATION:  main                                            */
        /**
         * This method represents the unit test entry point for this
         * class.
         *
         * @param       aArgs:String[]
         *                 the command line arguments. [Unused].
         * @return      :void
         */
        /*==============================================================*/
   public  static  void  main (
                               String args[]
                              )
   {
   }

        /*==============================================================*/
        /* OPERATION:  isRollBack()                               */
        /*                                                              */
        /**
// ***********************************************************************************
// *      when we have a DasPackage and when one TXN fails all txns are either rolled
// *      back or bypassed(not executed)
// *      For some reason unknown to me (Parag), we get a diff ROLLBACK CODE
// *      for mainframe and non-mainframe txns.
// *      Same for bypassed txns
// *
// *      Look at the non-Mainframe file DAUOWMGR.C; it says the following
// *      #define MAJBYPASSED     (-900)          /* Bypassed due to previous error. */
// *      #define MAJROLLBACK     (-990)          /* Rolled-back due to subsequent error*/
// *      #define MINPRIORERR     (-100)          /* There was a previous error. */
// *      #define MINLATERERR     (-300)          /* There was a subsequent error. */
// *      #define MSGSUCCESSFUL   "SUCCESSFUL"
// *      #define MSGBYPASSED     "BYPASSED"
// *      #define MSGROLLBACK     "ROLLED BACK"
// *      #define MSGSENDERROR    "SEND ERROR"
// *
// *      And compare it to mainframe file DASERMSG.CPY; it says the following
// *     05  DASER-MAJOR-MSG-CODES.
// *        10  C-MAJ-BYPASSED           PIC S9(04) COMP VALUE -9010.
// *        10  C-MAJ-RLBK               PIC S9(04) COMP VALUE -9036.
// *    05  DASER-MINOR-MSG-CODES.
// *        10  C-MNR-PRIOR-ERROR        PIC S9(04) COMP VALUE -100.
// *        10  C-MNR-SUBSEQUENT-ERROR   PIC S9(04) COMP VALUE -300.
// *    05  DASER-MESSAGE-TXT.
// *        10  C-MSG-BYPASSED           PIC  X(20) VALUE
// *                                     'BYPASSED            '.
// *        10  C-MSG-ROLBK              PIC  X(20) VALUE
// *                                     'ROLLED BACK         '.
// *
// *    AND SO HERE FOLLOWS THE HACK..... since I don't know and shouldn't know
// *    whether the TXN is mainframe or not I check for all possibilites to
// *    detect a rollback/bypass and a subsequent package failure which I
// *    faithfully report back to client.
// ***********************************************************************************

   private  boolean  isRollBack(
                                     long majorCode,
                                     long minorCode
                                     )
   {
//##Begin DasPackager:isRollBack(DasTransaction,long) preserve=yes

       boolean retValue = false;

       // if returnCode indicates that there has been an error from DAP
       // or
       // if we have a bypassed txn and a minor errorcode of MINPRIORERR
       // or
       // if we have a rolled back txn and a minor errorcode of LATER/SUBSEQUENT error
       // return 1
       // otherwise return 0
       if ( ( (majorCode == MAJBYPASSED || majorCode == MAINFRAME_MAJBYPASSED) && minorCode == MINPRIORERR )
            ||
            ( (majorCode == MAJROLLBACK || majorCode == MAINFRAME_MAJROLLBACK) && minorCode == MINLATERERR )
          )
       {
           System.out.println("INFORMATIONAL:"+"PACKAGE ROLLBACK:Major=" + majorCode + " Minor=" + minorCode);
           retValue = true;
       }

       return retValue;
//##End   DasPackager:isRollBack(DasTransaction,long)
   }
}

