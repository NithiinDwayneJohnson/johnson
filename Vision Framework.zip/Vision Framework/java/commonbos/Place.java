/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      Place.java                                              */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1999 July 27 at 14:55:45 CDT                            */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import COM.novusnet.vision.java.businessobjects.BusinessObject;
import COM.novusnet.vision.java.persistence.PersistenceException;

        /*==============================================================*/
        /* Custom Imports                                               */
        /*==============================================================*/
//##Begin Imports preserve=yes

//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       Place                                                   */
/**
 * No documentation is currently available for this class.
 */
/*======================================================================*/
public  class  Place  extends  BusinessObject
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin Place:Attributes preserve=yes

//##End   Place:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private String code;
   private String description;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getCode                                          */
        /*                                                              */
        /**
         * This method returns the value of the "code" attribute.
         *  
         * @return      :String -
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  String  getCode (
                           )
   {
//##Begin Place:getCode() preserve=no

      fetch ();

      return (code);

//##End   Place:getCode()
   }

        /*==============================================================*/
        /* OPERATION:  getDescription                                   */
        /*                                                              */
        /**
         * This method returns the value of the "description" attribute.
         *  
         * @return      :String -
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  String  getDescription (
                                  )
   {
//##Begin Place:getDescription() preserve=no

      fetch ();

      return (description);

//##End   Place:getDescription()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setCode                                          */
        /*                                                              */
        /**
         * This method sets the value of the "code" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "code" attribute.
         */
        /*==============================================================*/
   public  void  setCode (
                          String  aValue
                         )
   {
//##Begin Place:setCode(String) preserve=no

      if (code == aValue) {
         return;
      }

      if (code != null) {
         if (code.equals (aValue)) {
            return;
         }
      }

      String myOldValue = code;
      code = aValue;

      setDirty ("code" , myOldValue , code);

      firePropertyChange ("code", myOldValue, code);

//##End   Place:setCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  setDescription                                   */
        /*                                                              */
        /**
         * This method sets the value of the "description" attribute.
         *  
         * @param       aValue:String
         *                 The value of the "description" attribute.
         */
        /*==============================================================*/
   public  void  setDescription (
                                 String  aValue
                                )
   {
//##Begin Place:setDescription(String) preserve=no

      if (description == aValue) {
         return;
      }

      if (description != null) {
         if (description.equals (aValue)) {
            return;
         }
      }

      String myOldValue = description;
      description = aValue;

      setDirty ("description" , myOldValue , description);

      firePropertyChange ("description", myOldValue, description);

//##End   Place:setDescription(String)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin Place:equals(Object) preserve=no

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (Place.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Check the equality of superclasses                   */
                /*======================================================*/
      if (!super.equals(aObject)) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      Place  myOther  = (Place) aObject;

      try {
         String myCode = getCode ();
         if (myCode != null) {
            if ( ! (myCode.equals (myOther.getCode ()))) {
               return (false);
            }
         }
         else if (myOther.getCode () != null) {
               return (false);
         }

      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Place::equals: " +
                                     myThrowable.toString ()
                                    );
      }
      return (true);

//##End   Place:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin Place:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         myHashCode = super.hashCode();
         String myCode = getCode ();
         if (myCode != null) {
            myHashCode += (37 * myHashCode) + (myCode.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Place::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   Place:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  processRestoreResult                             */
        /*                                                              */
        /**
         * This method is called when data is being restored into an
         * existing object (as opposed to a newly PO_Factory-created
         * object.)
         *  
         * @param       aObject:Object
         *                 The object from which results are to be
         *                 restored.
         * @exception   PersistenceException -
         *                 A persistence exception occurred (possibly due
         *                 to an implicit restore resulting from a get
         *                 method called internally).
         */
        /*==============================================================*/
   public  void  processRestoreResult (
                                       Object  aObject
                                      )
                                throws PersistenceException
   {
//##Begin Place:processRestoreResult(Object) preserve=no

      Place  myOther  = (Place) aObject;

      try {
         super.processRestoreResult  (myOther);
         setCode (myOther.getCode ());
         setDescription (myOther.getDescription ());
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "Place::processRestoreResult: " +
                                     myThrowable.toString ()
                                    );
      }

//##End   Place:processRestoreResult(Object)
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin Place:printOut() preserve=no

      try {
         System.out.println ("Place:");
         System.out.println ("   code: " + getCode ());
         System.out.println ("   description: " + getDescription ());
         super.printOut     ();
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   Place:printOut()
   }


}
