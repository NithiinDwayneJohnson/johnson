/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*   +==============================================================+   */
/*                                                                      */
/* MODULE:      PostalCode.java                                         */
/*                                                                      */
/* Generator:   ObjectGenerator    Version 1.0                          */
/* Emitter  :   JavaFileEmitter    Version 1.0                          */
/* Generated:   1998 February 25 at 16:01:02 GMT+00:00                  */
/*======================================================================*/

/*======================================================================*/
/*                          Package Definition                          */
/*======================================================================*/
package COM.novusnet.vision.java.commonbos;

/*======================================================================*/
/*                               Imports                                */
/*======================================================================*/
        /*==============================================================*/
        /* Generated Imports                                            */
        /*==============================================================*/
                /*======================================================*/
                /* Java Platform Core APIs                              */
                /*======================================================*/
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;

import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;
//##End   Imports

/*======================================================================*/
/*                  Class Definition / Implementation                   */
/*======================================================================*/

/*======================================================================*/
/* CLASS:       PostalCode                                              */
/**
 * This class represents a postal code (or a zip code as known in the US).
 * Different countries have different representations of a postal code. For
 * example, the US postal code can be made up of 5 or nine decimal digits
 * where as in sime countries of Europe, the postal code can include
 * alphabetical characters. The PostalCode class insulates the developer
 * from such gory details. Most of the work in the PostalCode class is
 * delegated to a PostalCodeLocale class. This class performs locale
 * specific operations such as validations and formatting.
 */
/*======================================================================*/
public  class  PostalCode  implements  Serializable
{


    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Attributes ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Custom Attributes                                                */
    /*==================================================================*/
//##Begin PostalCode:Attributes preserve=yes

//##End   PostalCode:Attributes

    /*==================================================================*/
    /* Private Attributes                                               */
    /*==================================================================*/
   private           String[]              postalCodeComponents;
   private transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
   private           PostalCodeLocale      postalCodeLocale;

    /*==================================================================*/
    /*===========================            ===========================*/
    /*=========================== Operations ===========================*/
    /*===========================            ===========================*/
    /*==================================================================*/

    /*==================================================================*/
    /* Constructor Operations                                           */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  PostalCode                                       */
        /*                                                              */
        /**
         * This constructor takes a string representation of a postal code.
         * If the postal code is invalid, a null is set in the postal code
         * field. The user can call isValid() to validate a postal code.
         *  
         * @param       postalCode:String
         */
        /*==============================================================*/
   public    PostalCode (
                         String  postalCode
                        )
   {
//##Begin PostalCode:PostalCode(String) preserve=yes
      setPostalCodeLocale(createPostalCodeLocale());
      setPostalCode(postalCode);
//##End   PostalCode:PostalCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  PostalCode                                       */
        /*                                                              */
        /**
         * Default constructor.
         *  
         */
        /*==============================================================*/
   public    PostalCode (
                        )
   {
//##Begin PostalCode:PostalCode() preserve=yes
      this(null);
//##End   PostalCode:PostalCode()
   }


    /*==================================================================*/
    /* Attribute Get Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  getPostalCodeComponents                          */
        /*                                                              */
        /**
         * This method returns the value of the postal code components
         * vector. Postal codes can have many components that are locale
         * dependendent. The components are stored in an array so that
         * locale specific postal codes can store them as components.
         *  
         * @return      :String[] -
         *                 The value of the postal code components vector.
         *                 Postal codes can have many components that are
         *                 locale dependendent. The components are stored
         *                 in an array so that locale specific postal codes
         *                 can store them as components.
         */
        /*==============================================================*/
   public  String[]  getPostalCodeComponents (
                                             )
   {
//##Begin PostalCode:getPostalCodeComponents() preserve=no

      return (postalCodeComponents);

//##End   PostalCode:getPostalCodeComponents()
   }

        /*==============================================================*/
        /* OPERATION:  getPropertyChangeSupport                         */
        /*                                                              */
        /**
         * This method returns the value of the "propertyChangeSupport"
         * attribute.
         *  
         * @return      :PropertyChangeSupport -
         *                 The value of the "propertyChangeSupport"
         *                 attribute.
         */
        /*==============================================================*/
   private  PropertyChangeSupport  getPropertyChangeSupport (
                                                            )
   {
//##Begin PostalCode:getPropertyChangeSupport() preserve=no

      return (propertyChangeSupport);

//##End   PostalCode:getPropertyChangeSupport()
   }

        /*==============================================================*/
        /* OPERATION:  getPostalCodeLocale                              */
        /*                                                              */
        /**
         * This method returns the value of the "postalCodeLocale"
         * attribute.
         *  
         * @return      :PostalCodeLocale -
         *                 The value of the "postalCodeLocale" attribute.
         */
        /*==============================================================*/
   public  PostalCodeLocale  getPostalCodeLocale (
                                                 )
   {
//##Begin PostalCode:getPostalCodeLocale() preserve=no

      return (postalCodeLocale);

//##End   PostalCode:getPostalCodeLocale()
   }


    /*==================================================================*/
    /* Attribute Set Operations                                         */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  setPostalCodeComponents                          */
        /*                                                              */
        /**
         * This method sets the value of the postal code components vector.
         * Postal codes can have many components that are locale
         * dependendent. The components are stored in an array so that
         * locale specific postal codes can store them as components.
         *  
         * @param       aValue:String[]
         *                 The value of the postal code components vector.
         *                 Postal codes can have many components that are
         *                 locale dependendent. The components are stored
         *                 in an array so that locale specific postal codes
         *                 can store them as components.
         */
        /*==============================================================*/
     void  setPostalCodeComponents (
                                    String[]  aValue
                                   )
   {
//##Begin PostalCode:setPostalCodeComponents(String[]) preserve=no

      postalCodeComponents = aValue;

//##End   PostalCode:setPostalCodeComponents(String[])
   }

        /*==============================================================*/
        /* OPERATION:  setPostalCodeLocale                              */
        /*                                                              */
        /**
         * This method sets the value of the "postalCodeLocale" attribute.
         *  
         * @param       aValue:PostalCodeLocale
         *                 The value of the "postalCodeLocale" attribute.
         */
        /*==============================================================*/
   public  void  setPostalCodeLocale (
                                      PostalCodeLocale  aValue
                                     )
   {
//##Begin PostalCode:setPostalCodeLocale(PostalCodeLocale) preserve=no

      postalCodeLocale = aValue;

//##End   PostalCode:setPostalCodeLocale(PostalCodeLocale)
   }


    /*==================================================================*/
    /* Base Class Override Operations                                   */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  equals                                           */
        /*                                                              */
        /**
         * This method determines whether or not this object is
         * functionally equal to another specified object.
         *  
         * @param       aObject:Object
         *                 The object instance to be compared to this one.
         * @return      :boolean -
         *                 true, if the two objects are of the same type
         *                 and equal; false, otherwise.
         */
        /*==============================================================*/
   public  boolean  equals (
                            Object  aObject
                           )
   {
//##Begin PostalCode:equals(Object) preserve=yes

                /*======================================================*/
                /* References are to the same object - they are equal   */
                /*======================================================*/
      if (this == aObject) {
         return (true);
      }

                /*======================================================*/
                /* Comparison object null (but "this" object cannot be) */
                /*======================================================*/
      if (aObject == null) {
         return (false);
      }

                /*======================================================*/
                /* Classes are different - objects can't be equal       */
                /*======================================================*/
      if (PostalCode.class != aObject.getClass ()) {
         return (false);
      }

                /*======================================================*/
                /* Compare the individual attributes                    */
                /*======================================================*/
      PostalCode  myOther  = (PostalCode) aObject;

      if (!getUnformattedPostalCode().equals(myOther.getUnformattedPostalCode())) {
	 return (false);
      }

      return (true);

//##End   PostalCode:equals(Object)
   }

        /*==============================================================*/
        /* OPERATION:  hashCode                                         */
        /*                                                              */
        /**
         * This method determines a hash code value for this object
         * instance.
         *  
         * @return      :int -
         *                 The calculated hash code value.
         */
        /*==============================================================*/
   public  int  hashCode (
                         )
   {
//##Begin PostalCode:hashCode() preserve=no

                int             myHashCode      = 0;

      try {
         String[] myPostalCodeComponents = getPostalCodeComponents ();
         if (myPostalCodeComponents != null) {
            myHashCode += (37 * myHashCode) + (myPostalCodeComponents.hashCode ());
         }
      }
      catch (Throwable myThrowable) {
         throw new RuntimeException (
                                     "PostalCode::hashCode: " +
                                     myThrowable.toString ()
                                    );
      }
      return (myHashCode);

//##End   PostalCode:hashCode()
   }

        /*==============================================================*/
        /* OPERATION:  printOut                                         */
        /*                                                              */
        /**
         * This method is used to print out the current state of this
         * object instance.
         *  
         */
        /*==============================================================*/
   public  void  printOut (
                          )
   {
//##Begin PostalCode:printOut() preserve=no

      try {
         System.out.println ("PostalCode:");
         System.out.println ("   postalCodeComponents: " + getPostalCodeComponents ());
         System.out.println ("   propertyChangeSupport: " + getPropertyChangeSupport ());
         System.out.println ("   postalCodeLocale: " + getPostalCodeLocale ());
      }
      catch (Throwable myThrowable) {
         myThrowable.printStackTrace ();
         throw new RuntimeException (myThrowable.toString ());
      }

//##End   PostalCode:printOut()
   }


    /*==================================================================*/
    /* Public Operations                                                */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  addPropertyChangeListener                        */
        /*                                                              */
        /**
         * Adds a property change listener to the list of listeners. Used
         * by objects that are interested in events fiered by this object.
         *  
         * @param       aListener:PropertyChangeListener
         */
        /*==============================================================*/
   public  void  addPropertyChangeListener (
                                            PropertyChangeListener  aListener
                                           )
   {
//##Begin PostalCode:addPropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().addPropertyChangeListener (aListener);
//##End   PostalCode:addPropertyChangeListener(PropertyChangeListener)
   }

        /*==============================================================*/
        /* OPERATION:  removePropertyChangeListener                     */
        /*                                                              */
        /**
         * Removes the listener from the listener list.
         *  
         * @param       aListener:PropertyChangeListener
         */
        /*==============================================================*/
   public  void  removePropertyChangeListener (
                                               PropertyChangeListener  aListener
                                              )
   {
//##Begin PostalCode:removePropertyChangeListener(PropertyChangeListener) preserve=yes
      getPropertyChangeSupport ().removePropertyChangeListener (aListener);
//##End   PostalCode:removePropertyChangeListener(PropertyChangeListener)
   }

        /*==============================================================*/
        /* OPERATION:  setPostalCode                                    */
        /*                                                              */
        /**
         * Sets the postal code to the supplied string. The string is
         * validated, and if invalid the postal code is set to null.
         * Otherwise, it is broken into components by the locale dependent
         * postal code and stored. The user need not deal with components.
         *  
         * @param       postalCodeString:String
         */
        /*==============================================================*/
   public  void  setPostalCode (
                                String  postalCodeString
                               )
   {
//##Begin PostalCode:setPostalCode(String) preserve=yes
      getPostalCodeLocale().parsePostalCode(postalCodeString, 
					    this);
//##End   PostalCode:setPostalCode(String)
   }

        /*==============================================================*/
        /* OPERATION:  getFormattedPostalCode                           */
        /*                                                              */
        /**
         * Returns a formatted representation of a postal code.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getFormattedPostalCode (
                                          )
   {
//##Begin PostalCode:getFormattedPostalCode() preserve=yes
      return (getPostalCodeLocale().getFormattedPostalCode(this));
//##End   PostalCode:getFormattedPostalCode()
   }

        /*==============================================================*/
        /* OPERATION:  getUnformattedPostalCode                         */
        /*                                                              */
        /**
         * Returns an unformatted representation of a postal code.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getUnformattedPostalCode (
                                            )
   {
//##Begin PostalCode:getUnformattedPostalCode() preserve=yes
      return (getPostalCodeLocale().getUnformattedPostalCode(this));
//##End   PostalCode:getUnformattedPostalCode()
   }

        /*==============================================================*/
        /* OPERATION:  toString                                         */
        /*                                                              */
        /**
         * Returns a string representation of a postal code. The string is
         * formatted.
         *  
         * @return      :String -
         */
        /*==============================================================*/
   public  String  toString (
                            )
   {
//##Begin PostalCode:toString() preserve=yes
      return (getFormattedPostalCode());
//##End   PostalCode:toString()
   }

        /*==============================================================*/
        /* OPERATION:  getPostalCodeComponent                           */
        /*                                                              */
        /**
         * Returns a component of a postal code. Callers of this method
         * usually know the specific locale that they are dealing with.
         *  
         * @param       index:int
         * @return      :String -
         */
        /*==============================================================*/
   public  String  getPostalCodeComponent (
                                           int  index
                                          )
   {
//##Begin PostalCode:getPostalCodeComponent(int) preserve=yes
      if ( (postalCodeComponents != null) && 
	   (postalCodeComponents.length > index) ) {
	 return (postalCodeComponents[index]);
      }

      return (null);
//##End   PostalCode:getPostalCodeComponent(int)
   }


    /*==================================================================*/
    /* Private Operations                                               */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  firePropertyChange                               */
        /*                                                              */
        /**
         * @param       propertyName:String
         * @param       oldValue:Object
         * @param       newValue:Object
         */
        /*==============================================================*/
   private  void  firePropertyChange (
                                      String  propertyName,
                                      Object  oldValue,
                                      Object  newValue
                                     )
   {
//##Begin PostalCode:firePropertyChange(String,Object,Object) preserve=yes
      getPropertyChangeSupport ().firePropertyChange (propertyName, oldValue, newValue);    
//##End   PostalCode:firePropertyChange(String,Object,Object)
   }


    /*==================================================================*/
    /* Class Operations                                                 */
    /*==================================================================*/
        /*==============================================================*/
        /* OPERATION:  isValid                                          */
        /*                                                              */
        /**
         * Returns true if the postal code is valid for the current locale.
         * Otherwise a false is returned.
         *  
         * @param       postalCode:String
         * @return      :boolean -
         */
        /*==============================================================*/
   public static  boolean  isValid (
                                    String  postalCode
                                   )
   {
//##Begin PostalCode:isValid(String) preserve=yes
      PostalCodeLocale locale = createPostalCodeLocale();
      return (locale.isValid(postalCode));
//##End   PostalCode:isValid(String)
   }

        /*==============================================================*/
        /* OPERATION:  createPostalCodeLocale                           */
        /*                                                              */
        /**
         * Creates the appropriate postal code locale object.
         *  
         * @return      :PostalCodeLocale -
         */
        /*==============================================================*/
   private static  PostalCodeLocale  createPostalCodeLocale (
                                                            )
   {
//##Begin PostalCode:createPostalCodeLocale() preserve=yes
      ResourceResolver rr = new ResourceResolver();

      //=================================================================
      // Create a phone locale instance based on the current locale
      // We will look for the PhoneLocale object in the proper locale
      // subdirectory.
      //=================================================================
      PostalCodeLocale myPostalCodeLocale = (PostalCodeLocale)rr.getResourceForClass(PostalCode.class, 
										     "PostalCodeLocale");

      if (myPostalCodeLocale == null) {
	 throw new RuntimeException("Missing postal code locale information.");
      }

      return (myPostalCodeLocale);

//##End   PostalCode:createPostalCodeLocale()
   }

        /*==============================================================*/
        /* OPERATION:  main                                             */
        /*                                                              */
        /**
         * This method is represents the command-line executable entry
         * point for the PostalCode class.
         *  
         * @param       aArgs:String[]
         *                 The command-line arguments.
         */
        /*==============================================================*/
   public static  void  main (
                              String[]  aArgs
                             )
   {
//##Begin PostalCode:main(String[]) preserve=yes
      System.out.println("Checking validity of 60194. Should be true and the result is " + PostalCode.isValid("60194"));
      System.out.println("Checking validity of 0194. Should be false and the result is " + PostalCode.isValid("0194"));
      System.out.println("Checking validity of 60194-1234. Should be true and the result is " + PostalCode.isValid("60194-1234"));
      System.out.println("Checking validity of 60194-234.  Should be false and the result is " + PostalCode.isValid("60194-234"));

      {
	 PostalCode myPostalCode = new PostalCode("60194-1234");
	 System.out.println(myPostalCode + " should format to 60194-1234");
      }

      {
	 PostalCode myPostalCode = new PostalCode("601941234");
	 System.out.println(myPostalCode + " should format to 60194-1234");
      }

      {
	 PostalCode myPostalCode = new PostalCode("60194");
	 System.out.println(myPostalCode + " should format to 60194-0000");
      }

      {
	 PostalCode myPostalCode = new PostalCode(null);
	 System.out.println(myPostalCode + " should format to 00000-0000");
      }

//##End   PostalCode:main(String[])
   }


}
