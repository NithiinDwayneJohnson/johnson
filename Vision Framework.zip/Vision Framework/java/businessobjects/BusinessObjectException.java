package COM.novusnet.vision.java.businessobjects;

import java.lang.Exception;

public class BusinessObjectException extends Exception {

    public BusinessObjectException(String text) {
       super(text);
    }

}

