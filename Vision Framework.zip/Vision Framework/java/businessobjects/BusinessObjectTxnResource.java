/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

import java.lang.reflect.Method;
import java.util.Iterator;

import COM.novusnet.vision.java.transactions.Resource;
import COM.novusnet.vision.java.transactions.TransactionService;
import COM.novusnet.vision.java.utility.textformatting.Case;

/**
 * The Transaction Service uses a two-phase commit protocol to complete a
 * top-level transaction with each registered resource. The Resource
 * interface defines the operations invoked by the transaction service on
 * each resource.  Each object supporting the Resource interface is
 * implicitly associated with a single top-level transaction.
 * @version 1.0, 7-5-1998
 */
public class BusinessObjectTxnResource implements Resource {
	/*==================================================================*/
	/* Private Attributes                                               */
	/*==================================================================*/
	private Object beforeImage = null;
	private boolean involved = true;
	private BusinessObject businessObject = null;

	/*==================================================================*/
	/* Constructor Operations                                           */
	/*==================================================================*/

	/**
	 * Contructor.
	 * @param       aBO:BusinessObject
	 */
	public BusinessObjectTxnResource(BusinessObject aBO) {
		setBusinessObject(aBO);
		setBeforeImage(aBO.getBeforeImage());
	}

	/**
	 * This method returns the value of a before image reference. This
	 * image is BO dependent. At the beginning of a transaction, the
	 * transaction resource asks the BO for the image. At the end of
	 * transaction (in the case of a rollback), the transaction
	 * resource hands back the image to the BO for restoration.
	 * @return      :Object -
	 */
	public Object getBeforeImage() {
		return (beforeImage);
	}

	/**
	 * This method returns the value of this flag is set to reflect
	 * whether the BO should be involved in the 2-phase commit passes.
	 * The default is set to true.
	 * @return      :boolean -
	 */
	public boolean isInvolved() {
		return (involved);
	}

	/**
	 * This method returns the value of the "businessObject" attribute.
	 *  
	 * @return      :BusinessObject -
	 *                 The value of the "businessObject" attribute.
	 */
	protected BusinessObject getBusinessObject() {
		return (businessObject);
	}

	/*==================================================================*/
	/* Attribute Set Operations                                         */
	/*==================================================================*/

	/**
	 * This method sets the value of a before image reference. This
	 * image is BO dependent. At the beginning of a transaction, the
	 * transaction resource asks the BO for the image. At the end of
	 * transaction (in the case of a rollback), the transaction
	 * resource hands back the image to the BO for restoration.
	 *  
	 * @param       aValue:Object
	 */
	private void setBeforeImage(Object aValue) {
		beforeImage = aValue;
	}

	/**
	 * This method sets the value of this flag is set to reflect
	 * whether the BO should be involved in the 2-phase commit passes.
	 * The default is set to true.
	 *  
	 * @param       aValue:boolean
	 */
	public void setInvolved(boolean aValue) {
		involved = aValue;
	}

	/**
	 * This method sets the value of the "businessObject" attribute.
	 * @param       aValue:BusinessObject
	 */
	protected void setBusinessObject(BusinessObject aValue) {
		businessObject = aValue;
	}

	/*==================================================================*/
	/* Base Class Override Operations                                   */
	/*==================================================================*/

	/**
	 * This method is used to print out the current state of this
	 * object instance.
	 */
	public void printOut() {
		try {
			System.out.println("BusinessObjectTxnResource:");
			System.out.println("   beforeImage: " + getBeforeImage());
			System.out.println("   involved: " + isInvolved());
			System.out.println("   businessObject: " + getBusinessObject());
		} catch (Throwable myThrowable) {
			myThrowable.printStackTrace();
			throw new RuntimeException(myThrowable.toString());
		}
	}

	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/

	/**
	 * If necessary, the resource should commit all changes made as
	 * part of the transaction. If the resource has forgotten the
	 * transaction it should do nothing.
	 */
	public void commit() {
		cleanup();
	}

	/**
	 * This operation is invoked to begin the two-phase commit protocol
	 * on the resource. The resource can respond in several ways,
	 * represented by the Vote result.
	 *  
	 * @return      :int -
	 */
	public int prepare() {
		if (!isInvolved()) {
			cleanup();
			return TransactionService.VOTE_READONLY;
		}

		int myVote = getBusinessObject().prepare();

		//================================================================
		// If the vote is readonly, we will never be called again by the
		// transaction service
		//================================================================
		if (myVote == TransactionService.VOTE_READONLY) {
			cleanup();
		}

		return (myVote);
	}

	/**
	 * If necessary, the resource should rollback all changes made as
	 * part of the transaction.  If the resource has forgotten the
	 * transaction, it should do nothing.                              
	 */
	public void rollback() {
		try {
			if (isInvolved()) {
				getBusinessObject().reset();
			}
		} finally {
			cleanup();
		}
	}

	/**
	 * This method performs a default reset of the BO. This involves
	 * resetting the attributes to there pre-transaction value. A user
	 * that overrides the reset method should always call the
	 * performDefaultReset method on the transaction restore.
	 * <p>
	 * The way the image of the BO is restored is thru the dynamic
	 * invocation API of the reflection API. For each dirty attribute,
	 * a setter that takes the parameter type that is stored in our
	 * dirty list is called.
	 */
	public void performDefaultReset() {
		Iterator /*enum*/
		itr = getBusinessObject().getDirtyAttributes().iterator();
		Class aClass = getBusinessObject().getClass();
		Method aMethod = null;
		Method[] methods = aClass.getMethods();
		String fieldName = null;
		String methodName = null;
		Object attributeValue = null;

		try {
			while (itr.hasNext()) {

				fieldName = (String) itr.next();
				methodName = "set" + Case.capitalize(fieldName);

				for (int i = 0; i < methods.length; i++) {
					if (methods[i].getName().equals(methodName)) {
						attributeValue =
							getBusinessObject().getAttributeResetValue(
								fieldName);
						Class parameters[] = methods[i].getParameterTypes();
						Object args[] = { attributeValue };
						aMethod = aClass.getMethod(methodName, parameters);
						aMethod.invoke(getBusinessObject(), args);
						break;
					}
				}
			}
		} catch (Throwable e) {
			throw new RuntimeException(
				"Failed to reset attribute. \nClass is:"
					+ aClass
					+ ". Field is: "
					+ fieldName
					+ " .Method is: "
					+ methodName
					+ "\n .Attribute value is: "
					+ attributeValue);
		}
	}

	/**
	 * This method always returns false!
	 * @return      :boolean -
	 */
	public boolean isLastCalled() {
		return false;
	}

	/*==================================================================*/
	/* Private Operations                                               */
	/*==================================================================*/

	/**
	 * Cleans up BO transaction involvement.
	 */
	private void cleanup() {
		getBusinessObject().setTransactionControl(null);
		getBusinessObject().setBusinessObjectTxnResource(null);
	}
}
