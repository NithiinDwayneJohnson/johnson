/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

/**
 * A lookup list is handy class for maintaining a key to object mapping. It
 * allows an object to be retrieved from a container using a key. Lookup
 * lists candidates include states, countries, area codes. Data lists that
 * are static and rarely change.
 * <p>
 * Keyed and Index based lookup methods are provided by lookup lists. This
 * kind of access mechanism is very useful for a GUI application where the
 * code usually deals with an index. The GUI usually displays the
 * description and not the code. The lookup class provides an easy way of
 * mapping descriptions back to codes.
 * <p>
 * Previously this used to contain the getElementAt and indexOf methods.
 * They have been moved up to the parent class. Which makes this an empty
 * class. It is being left as is since there are many references to it by
 * other BOs.
 * @version 1.0, 11-14-1997
 */
public  class  BusinessObjectLookupList  extends  BusinessObjectOrderedContainer {


}

