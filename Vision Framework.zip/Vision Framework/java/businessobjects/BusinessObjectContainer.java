/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.AbstractListModel;
import javax.swing.ListModel;
import javax.swing.event.ListDataListener;

import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.PO;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.transactions.TransactionService;
import COM.novusnet.vision.java.utility.helpers.ClassHelper;

/**
 * A business object container is a business object that can contain other
 * business objects. Standard list operations are provided. There are many
 * possible types of collection classes and forcing a specific type in a
 * base class is very inflexible. Replacing (at construction time) the
 * default collection class is accomplished by calling the setContainer()
 * method.
 * <p>
 * This class defines a subset of the methods from the Container class of
 * the jgl collection set. Since all containers implement these methods.
 * Subclasses should define other specialty behavior that use the specific
 * jgl collection classes.
 * <p>
 * Most operations on this class are persistent. For example, a remove
 * operation deletes the actual BO. 
 * @version 1.0, 4-3-1999
 */
public abstract class BusinessObjectContainer
	extends BusinessObject
	implements ListModel {

	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Attributes ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/

	/*==================================================================*/
	/* Custom Attributes                                                */
	/*==================================================================*/
	//##Begin BusinessObjectContainer:Attributes preserve=yes

	//##End   BusinessObjectContainer:Attributes

	/*==================================================================*/
	/* Private Attributes                                               */
	/*==================================================================*/
	private transient BOListModel listModelDelegate = null;
	private Collection collection = null;
	private Map map = null;

	/*==================================================================*/
	/*===========================            ===========================*/
	/*=========================== Operations ===========================*/
	/*===========================            ===========================*/
	/*==================================================================*/

	/*==================================================================*/
	/* Attribute Get Operations                                         */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  getListModelDelegate                             */
	/*                                                              */
	/**
	 * This method returns the value of the "listModelDelegate"
	 * attribute.
	 *  
	 * @return      :BOListModel -
	 *                 The value of the "listModelDelegate" attribute.
	 */
	/*==============================================================*/
	protected BOListModel getListModelDelegate() {
		//##Begin BusinessObjectContainer:getListModelDelegate() preserve=yes

		if (listModelDelegate == null) {
			listModelDelegate = new BOListModel();
		}

		return (listModelDelegate);

		//##End   BusinessObjectContainer:getListModelDelegate()
	}

	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  fireIntervalRemoved                              */
	/*                                                              */
	/**
	 * This method must be called when elements are removed.
	 *  
	 * @param       source:Object
	 * @param       index0:int
	 * @param       index1:int
	 */
	/*==============================================================*/
	public void fireIntervalRemoved(Object source, int index0, int index1) {
		//##Begin BusinessObjectContainer:fireIntervalRemoved(Object,int,int) preserve=yes
		getListModelDelegate().fireIntervalRemoved(source, index0, index1);
		//##End   BusinessObjectContainer:fireIntervalRemoved(Object,int,int)
	}

	/*==============================================================*/
	/* OPERATION:  fireIntervalAdded                                */
	/*                                                              */
	/**
	 * This method must be called when new elements are added.
	 *  
	 * @param       source:Object
	 * @param       index0:int
	 * @param       index1:int
	 */
	/*==============================================================*/
	public void fireIntervalAdded(Object source, int index0, int index1) {
		//##Begin BusinessObjectContainer:fireIntervalAdded(Object,int,int) preserve=yes
		getListModelDelegate().fireIntervalAdded(source, index0, index1);
		//##End   BusinessObjectContainer:fireIntervalAdded(Object,int,int)
	}

	/*==============================================================*/
	/* OPERATION:  fireContentsChanged                              */
	/*                                                              */
	/**
	 * This method must be called when the contents of the list change.
	 *  
	 * @param       source:Object
	 * @param       index0:int
	 * @param       index1:int
	 */
	/*==============================================================*/
	public void fireContentsChanged(Object source, int index0, int index1) {
		//##Begin BusinessObjectContainer:fireContentsChanged(Object,int,int) preserve=yes
		getListModelDelegate().fireContentsChanged(source, index0, index1);
		//##End   BusinessObjectContainer:fireContentsChanged(Object,int,int)
	}

	/*==============================================================*/
	/* OPERATION:  isEmpty                                          */
	/*                                                              */
	/**
	 * @return true if I contain no objects
	 *  
	 * @return      :boolean -
	 */
	/*==============================================================*/
	public final boolean isEmpty() {
		//##Begin BusinessObjectContainer:isEmpty() preserve=yes

		if (getCollection() != null) {
			return getCollection().isEmpty(); 
		} else {
			return getMap().isEmpty();
		}

		//##End   BusinessObjectContainer:isEmpty()
	}

	/*==============================================================*/
	/* OPERATION:  elements                                         */
	/*                                                              */
	/**
	 * @return An Iterator of the components in this container 
	 *  
	 * @return      :Iterator -
	 */
	/*==============================================================*/
	public Iterator elements() {
		//##Begin BusinessObjectContainer:elements() preserve=yes

		if (getCollection() != null) {
			return getCollection().iterator();
		} else {
			return getMap().values().iterator();
		}

		//##End   BusinessObjectContainer:elements()
	}

	/*==============================================================*/
	/* OPERATION:  start                                            */
	/*                                                              */
	/**
	 * @return an iterator positioned at my first item. 
	 *  
	 * @return      :Iterator -
	 */
	/*==============================================================*/
	public Iterator start() {
		//##Begin BusinessObjectContainer:start() preserve=yes

		if (getCollection() != null) {
			return getCollection().iterator();
		} else {
			return getMap().values().iterator();
		}

		//##End   BusinessObjectContainer:start()
	}

	/*==============================================================*/
	/* OPERATION:  clear                                            */
	/*                                                              */
	/**
	 * Remove all of my objects without updating the database. To
	 * actually remove the itms from the database, please user
	 * removeAll().
	 *  
	 */
	/*==============================================================*/
	public void clear() {
		//##Begin BusinessObjectContainer:clear() preserve=yes

		if (getCollection() != null) {
			getCollection().clear();
		} else {
			getMap().clear();
		}

		fireContentsChanged(this, -1, -1);

		//##End   BusinessObjectContainer:clear()
	}

	/*==============================================================*/
	/* OPERATION:  equals                                           */
	/*                                                              */
	/**
	 * This method is overriden from Object. The default behavior calls
	 * equals() on the embedded collection class instance.
	 *  
	 * @param       obj:Object
	 * @return      :boolean -
	 */
	/*==============================================================*/
	public boolean equals(Object obj) {
		//##Begin BusinessObjectContainer:equals(Object) preserve=yes
		if (obj != null && obj instanceof BusinessObjectContainer) {
			if (getCollection() != null) {
				return getCollection().equals( ((BusinessObjectContainer) obj).getCollection() );
			} else {
				return getMap().equals( ((BusinessObjectContainer) obj).getMap() );
			}
		} else {
			return false;
		}

		//##End   BusinessObjectContainer:equals(Object)
	}

	/*==============================================================*/
	/* OPERATION:  hashCode                                         */
	/*                                                              */
	/**
	 * This method is overriden from Object. The default behavior calls
	 * hasCode() on the embedded collection class instance.
	 *  
	 * @return      :int -
	 */
	/*==============================================================*/
	public int hashCode() {
		//##Begin BusinessObjectContainer:hashCode() preserve=yes

		int result = 0;

		if (getCollection() != null) {
			result = 37 * result + getCollection().hashCode();
		} else {
			result = 37 * result + getMap().hashCode();
		}

		return result;

		//##End   BusinessObjectContainer:hashCode()
	}

	/*==============================================================*/
	/* OPERATION:  setFetched                                       */
	/*                                                              */
	/**
	 * This sets the retrieved state of the container. All the
	 * contained objects are marked as fetched.
	 * <p>
	 * @param flag The fetched state to set the BO to.
	 *  
	 * @param       flag:boolean
	 */
	/*==============================================================*/
	public final void setFetched(boolean flag) {
		//##Begin BusinessObjectContainer:setFetched(boolean) preserve=yes

		Iterator itr = null;
		BusinessObject aBO = null;

		if (getCollection() != null) {
			synchronized (getCollection()) {
				itr = elements();
	
				while (itr.hasNext()) {
					aBO = (BusinessObject) itr.next();
					aBO.setFetched(flag);
				}
			}
		} else {
			synchronized (getMap()) {
				itr = elements();
	
				while (itr.hasNext()) {
					aBO = (BusinessObject) itr.next();
					aBO.setFetched(flag);
				}
			}
		}

		super.setFetched(flag);

		return;

		//##End   BusinessObjectContainer:setFetched(boolean)
	}

	/*==============================================================*/
	/* OPERATION:  isDirty                                          */
	/*                                                              */
	/**
	 * @return The dirty state of the object. This method returns true
	 * if any objects of the container is dirty.
	 *  
	 * @param       name:String
	 * @return      :boolean -
	 */
	/*==============================================================*/
	public final boolean isDirty(String name) {
		//##Begin BusinessObjectContainer:isDirty(String) preserve=yes

		if (name != null) {
			return super.isDirty(name);
		}

		Iterator itr = null;
		if (getCollection() != null) {
			synchronized (getCollection()) {
				itr = getCollection().iterator();
				while (itr.hasNext()) {
					BusinessObject aBO = (BusinessObject) itr.next();
					if (aBO.isDirty(null)) {
						return true;
					}
				}
			}
		} else {
			synchronized (getMap()) {
				itr = getMap().values().iterator();
				while (itr.hasNext()) {
					BusinessObject aBO = (BusinessObject) itr.next();
					if (aBO.isDirty(null)) {
						return true;
					}
				}
			}
		}

		return false;

		//##End   BusinessObjectContainer:isDirty(String)
	}

	/*==============================================================*/
	/* OPERATION:  setDirty                                         */
	/*                                                              */
	/**
	 * This sets the dirty state of an attribute or the whole BO.
	 * <p>
	 * @param  name  If name is null, setDirty takes on BO scope
	 * behavior. This marks every BO in the container as dirty.  
	 * <p>
	 * @param dirtyState A false for dirtyState clears all dirty
	 * attributes and mark all objects as clean. whereas a true would
	 * mark the whole BO as dirty that includes the contained objects.
	 *  
	 * @param       name:String
	 * @param       dirtyState:boolean
	 */
	/*==============================================================*/
	public final void setDirty(String name, boolean dirtyState) {
		//##Begin BusinessObjectContainer:setDirty(String,boolean) preserve=yes

		if (name != null) {
			super.setDirty(name, dirtyState);
		}

		Iterator itr = elements();

		if (getCollection() != null) {
			synchronized (getCollection()) {
				while (itr.hasNext()) {
					BusinessObject aBO = (BusinessObject) itr.next();
					aBO.setDirty(null, dirtyState);
				}		
			}
		} else {
			synchronized (getMap()) {
				while (itr.hasNext()) {
					BusinessObject aBO = (BusinessObject) itr.next();
					aBO.setDirty(null, dirtyState);
				}
			}
		}

		return;

		//##End   BusinessObjectContainer:setDirty(String,boolean)
	}

	/*==============================================================*/
	/* OPERATION:  combine                                          */
	/*                                                              */
	/**
	 * Combine the contents of one BusinessObject container with
	 * another. Duplicate semantics depend on the type of the
	 * container.
	 * <p>
	 * This class simply copies the source container contents into the
	 * target container.
	 *  
	 * @param       container:BusinessObjectContainer
	 */
	/*==============================================================*/
	public abstract void combine(BusinessObjectContainer container);

	/*==============================================================*/
	/* OPERATION:  getSize                                          */
	/*                                                              */
	/**
	 * @return The number of objects contained in this business object.
	 *  
	 * @return      :int -
	 */
	/*==============================================================*/
	public final int getSize() {
		//##Begin BusinessObjectContainer:getSize() preserve=yes

		if (getCollection() != null) {
			return getCollection().size();
		} else {
			return getMap().size();
		}

		//##End   BusinessObjectContainer:getSize()
	}

	/*==============================================================*/
	/* OPERATION:  getElementAt                                     */
	/*                                                              */
	/**
	 * @return The object at the position specified  by the given
	 * index.
	 *  
	 * @param       anIndex:int
	 * @return      :Object -
	 */
	/*==============================================================*/
	public Object getElementAt(int anIndex) {
		//##Begin BusinessObjectContainer:getElementAt(int) preserve=yes

		return null;

		//##End   BusinessObjectContainer:getElementAt(int)
	}

	/*==============================================================*/
	/* OPERATION:  indexOf                                          */
	/*                                                              */
	/**
	 * @param       anObject:Object
	 * @return      :int -
	 */
	/*==============================================================*/
	public int indexOf(Object anObject) {
		//##Begin BusinessObjectContainer:indexOf(Object) preserve=yes
		return -1;
		//##End   BusinessObjectContainer:indexOf(Object)
	}

	/*==============================================================*/
	/* OPERATION:  addListDataListener                              */
	/*                                                              */
	/**
	 * Add a listener to the Business Object Container, for purposes of
	 * event notification.
	 *  
	 * @param       aListener:ListDataListener
	 */
	/*==============================================================*/
	public void addListDataListener(ListDataListener aListener) {
		//##Begin BusinessObjectContainer:addListDataListener(ListDataListener) preserve=yes

		getListModelDelegate().addListDataListener(aListener);

		//##End   BusinessObjectContainer:addListDataListener(ListDataListener)
	}

	/*==============================================================*/
	/* OPERATION:  removeListDataListener                           */
	/*                                                              */
	/**
	 * Remove a listener from the Business Object Container.
	 *  
	 * @param       aListener:ListDataListener
	 */
	/*==============================================================*/
	public void removeListDataListener(ListDataListener aListener) {
		//##Begin BusinessObjectContainer:removeListDataListener(ListDataListener) preserve=yes

		getListModelDelegate().removeListDataListener(aListener);

		//##End   BusinessObjectContainer:removeListDataListener(ListDataListener)
	}

	/*==============================================================*/
	/* OPERATION:  processRestoreResult                             */
	/*                                                              */
	/**
	 * This method is called by a PDS when a restore operation takes
	 * place against an existing object. The processRestoreResult
	 * method of the parent must be called during the processing of
	 * this method.
	 * <p>
	 * @param anObject. This object is cast to the proper type by this
	 * method.
	 * <p>
	 * @exception PersistenceException If a persistence error occurs
	 *  
	 * @param       anObject:Object
	 * @exception   PersistenceException -
	 */
	/*==============================================================*/
	public void processRestoreResult(Object anObject)
		throws PersistenceException {
		//##Begin BusinessObjectContainer:processRestoreResult(Object) preserve=yes

		combine((BusinessObjectContainer) anObject);
		setParent(getParent());
		//##End   BusinessObjectContainer:processRestoreResult(Object)
	}

	/*==============================================================*/
	/* OPERATION:  printOut                                         */
	/*                                                              */
	/**
	 * This method produces a formatted output of contents of the
	 * business object container. This entails invoking the printOut
	 * method on each of the contained business objects.
	 *  
	 */
	/*==============================================================*/
	public void printOut() {
		//##Begin BusinessObjectContainer:printOut() preserve=yes

		System.out.println(
			ClassHelper.getClassOnlyName(this) + " : " + getSize());

		if (getCollection() != null) {
			synchronized (getCollection()) {
				for (Iterator itr = elements(); itr.hasNext();) {
					((BusinessObject) itr.next()).printOut();
				}
			}
		} else {
			synchronized (getMap()) {
				for (Iterator itr = elements(); itr.hasNext();) {
					((BusinessObject) itr.next()).printOut();
				}
			}
		}

		//##End   BusinessObjectContainer:printOut()
	}

	/*==============================================================*/
	/* OPERATION:  setParent                                        */
	/*                                                              */
	/**
	 * Sets the parent on the children.
	 *  
	 * @param       parent:PO
	 */
	/*==============================================================*/
	public void setParent(PO parent) {
		//##Begin BusinessObjectContainer:setParent(PO) preserve=yes
		super.setParent(parent);

		Iterator itr = null;

		// Only set the parent on the children, if this object has children
		// Otherwise an unecessary fetch of the children will occur.
		if (getSize() > 0) {
			if (getCollection() != null) {
				synchronized (getCollection()) {
					itr = elements();

					while (itr.hasNext()) {
						BusinessObject aBO = (BusinessObject) itr.next();
						aBO.setParent(parent);
					}
				}
			} else {
				synchronized (getMap()) {
					itr = elements();

					while (itr.hasNext()) {
						BusinessObject aBO = (BusinessObject) itr.next();
						aBO.setParent(parent);
					}
				}
			}
		}
		//##End   BusinessObjectContainer:setParent(PO)
	}

	/*==============================================================*/
	/* OPERATION:  removeValue                                      */
	/*                                                              */
	/**
	 * Removes an object from a given collection. This allows keyed
	 * containers to remove elements using an object value and not a
	 * key like they normally require.
	 *  
	 * @param       aValue:Object
	 */
	/*==============================================================*/
	public abstract void removeValue(Object aValue);

	/*==============================================================*/
	/* OPERATION:  getIndexOfValue                                  */
	/*                                                              */
	/**
	 * Returns the index of a value. For keyed containers, the
	 * traversal is sequential by keys.
	 *  
	 * @param       aValue:Object
	 * @return      :int -
	 */
	/*==============================================================*/
	public abstract int getIndexOfValue(Object aValue);

	/*==============================================================*/
	/* OPERATION:  getReferencedBusinessObjects                     */
	/*                                                              */
	/**
	 * This method returns an enumeration to referenced business
	 * objects. 
	 *  
	 * @return      :Iterator -
	 */
	/*==============================================================*/
	public Iterator getReferencedBusinessObjects() {
		//##Begin BusinessObjectContainer:getReferencedBusinessObjects() preserve=yes
		return elements();
		//##End   BusinessObjectContainer:getReferencedBusinessObjects()
	}

	/*==============================================================*/
	/* OPERATION:  removeAll                                        */
	/*                                                              */
	/**
	 * Remove all of my objects and marking the objects as ready to be
	 * deleted. At the next transaction, the objects are removed from
	 * the database.
	 *  
	 */
	/*==============================================================*/
	public void removeAll() {
		//##Begin BusinessObjectContainer:removeAll() preserve=yes
		if (getCollection() != null) {
			synchronized (getCollection()) {
				for (Iterator itr = elements(); itr.hasNext();) {
					BusinessObject myBO = (BusinessObject) itr.next();
					myBO.Delete(null);
				}
			}
		} else {
			synchronized (getMap()) {
				for (Iterator itr = elements(); itr.hasNext();) {
					BusinessObject myBO = (BusinessObject) itr.next();
					myBO.Delete(null);
				}				
			}
		}
		//##End   BusinessObjectContainer:removeAll()
	}

	/*==============================================================*/
	/* OPERATION:  store                                            */
	/*                                                              */
	/**
	 * Overridden to store all children that need to be stored.
	 *  
	 * @param       aPID:PID
	 * @exception   PersistenceException -
	 */
	/*==============================================================*/
	public void store(PID aPID) throws PersistenceException {
		//##Begin BusinessObjectContainer:store(PID) preserve=yes
		//##End   BusinessObjectContainer:store(PID)
	}

	/*==================================================================*/
	/* Protected Operations                                             */
	/*==================================================================*/

	/*==============================================================*/
	/* OPERATION:  setCollection                                     */
	/*                                                              */
	/**
	 * This method can be used by subclasses to replace the default
	 * container implementation.
	 * <p>
	 * @param aCollection The collection to take the personality of.
	 *  
	 * @param       aCollection:Collection
	 */
	/*==============================================================*/
	protected final void setCollection(Collection aCollection) {
		//##Begin BusinessObjectCollection:setCollection(Collection) preserve=yes

		collection = aCollection;
		fireContentsChanged(this, -1, -1);

		//##End   BusinessObjectCollection:setCollection(Collection)
	}

	/*==============================================================*/
	/* OPERATION:  getCollection                                     */
	/*                                                              */
	/**
	 * @return The current collection object.
	 *  
	 * @return      :Collection -
	 */
	/*==============================================================*/
	public final Collection getCollection() {
		//##Begin BusinessObjectCollection:getCollection() preserve=yes
		fetch();
		return collection;
		//##End   BusinessObjectCollection:getCollection()
	}

	/*==============================================================*/
	/* OPERATION:  getContainedClass                                */
	/*                                                              */
	/**
	 * This method should be overridden by subclasses to return the
	 * Class instance of the contained Business Object.
	 *  
	 * @return      :Class -
	 *                 The Class instance of the contained Business
	 *                 Object.
	 */
	/*==============================================================*/
	protected Class getContainedClass() {
		//##Begin BusinessObjectContainer:getContainedClass() preserve=yes

		return null;

		//##End   BusinessObjectContainer:getContainedClass()
	}

	/*==============================================================*/
	/* OPERATION:  setMap                                     */
	/*                                                              */
	/**
	 * This method can be used by subclasses to replace the default
	 * container implementation.
	 * <p>
	 * @param aMap The map to take the personality of.
	 *  
	 * @param       aMap:Map
	 */
	/*==============================================================*/
	protected final void setMap(Map aMap) {
		//##Begin BusinessObjectMap:setMap(Map) preserve=yes

		map = aMap;
		fireContentsChanged(this, -1, -1);

		//##End   BusinessObjectMap:setMap(Map)
	}

	/*==============================================================*/
	/* OPERATION:  getMap                                     */
	/*                                                              */
	/**
	 * @return The current map object.
	 *  
	 * @return      :Map -
	 */
	/*==============================================================*/
	protected final Map getMap() {
		//##Begin BusinessObjectMap:getMap() preserve=yes
		fetch();
		return map;
		//##End   BusinessObjectMap:getMap()
	}

	/*==============================================================*/
	/* OPERATION:  reset                                            */
	/*                                                              */
	/**
	 * Reset. TDB
	 *  
	 */
	/*==============================================================*/
	protected void reset() {
		//##Begin BusinessObjectContainer:reset() preserve=yes
		super.reset();
		//##End   BusinessObjectContainer:reset()
	}

	/*==============================================================*/
	/* OPERATION:  getBeforeImage                                   */
	/*                                                              */
	/**
	 * This method gets called when the BO is involved in a
	 * transaction. When performing a reset, a BO can use the before
	 * image to restore its memory image.
	 *  
	 * @return      :Object -
	 */
	/*==============================================================*/
	protected Object getBeforeImage() {
		//##Begin BusinessObjectContainer:getBeforeImage() preserve=yes

		if (getCollection() != null) {
			if (getCollection() instanceof ArrayList) {
				return ((ArrayList)getCollection()).clone();
			} else if (getCollection() instanceof HashSet) {
				return ((HashSet)getCollection()).clone();
			} else if (getCollection() instanceof LinkedHashSet) {
				return ((LinkedHashSet)getCollection()).clone();
			} else if (getCollection() instanceof LinkedList) {
				return ((LinkedList)getCollection()).clone();
			} else if (getCollection() instanceof TreeSet) {
				return ((TreeSet)getCollection()).clone();
			} else if (getCollection() instanceof Vector) {
				return ((Vector)getCollection()).clone();
			} else {
				return null;
			}
		} else {
			if (getMap() instanceof HashMap) {
				return ((HashMap)getMap()).clone();
			} else if (getMap() instanceof Hashtable) {
				return ((Hashtable)getMap()).clone();
			} else if (getMap() instanceof TreeMap) {
				return ((TreeMap)getMap()).clone();
			} else {
				return null;
			}
		}

		//##End   BusinessObjectContainer:getBeforeImage()
	}

	/*==============================================================*/
	/* OPERATION:  post_restore                                     */
	/*                                                              */
	/**
	 * Called by the POM when the object has been restored. This method
	 * is overridden so that children PO's can be monitored for various
	 * events. 
	 * <p>
	 * @exception PersistenceException If a persistence error occurs.
	 *  
	 * @exception   PersistenceException -
	 */
	/*==============================================================*/
	protected void post_restore() throws PersistenceException {
		//##Begin BusinessObjectContainer:post_restore() preserve=yes
		addListeners(this);
		super.post_restore();
		//##End   BusinessObjectContainer:post_restore()
	}

	/*==============================================================*/
	/* OPERATION:  post_store                                       */
	/*                                                              */
	/**
	 * We override this method so that the container is marked as clean
	 * if all leafs are clean.
	 *  
	 * @exception   PersistenceException -
	 */
	/*==============================================================*/
	protected void post_store() throws PersistenceException {
		//##Begin BusinessObjectContainer:post_store() preserve=yes
		//##End   BusinessObjectContainer:post_store()
	}

	/*==============================================================*/
	/* OPERATION:  prepare                                          */
	/*                                                              */
	/**
	 * Overridden to do nothing.
	 *  
	 * @return      :int -
	 */
	/*==============================================================*/
	protected int prepare() {
		//##Begin BusinessObjectContainer:prepare() preserve=yes
		return TransactionService.VOTE_READONLY;
		//##End   BusinessObjectContainer:prepare()
	}

	/*==================================================================*/
	/* Private Operations                                               */
	/*==================================================================*/
	/*==============================================================*/
	/* OPERATION:  addListeners                                     */
	/*                                                              */
	/**
	 * Installs listeners on the BO's in the supplied container.
	 *  
	 * @param       container:BusinessObjectContainer
	 */
	/*==============================================================*/
	private void addListeners(BusinessObjectContainer container) {
		//##Begin BusinessObjectContainer:addListeners(BusinessObjectContainer) preserve=yes
		//##End   BusinessObjectContainer:addListeners(BusinessObjectContainer)
	}

	/*==================================================================*/
	/*=========================               ==========================*/
	/*========================= Inner Classes ==========================*/
	/*=========================               ==========================*/
	/*==================================================================*/

	/*==================================================================*/
	/* CLASS:       BOListModel                                         */
	/**
	 * No documentation is currently available for this class.
	 */
	/*==================================================================*/
	public class BOListModel extends AbstractListModel {

		/*==============================================================*/
		/* Custom Attributes                                            */
		/*==============================================================*/
		//##Begin BOListModel:Attributes preserve=yes

		//##End   BOListModel:Attributes

		/*==============================================================*/
		/* Public Operations                                            */
		/*==============================================================*/
		/*==========================================================*/
		/* OPERATION:  getSize                                      */
		/*                                                          */
		/**
		 * @return      :int -
		 */
		/*==========================================================*/
		public int getSize() {
			//##Begin BOListModel:getSize() preserve=yes
			return BusinessObjectContainer.this.getSize();
			//##End   BOListModel:getSize()
		}

		/*==========================================================*/
		/* OPERATION:  getElementAt                                 */
		/*                                                          */
		/**
		 * @param       index:int
		 * @return      :Object -
		 */
		/*==========================================================*/
		public Object getElementAt(int index) {
			//##Begin BOListModel:getElementAt(int) preserve=yes
			return BusinessObjectContainer.this.getElementAt(index);
			//##End   BOListModel:getElementAt(int)
		}

		/*==========================================================*/
		/* OPERATION:  fireContentsChanged                          */
		/*                                                          */
		/**
		 * This method must be called when the contents of the list
		 * change.
		 *  
		 * @param       source:Object
		 * @param       index0:int
		 * @param       index1:int
		 */
		/*==========================================================*/
		public void fireContentsChanged(
			Object source,
			int index0,
			int index1) {
			//##Begin BOListModel:fireContentsChanged(Object,int,int) preserve=yes
			super.fireContentsChanged(source, index0, index1);
			//##End   BOListModel:fireContentsChanged(Object,int,int)
		}

		/*==========================================================*/
		/* OPERATION:  fireIntervalAdded                            */
		/*                                                          */
		/**
		 * This method must be called when new elements are added.
		 *  
		 * @param       source:Object
		 * @param       index0:int
		 * @param       index1:int
		 */
		/*==========================================================*/
		public void fireIntervalAdded(Object source, int index0, int index1) {
			//##Begin BOListModel:fireIntervalAdded(Object,int,int) preserve=yes
			super.fireIntervalAdded(source, index0, index1);
			//##End   BOListModel:fireIntervalAdded(Object,int,int)
		}

		/*==========================================================*/
		/* OPERATION:  fireIntervalRemoved                          */
		/*                                                          */
		/**
		 * This method must be called when elements are removed.
		 *  
		 * @param       source:Object
		 * @param       index0:int
		 * @param       index1:int
		 */
		/*==========================================================*/
		public void fireIntervalRemoved(
			Object source,
			int index0,
			int index1) {
			//##Begin BOListModel:fireIntervalRemoved(Object,int,int) preserve=yes
			super.fireIntervalRemoved(source, index0, index1);
			//##End   BOListModel:fireIntervalRemoved(Object,int,int)
		}
	}
}
