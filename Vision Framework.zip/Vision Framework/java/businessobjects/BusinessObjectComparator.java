package COM.novusnet.vision.java.businessobjects;

import java.io.Serializable;
import java.util.Comparator;

/**
 * This is the default class for Comparators. Users should extend this class for
 * more specific object comparators and override the compare(Object, Object) method.
 * 
 * @author rstrea1
 *
 * 
 */
public class BusinessObjectComparator implements Comparator, Serializable {
	
	protected int m_sortcol;
	protected boolean defaultOrder;
	protected boolean m_sortAsc;
	
	public BusinessObjectComparator() {
		m_sortcol = 0;
		defaultOrder = true;
		m_sortAsc = true;
	}

	/**
	 * METHOD: setSortColumn
	 * 
	 * This method sets the attribute m_sortCol.  This is used to determine
	 * which attribute to sort on. Users should determine column - attributes
	 * mapping in a subclass.
	 * 
	 * @param	sortCol:int
	 */
	
	public void setSortColumn(int sortCol){
		this.m_sortcol = sortCol;
	}
	
	/**
	 * METHOD: getSortColumn
	 * 
	 * This returns the value of "m_sortcol"
	 * 
	 * @return m_sortcol:int
	 */
	public int getSortColumn(){
		return m_sortcol;
	}
	

	/**
	 * @see Comparator#compare(Object, Object)
	 */
	public int compare(Object o1, Object o2) {
		
		if(!(o1 instanceof BusinessObject) || !(o2 instanceof BusinessObject))
			return 0;
			
		BusinessObject b1 = (BusinessObject) o1;
		BusinessObject b2 = (BusinessObject) o2;
		
		if (b1.hashCode() < b2.hashCode()) {
			return -1;
		} else if (b1.hashCode() > b2.hashCode()) {
			return 1;
		}
		
		return 0;
	}

	/**
	 * Gets the defaultOrder
	 * @return Returns a boolean
	 */
	public boolean isDefaultOrder() {
		return defaultOrder;
	}
	/**
	 * Sets the defaultOrder
	 * @param defaultOrder The defaultOrder to set
	 */
	public void setDefaultOrder(boolean defaultOrder) {
		this.defaultOrder = defaultOrder;
	}

	/**
	 * Gets the m_sortAsc
	 * @return Returns a boolean
	 */
	public boolean isSortAssociation() {
		return m_sortAsc;
	}
	/**
	 * Sets the m_sortAsc
	 * @param m_sortAsc The m_sortAsc to set
	 */
	public void setSortAssociation(boolean m_sortAsc) {
		this.m_sortAsc = m_sortAsc;
	}

}

