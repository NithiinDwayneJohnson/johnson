package COM.novusnet.vision.java.businessobjects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * This subclass provides a way to sort a BusinessObjectIndexedContainer. None of the 
 * containers in DFSClientLib originally had a sorting mechanism. By subclassing the sorting
 * out we don't have to disurb the original BOs.
 * 
 * @version 1.0, 7-23-2005
 * 
 */
public class BusinessObjectSortableIndexedContainer
	extends BusinessObjectIndexedContainer {

	private BusinessObjectComparator aComparator = new BusinessObjectComparator(); 
	
	/**
    * Constructor. This class sets the default collection to be a an Array. 
    */
	public    BusinessObjectSortableIndexedContainer () {
      super();
   }

	
	/**
	 * Sorts the container based on a given column and association.
	 * @param int:sortCol
	 * @param boolean:sortAsc
	 */
	public synchronized void sort(int sortCol, boolean sortAsc){
		aComparator.setSortColumn(sortCol);
		aComparator.setSortAssociation(sortAsc);
		aComparator.setDefaultOrder(false);
		if (!sortAsc) {
			Collections.reverse((List)getCollection());
		}else {
			Collections.sort((List)getCollection(), aComparator);
		}
		
      	fireContentsChanged(this, -1, -1);
   	}
   
   	/**
   	 * Sorts the container.
   	 * 
   	 */
   	public synchronized void sort(){
   		if (!aComparator.isSortAssociation()) {
   			Collections.reverse((List)getCollection());
   		}else{
			Collections.sort((List)getCollection(), aComparator);
   		}

      fireContentsChanged(this, -1, -1);
   	}
   
  	public void setComparator(BusinessObjectComparator aValue) {
  		this.aComparator = aValue;
  	}
  
  	public BusinessObjectComparator getComparator() {
  		return ( aComparator );
  	}
	/**
	 * Clears the contents of the container and the associated BinaryPredicate.
	 * 
	 */

	public void clear(){
   		super.clear();
   		aComparator = null;
   	}
}

