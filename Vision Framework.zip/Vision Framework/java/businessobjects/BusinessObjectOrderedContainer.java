/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * This class is an ordered container class using an OrderedMap. An
 * OrderedMap is an associative container that manages a set of ordered
 * key/value pairs. The pairs are ordered by key, using a comparator. By
 * default, a HashComparator is used, which orders keys based on their hash
 * value. By default, only one value may be associated with a particular
 * key. An OrderedMap's underlying data structure allows you to very
 * efficiently find all of the values associated with a particular key. 
 * <p>
 * Please refer to the JGL documentation for this class.
 * @version 1.0, 4-29-1998
 */
public class BusinessObjectOrderedContainer extends BusinessObjectContainer {

	/**
	 * Constructor. This class sets the default collection to be an
	 * OrderedMap. The default is not to allow duplicates.
	 */
	public BusinessObjectOrderedContainer() {
		setMap( Collections.synchronizedMap(new TreeMap()) );
	}

	/**
	 * Get an object that matches the supplied key.
	 * @param       key:Object
	 * @return      :Object -
	 */
	public Object get(Object key) {
		return getMap().get(key);
	}

	/**
	 * Put a key,value pair into the collection. If the key doesn't exist, 
	 * associate the value with the key and return null, otherwise replace 
	 * the first value associated with the key and return the old value
	 * @param       key:Object
	 * @param       value:Object
	 * @return      :Object -
	 */
	public Object put(Object key, Object value) {
		handleTransactionInvolvement();

		getMap().put(key, value);

		fireContentsChanged(this, -1, -1);

		((BusinessObject) value).setParentContainer(this);
		return value;
	}

	/**
	 * If the key doesn't exist or duplicates are allowed, associate
	 * the value with the key and return null, otherwise don't modify
	 * the map and return the current value associated with the key. 
	 *  
	 * @param       key:Object
	 * @param       value:Object
	 * @return      :Object -
	 */
	public Object add(Object key, Object value) {
		return put(key, value);
	}

	/**
	 * Return the number of objects in the container that match the given key.
	 * @param       key:Object
	 * @return      :int -
	 */
	public int count(Object key) {
		int count = 0;
		if (getMap().containsKey(key)) {
			synchronized (getMap()) {
				Iterator itr = getMap().keySet().iterator();
				while (itr.hasNext()) {
					if (itr.next().equals(key))
						count++;
				}
			}
		}
		return count;
	}

	/**
	 * Combine the contents of one BusinessObject container with
	 * another. Duplicate semantics depend on the type of the
	 * container.
	 * <p>
	 * This class simply copies the source container contents into the
	 * target container.
	 *  
	 * @param       container:BusinessObjectContainer
	 */
	public void combine(BusinessObjectContainer container) {
		getMap().putAll(container.getMap());
		fireContentsChanged(this, -1, -1);
	}

	/**
	 * Remove all key/value pairs that match a particular key. 
	 * @param  key - The key of the pair(s) to be removed. 
	 * @return  The first object removed or null if not changed. 
	 */
	public Object remove(Object object) {
		handleTransactionInvolvement();

		BusinessObject bo = (BusinessObject) getMap().get(object);
		bo.Delete(null);
		getMap().remove(object);

		return object;
	}

	/**
	 * Return the object in the container that is at the given index.
	 * @param       index:int
	 * @return      :Object -
	 */
	public Object getElementAt(int index) {
		Object[] values = getMap().values().toArray();
		for (int i = 0; i < values.length; i++) {
			if (index == i)
				return values[i];
		}
		return null;
	}

	/**
	 * Return the index of the first object that matches a particular
	 * value, or -1 if the object is not found. 
	 * @param  object - The key to the object whose index is being queried. 
	 * @return      :int 
	 */
	public int indexOf(Object code) {
		if (!getMap().containsValue(code)) {
			return -1;
		}
		Object[] values = getMap().values().toArray();
		for (int i = 0; i < values.length; i++) {
			if (code != null && code.equals(values[i]))
				return i;
		}
		return -1;
	}

	/**
	 * Removes an object from a given collection. This allows keyed
	 * containers to remove elements using an object value and not a
	 * key like they normally require.
	 * @param       aValue:Object
	 */
	public void removeValue(Object aValue) {

		if (getMap().containsValue(aValue)) {
			synchronized (getMap()) {
				Iterator itr = getMap().entrySet().iterator();
				while (itr.hasNext()) {
					Map.Entry entry = (Map.Entry) itr.next();
					if (entry.getValue().equals(aValue)) {
						itr.remove();
						((BusinessObject) aValue).setParentContainer(null);
						fireContentsChanged(this, -1, -1);
					}
				}
			}
		}
		
	}

	/**
	 * Returns the index of a value. For keyed containers, the
	 * traversal is sequential by keys.
	 * @param       aValue:Object
	 * @return      :int -
	 */
	public int getIndexOfValue(Object aValue) {
		if (!getMap().containsValue(aValue)) {
			return -1;
		}
		Object[] values = getMap().values().toArray();
		for (int i = 0; i < values.length; i++) {
			if (aValue != null && aValue.equals(values[i]))
				return i;
		}
		return -1;
	}
}
