/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListResourceBundle;
import java.util.Locale;
import java.util.Set;
import java.util.Vector;

import COM.novusnet.vision.java.persistence.ActiveRestoreManager;
import COM.novusnet.vision.java.persistence.GenericPID;
import COM.novusnet.vision.java.persistence.KeyDescriptor;
import COM.novusnet.vision.java.persistence.PID;
import COM.novusnet.vision.java.persistence.PIDFactory;
import COM.novusnet.vision.java.persistence.PO;
import COM.novusnet.vision.java.persistence.POFactory;
import COM.novusnet.vision.java.persistence.PersistenceException;
import COM.novusnet.vision.java.transactions.Control;
import COM.novusnet.vision.java.transactions.Current;
import COM.novusnet.vision.java.transactions.Inactive;
import COM.novusnet.vision.java.transactions.TransactionService;
import COM.novusnet.vision.java.utility.helpers.ClassHelper;
import COM.novusnet.vision.java.utility.resourcehelpers.ResourceResolver;

/**
 * A business object is an object that represents a person, place, thing or
 * concept in the business domain. Business objects serve as a storage
 * place for business policy and data, packaging business policy and rules
 * with data and ensuring that data is only used in a manner semantically
 * consistent with business intent. This property is called semantic
 * normalization: putting the right data with the right procedures in the
 * right place based on the meaning of the underlying business concept that
 * the object represents.
 * <p>
 * Common examples of business objects include: purchase order, customer
 * order, customer, product, invoice, payment, stock, bond, cash, stock
 * swap, flight segment, vehicle, and temporal events like end of product
 * lifecycle or start of quarterly earnings period. Business processes like
 * order fulfillment and procurement can also be represented by business
 * objects. 
 * <p>
 * Traditional business modeling and system development practices separate
 * data from process and business rules. Different procedures (and possibly
 * different data) are defined for each information system. The underlying,
 * unifying idea of a purchase order or a sales order is easily lost when
 * departments and applications redefine fundamental business concepts.
 * Even more important for successful business engineering, the commonality
 * between these two concepts (the unifying notion of an order) is entirely
 * lost in the details and differences. Business objects help us focus on
 * the underlying concepts so that we can create a structure within which
 * to manage the details and differences. This object perspective inverts
 * traditional analytical thinking by placing greater emphasis on the whole
 * rather than the parts. This is one reason why a business object can be
 * shared by different people (or programs) with seemingly dissimilar
 * needs. 
 * <p>
 * The BusinessObject class is transactional. It gets involved in active
 * transactions whenever any of its attributes is changed. In cooperation
 * with the transaction service, the in memory state of the BO can be
 * rolled back in case of a failure. Any changes to the BO state are
 * recorded in an in-memory image for a potential rollback. There are
 * several methods that allow a developer to access these dirty attributes.
 * <p>
 * The BO class provides support for the property change interface as
 * defined by the java beans specifications. If a subclass defines an
 * attribute as bound, it can use the BO base funtionality to fire events
 * to registered listeners. Listeners can register for notifications by
 * using the BO base class functionality. This functionality is provided in
 * the form of adddPropertyChangeListener() and
 * removePropertyChangeListener(). A business object by default implements
 * the listener interface. The propertyChange() method should be overridden
 * by subclasses.
 * <p>
 * The BO class interfaces with the ResourceResolver to ease the pain of
 * I18N. Callers can use simple methods to extract resources (i.e messages)
 * for a given class of BO. The caller does not have to specify any locale
 * specific information in their his code.
 * <p>
 * The BO class is persistent. The store(), restore() and Delete()
 * operations result in the state of the BO being stored, restored and
 * deleted respectively. For more information on persistence, please refer
 * to the persistence framework.
 * @version 1.0, 5-3-2000
 */
public abstract  class  BusinessObject  extends  PO
	implements Cloneable, ModelInterface, PropertyChangeListener {
	public static final String BUSINESSOBJECT_DIRTY = "Vision-dirty";
	private static final String VISION_NULL_VALUE = "Vision-2000 Null value";
   private static final String VISION_DIRTY_PLACEHOLDER = "Vision-2000 Place holder";
	private static final String DIRTY_NO_TRAVERSAL = "Vision-2000 Dirty_no";

	private boolean fetched = false;
	private transient PropertyChangeSupport propertyChangeSupport = null;
	private transient int listenerCount = 0;
	private boolean inReset = false;
	private boolean byValue = false;
	private boolean markedForDeletion = false;

	/**
	 * List of the names and reset values (values at the time of the previous 
	 * restore) of dirty attributes for this Business Object.
	 */
	private HashMap attributeResetValues = null;
	private Integer objectID = new Integer(System.identityHashCode(this));
	private Object parentContainer;
	private transient Control transactionControl = null;
   private transient    BusinessObjectTxnResource businessObjectTxnResource = null;

	/*==================================================================*/
	/* Class Attributes                                                 */
	/*==================================================================*/

	/**
	 * This class points to the vision framework resource file. There is a 
	 * separate version of this resource file for every locale.
	 */
	private static ListResourceBundle resources = null;
	private static final String GLOBAL_DIRTY_NAME = "Framework Dirty Attribute";
	private static Hashtable defaultPIDFactories = new Hashtable();

	/*=========================== Operations ===========================*/

	/*==================================================================*/
	/* Constructor Operations                                           */
	/*==================================================================*/

	/**
	 */
	public BusinessObject() {
	}

	/*==================================================================*/
	/* Attribute Get Operations                                         */
	/*==================================================================*/

	/**
	 * This method returns the value of the "propertyChangeSupport"
	 * attribute.
	 * @return      :java.beans.PropertyChangeSupport -
	 */
	private java.beans.PropertyChangeSupport getPropertyChangeSupport() {
		if (propertyChangeSupport == null) {
			propertyChangeSupport = new PropertyChangeSupport(this);
		}

		return (propertyChangeSupport);
	}

	/**
	 * This method returns the value of a private indicator to tell the
	 * BO whether reset is currently active.
	 * @return      :boolean -
	 */
	public boolean isInReset() {
		return (inReset);
	}

	/**
	 * This method returns the value of an indicator that marks a BO as
	 * being by value. Some portions of the framework, like the
	 * transaction service, does not store by value objects. It assumes
	 * a parent will store the object. If a BO is by value, then the
	 * parent must be the sole creator of the object. A setXXX on a
	 * by-value attribute is a copy of the contents.
	 *  
	 * @return      :boolean -
	 */
	public boolean isByValue() {
		return (byValue);
	}

	/**
	 * This method returns the value of indicates whether a BO has been
	 * marked for deletion.
	 *  
	 * @return      :boolean -
	 */
	public boolean isMarkedForDeletion() {
		return (markedForDeletion);
	}

	/**
	 * This method returns the value of list of the names and reset
	 * values (values at the time of the previous restore) of dirty
	 * attributes for this Business Object.
	 *  
	 * @return      :java.util.HashMap -
	 */
	private HashMap getAttributeResetValues() {
		if (attributeResetValues == null) {
			attributeResetValues = new HashMap();
		}
		return (attributeResetValues);
	}

	/**
	 * This method returns the value of the "objectID" attribute.
	 * @return      :java.lang.Integer -
	 */
	public java.lang.Integer getObjectID() {
		return (objectID);
	}

	/**
	 * This method returns the value of the "parentContainer"
	 * attribute.
	 *  
	 * @return      :java.lang.Object -
	 */
	public java.lang.Object getParentContainer() {
		return (parentContainer);
	}

	/**
	 * This method returns the value of the "transactionControl"
	 * attribute.
	 * @return      :COM.novusnet.vision.java.transactions.Control -
	 */
	protected Control getTransactionControl() {
		return (transactionControl);
	}

	/**
	 * This method returns the value of the "businessObjectTxnResource"
	 * attribute.
	 * @return     :BusinessObjectTxnResouce -
	 */
	public BusinessObjectTxnResource getBusinessObjectTxnResource() {
		return (businessObjectTxnResource);
	}

	/*==================================================================*/
	/* Attribute Set Operations                                         */
	/*==================================================================*/

	/**
	 * This method sets the value of a private indicator to tell the BO
	 * whether reset is currently active.
	 * @param       aValue:boolean
	 */
	protected void setInReset(boolean aValue) {
		inReset = aValue;
	}

	/**
	 * This method sets the value of an indicator that marks a BO as
	 * being by value. Some portions of the framework, like the
	 * transaction service, does not store by value objects. It assumes
	 * a parent will store the object. If a BO is by value, then the
	 * parent must be the sole creator of the object. A setXXX on a
	 * byvalue attribute is a copy of the contents.
	 *  
	 * @param       aValue:boolean
	 */
	public void setByValue(boolean aValue) {
		byValue = aValue;
	}

	/**
	 * This method sets the value of indicates whether a BO has been
	 * marked for deletion.
	 *  
	 * @param       aValue:boolean
	 */
	public void setMarkedForDeletion(boolean aValue) {
		markedForDeletion = aValue;
	}

	/**
	 * This method sets the value of the "parentContainer" attribute.
	 * @param       aValue:java.lang.Object
	 */
	public void setParentContainer(Object aValue) {
		parentContainer = aValue;
	}

	/**
	 * This method sets the value of the "transactionControl"
	 * attribute.
	 * @param       aValue:Control
	 */
	protected void setTransactionControl(Control aValue) {
		transactionControl = aValue;
	}

	/**
	 * This method sets the value of the "businessObjectTxnResource"
	 * attribute.
	 * @param      aValue:BusinessObjectTxnResource
	 */
	public void setBusinessObjectTxnResource(BusinessObjectTxnResource aValue) {
		businessObjectTxnResource = aValue;
	}

	/*==================================================================*/
	/* Public Operations                                                */
	/*==================================================================*/

	/**
	 * Returns true if the object has been retrieved from persistent
	 * storage.
	 * @return      :boolean -
	 */
	public boolean isFetched() {
		return (fetched);
	}

	/**
	 * This sets the retrieved state of the object.
	 * @param       flag:boolean
	 */
	public void setFetched(boolean flag) {
		fetched = flag;
	}

	/**
	 * Adds a property change listener to the list of listeners. Used
	 * by objects that are interested in events fiered by this object.
	 *  
	 * @param       aListener:java.beans.PropertyChangeListener
	 */
	public synchronized void addPropertyChangeListener(PropertyChangeListener aListener) {
		getPropertyChangeSupport().addPropertyChangeListener(aListener);
		listenerCount++;
	}

	/**
	 * Removes the listener from the listener list.
	 * @param       aListener:java.beans.PropertyChangeListener
	 */
	public synchronized void removePropertyChangeListener(PropertyChangeListener aListener) {
		getPropertyChangeSupport().removePropertyChangeListener(aListener);
		listenerCount--;
	}

	/**
	 * Called by subclasses to fire property change notifications to event listeners.
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:java.lang.Object
	 * @param       newValue:java.lang.Object
	 */
	public final void firePropertyChange(
		String propertyName,
		Object oldValue,
		Object newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				oldValue,
				newValue);
		}
	}

	/**
	 * Returns the number of listener for the object.
	 * @return      :int -
	 */
	public final int getListenerCount() {
		return (listenerCount);
	}

	/**
	 * This method returns the default PID factory for the application
	 * associated with this business object instance. PID factories are
	 * registered on a per-application basis and are identified by the
	 * application name portion of the fully qualified business object
	 * class name.
	 * <p>
	 * <b>Notes:</b><p>
	 * This is an instance method - there is a related static
	 * getDefaultPIDFactory method which uses a business object's class
	 * instance to locate the associated application's default PID
	 * factory.
	 *  
	 * @return      :COM.novusnet.vision.java.persistence.PIDFactory -
	 */
	public PIDFactory getDefaultPIDFactory() {
		return getDefaultPIDFactory(getClass());
	}

	/**
	 * To support the Cloneable interface. Note that listeners are
	 * never cloned.
	 *  
	 * @return      :java.lang.Object -
	 */
	public Object clone() {
		BusinessObject aBO = null;

		try {
			aBO = (BusinessObject) super.clone();
		} catch (CloneNotSupportedException e) {
		}
		aBO.propertyChangeSupport = null;
		aBO.listenerCount = 0;
		aBO.inReset = false;
		aBO.transactionControl = null;
		aBO.businessObjectTxnResource = null;
		aBO.markedForDeletion = false;

		//==============================================================
		// We set the fetched flag to false, going with the notion that
		// there exists one and only one copy in a given system. The caller
		// must have cloned to change something. They can always change the
		// behavior (if they know better) by calling setFetched(true).
		//==============================================================
		aBO.setFetched(false);

		//=======================================================================
		// We clone the attribute reset values, since a dirty bo that gets saved
		// and was cloned will blow away the reset values thus causing BO number
		// to not to be dirty. Do so only if there are attributeResetValues
		//=======================================================================
		if (this.attributeResetValues != null) {
			aBO.attributeResetValues =
				(HashMap) this.attributeResetValues.clone();
		}
		return (aBO);
	}

	/**
	 * Returns the dirty state of an attribute. If a name is null
	 * isDirty returns true if any attributes are dirty. There must be
	 * a transaction context in order for this call to work.
	 *  
	 * @param       name:java.lang.String
	 * @return      :boolean -
	 */
	public boolean isDirty(String name) {
		//******************************************************//
		// If name is null, then caller means all attributes    //
		//******************************************************//       
		if (name == null || name == DIRTY_NO_TRAVERSAL) {
			if ((attributeResetValues != null)
				&& getAttributeResetValues().size() > 0) {
				return (true);
			}

			if (name == DIRTY_NO_TRAVERSAL) {
				return false;
			}

			// 	 System.out.println("Expensive call to isDirty()");

			return (getDirtyBusinessObjects() != null);
		} else {

			//***********************************************************//
			// If the object exists in the HashSet, then it is dirty     //
			//***********************************************************//
			if ((attributeResetValues != null)
				&& (getAttributeResetValues().get(name) != null)) {
				return (true);
			}
		}

		return (false);
	}

	/**
	 * This sets the dirty state of an attribute or all attributes. If
	 * the dirty state is set to false (i.e. clean), the reset value(s)
	 * of the attribute (or attributes, if the operation is at BO
	 * scope) is/are also cleared. There must be a transaction context
	 * in order to for this call to work.
	 * <p>
	 * @param name The attribute name. If the name is null, setDirty
	 * takes on BO scope behavior. 
	 * <p>
	 * @param dirtyState The attribute dirty state. If name is null, a
	 * false for the dirty state clears all dirty attributes, whereas a
	 * true would mark the whole BO as dirty.
	 *  
	 * @param       name:java.lang.String
	 * @param       dirtyState:boolean
	 * @exception   COM.novusnet.vision.java.transactions.Inactive -
	 */
	public void setDirty(String name, boolean dirtyState) throws Inactive {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}

		//=================================================
		// If this is as a result of a reset then bail out
		//=================================================
		if (isInReset()) {
			return;
		}

		if (name != null) {
			if (dirtyState == true) {
				getAttributeResetValues().put(name, VISION_DIRTY_PLACEHOLDER);
			} else {
				getAttributeResetValues().remove(name);
			}
		} else {
			if (dirtyState == true) {
				getAttributeResetValues().put(
					GLOBAL_DIRTY_NAME,
					VISION_NULL_VALUE);
			} else {
				getAttributeResetValues().clear();
			}
		}

		if (dirtyState) {
			// If there is an active transaction, then get invovled.
			handleTransactionInvolvement();
		}

		return;
	}

	/**
	 * This method is called from the pre_store method. Model
	 * validation should be performed here.
	 *  
	 * @exception  
	 * COM.novusnet.vision.java.businessobjects.InvalidModelException -
	 */
	public void validateModel() throws InvalidModelException {
	}

	/**
	 * A method that a subclass overrides to print out the formatted
	 * contents of the business object.
	 */
	public void printOut() {
		System.out.println(ClassHelper.getClassOnlyName(this));
	}

	/**
	 * This method returns the list of dirty attribute names for this
	 * Business Object. There must be a transaction context for in
	 * ordere for this call to work.
	 * <p>
	 * @return  List of dirty attribute names.
	 *  
	 * @return      :java.util.HashSet -
	 */
	public HashSet getDirtyAttributes() {
		// JGL Conversion
		// 10-03-2005 Fix ConcurrentModificationException
		HashSet myHashSet = new HashSet();
		
		Set mySet = getAttributeResetValues().keySet();
		
		Iterator itr = mySet.iterator();
		while ( itr.hasNext() )
		{
			String myKey = (String)itr.next();
			myHashSet.add(myKey);
		}
		return (myHashSet);
	}

	/**
	 * This method returns the reset value (or value at the time of the
	 * previous restore) of the dirty attribute with the specified
	 * name. There must be a transaction context in order for this call
	 * to work.
	 * <p>
	 * @param name The name of the dirty attribute.
	 * <p>
	 * @return  Reset or previous value of the dirty attribute.
	 *  
	 * @param       name:java.lang.String
	 * @return      :java.lang.Object -
	 */
	public java.lang.Object getAttributeResetValue(String name) {
		Object myObject = getAttributeResetValues().get(name);

		if (myObject == VISION_NULL_VALUE
			|| myObject == VISION_DIRTY_PLACEHOLDER) {
			myObject = null;
		}

		return myObject;
	}

	/**
	 * This method returns the default PID for the business object
	 * instance either from the registered application default PID
	 * factory or the PID set on the PO if no PID factory is
	 * registered.
	 *  
	 * @return      :COM.novusnet.vision.java.persistence.GenericPID -
	 *                 The default PID for this business object
	 *                 instance.
	 */
	public GenericPID getDefaultPID() {

		//==============================================================
		// Obtain the default PID for this business object instance from
		// the default PID factory registered for this application.
		// If no PID factory is registered, return the PID set on the PO
		// via setPID() (if any).
		//==============================================================
		PIDFactory pidFactory = getDefaultPIDFactory();
		GenericPID myPID = null;

		if (pidFactory != null) {
			myPID = (GenericPID) pidFactory.create_PID_from_class(getClass());
		} else {
			myPID = (GenericPID) getPID();
		}

		return myPID;
	}

	/**
	 * This will involve the BO in a transaction if one is active. When
	 * a transaction is active, any changes to the state of the BO
	 * immediatley involve the BO in the current transaction context.
	 * At the end of the transaction, the BO is stored().
	 *  
	 */
	public void handleTransactionInvolvement() {
		Control currentControl = TransactionService.instance().getControl(null);

		if (currentControl == null) {
			return;
		}

		if ((currentControl != getTransactionControl())
			&& getTransactionControl() != null) {
			throw new IllegalArgumentException("Can not involve in more than one transaction");
		}

		//===========================================
		// If we are already involved then return
		//===========================================

		if (getTransactionControl() != null) {
			return;
		}

		//===================================================
		// Otherwise get involved by creating a BO resource
		//====================================================

		setBusinessObjectTxnResource(new BusinessObjectTxnResource(this));

		setTransactionControl(currentControl);

		//===================================================
		// and registering the resource with the transaction
		// coordinator
		//====================================================
      		currentControl.getCoordinator().registerResource(getBusinessObjectTxnResource());
	}

	/**
	 * This method uninvolves a BO in an active transaction. The BO can
	 * never be involved in the same transaction.
	 *  
	 * @exception   COM.novusnet.vision.java.transactions.Inactive -
	 */
	public void uninvolve() throws Inactive {
		BusinessObjectTxnResource txnResource = getBusinessObjectTxnResource();

		if (txnResource == null) {
			throw new Inactive("Uninvolve:There is no active transaction. Use Current.begin()");
		}

		txnResource.setInvolved(false);
		setBusinessObjectTxnResource(null);
		setTransactionControl(null);
	}

	/**
	 * Implemented as part of the PropertyChangeListener interface.
	 * This method is just a place holder. If a BO wishes to listen to
	 * another bean, it must override this method.
	 *  
	 * @param       event:java.beans.PropertyChangeEvent
	 */
	public void propertyChange(PropertyChangeEvent event) {
		if (event.getPropertyName() == BusinessObject.BUSINESSOBJECT_DIRTY) {
			return;
		}

	      setDirty(event.getPropertyName(), event.getOldValue(), event.getNewValue());
	}

	/**
	 * Copies an objects attributes (those with public get methods)
	 * into this BO.
	 *  
	 * @param       source:java.lang.Object
	 */
	public void copy(Object source) {
		processRestoreResult(source);
	}

	/**
	 * Overide equals to prevent it from going to Object.equals().
	 * Note that this method allways returns true. Sub-classes of BusinessObject
	 * must implement this method in order to allow tests for equality on 
	 * themselves.
	 *  
	 * @param       anObject:java.lang.Object
	 * @return      :boolean -
	 */
	public boolean equals(Object anObject) {
		return (true);
	}

	/**
	 * This method is overriden so that a transaction is started if
	 * none exist. If a transaction is active, this method simply marks
	 * the object for deletion. At prepare, the delete method of PO is
	 * called. This makes the Delete consistent with the store method.
	 * <p>
	 * @param aPID. The pid can be null in which case the pid set on
	 * the PO will be used.
	 * <p>
	 * @exception PersistenceException If a persistence error occurs
	 *  
	 * @param       aPID:COM.novusnet.vision.java.persistence.PID
	 * @exception  
	 * COM.novusnet.vision.java.persistence.PersistenceException -
	 */
	public void Delete(PID aPID) throws PersistenceException {
		System.out.println("In BO delete()" + this);

		if (aPID == null && getPID() == null) {
			aPID = getDefaultPID();
		}

		// If there is no transaction, then start one.
		Current current = TransactionService.instance().getCurrent();
		boolean startedTransaction = false;

		if (current == null) {
			current = new Current();
			current.begin();
			startedTransaction = true;
		}

		handleTransactionInvolvement();

		setMarkedForDeletion(true);

		if (isFetched()) {
			super.Delete(aPID);
		}

		if (startedTransaction) {
			current.commit();
		}

		if (getParentContainer() != null) {
			((BusinessObjectContainer) getParentContainer()).removeValue(this);
		}
	}

	/**
	 * This method takes an attribute name, old value and a new value.
	 * If the attribute does not have a reset value, a new one is
	 * added.
	 *  
	 * @param       name:java.lang.String
	 * @param       oldValue:java.lang.Object
	 * @param       newValue:java.lang.Object
	 */
	public final void setDirty(String name, Object oldValue, Object newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}

		Object resetValue = null;
		boolean resetExists = false;

		// If there is a place holder because of setDirty, then remove it

		// If there exists a reset value for the attribute, and the reset value
		// is the same as the new value being set, then we remove the reset
		// value since the attribute is not considered dirty anymore.

		resetValue = getAttributeResetValues().get(name);

		if (resetValue != null) {
			if (resetValue == VISION_DIRTY_PLACEHOLDER) {
				resetValue = null;
				setDirty(name, false);
				resetExists = false;
			} else {
				resetExists = true;
			}
		}

		if (resetExists) {
			// If both are null, then remove the reset value from the list and
			// bail out.
			if (resetValue == null && newValue == null) {
				setDirty(name, false);
			}
			// If both are non-null but equal, then remove the reset value from the list and
			// bail out.

			else if (resetValue != null && newValue != null) {
				if (resetValue.equals(newValue)) {
					setDirty(name, false);
				}
				// If it is a Boolean and there is a reset value then we are resetting to 
				// the original value. 
				if (oldValue instanceof Boolean) {
					setDirty(name, false);
				}
			}
			return;
		}

		if (oldValue == null) {
			oldValue = VISION_NULL_VALUE;
		}

		// Add the reset value to the list.
		getAttributeResetValues().put(name, oldValue);

		// If there is an active transaction, then get invovled.
		handleTransactionInvolvement();
	}

	/**
	 * Returns a list of referenced business objects. If a reference is
	 * non-null, then the reference should be added to the list. A
	 * subclass should always call super when adding referenced objects
	 * to the list.
	 *  
	 * @param       container:java.util.Vector
	 */
	public void addReferencedBusinessObjects(Vector container) {
		if (getParent() != null) {
			container.addElement(getParent());
		}
		return;
	}

	/**
	 * This method returns an Iterator to referenced business
	 * objects. 
	 *  
	 * @return      :java.util.Iterator -
	 */
	public Iterator getReferencedBusinessObjects() {
		Vector myVector = new Vector();
		addReferencedBusinessObjects(myVector);
		return myVector.iterator();
	}

	/**
	 * This method stores this object and referenced objects that are
	 * dirty. If a transaction is not active, a transaction is started.
	 * Any object that is reachable from this BO that is dirty is also
	 * involved in the transaction.
	 *  
	 * @param       aPID:COM.novusnet.vision.java.persistence.PID
	 * @exception  
	 * COM.novusnet.vision.java.persistence.PersistenceException -
	 */
   public  void  store (PID  aPID , boolean forceCommit) throws PersistenceException {
		Vector dirtyObjects = getDirtyBusinessObjects();

      if (dirtyObjects == null && 
          !forceCommit) {
			return;
		}

		// If there is no transaction, then start one.
		Current current = TransactionService.instance().getCurrent();
		boolean startedTransaction = false;

		setPID(aPID);
      if(current == null) {
			current = new Current();
			current.begin();
			startedTransaction = true;
		}
      if(dirtyObjects != null) {
		Enumeration enum = dirtyObjects.elements();
         while(enum.hasMoreElements()) {
            BusinessObject referencedBO = (BusinessObject)enum.nextElement();
			referencedBO.handleTransactionInvolvement();
		}
      }
      if(startedTransaction
       || forceCommit) {
             if(forceCommit) {
             //  System.err.println("I'm forcing the commit!");
             } else {
             //  System.err.println("I'm passively commiting...");
             }
			current.commit();
		}
	}

   public void store(COM.novusnet.vision.java.persistence.PID aPID) throws COM.novusnet.vision.java.persistence.PersistenceException {
      this.store(aPID, false);
   }
	/**
	 * This method returns a list of all dirty business objects
	 * (including this) that are reachable from this BO.
	 *  
	 * @return      :java.util.Vector -
	 */
	public java.util.Vector getDirtyBusinessObjects() {
		Vector myResult = new Vector();
		HashSet myProcessedBOs = new HashSet();

		getDirtyBusinessObjects_worker(this, myResult, myProcessedBOs);

		if (myResult.size() == 0) {
			myResult = null;
		}

		return myResult;
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:byte
	 * @param       newValue:byte
	 */
	public final void firePropertyChange(
		String propertyName,
		byte oldValue,
		byte newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Byte(oldValue),
				new Byte(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:char
	 * @param       newValue:char
	 */
	public final void firePropertyChange(
		String propertyName,
		char oldValue,
		char newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Character(oldValue),
				new Character(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:short
	 * @param       newValue:short
	 */
	public final void firePropertyChange(
		String propertyName,
		short oldValue,
		short newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Short(oldValue),
				new Short(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:int
	 * @param       newValue:int
	 */
	public final void firePropertyChange(
		String propertyName,
		int oldValue,
		int newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Integer(oldValue),
				new Integer(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:long
	 * @param       newValue:long
	 */
	public final void firePropertyChange(
		String propertyName,
		long oldValue,
		long newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Long(oldValue),
				new Long(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:double
	 * @param       newValue:double
	 */
	public final void firePropertyChange(
		String propertyName,
		double oldValue,
		double newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Double(oldValue),
				new Double(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:float
	 * @param       newValue:float
	 */
	public final void firePropertyChange(
		String propertyName,
		float oldValue,
		float newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Float(oldValue),
				new Float(newValue));
		}
	}

	/**
	 * Called by subclasses to fire property change notifications to
	 * event listeners.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:boolean
	 * @param       newValue:boolean
	 */
	public final void firePropertyChange(
		String propertyName,
		boolean oldValue,
		boolean newValue) {
		if (propertyChangeSupport != null) {
			getPropertyChangeSupport().firePropertyChange(
				propertyName,
				new Boolean(oldValue),
				new Boolean(newValue));
		}
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:byte
	 * @param       newValue:byte
	 */
	public final void setDirty(
		String propertyName,
		byte oldValue,
		byte newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Byte(oldValue), new Byte(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:char
	 * @param       newValue:char
	 */
	public final void setDirty(
		String propertyName,
		char oldValue,
		char newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(
			propertyName,
			new Character(oldValue),
			new Character(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:short
	 * @param       newValue:short
	 */
	public final void setDirty(
		String propertyName,
		short oldValue,
		short newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Short(oldValue), new Short(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:int
	 * @param       newValue:int
	 */
	public final void setDirty(
		String propertyName,
		int oldValue,
		int newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Integer(oldValue), new Integer(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:long
	 * @param       newValue:long
	 */
	public final void setDirty(
		String propertyName,
		long oldValue,
		long newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Long(oldValue), new Long(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:float
	 * @param       newValue:float
	 */
	public final void setDirty(
		String propertyName,
		float oldValue,
		float newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Float(oldValue), new Float(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:double
	 * @param       newValue:double
	 */
	public final void setDirty(
		String propertyName,
		double oldValue,
		double newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Double(oldValue), new Double(oldValue));
	}

	/**
	 * Marks the attribute as dirty.
	 *  
	 * @param       propertyName:java.lang.String
	 * @param       oldValue:boolean
	 * @param       newValue:boolean
	 */
	public final void setDirty(
		String propertyName,
		boolean oldValue,
		boolean newValue) {
		if (ActiveRestoreManager.isRestoreActive()) {
			return;
		}
		setDirty(propertyName, new Boolean(oldValue), new Boolean(oldValue));
	}

	/*==================================================================*/
	/* Protected Operations                                             */
	/*==================================================================*/

	/**
	 * This method must be called by subclasses to indicate to BO that
	 * a client has requested a fetch operation.
	 * <p>
	 * During a fetch method, the BO checks to see if an object has
	 * been retrieved from the database. If it has not, the BO calls
	 * the restore method. If the object has already been retrieved,
	 * the fetch() method is ignored.
	 * <p>
	 * Remarks
	 * <p>
	 * If the object is involved in a transaction (dirty attributes)
	 * this signifies a write before read, the BO will not restore the
	 * object. It will assume that the client is creating a new
	 * instance of the object. The BO will not be fetched if the PID is
	 * null
	 *  
	 * @exception  
	 * COM.novusnet.vision.java.persistence.PersistenceException -
	 */
	protected void fetch() throws PersistenceException {
		// If I am currently being fetched, then 
		// bail out.
		if (isRestoreInProgress()) {
			return;
		}

		// If the previous restore operation failed,
		// do not attempt another implicit restore.
		if (isFailedRestore()) {
			return;
		}

		try {
			if ((isFetched() == false)
				&& (getBusinessObjectTxnResource() == null)
				&& (getPID() != null)) {
				restore(null);
			}
		} finally {
		}
	}

	/**
	 * Called by POM when the object is about to be stored. This method
	 * calls the validateModel method.
	 * <p>
	 * @exception PersistenceException If a persistence error occurs.
	 *  
	 * @exception  
	 * COM.novusnet.vision.java.persistence.PersistenceException -
	 */
	protected void pre_store() throws PersistenceException {
		try {
			validateModel();
		} catch (InvalidModelException e) {
			throw new PersistenceException(e.getMessage());
		}
	}

	/**
	 * Called by the POM when the object has been stored().
	 * @exception PersistenceException If a persistence error occurs.
	 * @exception  
	 * COM.novusnet.vision.java.persistence.PersistenceException -
	 */
	protected void post_store() throws PersistenceException {
		setFetched(true);
		setDirty(null, false);
	}

	/**
	 * Called by the POM when the object has been restored().
	 * @exception PersistenceException If a persistence error occurs.
	 * @exception  COM.novusnet.vision.java.persistence.PersistenceException -
	 */
	protected void post_restore() throws PersistenceException {
		setFetched(true);
		setDirty(null, false);
	}

	/*==============================================================*/
	/* OPERATION:  reset                                            */
	/*                                                              */
	/**
	 * This method is called by the transaction service to reset the
	 * state of the in memory image to the way it was before the
	 * transaction was started. The default reset, restores the publi
	 * attribute values to their previous value by using the core
	 * reflection API. If the BO uses temporary values, then in should
	 * override this method, call super() and then fix up the
	 * temporaries.
	 * <p>
	 * The reset() method can only reset attributes that have a
	 * setXXX() public method per reflection API. No overloads of
	 * setXXX are allowed. If an attribute setter is private, then the
	 * subclass should override this method, call super() and handle
	 * the private attribute. The getDirtyAttributes() and
	 * getAttributeResetValue() should be used to perform this task.
	 *  
	 */
	protected void reset() {
		//       BusinessObjectTxnResource txnResource = getBusinessObjectTxnResource();

		//       if (txnResource == null) {
		// 	 throw new Inactive("reset:There is no active transaction. Use Current.begin():" + this);
		//       }

		//       //==============================================================
		//       // Obtain the default PID for this business object instance
		//       //==============================================================
		//       GenericPID myPID = getDefaultPID();
		//       POM        myPOM = POM.instance();
		//       PDS        myPDS = null;

		//       try {
		// 	 myPDS = POM.instance().connect(this, myPID);
		//       }
		//       catch(Exception ignore) {
		//       }

		// 	 //=========================================================================
		// 	 // If the PDS used to save this BO is nontransactional, then we need to 
		// 	 // back the memory image only if the attributes are dirty.
		// 	 //=========================================================================
		//       if (myPDS != null) {
		// 	 if (!isDirty(null) && !myPDS.isTransactional(myPID)) {
		// 	    return;
		// 	 }
		//       }

		//       //=========================================================================
		//       // The PDS is transactional or we are dirty (with a nontransactional PDS).
		//       // Commence reset.
		//       //=========================================================================
		//      setInReset(true);

		//       try {
		// 	 txnResource.performDefaultReset();
		//       }
		//       finally {
		// 	 setInReset(false);
		//       }

		//      setInReset(false);

		return;
	}

	/**
	 * This method is called by the business object transaction
	 * resource as a result of receiving the prepare() message from the
	 * transaction service. The default behavior for this method is to
	 * save the businessobject. Subclassers can override this method to
	 * return a different vote based on their situation.
	 *  
	 * @return      :int -
	 */
	protected int prepare() {
		if (getBusinessObjectTxnResource().isInvolved() == false) {
			return TransactionService.VOTE_COMMIT;
		}

		if (!isDirty(DIRTY_NO_TRAVERSAL) || isMarkedForDeletion()) {
			return TransactionService.VOTE_READONLY;
		}

		// If the object is by value, then return saying
		// that we committed. Parent is responsible for save.
		if (isByValue()) {
			return TransactionService.VOTE_COMMIT;
		}

		// Obtain the default PID for this business object instance
		PID aPID = getPID();

		if (getPID() == null) {
			aPID = getDefaultPID();
		}

		System.out.println("BO: Calling store() on   :" + this);
		System.out.println(
			"BO: Dirty attributes are :" + getAttributeResetValues() + "\n");

		super.store(aPID);

		return TransactionService.VOTE_COMMIT;
	}

	/**
	 * This method gets called when the BO is involved in a
	 * transaction. When performing a reset, a BO can use the before
	 * image to restore its memory image.
	 * Note: At this time this method is just a place holder. It allways returns null.  
	 * @return      :java.lang.Object -
	 */
	protected java.lang.Object getBeforeImage() {
		return null;
	}

	/**
	 * This code fetches a child (aggregate object from the datastore).
	 * The algorithm works as follows:
	 * <p>
	 * 1) Load a key descriptor of the child by appending the term
	 * KeyDescriptor to the childs class name.
	 * <p>
	 * 2) Create a PID for the class.
	 * <p>
	 * 3) Using introspection, for every attribute (set method) in the
	 * child's key descriptor, locate a matching get method in the
	 * parent. If a set method  is found on the key descriptor, but no
	 * appropriate get was found on the parent, the entity is not
	 * populated. It is assumed to have some default value.
	 * <p>
	 * Later as an improvment, some metadata can be provided to fix up
	 * all the keys.
	 * <p>
	 * 4) Restore the child.
	 * <p>
	 * 5) fix the parent of the child to be this BO.
	 * <p>
	 * Input to the method is the childs class object and a reference
	 * to the child which ofcourse will be null in most of the cases.
	 * The reason for passing a child reference in, is to detect
	 * duplicate fetches and save the client the if logic test. If the
	 * child PO that is passed in is not null and is fetched, the same
	 * reference is returned to caller.
	 * <p>
	 * All the steps are implemented as protected methods allowing the
	 * user to override certain aspects of the fetch process.
	 *  
	 * @param       aChildClass:java.lang.Class
	 * @param      
	 * aChild:COM.novusnet.vision.java.businessobjects.BusinessObject
	 * @return      :COM.novusnet.vision.java.persistence.PO -
	 */
	protected PO fetchChild(Class aChildClass, BusinessObject aChild) {
		//===============================================================//
		// If the child is not null and has been fetched, then bail out  //
		//===============================================================//
		if ((aChild != null) && aChild.isFetched()) {
			return aChild;
		}

		KeyDescriptor myKeyDescriptor = createChildKeyDescriptor(aChildClass);
		PID myPID = createChildPID(aChildClass);
		POFactory myFactory = new POFactory();
		PO myPO = null;

		populateChildKeyDescriptor(aChildClass, myKeyDescriptor);

		try {
			myPID.writeObject(myKeyDescriptor);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to write object to PID");
		}

		myPO = myFactory.create_PO(myPID, null);
		myPO.setPID(myPID);

		return (myPO);
	}

	/**
	 * This method creates a key descriptor by appending the term
	 * "KeyDescriptor" to the class name and instantiating an instance
	 * of the KeyDescriptor.
	 * @param       aClass:java.lang.Class
	 * @return      :COM.novusnet.vision.java.persistence.KeyDescriptor
	 */
	protected KeyDescriptor createChildKeyDescriptor(Class aClass) {
		String className = aClass.getName() + "KeyDescriptor";
		KeyDescriptor myKeyDescriptor = null;

		try {
			myKeyDescriptor =
				(KeyDescriptor) Class.forName(className).newInstance();
		} catch (Throwable anException) {
			throw new RuntimeException(
				"Failed to create a key descriptor for class " + className);
		}

		return myKeyDescriptor;
	}

	/**
	 * This method creates a PID using the registered PID factory.
	 *  
	 * @param       aClass:java.lang.Class
	 * @return      :COM.novusnet.vision.java.persistence.PID -
	 */
	protected PID createChildPID(Class aClass) {
		PID myPID = getDefaultPIDFactory(aClass).create_PID_from_class(aClass);
		myPID.setParentPO(this);
		return (myPID);
	}

	/**
	 * This method populates the child's key descriptor with attributes
	 * of the same name from the parent class (i.e this).
	 * <p>
	 * For each method of the form setXXX(one parameter), find a
	 * matching get in this class. If one is found then call the get
	 * and set it on the key descriptor. If no appropriate getter is
	 * found, then leave the attribute alone. It is very important to
	 * note that the get on the parent and the set on the key
	 * descriptor be of the same type if they get and set the same
	 * attribute name. For example a setAddress(xxx) on a KeyDescriptor
	 * takes an xxx parameter type. The Address() on the parent, say
	 * Account, must return an xxx. No type checking is done for
	 * performance purposes. An exception will be thrown if there is a
	 * mismatch.
	 *  
	 * @param       aClass:java.lang.Class
	 * @param      
	 * aKeyDescriptor:COM.novusnet.vision.java.persistence.KeyDescripto
	 */
	protected void populateChildKeyDescriptor(
		Class aClass,
		KeyDescriptor aKeyDescriptor) {
		Method[] methods = aKeyDescriptor.getClass().getMethods();

		for (int i = 0; i < methods.length; i++) {

			Class parameters[] = methods[i].getParameterTypes();

			if (parameters.length > 1) {
				continue;
			}

			String methodName = methods[i].getName();

			if (methodName.startsWith("set")) {

				String attributeName = methodName.substring(3);
				Method sourceGetMethod = null;
				PO lookinObject = this;

				while ((lookinObject != null) && (sourceGetMethod == null)) {
					try {
						sourceGetMethod =
							lookinObject.getClass().getMethod(
								"get" + attributeName,
								null);
					} catch (NoSuchMethodException e) {
						lookinObject = lookinObject.getParent();
					}
				}

				if (sourceGetMethod == null) {
					continue;
				}

				try {
					Object result = sourceGetMethod.invoke(lookinObject, null);
					Object args[] = { result };
					methods[i].invoke(aKeyDescriptor, args);
				} catch (Throwable e) {
					e.printStackTrace();
					new RuntimeException("Failed to populate key descriptor.");
				}
			}
		}
	}

	/*==================================================================*/
	/* Private Operations                                               */
	/*==================================================================*/

	/**
	 * A private method to recuse into referenced BOs.
	 *  
	 * @param       obj:BusinessObject
	 * @param       result:java.util.Vector
	 * @param       processedBOs:java.util.HashSet
	 */
	private void getDirtyBusinessObjects_worker(
		BusinessObject obj,
		Vector result,
		HashSet processedBOs) {
		// JGL Conversion
		if (processedBOs.contains(obj.getObjectID())) {
			return;
		} else {
			processedBOs.add(obj.getObjectID());
		}

		Iterator itr = obj.getReferencedBusinessObjects();
		BusinessObject referencedBO = null;

		if (obj.isDirty(DIRTY_NO_TRAVERSAL)) {
			result.addElement(obj);
		}

		while (itr.hasNext()) {
			Object obja = itr.next();
			if (obja instanceof BusinessObject) {
				referencedBO = (BusinessObject) obja;
				getDirtyBusinessObjects_worker(
					referencedBO,
					result,
					processedBOs);
			}
		}
	}

	/*==================================================================*/
	/* Class Operations                                                 */
	/*==================================================================*/

	/**
	 * Register the given default PID factory for the application
	 * identified by the specified name.
	 * @param       anApplicationName:java.lang.String
	 *                 the fully qualified application name
	 * @param      aPIDFactory:PIDFactory - the default PID factory
	 */
	public static void registerDefaultPIDFactory(
		String anApplicationName,
		PIDFactory aPIDFactory) {
		defaultPIDFactories.put(anApplicationName, aPIDFactory);
	}

	/**
	 * Deregister the default PID factory for the application
	 * identified by the specified name.
	 *  
	 * @param       anApplicationName:java.lang.String
	 *                 the fully qualified application name
	 */
	public static void deregisterDefaultPIDFactory(String anApplicationName) {
		defaultPIDFactories.remove(anApplicationName);
	}

	/**
	 * This method returns the default PID factory for the application
	 * associated with the specified business object class. PID
	 * factories are registered on a per-application basis and are
	 * identified by the application name portion of the fully
	 * qualified business object class name.
	 * <p>
	 * <b>Notes:</b><p>
	 * This is a static method - there is a related instance
	 * getDefaultPIDFactory method which returns the default PID
	 * factory associated with the business object instance.
	 *  
	 * @param       aClass:java.lang.Class
	 *                 the business object class instance
	 * @return      :COM.novusnet.vision.java.persistence.PIDFactory -
	 */
	public static PIDFactory getDefaultPIDFactory(Class aClass) {
		return (PIDFactory) defaultPIDFactories.get(
			ClassHelper.getApplicationNameFromClass(aClass));

	}

	/**
	 * This method returns the resource string specified by the
	 * resourcekey. A resource class file that matches any of the base
	 * classes of this subclass is looked for. If none were found, an
	 * attempt to load the GENERIC_RESOURCE_CLASSNAME is used.
	 * @param aClass The class object to use as a base for searching.
	 * @param locale The locale to use. If locale is null, the default
	 * locale will be used.
	 * @param resourceKey The resource name to lookup.
	 * @param returnDefault If set to true and the key is not found, a default
	 * message is returned.
	 * @return The message, a default message if key is not found or a
	 * null if a default message could not be loaded for some reason.
	 *  
	 * @see COM.novusnet.vision.java.utility.resources.ResourceResolver
	 *    
	 *  
	 * @param       aClass:java.lang.Class
	 * @param       locale:java.util.Locale
	 * @param       resourceKey:java.lang.String
	 * @param       returnDefault:boolean
	 * @return      :java.lang.String -
	 */
	public static String getStringResource(
		Class aClass,
		Locale locale,
		String resourceKey,
		boolean returnDefault) {
		ResourceResolver aResolver =
			new ResourceResolver(
				"COM.novusnet.vision.java.businessobjects.BusinessObject",
				locale);
		aResolver.setPolicy(ResourceResolver.POLICY_EXACT_CLASS);
		String string = aResolver.getStringResource(resourceKey, aClass);
		if ((string == null) && returnDefault) {
			if (resources == null) {
				String masterResource = null;
				// Create and load the class name
				try {
					masterResource =
						"COM.novusnet.vision.java.locale."
							+ Locale.getDefault().toString()
							+ ".Resources";
					resources =
						(ListResourceBundle) Class
							.forName(masterResource)
							.newInstance();
				} catch (Throwable e) {
					// 	       VisionRuntime.instance ().getDispatcher ().output 
					// 	       (
					// 		VisionRuntime.BUSINESS_OBJECTS, 
					// 		EventDispatcher.NPS_ERROR,
					// 		EventDispatcher.NPS_ERRORCLASS_CONFIGURATION,
					// 		0,
					// 		EventDispatcher.NPS_SUBSYSTEM_VISION,
					// 		"BusinessObject.java", 
					// 		0, 
					// 		"getStringResource",
					// 		"Could not load vision master resource file: " + 
					// 		masterResource
					// 	       );
					//  Use log4J here
					return ("messagenotfound");
				}
			}
			string = resources.getString("messagenotfound") + resourceKey;
		}

		return (string);
	}
}
