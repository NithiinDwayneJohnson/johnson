package COM.novusnet.vision.java.businessobjects;

public class InvalidModelException extends BusinessObjectException {

    public InvalidModelException(String text) {
       super(text);
    }

}

