/*======================================================================*/
/*   | Copyright, 1997, Novus Services, Inc. - All Rights Reserved. |   */
/*======================================================================*/
package COM.novusnet.vision.java.businessobjects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * This subclass uses an ArrayList as its container. The underlying
 * architecture of Arrays makes them ideal for storing elements whose order
 * is significant and where fast numeric indexing is important. 
 * Inserting elements anywhere except at the end of an ArrayList is
 * slow, so they should not be used where this kind of operation is common.
 * @version 1.0, 6-12-1998
 */
public class BusinessObjectIndexedContainer extends BusinessObjectContainer {
	/**
	 * Constructor. This class sets the default collection to be a an ArrayList. 
	 */
	public BusinessObjectIndexedContainer() {
		// JGL Conversion
		setCollection( Collections.synchronizedList(new ArrayList()) );
	}

	/**
	 * Add an object after my last element. Returns null.
	 * @param  object - The object to add. 
	 */
	public Object add(Object anObject) {
		handleTransactionInvolvement();
		// JGL Conversion
		getCollection().add(anObject);
		int index = getSize();
		((BusinessObject) anObject).setParentContainer(this);
		fireIntervalAdded(this, index - 1, index - 1);
		return anObject;
	}

	/**
	 * Combine the contents of one BusinessObject container with
	 * another. Duplicate semantics depend on the type of the
	 * container.
	 * <p>
	 * This class simply copies the source container contents into the
	 * target container.
	 *  
	 * @param       container:BusinessObjectContainer
	 */
	public void combine(BusinessObjectContainer container) {

		synchronized (getCollection()) {
			Iterator itr = container.elements();

			while (itr.hasNext()) {
				BusinessObject aBO = (BusinessObject) itr.next();
				this.add(aBO);
			}
		}

		if (container.getSize() > 0) {
			fireContentsChanged(this, -1, -1);
		}
	}

	/**
	 * Return the index of the first object that matches a particular
	 * value, or -1 if the object is not found. 
	 * @param  object - The object to find. 
	 * @return      :int -
	 */
	public int indexOf(Object object) {
		return ((List)getCollection()).indexOf(object);
	}

	/**
	 * Return true if this collection contain a particular object. 
	 * @param  object - The object in question. 
	 * @return :boolean
	 */
	public boolean contains(Object object) {
		return getCollection().contains(object);
	}

	/**
	 * Replace all elements that match a particular object with a new
	 * value and return the number of objects that were replaced. 
	 * @param  oldValue - The object to be replaced. 
	 * @param  newValue - The value to substitute. 
	 * @return      :int -
	 */
	public synchronized int replace(Object oldValue, Object newValue) {
		int index = 0, count = 0;

		synchronized (getCollection()) {
			Iterator itr = getCollection().iterator();
		
			while (itr.hasNext()) {
				BusinessObject obj = (BusinessObject) itr.next();
				if (obj != null && oldValue != null && obj.equals(oldValue)) 
				{
					// 11-07-2005, index should not increment by one here.
					//((List) getCollection()).set(index++, newValue);
					((List) getCollection()).set(index, newValue);
					count++;
				}
				// 11-07-2005, index has to be incremented by one here
				index ++;
			}
		}

		fireContentsChanged(this, -1, -1);
		((BusinessObject) newValue).setParentContainer(this);

		return count;
	}
	
	
	/**
	 * Replace the Object at the given index in the ArrayList.
	 * @param       index:int
	 * @param       newValue:Object
	 * @return      :int - count
	 * @exception IndexOutOfBoundsException - If the index is invalid. 
	*/
	public synchronized int replace(int index, Object newValue)
	throws IndexOutOfBoundsException 
	{
		int count = 0;
		synchronized (getCollection()) 
		{		
			((List) getCollection()).set(index, newValue);
			count++;
		}
		fireContentsChanged(this, -1, -1);
		((BusinessObject) newValue).setParentContainer(this);

		return count;
	}	
	

	/**
	 * Remove all elements that match a particular object and return
	 * the number of objects that were removed. 
	 * @param object - The object to remove. 
	 * @return int - The number of objects that were removed. 
	 */
	public int remove(Object object) {
		int count = 0;
		
		// 10-07-2005, put this back since original indexed container has this.
		handleTransactionInvolvement();
				
		synchronized (getCollection()) {
			ListIterator itr = ((List) getCollection()).listIterator();
		
			while (itr.hasNext()) {
				BusinessObject obj = (BusinessObject) itr.next();
				if (obj != null && object != null && obj.equals(object)) {
					itr.remove();
					obj.Delete(null);
					count++;
				}
			}			
		}
		return count;
	}

	/**
	 * Set the element at the specified index to a particular object. 
	 * @param  index - The index. 
	 * @param  object - The object. 
	 */
	public synchronized void put(int index, Object object) {
		handleTransactionInvolvement();

		((List) getCollection()).set(index, object);
		fireIntervalAdded(this, index, index);
		((BusinessObject) object).setParentContainer(this);
	}

	/**
	 * Return the Object at the given index in the ArrayList.
	 * @param       index:int
	 * @return      :Object -
	 * @exception IndexOutOfBoundsException - If the index is invalid. 
	 */
	public synchronized Object getElementAt(int index)
		throws IndexOutOfBoundsException {
		return ((List) getCollection()).get(index);
	}

	/**
	 * Return the first item. 
	 * @exception InvalidOperationException If the ArrayList is empty. 
	 * @return      :Object -
	 */
	public synchronized Object front() {
		return ((List) getCollection()).get(0);
	}

	/**
	 * Return the last item. 
	 * @exception InvalidOperationException If the ArrayList is empty.
	 * @return      :Object -
	 */
	public synchronized Object back() {
		return ((List) getCollection()).get(getCollection().size()-1);
	}

	/**
	 * Return the number of objects that match a particular object. 
	 * @param  object - The object to count. 
	 * @param       key:Object
	 * @return      :int -
	 */
	public int count(Object object) {
		int count = 0;

		synchronized (getCollection()) {
			ListIterator itr = ((List) getCollection()).listIterator();
		
			while (itr.hasNext()) {
				BusinessObject obj = (BusinessObject) itr.next();
				if (obj != null && object != null && obj.equals(object)) {
					count++;
				}
			}
		}

		return count;
	}

	/**
	 * Remove the element at a particular index. 
	 * @param  index - The index of the element to remove. 
	 * @return  :Object - The object removed. 
	 * @exception IndexOutOfBoundsException - If the index is invalid. 
	 */
	public Object remove(int index) throws IndexOutOfBoundsException {
		handleTransactionInvolvement();
		BusinessObject myBO = (BusinessObject) getElementAt(index);
		myBO.Delete(null);
		return myBO;
	}

	/**
	 * Removes an object from a given collection. This allows keyed
	 * containers to remove elements using an object value and not a
	 * key like they normally require.
	 * @param       aValue:Object
	 */
	public void removeValue(Object aValue) {
		((BusinessObject) aValue).setParentContainer(null);
		//remove(aValue);
		// 10-07-2005
		// Should remove an object from the collection, refer to original indexed container.
		if ( indexOf(aValue) >= 0 )
		{
			((List)getCollection()).remove(indexOf(aValue));
		}
		else
		{
		}
		
		fireContentsChanged(this, -1, -1);
	}

	/**
	 * Returns the index of a value. For keyed containers, the
	 * traversal is sequential by keys.
	 *  
	 * @param       aValue:Object
	 * @return      :int -
	 */
	public int getIndexOfValue(Object aValue) {
		return indexOf(aValue);
	}

	/**
	 * Inserts an element at the specified index .
	 * @param  index - The index. 
	 * @param  object - The object. 
	 */
	public synchronized void insertElementAt(int index, Object object) {
		handleTransactionInvolvement();
		if (getCollection().size() == 0) {
			((List) getCollection()).add(object);
		} else {
			// 11-18-2005, insertElement should use add not set.
			// set would overwrite the record already there.
			//((List) getCollection()).set(index, object);
			((List) getCollection()).add(index, object);
		} 
		fireIntervalAdded(this, index, index);
		((BusinessObject) object).setParentContainer(this);
	}
}
