package COM.novusnet.vision.java.businessobjects;

import java.beans.PropertyChangeListener;


public interface ModelInterface {

    /**
    Adds a property change listener to the list of listeners. Used by
    objects that are interested in events fiered by this object.
    */
    public void addPropertyChangeListener(PropertyChangeListener aListener);

    /**
    Removes the listener from the listener list.
    */
    public void removePropertyChangeListener(PropertyChangeListener aListener);

    /**
    Called by subclasses to fire property change notifications to event
    listeners.
    */
    public void firePropertyChange(String propertyName, Object oldValue, Object newValue);

}

