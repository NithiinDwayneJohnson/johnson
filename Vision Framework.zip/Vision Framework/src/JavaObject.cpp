/************************************************************************/
/* MODULE:      JavaObject.cpp                                          */
/* DESCRIPTION: The implementation of the JavaObject class.             */
/* PURPOSE:     A simple wrapper around the JNI.                        */
/* REFERENCES:  JDK's JNI documentation                                 */
/* AUTHOR:                                                              */
/************************************************************************/ 
#define  JAVAINTERFACE_DLL
#include <JavaInterface.hh>

JavaMachine* JavaObject::iJavaVM = NULL;

/*************************************************************************/
/* NAME: resolveMethodID                                                 */
/*                                                                       */
/* DESCRIPTION: Resolves a Java method ID.                               */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*              char * returnSig     The return type signature.          */
/*************************************************************************/
jmethodID  JavaObject::resolveMethodID(const char * methodName,
                                       const char * paramSig,
                                       const char * returnSig)
{
   char paramsignature[255];

   strcpy(paramsignature , paramSig);
   strcat(paramsignature , returnSig);

   jmethodID   methodID = getVM()->getMethodInterface()->GetMethodID(getClass(),
                                                                     methodName, 
                                                                     paramsignature);
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return(methodID);
}

/*************************************************************************/
/* NAME: CallVoidMethod                                                  */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a void                  */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
void JavaObject::CallVoidMethod(const char * methodName , 
                                const char * paramSig, 
                                ...)
{
   /********************************************************/
   /* Obtain a method ID                                   */
   /********************************************************/
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "V");

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   va_list arglist;
   va_start(arglist, paramSig);

   getVM()->getMethodInterface()->CallVoidMethodV(iJRef , 
                                                methodID,
                                                arglist);

   JavaMachine::handleJavaException(getVM()->getMethodInterface());
   
   return;
}

/*************************************************************************/
/* NAME: CallBooleanMethod                                               */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a boolean               */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jboolean JavaObject::CallBooleanMethod(const char * methodName , 
                                       const char * paramSig, 
                                       ...)
{
   
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "Z");
   jboolean    result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallBooleanMethodV(iJRef , 
                                                            methodID,
                                                            arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;
}
/*************************************************************************/
/* NAME: CallByteMethod                                                  */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a byte                  */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jbyte JavaObject::CallByteMethod(const char * methodName , 
                                 const char * paramSig, 
                                 ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "B");
   jbyte       result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallByteMethodV(iJRef , 
                                                         methodID,
                                                         arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}

/*************************************************************************/
/* NAME: CallCharMethod                                                  */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a char                  */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jchar JavaObject::CallCharMethod(const char * methodName , 
                                 const char * paramSig, 
                                 ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "C");
   jchar       result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallCharMethodV(iJRef , 
                                                         methodID,
                                                         arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}

/*************************************************************************/
/* NAME: CallShortMethod                                                 */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a short                 */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jshort JavaObject::CallShortMethod(const char * methodName , 
                                   const char * paramSig, 
                                   ...          )
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "S");
   jshort      result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallShortMethodV(iJRef , 
                                                           methodID,
                                                           arglist);

   JavaMachine::handleJavaException(getVM()->getMethodInterface());
   
   return result;
}

/*************************************************************************/
/* NAME: CallIntMethod                                                   */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns an integer.             */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jint  JavaObject::CallIntMethod(const char * methodName , 
                                const char * paramSig, 
                                ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "I");
   jint        result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallIntMethodV(iJRef , 
                                                         methodID,
                                                         arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}
/*************************************************************************/
/* NAME: CallLongMethod                                                  */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a long.                 */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jlong JavaObject::CallLongMethod(const char * methodName , 
                                 const char * paramSig, 
                                 ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "J");
   jlong       result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallLongMethodV(iJRef , 
                                                          methodID,
                                                          arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}

/*************************************************************************/
/* NAME: CallFloatMethod                                                 */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a float.                */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jfloat   JavaObject::CallFloatMethod(const char * methodName , 
                                     const char * paramSig, 
                                     ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "F");
   jfloat      result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallFloatMethodV(iJRef , 
                                                           methodID,
                                                           arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}

/*************************************************************************/
/* NAME: CallDoubleMethod                                                */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns a double.               */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter          */
/*                                   signatures                          */
/*************************************************************************/
jdouble  JavaObject::CallDoubleMethod(const char * methodName , 
                                      const char * paramSig, 
                                      ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "D");
   jdouble     result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallDoubleMethodV(iJRef , 
                                                            methodID,
                                                            arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;

}

/*************************************************************************/
/* NAME: CallObjectMethod                                                */
/*                                                                       */
/* DESCRIPTION: Calls a java method that returns an object.              */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/* REMARKS:                                                              */
/*              The paramSig must also include the class of the returned */
/*              object.                                                  */
/*************************************************************************/
JavaObject JavaObject::CallObjectMethod(const char * methodName , 
                                         const char * paramSig, 
                                         ...)
{
   jmethodID   methodID = resolveMethodID(methodName , 
                                          paramSig,
                                          "");

   jobject     result;

   /********************************************************/
   /* Call the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = getVM()->getMethodInterface()->CallObjectMethodV(iJRef , 
                                                            methodID,
                                                            arglist);
   
   JavaMachine::handleJavaException(getVM()->getMethodInterface());

   return result;
}

/*************************************************************************/
/* NAME: JavaObject                                                      */
/*                                                                       */
/* DESCRIPTION: This is the contructor by a class name. It creates a     */
/*              Java object (invoking its default constructor)           */
/*                                                                       */
/*************************************************************************/
JavaObject::JavaObject(const char * aClassName)
{
   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/ 
   iClass  = getVM()->resolveClassName(aClassName);
   
   /******************************************************************/
   /* Ask the Class object to create a new instance that invokes the */
   /* default constructor.                                           */
   /******************************************************************/
   
   jmethodID   methodID = getVM()->getMethodInterface()->GetMethodID(iClass, 
                                           "<init>", 
                                           "()V");

   JavaMachine::handleJavaException(getVM()->getMethodInterface());
   
   iJRef = getVM()->getMethodInterface()->NewObject(iClass , methodID);

   getVM()->addReference(iJRef);
   //   getVM()->addReference(iClass);

   JavaMachine::handleJavaException(getVM()->getMethodInterface());
   JavaMachine::handleJavaException(getVM()->getMethodInterface());   
}
/*************************************************************************/
/* NAME: JavaObject                                                      */
/*                                                                       */
/* DESCRIPTION: A constructor from an object reference.                  */
/* PARAMETERS:  jref   java object reference                             */
/*************************************************************************/
JavaObject::JavaObject(jobject aJRef)
{
   iJRef  = aJRef;   
   iClass = 0;
   getVM()->addReference(iJRef);
}
/*************************************************************************/
/* NAME: ~JavaObject                                                     */
/*                                                                       */
/* DESCRIPTION: destructor. Deletes the global reference.                */
/*                                                                       */
/*************************************************************************/
JavaObject::~JavaObject()
{
   iJRef  = 0;
   iClass = 0;
}
/*************************************************************************/
/* NAME: JavaObject                                                      */
/*                                                                       */
/* DESCRIPTION: Copy constructor. Creates a new global reference to the  */
/*              same object instance.                                    */
/*                                                                       */
/* PARAMETERS:  JavaObject&          Reference to copy construct from.   */
/*************************************************************************/
JavaObject::JavaObject(const JavaObject& aJavaClass)
{  
   iJRef  = aJavaClass.iJRef;
   iClass = 0;
}
/*************************************************************************/
/* NAME: operator =                                                      */
/*                                                                       */
/* DESCRIPTION: Assignment operator. Deletes the global reference before */
/*              performing the assignment.                               */
/*                                                                       */
/* PARAMETERS:  JavaObject&          Reference to copy from.             */
/*************************************************************************/
void JavaObject::operator= (const JavaObject& aJavaClass)
{
   iJRef  = aJavaClass.iJRef;
   iClass = 0;
}






