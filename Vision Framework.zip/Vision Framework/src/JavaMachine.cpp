/************************************************************************/
/* MODULE:      JavaMachine.cpp                                         */
/* DESCRIPTION: The implementation of the JavaMachine class.            */
/* PURPOSE:     A simple wrapper around the JNI.                        */
/* REFERENCES:  JDK's JNI documentation                                 */
/* AUTHOR:                                                              */
/************************************************************************/ 


   /************************************************************************/
   /*                                  Include files                       */
   /************************************************************************/

#define  JAVAINTERFACE_DLL
#include <JavaInterface.hh>


jint JNICALL myvfprintf(FILE *fp, const char *format, va_list args)
{
   char buf[2048];

   _vsnprintf(buf, sizeof(buf), format, args);
   return(0);
}
    
/*************************************************************************/
/* NAME: JavaVM                                                          */
/*                                                                       */
/* DESCRIPTION: The constructor. This method initializes the VM if none  */
/*              already exist or attaches to the exiting VM.             */
/*************************************************************************/ 
JavaMachine::JavaMachine()
{
   JDK1_1InitArgs vm_args;            // VM initialization arguments
   jsize          returned = 0;
   
   
   JNI_GetCreatedJavaVMs(&jvm, 1, &returned);

   if (returned == 0) {

      /**************************************************/
      /* The default arguments are usually good enough. */
      /**************************************************/

      JNI_GetDefaultJavaVMInitArgs(&vm_args);

      /**************************************************/
      /* Must specify a class path or it won't work     */
      /**************************************************/

      vm_args.classpath   = getenv("CLASSPATH");
      vm_args.maxHeapSize = 64000000;
      //vm_args.minHeapSize = 64000000;
      //vm_args.vfprintf    = myvfprintf;

      //vm_args.enableClassGC   = 0; 
      //vm_args.enableVerboseGC = 1;    
      //vm_args.disableAsyncGC  = 1;

      if (vm_args.classpath == 0) {
        throw JavaException("No class path specified");
      }

      /*************************************************************/
      /* load and initialize a Java VM, return a native method     */
      /* interface pointer in env.                                 */
      /*************************************************************/
   
      if (JNI_CreateJavaVM(&jvm, &env, &vm_args) < 0) {
	cout << "Failed to create needed VM" << endl;
         throw JavaException("Failed to create the need Java VM");
      }
   } 
   else {
      jvm->AttachCurrentThread(&env , 0);      
   }
}

/*************************************************************************/
/* NAME: ~JavaVM                                                         */
/*                                                                       */
/* DESCRIPTION: The destructor zaps the VM                               */
/*************************************************************************/  
JavaMachine::~JavaMachine()
{
   jvm->DestroyJavaVM();
}
/*************************************************************************/
/* NAME: resolveStaticMethodID                                           */
/*                                                                       */
/* DESCRIPTION: Returns the method ID of a method within a given class.  */
/*                                                                       */
/* PARAMETERS:  jclass aClass        The class object                    */
/*              char*  methodName    The method name                     */
/*              char*  parmSig       Parameter signature.                */
/*              char*  returnSig     The return signature.               */
/*************************************************************************/  
jmethodID  JavaMachine::resolveStaticMethodID(jclass       aClass,
                                              const char * methodName,
                                              const char * paramSig,
                                              const char * returnSig)
{
   char paramsignature[255];

   strcpy(paramsignature , paramSig);
   strcat(paramsignature , returnSig);

   jmethodID   methodID = env->GetStaticMethodID(aClass, methodName, paramsignature);

   handleJavaException(env);

   return(methodID);
}

/*************************************************************************/
/* NAME: resolveStaticFieldID                                            */
/*                                                                       */
/* DESCRIPTION: Returns the field ID of a field within a given class.    */
/*                                                                       */ 
/* PARAMETERS:  jclass aClass        The class object                    */
/*              char*  fieldName     The field name                      */
/*              char*  parmSig       The type of the parameter           */
/*************************************************************************/ 
jfieldID   JavaMachine::resolveStaticFieldID(jclass       aClass,
                                             const char * fieldName,
                                             const char * paramSig)
{
   jfieldID fieldID = env->GetStaticFieldID(aClass, fieldName, paramSig);

   handleJavaException(env);

   return(fieldID);
}
      
/*************************************************************************/
/* NAME: resolveClassName                                                */
/*                                                                       */
/* DESCRIPTION: Returns the class object associated with a class name.   */
/*                                                                       */
/* PARAMETERS:  char * className     The class name                      */
/*************************************************************************/  
jclass JavaMachine::resolveClassName(const char* aClassName)
                                          
{
   jclass   cls = env->FindClass(aClassName);

   handleJavaException(env);

   return(cls);
}
/*************************************************************************/
/* NAME: GetStaticBooleanField                                           */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a boolean.      */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/  
jboolean JavaMachine::GetStaticBooleanField (const char * className , 
                                             const char * fieldName)
{
   jboolean   result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "Z");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticBooleanField(cls , fieldID);

   handleJavaException(env);                                              
   
   return(result);

}
/*************************************************************************/
/* NAME: GetStaticByteField                                              */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a byte.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/  
jbyte JavaMachine::GetStaticByteField (const char * className , 
                                   const char * fieldName)
{
   jbyte result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "B");

   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticByteField(cls , fieldID);

   handleJavaException(env);                                              

   return(result);

}
/*************************************************************************/
/* NAME: GetStaticCharField                                              */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a char.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/ 
jchar JavaMachine::GetStaticCharField (const char * className , 
                                   const char * fieldName)
{
   jchar result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "C");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticCharField(cls , fieldID);

   handleJavaException(env);
   
   return(result);
}

/*************************************************************************/
/* NAME: GetStaticShortField                                             */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a short.        */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/ 
jshort JavaMachine::GetStaticShortField (const char * className , 
                                     const char * fieldName)
{
   jshort result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "S");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticShortField(cls , fieldID);

   handleJavaException(env);
   
   return(result);

}
/*************************************************************************/
/* NAME: GetStaticIntField                                               */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is an int.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/ 
jint JavaMachine::GetStaticIntField (const char * className , 
                                 const char * fieldName)
{
   jint result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "I");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticIntField(cls , fieldID);

   handleJavaException(env);
      
   return(result);
}

/*************************************************************************/
/* NAME: GetStaticLongField                                              */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a long.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/ 
jlong JavaMachine::GetStaticLongField (const char * className , 
                                   const char * fieldName)
{
   jlong result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "L");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticLongField(cls , fieldID);

   handleJavaException(env);
      
   return(result);

}
/*************************************************************************/
/* NAME: GetStaticFloatField                                             */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a float.        */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */ 
/*************************************************************************/  
jfloat JavaMachine::GetStaticFloatField (const char * className , 
                                     const char * fieldName)
{
   jfloat result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "F");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticFloatField(cls , fieldID);

   handleJavaException(env);
   
   return(result);
}
/*************************************************************************/
/* NAME: GetStaticDoubleField                                            */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is a double.       */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */
/*************************************************************************/
jdouble JavaMachine::GetStaticDoubleField (const char * className , 
                                       const char * fieldName)
{
   jdouble result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls , fieldName , "D");
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticDoubleField(cls , fieldID);

   handleJavaException(env);
   
   return(result);
}

/*************************************************************************/
/* NAME: GetStaticObject                                                 */
/*                                                                       */
/* DESCRIPTION: Returns the class variable whose type is an object.      */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * fieldName     Static field name                   */
/*              char * classType     The object type.                    */
/*************************************************************************/
JavaObject JavaMachine::GetStaticObjectField  (const char * className , 
                                               const char * fieldName, 
                                               const char * classType)
{
   jobject  result;

   /******************************************************************/
   /* load the Class object of the supplied class                    */
   /******************************************************************/
   
   jclass     cls = resolveClassName(className);

   /********************************************************/
   /* Obtain a field ID                                    */
   /********************************************************/
   jfieldID fieldID = resolveStaticFieldID(cls, fieldName , classType);
   
   /********************************************************/
   /* Get the value                                        */
   /********************************************************/
            
   result = env->GetStaticObjectField(cls , fieldID);

   handleJavaException(env);
   
   /*****************************************************************/  
   /* We must create a global reference to the newly created object */
   /* otherwise the GC will zap it from undeneath us.               */
   /*****************************************************************/
   
   jref  hgref = env->NewGlobalRef(result);

   /*****************************************************************/
   /* Create a JavaObject Object on the heap.                      */  
   /*****************************************************************/

   return ( JavaObject(hgref) );
}

/*************************************************************************/
/* NAME: CallStaticVoidMethod                                            */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a void.          */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
void JavaMachine::CallStaticVoidMethod(const char * className , 
                                   const char * methodName , 
                                   const char * paramSig, 
                                   ...)
{
   jclass      aClass = resolveClassName(className);

   /********************************************************/
   /* Obtain a method ID                                   */
   /********************************************************/
   
   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "V");

   /********************************************************/
   /* CallStatic the method                                */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   env->CallStaticVoidMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   return;
}

/*************************************************************************/
/* NAME: CallStaticBooleanMethod                                         */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a boolean.       */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jboolean JavaMachine::CallStaticBooleanMethod(const char * className , 
                                          const char * methodName , 
                                          const char * paramSig, 
                                          ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "Z");
   jboolean    result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticBooleanMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   return result;
}
/*************************************************************************/
/* NAME: CallStaticByteMethod                                            */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a byte.          */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jbyte JavaMachine::CallStaticByteMethod(const char * className , 
                                    const char * methodName ,  
                                    const char * paramSig, 
                                    ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "B");
   jbyte       result;

   /********************************************************/
   /* CallStatic the method                                */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticByteMethodV(aClass,methodID, arglist);

   handleJavaException(env);
      
   return result;

}
/*************************************************************************/
/* NAME: CallStaticCharMethod                                            */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a char.          */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jchar JavaMachine::CallStaticCharMethod(const char * className , 
                                        const char * methodName , 
                                        const char * paramSig, 
                                        ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "C");
   jchar       result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticCharMethodV(aClass, methodID, arglist);

   handleJavaException(env);
   
   return result;

}
/*************************************************************************/
/* NAME: CallStaticShortMethod                                           */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a short.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jshort JavaMachine::CallStaticShortMethod(const char * className , 
                                      const char * methodName , 
                                      const char * paramSig, 
                                      ...          )
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "S");
   jshort      result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticShortMethodV(aClass, methodID, arglist);

   handleJavaException(env);
      
   return result;
}
/*************************************************************************/
/* NAME: CallStaticIntMethod                                             */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns an integer.      */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jint  JavaMachine::CallStaticIntMethod(const char * className , 
                                   const char * methodName , 
                                   const char * paramSig, 
                                   ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "I");
   jint        result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticIntMethodV(aClass, methodID, arglist);

   handleJavaException(env);
   
   return result;

}
/*************************************************************************/
/* NAME: CallStaticLongMethod                                            */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a long.          */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jlong JavaMachine::CallStaticLongMethod(const char * className , 
                                    const char * methodName , 
                                    const char * paramSig, 
                                    ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "J");
   jlong       result;

   /********************************************************/
   /* CallStatic the method                                */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticLongMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   return result;

}
/*************************************************************************/
/* NAME: CallStaticFloatMethod                                           */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a float.         */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jfloat JavaMachine::CallStaticFloatMethod(const char * className , 
                                      const char * methodName , 
                                      const char * paramSig, 
                                      ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "F");

   jfloat      result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticFloatMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   return result;

}
/*************************************************************************/
/* NAME: CallStaticDoubleMethod                                          */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns a double.        */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/*************************************************************************/
jdouble  JavaMachine::CallStaticDoubleMethod(const char * className , 
                                         const char * methodName , 
                                         const char * paramSig, 
                                         ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "D");

   jdouble     result;

   /********************************************************/
   /* CallStatic the method                                      */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticDoubleMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   return result;

}
/*************************************************************************/
/* NAME: CallStaticObjectMethod                                          */
/*                                                                       */
/* DESCRIPTION: Calls a static java method that returns an object.       */
/*                                                                       */
/* PARAMETERS:  char * methodName    The method name                     */
/*              char * paramSig      Parameter signature. Refer to JNI   */
/*                                   for more info on parameter signaturs*/
/* REMARKS:                                                              */
/*              The paramSig must also include the class of the returned */
/*              object.                                                  */
/*************************************************************************/
JavaObject JavaMachine::CallStaticObjectMethod(const char * className , 
                                            const char * methodName , 
                                            const char * paramSig, 
                                            ...)
{
   jclass      aClass = resolveClassName(className);

   jmethodID   methodID = resolveStaticMethodID(aClass,
                                                methodName , 
                                                paramSig,
                                                "");

   jobject     result;

   /********************************************************/
   /* CallStatic the method                                */
   /********************************************************/
   
   va_list arglist;
   va_start(arglist, paramSig);
          
   result = env->CallStaticObjectMethodV(aClass,methodID, arglist);

   handleJavaException(env);
   
   /*****************************************************************/  
   /* We must create a global reference to the newly created object */
   /* otherwise the GC will zap it from undeneath us.               */
   /*****************************************************************/
   
   jref  hgref = env->NewGlobalRef(result);

   /*****************************************************************/
   /* Create a JavaObject Object on the heap.                      */  
   /*****************************************************************/

   return ( JavaObject(hgref) );
}

