// pushConsumer.C

#include "CosEventComm_s.hh"
#include "CosEventChannelAdmin_c.hh"

class PushConsumerImpl : public _sk_CosEventComm::_sk_PushConsumer {
public:
  void push(const CORBA::Any& any) {
    char* string;
    if(any >>= string) {
      cout << string << endl;
    }
    else {
      cout << "Non string: " << any << endl;
    }
  }

  void disconnect_push_consumer() {
    cout << "disconnect_push_consumer()" << endl;
    _boa()->exit_impl_ready();
  }
};

int
main(int argc, char* const* argv)
{
  try {
    CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
    CORBA::BOA_var boa = orb->BOA_init(argc, argv);
    boa->scope(CORBA::BOA::SCOPE_LOCAL);
    PushConsumerImpl pushConsumer;
    boa->obj_is_ready(&pushConsumer);
    CosEventChannelAdmin::EventChannel_var channel = 
      CosEventChannelAdmin::EventChannel::_bind();
    CosEventChannelAdmin::ConsumerAdmin_var for_consumer = 
      channel->for_consumers();
    CosEventChannelAdmin::ProxyPushSupplier_var pushSupplier = 
      for_consumer->obtain_push_supplier();
    pushSupplier->connect_push_consumer(&pushConsumer);
    boa->impl_is_ready();
  }
  catch(const CORBA::Exception& e) {
    cout << "Failure: " << e << endl;
  }
  return 0;
}
