// pushSupplier.C

#include "CosEventComm_s.hh"
#include "CosEventChannelAdmin_c.hh"
#include "VisionEvent_c.hh"
#include "ExampleEmbeddedClass_c.hh"

class PushSupplierImpl : public _sk_CosEventComm::_sk_PushSupplier 
{

private:
       CORBA::ORB_var orb;
       CosEventChannelAdmin::ProxyPushConsumer_var pushConsumer ; 
public:
  void disconnect_push_supplier() {
    cout << "disconnect_push_supplier()" << endl;
  }

  PushSupplierImpl(const char* objName=NULL) :
    _sk_CosEventComm::_sk_PushSupplier(objName)
  {
     try {
       orb = CORBA::ORB_init();
       CORBA::BOA_var boa = orb->BOA_init();
       boa->scope(CORBA::BOA::SCOPE_LOCAL);
       boa->obj_is_ready(this);
       CosEventChannelAdmin::EventChannel_var channel = 
         CosEventChannelAdmin::EventChannel::_bind();
       CosEventChannelAdmin::SupplierAdmin_var for_supplier = 
         channel->for_suppliers();
       pushConsumer = for_supplier->obtain_push_consumer();
       pushConsumer->connect_push_supplier(this);
   
    }
     catch(const CORBA::Exception& e) {
       cout << "Failure: " << e << endl;
     }
  }

  void sendVisionEvent(  int    eventID,
                         char* applID,
                         char* userID,
                         char* centerID,
                         CORBA::Any anyObject )
  {
     COM::novusnet::vision::java::eventservice::VisionEvent ve;
     ve.eventID   = eventID;
     ve.applID    = CORBA::String_var(applID) ;
     ve.userID    = userID ;
     ve.centerID  = centerID;
     ve.anyObject = anyObject;
     try {
        CORBA::Any message;
        message <<= ve;
        pushConsumer->push(message);
     } catch(const CORBA::Exception& e) {
       cout << "Failure in sendEvent: " << e << endl;
     }
  }
};

int
main(int argc, char* const* argv)
{
   PushSupplierImpl supplier("Parag");
   char junk[128];
   cout << "PushSupplierImpl ready. q to quit, <- Enter to send next event.\n";
   for( int i = 0; cin >> junk ; i++ )
   {
      ExampleEmbeddedClass parag;
      parag.i = i * 10;
      parag.j = i * 13.17;
      parag.k = "Parag";

      CORBA::Any anyObject;
      anyObject <<= parag;

      supplier.sendVisionEvent(i, "PCSOLAR", "PARAG", "HQ", anyObject);
      cout << "PushSupplierImpl sending out event number: " << i << endl;
   }
   return 0;
}
