/************************************************************************/
/* MODULE:      JavaMachine.hpp                                         */
/* DESCRIPTION: The interface of the JavaMachine class.                 */
/* PURPOSE:     A simple wrapper around the JNI.                        */
/* REFERENCES:  JDK's JNI documentation                                 */
/* AUTHOR:                                                              */
/************************************************************************/ 
#ifndef  _JAVAMACHINE
#define  _JAVAMACHINE_

// Will be declared later
class FUNC_DECL JavaObject;                    

/************************************************************************/
/* CLASS:       JavaMachine                                             */
/*                                                                      */
/* PURPOSE: This class represents a Java virtual machine. The main      */
/*          responsibility for this class is to isolate the caller from */
/*          JNI. Its main functions are: Initialization, static method  */
/*          invocations and exception handling.                         */
/*                                                                      */
/************************************************************************/
class FUNC_DECL JavaMachine
{
   /***********************************************************/
   /*                     Privates                            */
   /***********************************************************/
   private:

   JavaVM   *jvm;                // denotes a Java VM
   JNIEnv   *env;                // pointer to native method interface
   
   CArray<jobject , jobject> referenceArray;
               
               /*********************************************/
               /* Disallow assignment and copy constructors */
               /*********************************************/
      JavaMachine(const JavaMachine &);
      void operator= (const JavaMachine&);

               /*********************************************/
               /* Exception handler                         */
               /*********************************************/
      
      static void handleJavaException(JNIEnv *anEnv) 
      {
	 if (anEnv) {
	    if (anEnv->ExceptionOccurred()) {

	       /******************************************************/
	       /* Throw a C++ exception and clear the JAVA one.      */
	       /******************************************************/

	       anEnv->ExceptionDescribe();
	       anEnv->ExceptionClear();
	       throw JavaException();
	    }
         }
      }

   /***********************************************************/
   /*                     Publics                             */
   /***********************************************************/
   
   public:

   /************************************/
   /* Constructors / Destructors       */
   /************************************/
   JavaMachine();
   ~JavaMachine();
   
   void AttachCurrentThread() { jvm->AttachCurrentThread(&env, 0); }
   void DetachCurrentThread() { jvm->DetachCurrentThread(); }
   void Destroy()             { jvm->DestroyJavaVM      (); deleteReferences();}

   void addReference(jobject anObject) 
   { 
      referenceArray.Add(anObject); 
   }

   void deleteReferences()
   {   
      for (int i = 0; i < referenceArray.GetSize(); i++) {
	 
	 jobject anObject = referenceArray.GetAt(i);
	 
	 if ( ((unsigned long)anObject) > 0xFFFF) {
	    getMethodInterface()->DeleteGlobalRef(anObject);
	    handleJavaException(getMethodInterface());	    
	 } else {
	    getMethodInterface()->DeleteLocalRef(anObject); 
	    handleJavaException(getMethodInterface());
	 }
      } 
      referenceArray.RemoveAll();
   }

               /************************************/
               /* setters/getters                  */
               /************************************/
      JNIEnv*  getMethodInterface() const      {   return env;      }

               /************************************/
               /* resolver methods                 */
               /************************************/
      
      jmethodID  resolveStaticMethodID(jclass       aClass,
                                       const char * methodName,
                                       const char * paramSig,
                                       const char * returnSig);

      jfieldID   resolveStaticFieldID(jclass       aClass,
                                      const char * fieldName,
                                      const char * paramSig);
                                     

      jclass     resolveClassName(const char * className);
                                        
               /************************************/
               /* Object creation methods          */
               /************************************/

      JavaObject  newClassInstance(const char * aClassName);

               /************************************/
               /* Static method invocation         */
               /************************************/

      void     CallStaticVoidMethod (const char * className , 
                                     const char * methodName , 
                                     const char * methodSig,
                                     ...);

      jboolean CallStaticBooleanMethod (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);
      
      jbyte    CallStaticByteMethod (const char * className , 
                                     const char * methodName , 
                                     const char * methodSig,
                                     ...);

      jchar    CallStaticCharMethod (const char * className , 
                                     const char * methodName , 
                                     const char * methodSig,
                                     ...);

      jshort   CallStaticShortMethod   (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);
      
      jint     CallStaticIntMethod     (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);

      jlong    CallStaticLongMethod    (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);

      jfloat   CallStaticFloatMethod   (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);

      jdouble  CallStaticDoubleMethod  (const char * className , 
                                        const char * methodName , 
                                        const char * methodSig,
                                        ...);

      JavaObject  CallStaticObjectMethod  (const char * className , 
                                            const char * methodName , 
                                            const char * methodSig,
                                           ...);

               /************************************/
               /* Field accessor methods. static   */
               /************************************/
                        
      jboolean     GetStaticBooleanField (const char * className , 
                                          const char * FieldName);

      jbyte        GetStaticByteField    (const char * className , 
                                          const char * FieldName); 

      jchar        GetStaticCharField    (const char * className , 
                                          const char * FieldName);

      jshort       GetStaticShortField   (const char * className , 
                                          const char * FieldName); 

      jint         GetStaticIntField     (const char * className , 
                                          const char * FieldName);

      jlong        GetStaticLongField    (const char * className , 
                                          const char * FieldName);

      jfloat       GetStaticFloatField   (const char * className , 
                                          const char * FieldName);

      jdouble      GetStaticDoubleField  (const char * className , 
                                          const char * FieldName);


      JavaObject GetStaticObjectField  (const char * className , 
                                          const char * FieldName, 
                                          const char * classType);
      friend class JavaObject;
};
#endif
