#ifndef _JAVAINTERFACE
#define _JAVAINTERFACE

#include <jni.h>                   
#include <stdlib.h>   
#include  "afx.h"            
#include  "afxtempl.h"
#include <windows.h>
#include <string.h> 
#include <iostream.h>

#ifdef _WIN32
   #ifdef JAVAINTERFACE_DLL
      #define FUNC_DECL __declspec(dllexport)
   #else 
      #define FUNC_DECL __declspec(dllimport)
   #endif 
#else
   #define FUNC_DECL 
#endif


class FUNC_DECL JavaException
{
   private:
      char * text;
   
   public:   
      JavaException()              { text = "Unknown";  }      
      JavaException(char * string) { text = string;     }
      char * getText()             { return (text);     } 
};


#include <JavaMachine.hh>
#include <JavaObject.hh>

#endif









