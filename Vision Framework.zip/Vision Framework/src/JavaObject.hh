/************************************************************************/
/* MODULE:      JavaObject.hpp                                          */
/* DESCRIPTION: The interface of the JavaObject class.                  */
/* PURPOSE:     A simple wrapper around the JNI.                        */
/* REFERENCES:  JDK's JNI documentation                                 */
/* AUTHOR:                                                              */
/************************************************************************/

/************************************************************************/
/* CLASS:       JavaObject                                              */
/*                                                                      */
/* PURPOSE: This class represents a Java class instance. The main       */
/*          responsibility for this class is to isolate the caller from */
/*          JNI. Its main functions are: method invocations, and        */
/*          reference maintenance.                                      */
/*                                                                      */
/* REMARKS: There is no support for direct field access.                */
/*                                                                      */
/*                                                                      */
/************************************************************************/
class FUNC_DECL JavaObject
{
   /***********************************************************/
   /*                     Privates                            */
   /***********************************************************/
   private:
  
   static      JavaMachine* iJavaVM;       // Reference to the creating JAVA VM
   jobject     iJRef;                      // JAVA reference to jclass
   jclass      iClass;                     // Reference to class object

   jfieldID    resolveFieldID(const char * fieldName,
                              const char * fieldType);
   
   jmethodID   resolveMethodID(const char * methodName,
                               const char * paramSig,
                               const char * returnSig);
                    
   /***********************************************************/
   /*                     Publics                             */
   /***********************************************************/
   
   public:

      static JavaMachine* getVM() 
      {
	 if (iJavaVM == NULL) {
	    iJavaVM = new JavaMachine();
	 }
	 return iJavaVM;
      }

               /************************************/
               /* Constructors / Destructors       */
               /************************************/

      JavaObject(const char * className);   
      JavaObject(jobject  aJRef);
      JavaObject(const JavaObject& aJavaClass);
      ~JavaObject();
      
               /************************************/
               /* Overload the assignment op       */
               /************************************/
      void operator= (const JavaObject& aJavaClass);

               /************************************/
               /* getter on java reference         */
               /************************************/
      jref    jreference() { return iJRef; }

      jclass  getClass()   
      {
	 if (iClass == 0 ) {
	    iClass = getVM()->getMethodInterface()->GetObjectClass(iJRef);  
	    //getVM()->addReference(iClass);
	 }
	 return iClass;	
      }

               /************************************/
               /* Dynamic method invocation        */
               /************************************/

      void     CallVoidMethod    (const char * methodName , 
                                  const char * methodSig,
                                  ...);
                                 
      jboolean CallBooleanMethod (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jbyte    CallByteMethod    (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jchar    CallCharMethod    (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jshort   CallShortMethod   (const char * methodName , 
                                  const char * methodSig,
                                  ...);
      
      jint     CallIntMethod     (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jlong    CallLongMethod    (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jfloat   CallFloatMethod   (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      jdouble  CallDoubleMethod  (const char * methodName , 
                                  const char * methodSig,
                                  ...);

      JavaObject  CallObjectMethod  (const char * methodName , 
                                      const char * methodSig,
                                     ...);
};

/*******************************************************************/
/* This inline converts a C-String to a Java object of class String*/
/*******************************************************************/
class FUNC_DECL JavaString
{
   private:  
   jref         iJRef;                      // JAVA reference to jclass
   const char * iString;

   public:

   JavaString(const char * aString)
   {
      iJRef = JavaObject::getVM()->getMethodInterface()->NewStringUTF(aString);
      iString = aString;
   }

   ~JavaString()
   {
      JavaObject::getVM()->getMethodInterface()->DeleteLocalRef(iJRef); 
   }

   operator jstring() { return (jstring) iJRef; }
};




























